package com.walmart.international.wallet.payment.app.controller.impl.kafka;

import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PBChargeKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.refund.PBReverseKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.service.KafkaService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/kafka")
@Tag(name = "KafkaController API", description = "APIs to perform Kafka related activities.")
public class KafkaController {

    @Autowired
    private KafkaService kafkaService;

    @PostMapping("/pb/charge")
    public void chargeReconFromPB(@RequestBody PBChargeKafkaResponse kafkaResponse) {
        kafkaService.consumeChargeReconPayload(kafkaResponse);
    }

    @PostMapping("/pb/refund")
    public void refundReconFromPB(@RequestBody PBReverseKafkaResponse kafkaResponse) {
        kafkaService.consumeRefundReconPayload(kafkaResponse);
    }

}
