package com.walmart.international.wallet.payment.app.controller.impl.billpay.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.billpay.migration.MigrationBillPaymentController;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillPaymentService;
import com.walmart.international.wallet.payment.dto.request.migration.CancelPayBillInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchBillPayPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.PayInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeInitRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelPayBillInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchBillPayPaymentInstrumentsResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.ValidateChargeInitResponseEWS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class MigrationBillPaymentControllerImpl implements MigrationBillPaymentController {

    @Autowired
    private MigrationBillPaymentService migrationBillPaymentService;

    @Override
    @Metered(level1 = "Payment", level2 = "fetchBillPayPaymentInstruments", level3 = "All", metricName = "CASHI_TRANSACTION")
    public FetchBillPayPaymentInstrumentsResponseEWS migrationFetchBillPayPaymentInstruments(UUID customerAccountId, FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillPaymentService.fetchBillPayPaymentInstruments(customerAccountId, fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public FetchPaymentOptionsWithPreselectionResponse migrationFetchBillPayPaymentInstrumentsWithPreselection(UUID customerAccountId, FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillPaymentService.fetchBillPayPaymentInstrumentsWithPreselection(customerAccountId, fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public PayInitResponseEWS migrationPayBillInit(UUID customerAccountId, PayInitRequestEWS payInitRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillPaymentService.payBillInit(customerAccountId, payInitRequestEWS, headers);
    }

    @Override
    public CancelPayBillInitResponseEWS migrationCancelPaymentInit(UUID customerAccountId, UUID transactionId, CancelPayBillInitRequestEWS cancelPayBillInitRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillPaymentService.cancelPaymentInit(customerAccountId, transactionId, cancelPayBillInitRequestEWS, headers);
    }

    @Override
    public ValidateChargeInitResponseEWS migrationValidateChargeInit(UUID customerAccountId, ValidateChargeInitRequestEWS validateChargeInitRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillPaymentService.validateChargeInit(customerAccountId, validateChargeInitRequestEWS, headers);
    }
}
