package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillInitResponse;
import org.springframework.stereotype.Component;

@Component
public class BillPayTxnDomainResponseBuilder extends BaseDomainResponseBuilder<PayBillInitResponse, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) throws ApplicationException {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public PayBillInitResponse buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) throws ApplicationException {
        return billPayMapper.mapToPayBillInitResponseFromContext(billPayTxnResponseDomainContext);
    }
}
