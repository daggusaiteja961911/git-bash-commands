package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.BillService;
import com.walmart.international.wallet.payment.app.service.impl.mapper.BillDTOMapper;
import com.walmart.international.wallet.payment.core.config.ccm.BillReminderConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.AlreadyPaidRequestContext;
import com.walmart.international.wallet.payment.core.domain.model.request.UpdateCustomerBillDueInfoRequestContext;
import com.walmart.international.wallet.payment.core.domain.model.response.AlreadyPaidResponseContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CustomerBillAccountsByType;
import com.walmart.international.wallet.payment.core.service.BillCoreService;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.data.constant.enums.BillType;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import com.walmart.international.wallet.payment.dto.request.billpay.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.DeleteCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetBillsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetSavedCustomerBillAccountsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountDueInfoRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.DeleteCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillsCustomerBillAccountDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetSavedCustomerBillAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.SavedCustomerBillAccountDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountDueInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.joda.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class BillServiceImpl implements BillService {

    @ManagedConfiguration
    private BillReminderConfiguration billReminderConfiguration;

    @Autowired
    private WalletServiceRouter walletServiceRouter;

    @Autowired
    private BillCoreService billCoreService;

    @Autowired
    private BillerCoreService billerCoreService;

    private BillDTOMapper billDTOMapper = BillDTOMapper.INSTANCE;

    @Override
    public GetBillsResponse getBills(GetBillsRequest getBillsRequest,
                                     MultiValueMap<String, String> headers) throws BusinessValidationException {

        List<BillType> billTypes = new ArrayList<>();
        if (Objects.nonNull(getBillsRequest) && !CollectionUtils.isEmpty(getBillsRequest.getBillType())) {
            getBillsRequest.getBillType().forEach(billType -> billTypes.add(BillType.valueOf(billType.name())));
        } else {
            billTypes.add(BillType.ALL);
        }

        int dueBillsDaysLimit = billReminderConfiguration.getDaysToConsiderBillsAsDueBills();
        int maxDaysForNudge = billReminderConfiguration.getMaxDaysForNudge();
        int minDaysForNudge = billReminderConfiguration.getMinDaysForNudge();
        int count = Objects.nonNull(getBillsRequest) && Objects.nonNull(getBillsRequest.getCount()) ? getBillsRequest.getCount() : Integer.MAX_VALUE;
        count = billTypes.contains(BillType.ALL) ? Integer.MAX_VALUE : count;
        Pageable pageable = PageRequest.of(0, count);

        List<BillerCategory> billerCategoriesList = billerCoreService.getBillerCategoriesList(1);
        HashMap<UUID, UUID> billerIdToBillerCategoryMap = new HashMap<>();
        HashMap<UUID, String> billerIdToBillerCategoryNameMap = new HashMap<>();

        log.info("Fetching bills for customerAccountId : {}", getBillsRequest.getCustomerAccountId());

        CustomerBillAccountsByType customerBillAccountsByType;

        customerBillAccountsByType = billCoreService.getCustomerBillAccountsByType(getBillsRequest.getCustomerAccountId(), billTypes, dueBillsDaysLimit, maxDaysForNudge, minDaysForNudge, pageable);

        return GetBillsResponse.builder()
                .dueBills(getCustomerBillAccountDTOList(BillType.DUE, customerBillAccountsByType.getDueBills(), billerCategoriesList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap))
                .paidBills(getCustomerBillAccountDTOList(BillType.PAID, customerBillAccountsByType.getPaidBills(), billerCategoriesList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap))
                .overdueBills(getCustomerBillAccountDTOList(BillType.OVERDUE, customerBillAccountsByType.getOverdueBills(), billerCategoriesList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap)).build();
    }

    private List<GetBillsCustomerBillAccountDTO> getCustomerBillAccountDTOList(BillType billType, List<CustomerBillAccount> customerBillAccountList, List<BillerCategory> billerCategoryList, HashMap<UUID, UUID> billerIdToBillerCategoryMap, HashMap<UUID, String> billerIdToBillerCategoryNameMap) {
        List<GetBillsCustomerBillAccountDTO> getBillsCustomerBillAccountDTOList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(customerBillAccountList)) {
            customerBillAccountList.forEach(customerBillAccount -> getBillsCustomerBillAccountDTOList.add(getCustomerBillAccountDTO(billType, customerBillAccount, billerCategoryList, billerIdToBillerCategoryMap, billerIdToBillerCategoryNameMap)));
        }
        return getBillsCustomerBillAccountDTOList;
    }

    //TODO scope of optimisation. Cache use can help.
    private GetBillsCustomerBillAccountDTO getCustomerBillAccountDTO(BillType billType, CustomerBillAccount customerBillAccount, List<BillerCategory> billerCategoryList, HashMap<UUID, UUID> billerIdToBillerCategoryIdMap, HashMap<UUID, String> billerIdToBillerCategoryNameMap) {
        Biller biller = customerBillAccount.getBiller();
        boolean isGiftCardBiller = biller.isBillTypeGiftCard();
        log.info("Building customer bill account DTO for customerBillAccountId : {}, billType : {}, customerAccountId : {}", customerBillAccount.getCustomerBillAccountId(), billType, customerBillAccount.getCustomerAccountId());
        UUID queryBillerId = getQueryBillerId(biller);
        getBillerCategoryIdAndNameForBiller(billerCategoryList, billerIdToBillerCategoryIdMap, billerIdToBillerCategoryNameMap, queryBillerId);
        UUID categoryId = billerIdToBillerCategoryIdMap.get(queryBillerId);
        String categoryName = billerIdToBillerCategoryNameMap.get(queryBillerId);
        GetBillsCustomerBillAccountDTO.BillerDTO billerDTO = GetBillsCustomerBillAccountDTO.BillerDTO.builder()
                .billerId(biller.getBillerId())
                .processorBillerId(customerBillAccount.getBiller().getProcessorBillerId())
                .queryBillerId(queryBillerId)
                .categoryId(categoryId)
                .categoryName(categoryName)
                .displayName(biller.getDisplayName())
                .imageUrl(biller.getImageURL())
                .productName(biller.getProductDisplayName())
                .billerIdLinkedToCategory(BillPayUtil.getBillerIdLinkedToCategoryForBiller(customerBillAccount.getBiller()))
                .billDetailId(Objects.nonNull(customerBillAccount.getLastPaidBillPayTransaction()) && Objects.nonNull(customerBillAccount.getLastPaidBillPayTransaction().getBillDetail()) ? customerBillAccount.getLastPaidBillPayTransaction().getBillDetail().getBillDetailId() : null)
                .build();

        return GetBillsCustomerBillAccountDTO.builder()
                .customerBillAccountId(customerBillAccount.getCustomerBillAccountId())
                .customerAccountId(customerBillAccount.getCustomerAccountId())
                .processorBillAccountId(customerBillAccount.getProcessorBillAccountId())
                .biller(billerDTO)
                .accountNumber(isGiftCardBiller ? null : customerBillAccount.getAccountNumber())
                .alias(customerBillAccount.getAlias())
                .dueDate(billType.equals(BillType.PAID) ? null : customerBillAccount.getDueDate())
                .dueAmount(customerBillAccount.getDueAmount())
                .dueAmountCurrency(customerBillAccount.getDueAmountCurrencyUnit())
                .lastPaidDate(customerBillAccount.getLastPaidDateValue())
                .lastPaidAmount(customerBillAccount.getLastPaidAmountValue())
                .lastPaidAmountCurrency(customerBillAccount.getLastPaidAmountCurrencyUnitValue())
                .info(!billType.equals(BillType.PAID) ? getDueBillsInfoDTO(customerBillAccount) : null)
                .build();
    }

    private void getBillerCategoryIdAndNameForBiller(List<BillerCategory> billerCategoryList, HashMap<UUID, UUID> billerIdToBillerCategoryIdMap, HashMap<UUID, String> billerIdToBillerCategoryNameMap, UUID billerId) {
        if (!billerIdToBillerCategoryIdMap.isEmpty() && billerIdToBillerCategoryIdMap.containsKey(billerId)) {
            return;
        }
        if (!billerCategoryList.isEmpty()) {
            for (BillerCategory billerCategory : billerCategoryList) {
                List<Biller> billerList = billerCategory.getBillers();
                boolean isBillerMappedToCategory = billerList.stream().anyMatch(in -> in.getBillerId().equals(billerId) || (!CollectionUtils.isEmpty(in.getSubBillers()) && in.getSubBillers().stream().anyMatch(in1 -> in1.getBillerId().equals(billerId))));
                if (isBillerMappedToCategory) {
                    billerIdToBillerCategoryIdMap.put(billerId, billerCategory.getId());
                    billerIdToBillerCategoryNameMap.put(billerId, billerCategory.getCategoryName());
                    return ;
                }
            }
        }
    }

    public static Biller getParentBiller(Biller biller) {
        if (Objects.nonNull(biller.getParentBiller())) {
            return biller.getParentBiller();
        } else {
            return null;
        }
    }

    public static UUID getQueryBillerId(Biller biller) {
        Biller parentBiller = getParentBiller(biller);
        if (Objects.isNull(parentBiller) || parentBiller.getSubBillerShownAsProduct()) {
            return biller.getBillerId();
        }
        return parentBiller.getBillerId();
    }

    private GetBillsCustomerBillAccountDTO.BillInfo getDueBillsInfoDTO(CustomerBillAccount customerBillAccount) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate todayDate = LocalDate.now();
        if (customerBillAccount.getDueDate() != null) {
            LocalDate dueDate = getDateInLocalDateFormat(LocalDateTime.fromDateFields(customerBillAccount.getDueDate()).toLocalDate());
            if (dueDate.isAfter(todayDate) || dueDate.isEqual(todayDate)) {
                if (dueDate.isEqual(todayDate)) {
                    return GetBillsCustomerBillAccountDTO.BillInfo.builder()
                            .type(WPSConstants.Bills.DUE_BILL_TYPE_TODAY)
                            .text(WPSConstants.Bills.DUE_TODAY)
                            .build();
                } else if (dueDate.equals(todayDate.plusDays(1))) {
                    return GetBillsCustomerBillAccountDTO.BillInfo.builder()
                            .type(WPSConstants.Bills.DUE_BILL_TYPE_LATER)
                            .text(WPSConstants.Bills.DUE_TOMORROW)
                            .build();
                } else {
                    return GetBillsCustomerBillAccountDTO.BillInfo.builder()
                            .type(WPSConstants.Bills.DUE_BILL_TYPE_LATER)
                            .text(WPSConstants.Bills.DUE_BILL_DESC.concat(dueDate.format(formatter)))
                            .build();
                }
            } else if (todayDate.isAfter(dueDate)) {
                return GetBillsCustomerBillAccountDTO.BillInfo.builder()
                        .type(WPSConstants.Bills.OVERDUE_BILL)
                        .text(WPSConstants.Bills.OVERDUE_BILL_PAY_DESC)
                        .build();
            }
        } else if (customerBillAccount.getNudgeBucket() != null) {
            return GetBillsCustomerBillAccountDTO.BillInfo.builder()
                    .type(WPSConstants.Bills.NUDGE_BILL)
                    .text(WPSConstants.Bills.NUDGE_BILL_DESC)
                    .build();
        }
        return null;
    }

    private LocalDate getDateInLocalDateFormat(io.strati.libs.joda.time.LocalDate dueDate) {
        return LocalDate.of(dueDate.getYear(), dueDate.getMonthOfYear(), dueDate.getDayOfMonth());
    }

    @Override
    public UpdateCustomerBillAccountResponse updateCustomerBillAccount(UpdateCustomerBillAccountRequest request,
                                                                       MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.updateCustomerBillAccount(request, headers);
    }

    @Override
    public UpdateCustomerBillAccountDueInfoResponse updateCustomerBillAccountDueInfo(UpdateCustomerBillAccountDueInfoRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        UpdateCustomerBillDueInfoRequestContext requestContext;
        try {
             requestContext = UpdateCustomerBillDueInfoRequestContext.builder()
                    .processorBillAccountId(request.getProcessorBillAccountId())
                    .processorBillerId(request.getProcessorBillerId())
                    .accountNumber(request.getAccountNumber())
                    .dueDate(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(request.getDueDate()))
                    .dueAmount(request.getDueAmount())
                    .dueAmountCurrencyUnit(request.getDueAmountCurrencyUnit())
                    .dueInfoUpdatedBy(WPSConstants.Bills.DUE_INFO_UPDATED_BY_ARCUS_CONSTANT)
                    .build();
        } catch (ParseException pe) {
            String msg = String.format("Error while parsing dueDate in updateCustomerBillAccountDueInfo API for processorBillAccountId:[%s]",
                    request.getProcessorBillAccountId());
            throw new ProcessingException(ErrorConstants.UpdateCustomerBillAccountDueInfo.ERROR_IN_PARSING_DUE_DATE, msg);
        }
        billCoreService.updateCustomerBillAccountDueInfoAndRaiseReminders(requestContext);
        return UpdateCustomerBillAccountDueInfoResponse.builder()
                .status("SUCCESS")
                .message(WPSConstants.Bills.RECORDS_UPDATED_SUCCESSFULLY)
                .build();
    }

    @Override
    public DeleteCustomerBillAccountResponse deleteCustomerBillAccount(DeleteCustomerBillAccountRequest deleteCustomerBillAccountRequest, MultiValueMap<String, String> headers) throws BusinessValidationException {
        CustomerBillAccount customerBillAccount = billCoreService.deleteCustomerBillAccount(deleteCustomerBillAccountRequest.getCustomerBillAccountId(), deleteCustomerBillAccountRequest.getCustomerAccountId());
        DeleteCustomerBillAccountResponse deleteCustomerBillAccountResponse = billDTOMapper.mapCustomerBillAccountToDeleteCustomerBillAccountResponse(customerBillAccount);
        deleteCustomerBillAccountResponse.setCustomerBillAccountDeletedAt(new Date());
        return deleteCustomerBillAccountResponse;
    }

    @Override
    public CreateBillResponse createBill(CreateBillRequest createBillRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.createBill(createBillRequest, headers);
    }

    @Override
    public GetSavedCustomerBillAccountsResponse getSavedCustomerBillAccounts(GetSavedCustomerBillAccountsRequest getSavedCustomerBillAccountsRequest,
                                                                             MultiValueMap<String, String> headers) throws ApplicationException {
        UUID billerId = getSavedCustomerBillAccountsRequest.getBillerId();
        UUID customerAccountId = getSavedCustomerBillAccountsRequest.getCustomerAccountId();
        String accountNumber = getSavedCustomerBillAccountsRequest.getAccountNumber();
        List<CustomerBillAccount> customerBillAccounts = billCoreService.getSavedCustomerBillAccounts(billerId, customerAccountId, accountNumber);
        List<SavedCustomerBillAccountDTO> savedCustomerBillAccountDTOs = billDTOMapper.mapToSavedCustomerBillAccountDTOsFromCustomerBillAccounts(customerBillAccounts);
        return GetSavedCustomerBillAccountsResponse.builder()
                .savedCustomerBillAccounts(savedCustomerBillAccountDTOs)
                .build();
    }

    @Override
    public AlreadyPaidResponse markAlreadyPaid(AlreadyPaidRequest alreadyPaidRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        AlreadyPaidRequestContext alreadyPaidRequestContext = AlreadyPaidRequestContext.builder()
                .customerBillAccountId(alreadyPaidRequest.getCustomerBillAccountId())
                .customerAccountId(alreadyPaidRequest.getCustomerAccountId())
                .lastPaidDate(alreadyPaidRequest.getLastPaidDate())
                .build();
        AlreadyPaidResponseContext alreadyPaidResponseContext = billCoreService.updateCustomerBillAccountAsAlreadyPaidAndSendReminders(alreadyPaidRequestContext);
        return billDTOMapper.mapCustomerBillAccountToAlreadyPaidResponse(alreadyPaidResponseContext.getCustomerBillAccount());
    }
}