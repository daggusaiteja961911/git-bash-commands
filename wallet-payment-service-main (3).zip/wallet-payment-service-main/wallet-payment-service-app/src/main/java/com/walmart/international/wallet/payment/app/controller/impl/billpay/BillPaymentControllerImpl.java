package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.app.controller.billpay.BillPaymentController;
import com.walmart.international.wallet.payment.app.service.BillPaymentService;
import com.walmart.international.wallet.payment.app.auth.WPSAuthValidator;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ReconcilePendingBillPayTxnRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ValidatePayBillInitRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.ReconcilePendingBillPayTxnResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.ValidatePayBillInitResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillPaymentControllerImpl implements BillPaymentController {

    @Autowired
    private BillPaymentService billPaymentService;

    @Autowired
    private WPSAuthValidator wpsAuthValidator;

    @Override
    public FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(fetchBillPayPaymentInstrumentsRequest.getCustomerAccountId().toString(), headers);
        return billPaymentService.fetchBillPayPaymentInstruments(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(fetchBillPayPaymentInstrumentsRequest.getCustomerAccountId().toString(), headers);
        return billPaymentService.fetchBillPayPaymentInstrumentsWithPreselection(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public PayBillInitResponse payBillInit(PayBillInitRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(request.getCustomerAccountId().toString(), headers);
        return billPaymentService.payBillInit(request, headers);
    }

    @Override
    public ReconcilePendingBillPayTxnResponse reconcilePendingBillPayTxn(ReconcilePendingBillPayTxnRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        return billPaymentService.reconcilePendingBillPayTxn(request, headers);
    }

    @Override
    public CancelPayBillInitResponse cancelPayBillInit(CancelPayBillInitRequest cancelPayBillInitRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(cancelPayBillInitRequest.getCustomerAccountId().toString(), headers);
        return billPaymentService.cancelPayBillInit(cancelPayBillInitRequest, headers);
    }

    @Override
    public ValidatePayBillInitResponse validatePayBillInit(ValidatePayBillInitRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(request.getCustomerAccountId().toString(), headers);
        return billPaymentService.validatePayBillInit(request, headers);
    }
}
