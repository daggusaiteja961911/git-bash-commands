package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class FetchBillPayPaymentInstrumentsDomainResponseBuilder extends BaseDomainResponseBuilder<FetchBillPayPaymentInstrumentsResponse, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public FetchBillPayPaymentInstrumentsResponse buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        return FetchBillPayPaymentInstrumentsResponse.builder()
                .transaction(billPayMapper.mapBillPayTransactionToTransactionDTO(billPayTxnResponseDomainContext.getTransaction()))
                .cardPaymentOptions(billPayMapper.mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getCardPaymentInstruments().getCardPaymentInstrumentList()))
                .giftCardPaymentOptions(billPayMapper.mapGiftCardPaymentInstrumentListToGiftCardPaymentInstrumentDTOList(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getGiftCardPaymentInstruments().getGiftCardPaymentInstrumentList()))
                .isMSIAllowedForSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getIsMSIAllowedForSplitPayment())
                .allowCoFForBillPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowCoFForBillPayment())
                .allowB2BSplitForBillPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowB2BForSplitPayment())
                .allowMultipleB2BForSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowMultipleB2BForSplitPayment()).build();
    }
}
