package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.TransactionMapper;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.common.CardPaymentDetail;
import com.walmart.international.wallet.payment.dto.request.common.GiftCardPaymentDetail;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.Objects;

@Component
public class BillPayTxnDomainRequestBuilder extends BaseDomainRequestBuilder<PayBillInitRequest, BillPayTxnRequestDomainContext> {

    TransactionMapper transactionMapper = TransactionMapper.INSTANCE;
    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(PayBillInitRequest payBillInitRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        BillPayTransaction.BillPayTransactionBuilder billPayTransactionBuilder = BillPayTransaction.builder()
                .transactionType(TransactionType.BILL_PAY)
                .customerBillAccount(CustomerBillAccount.builder()
                        .billerId(payBillInitRequest.getCustomerBillDetails().getBillerId())
                        .accountNumber(payBillInitRequest.getCustomerBillDetails().getAccountNumber())
                        .processorBillAccountId(payBillInitRequest.getCustomerBillDetails().getProcessorBillAccountId())
                        .customerAccountId(payBillInitRequest.getCustomerAccountId())
                        .build())
                .amountRequested(Amount.builder()
                        .value(payBillInitRequest.getCustomerBillDetails().getAmount().getValue())
                        .currencyUnit(CurrencyUnit.valueOf(payBillInitRequest.getCustomerBillDetails().getAmount().getCurrencyUnit()))
                        .build());

        if (Objects.nonNull(payBillInitRequest.getCustomerBillDetails().getBillDetailId())) {
            billPayTransactionBuilder.billDetail(BillDetail.builder()
                    .billDetailId(payBillInitRequest.getCustomerBillDetails().getBillDetailId())
                    .build());
        }

        for (CardPaymentDetail cardPaymentDetail : payBillInitRequest.getPaymentDetails().getCardPaymentDetails()) {
            CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                    .paymentInstrumentId(cardPaymentDetail.getPaymentInstrumentId())
                    .cardTokenInformation(transactionMapper.mapCardTokenInformationFromDTOToContext(cardPaymentDetail.getCardMetadata().getCardTokenInformation()))
                    .fraudInfo(transactionMapper.mapFraudInfoFromDTOToContext(cardPaymentDetail.getCardMetadata().getFraudInfo()))
                    .amount(Amount.builder()
                            .value(cardPaymentDetail.getAmount().getValue())
                            .currencyUnit(CurrencyUnit.valueOf(cardPaymentDetail.getAmount().getCurrencyUnit()))
                            .build())
                    .affiliationType(AffiliationType.valueOf(cardPaymentDetail.getCardMetadata().getAffiliationType().name()))
                    .build();
            billPayTransactionBuilder.cardPaymentTransactionList(cardPaymentTransaction);
        }
        for (GiftCardPaymentDetail giftCardPaymentDetail : payBillInitRequest.getPaymentDetails().getGiftCardPaymentDetails()) {
            GiftCardTransaction giftCardPaymentTransaction = GiftCardTransaction.builder()
                    .paymentInstrumentId(giftCardPaymentDetail.getPaymentInstrumentId())
                    .amount(Amount.builder()
                            .value(giftCardPaymentDetail.getAmount().getValue())
                            .currencyUnit(CurrencyUnit.valueOf(giftCardPaymentDetail.getAmount().getCurrencyUnit()))
                            .build())
                    .giftCardTransactionType(GiftCardTransactionType.PAY)
                    .build();
            billPayTransactionBuilder.giftCardPaymentTransactionList(giftCardPaymentTransaction);
        }

        billPayTransactionBuilder.customer(Customer.builder()
                .customerAccountId(payBillInitRequest.getCustomerAccountId())
                .build());

        return BillPayTxnRequestDomainContext.builder()
                .clientRequestId(Objects.nonNull(headers.get(WPSConstants.Headers.CLIENT_REQ_ID)) ? String.valueOf(headers.get(WPSConstants.Headers.CLIENT_REQ_ID).get(0)) : null)
                .transaction(billPayTransactionBuilder.build())
                .headers(headers)
                .build();
    }
}
