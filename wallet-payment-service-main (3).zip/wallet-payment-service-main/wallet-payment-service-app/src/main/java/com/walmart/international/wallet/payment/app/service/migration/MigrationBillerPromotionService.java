package com.walmart.international.wallet.payment.app.service.migration;

import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;

public interface MigrationBillerPromotionService {
    BillerPromotionsResponse getPromotions(String billerCategoryIds, String billerIds, int billerCategoryVersion);
}
