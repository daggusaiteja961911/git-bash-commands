package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.BillPaymentService;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ReconcilePendingBillPayTxnRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ValidatePayBillInitRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.ReconcilePendingBillPayTxnResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.ValidatePayBillInitResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class BillPaymentServiceImpl implements BillPaymentService {

    @Autowired
    private WalletServiceRouter walletServiceRouter;

    @Override
    public FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest,
                                                                                 MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.fetchBillPayPaymentInstruments(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest,
                                                                                                                 MultiValueMap<String, String> headers) {
        return walletServiceRouter.fetchBillPayPaymentInstrumentsWithPreselection(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public PayBillInitResponse payBillInit(PayBillInitRequest request,
                                           MultiValueMap<String, String> headers) {
        return walletServiceRouter.payBillInit(request, headers);
    }

    @Override
    public ReconcilePendingBillPayTxnResponse reconcilePendingBillPayTxn(ReconcilePendingBillPayTxnRequest request,
                                                        MultiValueMap<String, String> headers) {
        return walletServiceRouter.reconcilePendingBillPayTxn(request, headers);
    }

    @Override
    public CancelPayBillInitResponse cancelPayBillInit(CancelPayBillInitRequest request,
                                                       MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.cancelPayBillInit(request, headers);
    }

    @Override
    public ValidatePayBillInitResponse validatePayBillInit(ValidatePayBillInitRequest request,
                                                           MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.validatePayBillInit(request, headers);
    }
}
