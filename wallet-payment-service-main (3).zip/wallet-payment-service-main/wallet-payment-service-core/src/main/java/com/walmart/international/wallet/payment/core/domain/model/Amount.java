package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Objects;

@Data
@Builder
public class Amount {

    BigDecimal value;
    CurrencyUnit currencyUnit;

    public static Amount sum(Amount a, Amount b) {
        if (a.currencyUnit != b.currencyUnit) {
            throw new ProcessingException(ErrorConstants.Common.AMOUNT_CURRENCY_MISMATCH);
        }
        if (Objects.nonNull(b.value) && b.value.compareTo(BigDecimal.ZERO) < 0) {
            throw new ProcessingException(ErrorConstants.Common.INVALID_AMOUNT_VALUE);
        }
        return new Amount(a.value.add(b.value), a.currencyUnit);
    }
}
