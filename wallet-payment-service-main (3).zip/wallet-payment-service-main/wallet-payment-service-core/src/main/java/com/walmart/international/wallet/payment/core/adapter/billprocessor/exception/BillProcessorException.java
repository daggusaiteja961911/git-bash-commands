package com.walmart.international.wallet.payment.core.adapter.billprocessor.exception;

import com.walmart.international.digiwallet.service.basic.util.CommonUtils;

import java.util.Arrays;

public abstract class BillProcessorException extends Exception {
    private final String errorCode;
    private final Object[] args;

    public BillProcessorException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.args = new Object[0];
    }

    public BillProcessorException(String errorCode, String message, Object[] args) {
        super(message);
        this.errorCode = errorCode;
        this.args = args;
    }

    public BillProcessorException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.args = new Object[0];
    }

    public BillProcessorException(String errorCode, String message, Object[] args, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.args = args;
    }

    public String getQualifiedErrorCode() {
        return CommonUtils.getQualifiedErrorCode(this.getErrorCode());
    }



    @Override
    public String toString() {
        return "ArcusClientException(errorCode=" + this.getErrorCode() + ", args=" + Arrays.deepToString(this.getArgs()) + ")";
    }

    public String toString(BillProcessorException ex) {
        return ex.getClass() + "(errorCode=" + this.getErrorCode() + ", args=" + Arrays.deepToString(this.getArgs()) + ")";
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public Object[] getArgs() {
        return this.args;
    }
}
