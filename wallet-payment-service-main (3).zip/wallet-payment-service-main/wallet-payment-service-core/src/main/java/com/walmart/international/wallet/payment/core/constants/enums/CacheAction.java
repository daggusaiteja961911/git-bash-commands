package com.walmart.international.wallet.payment.core.constants.enums;

public enum CacheAction {
    WRITE, EVICT
}
