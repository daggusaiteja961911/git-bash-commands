package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;

import java.util.UUID;

public interface BillPaymentCoreService {

    void processCancelBillPaymentInitEvent(PayBillInitEventPayload payBillInitEventPayload);

    void updateBillPayTransactionStateForReversal(UUID transactionId, BillPayTxnStateReason billPayTxnStateReason);
}
