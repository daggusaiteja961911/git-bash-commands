package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class BillPayTxnResponseDomainContext extends TransactionResponseDomainContext {

    private BillPayTransactionDO billPayTransactionDO;
    private CoFTopupTransactionDO coFTopupTransactionDO;
    private CustomerBillAccountDO customerBillAccountDO;

    public BillPayTransaction getTransaction() {
        return (BillPayTransaction) super.transaction;
    }

    public void setTransaction(BillPayTransaction billPayTransaction) {
        super.transaction = billPayTransaction;
    }
}
