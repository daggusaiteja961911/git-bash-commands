package com.walmart.international.wallet.payment.core.processor.coftopup;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.config.ccm.SingleScreenPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopupPaymentOptions;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class CoFTopupPaymentInstrumentsWithPreselectionFetcher implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    ICustomerServiceClient customerServiceClient;

    @ManagedConfiguration
    SingleScreenPaymentConfiguration singleScreenPaymentConfiguration;

    CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext = (CoFTopupTxnRequestDomainContext) wpsRequestDomainContext;
        CoFTopupTxnResponseDomainContext cofTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
        UUID customerAccountId = cofTopupTxnRequestDomainContext.getTransaction().getCustomer().getCustomerAccountId();
        WalletResponse paymentInstrumentResponse = customerServiceClient.getPaymentInstruments(customerAccountId, false, false);
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = paymentInstrumentResponse.getPaymentInstruments();
        List<CardPaymentInstrument> cardPaymentInstruments = getCardPaymentInstruments(paymentInstrumentList);
        List<CardPaymentInstrument> sortedPaymentInstruments = sortAndPreselectPaymentInstrument(cardPaymentInstruments);

        cofTopupTxnResponseDomainContext.setTransaction(CoFTopUpTransaction.builder()
                .cofTopupPaymentOptions(CoFTopupPaymentOptions.builder()
                        .cardPaymentInstruments(CardPaymentInstruments.builder()
                                .cardPaymentInstrumentList(sortedPaymentInstruments)
                                .build())
                        .build())
                .build());
        return true;
    }

    private List<CardPaymentInstrument> getCardPaymentInstruments(List<WalletResponse.PaymentInstrument> paymentInstrumentList) {
        List<CardPaymentInstrument> cardPaymentInstruments = new ArrayList<>();
        for (WalletResponse.PaymentInstrument paymentInstrument : paymentInstrumentList) {
            if (PaymentInstrumentType.CARD.name().equals(paymentInstrument.getPaymentInstrumentType().name())) {
                CardPaymentInstrument cardPaymentInstrument = customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument);
                cardPaymentInstrument.setTag(PaymentInstrumentType.CARD.name());
                cardPaymentInstruments.add(cardPaymentInstrument);
            }
        }
        return cardPaymentInstruments;
    }

    public List<CardPaymentInstrument> sortAndPreselectPaymentInstrument(List<CardPaymentInstrument> paymentInstruments) {
        List<CardPaymentInstrument> sortedPaymentInstruments = paymentInstruments.stream()
                .filter(card -> !card.getCardExpired())
                .sorted(Comparator.comparing((CardPaymentInstrument dto) -> singleScreenPaymentConfiguration.getCuentaCashiDigitalCardBins().contains(String.valueOf(dto.getBinDetails().getBin())) ? -1 : 0) //cuenta cashi digital card
                        .thenComparing((CardPaymentInstrument dto) -> dto.getFavoriteCard() ? -1 : 0) //favorite card
                        .thenComparing(CardPaymentInstrument::getLastUsedDate, Comparator.nullsLast(Comparator.reverseOrder())) //last used card date
                        .thenComparing(dto -> dto.getBinDetails().getBankName()))
                .collect(Collectors.toList());
        if (null != sortedPaymentInstruments && !sortedPaymentInstruments.isEmpty()) {
            sortedPaymentInstruments.get(0).setIsPreSelected(true);
        }
        return sortedPaymentInstruments;
    }
}