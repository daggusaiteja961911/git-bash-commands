package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.CustomerBasicResponse;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Mapper
public interface CustomerMapper {

    CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);

    @Mapping(target = "customerAccountId", source = "customerAccountId", qualifiedByName = "mapStringToUUID")
    @Mapping(target = "dateOfBirth", source = "dateOfBirth", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "createDate", source = "createDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    Customer mapCustomerFromDTOToContext(CustomerResponse customerResponse);

    @Mapping(target = "customerAccountId", source = "customerAccountId", qualifiedByName = "mapStringToUUID")
    @Mapping(target = "dateOfBirth", source = "dateOfBirth")
    @Mapping(target = "createDate", source = "createDate")
    Customer mapCustomerFromBasicDTOToContext(CustomerBasicResponse customerResponse);

    @Mapping(target = "customerAccountId", source = "customerAccountId", qualifiedByName = "mapStringToUUID")
    @Mapping(target = "dateOfBirth", source = "dateOfBirth", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "createDate", source = "createDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    void updateCustomerDataInContext(CustomerResponse customerResponse, @MappingTarget Customer customer);

    default void mapPaymentInstrumentsToCustomerContext(Customer customer, CustomerResponse customerResponse) {
        List<CardPaymentInstrument> cardPaymentInstrumentList = new ArrayList<>();
        List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList = new ArrayList<>();
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = customerResponse.getWalletAccountDTO().getWalletResponse().getPaymentInstruments();
        paymentInstrumentList.forEach(paymentInstrument -> {
            if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.CARD)) {
                cardPaymentInstrumentList.add(mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument));
            }
            if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.GIFTCARD)) {
                giftCardPaymentInstrumentList.add(mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument));
            }
        });
        customer.setCardPaymentInstrumentList(cardPaymentInstrumentList);
        customer.setGiftCardPaymentInstrumentList(giftCardPaymentInstrumentList);
    }

    @Mapping(target = "lastUsedDate", source = "lastUsedCardDate")
    @Mapping(target = "expirationMonth", source = "metadata.expirationMonth")
    @Mapping(target = "expirationYear", source = "metadata.expirationYear")
    @Mapping(target = "cardExpired", source = "metadata.cardExpired")
    @Mapping(target = "favoriteCard", source = "metadata.favoriteCard")
    @Mapping(target = "paymentInstrumentId", source = "paymentInstrumentId", qualifiedByName = "mapUUIDToString")
    CardPaymentInstrument mapPaymentInstrumentToCardPaymentInstrument(WalletResponse.PaymentInstrument paymentInstrument);

    @Mapping(target =  "paymentInstrumentId", source = "paymentInstrumentId", qualifiedByName = "mapUUIDToString")
    GiftCardPaymentInstrument mapPaymentInstrumentToGiftCardPaymentInstrument(WalletResponse.PaymentInstrument paymentInstrument);

    @Named("mapStringToUUID")
    default UUID mapStringToUUID(String string) {
        return UUID.fromString(string);
    }

    @Named("mapUUIDToString")
    default String mapUUIDToString(UUID value) {
        return value.toString();
    }
}
