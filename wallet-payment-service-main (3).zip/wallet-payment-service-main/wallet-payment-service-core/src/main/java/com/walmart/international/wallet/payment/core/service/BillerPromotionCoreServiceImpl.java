package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.campaign.client.CampaignServiceClient;
import com.walmart.international.digiwallet.service.basic.dto.PromotionMappingDTO;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import com.walmart.international.wallet.payment.core.mapper.BillerPromotionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

@Service
public class BillerPromotionCoreServiceImpl implements BillerPromotionCoreService {

    @Autowired
    private CampaignServiceClient campaignServiceClient;

    @Autowired
    private BillerCoreService billerCoreService;

    private static final BillerPromotionMapper billerPromotionMappper = BillerPromotionMapper.INSTANCE;

    @Override
    public Map<String, List<BillerPromotion>> getAllPromotionsForPromotionCategory(String billerCategoryIds, String processorBillerIds, int billerCategoryVersion) {

        validatePromotionsRequest(billerCategoryIds, processorBillerIds);

        List<BillerCategory> billerCategoriesList;
        billerCategoriesList = billerCoreService.getBillerCategoriesList(billerCategoryVersion);

        Map<String, List<PromotionMappingDTO>> billerPromotionsMapFromCaas = campaignServiceClient.getAllPromotions(WPSConstants.Promotions.IS_PROMOTIONS_FROM_CACHE);
        Map<String, List<BillerPromotion>> promotionsMap = new HashMap<>();

        processPromotionsForBillerCategoryIds(billerCategoryIds, billerCategoriesList, billerPromotionsMapFromCaas, promotionsMap);
        processPromotionsForBillerIds(processorBillerIds, billerPromotionsMapFromCaas, promotionsMap);
        return promotionsMap;
    }

    private void processPromotionsForBillerCategoryIds(String billerCategoryIds, List<BillerCategory> billerCategoriesList,
                                                       Map<String, List<PromotionMappingDTO>> promotionMapFromCaas,
                                                       Map<String, List<BillerPromotion>> promotionsMap) {
        if (Objects.nonNull(billerCategoryIds)) {
            List<UUID> categoryIds;
            categoryIds = validateBillerCategoryIds(billerCategoryIds);

            for (UUID billerCategoryId : categoryIds) {
                BillerCategory billerCategory = null;
                if (!billerCategoriesList.isEmpty()) {
                    billerCategory = billerCategoriesList.stream()
                            .filter(i -> i.getId().toString().equalsIgnoreCase(billerCategoryId.toString()))
                            .findFirst().orElse(null);
                }

                if (Objects.nonNull(billerCategory)) {
                    List<Biller> billers = billerCategory.getBillers();
                    if (Objects.nonNull(billers)) {
                        billers.forEach(biller -> createPromotionsResponse(promotionMapFromCaas, promotionsMap, String.valueOf(biller.getProcessorBillerId())));
                    }
                } else {
                    String msg = String.format("No biller category record found for billerCategoryId[%s]", billerCategoryId);
                    throw new BusinessValidationException(ErrorConstants.Promotions.INVALID_BILLER_CATEGORY_ID, msg);
                }
            }
        }
    }

    private void processPromotionsForBillerIds(String processorBillerIds, Map<String, List<PromotionMappingDTO>> promotionMapFromCaas, Map<String, List<BillerPromotion>> promotionsMap) {
        if (Objects.nonNull(processorBillerIds)) {
            String[] billersList = processorBillerIds.split(",");
            for (String billerId : billersList) {
                createPromotionsResponse(promotionMapFromCaas, promotionsMap, billerId);
            }
        }
    }

    private void validatePromotionsRequest(String billerCategoryIds, String processorBillerIds) {
        if (Objects.isNull(billerCategoryIds) && Objects.isNull(processorBillerIds))
            throw new DataValidationException(ErrorConstants.Promotions.BILLER_ID_NULL);
    }

    private List<UUID> validateBillerCategoryIds(String billerCategoryIds) {
        String[] categoryIds = billerCategoryIds.split(",");
        List<UUID> validatedIds = new ArrayList<>();
        for (String billerCategoryId : categoryIds) {
            try {
                UUID id = UUID.fromString(billerCategoryId);
                validatedIds.add(id);
            } catch (Exception e) {
                String msg = String.format("billerCategoryId[%s] is not a valid UUID", billerCategoryId);
                throw new ProcessingException(ErrorConstants.Promotions.INVALID_BILLER_CATEGORY_ID, msg);
            }
        }
        return validatedIds;
    }

    private void createPromotionsResponse(Map<String, List<PromotionMappingDTO>> promotionMapFromCaas, Map<String, List<BillerPromotion>> promotionsMap, String billerId) {
        List<BillerPromotion> billerPromotionList = billerPromotionMappper.mapCaasPromotionResponsesToBillerPromotions(promotionMapFromCaas.get(billerId));
        if (!billerPromotionList.isEmpty()) {
            billerPromotionList.sort(new BillerPromotion.BillerPromotionComparator());
            promotionsMap.put(billerId, billerPromotionList.subList(0, 1));
        }
    }
}
