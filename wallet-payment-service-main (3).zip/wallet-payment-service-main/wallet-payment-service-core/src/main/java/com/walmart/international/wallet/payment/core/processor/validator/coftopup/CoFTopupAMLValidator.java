package com.walmart.international.wallet.payment.core.processor.validator.coftopup;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.validator.Validator;
import com.walmart.international.wallet.payment.core.config.ccm.AMLConfig;
import com.walmart.international.wallet.payment.core.constants.enums.AMLValidationType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.AMLValidationRequest;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.service.AMLValidationService;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class CoFTopupAMLValidator implements Validator<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private AMLValidationService amlValidationService;

    @ManagedConfiguration
    private AMLConfig amlConfiguration;

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Override
    public boolean validate(WPSRequestDomainContext wpsRequestDomainContext) throws ApplicationException {
        CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext = (CoFTopupTxnRequestDomainContext) wpsRequestDomainContext;
        BigDecimal amountAssociatedWithGiftCard = null;

        List<GiftCardTransaction> giftCardLoadTransactionList = coFTopupTxnRequestDomainContext.getTransaction().getGiftCardLoadTransactionList();;
        if (CollectionUtils.isNotEmpty(giftCardLoadTransactionList)) {
            amountAssociatedWithGiftCard = giftCardLoadTransactionList.stream()
                    .map(GiftCardTransaction::getAmount).map(Amount::getValue).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        }

        UUID customerAccountId = coFTopupTxnRequestDomainContext.getTransaction().getCustomer().getCustomerAccountId();
        AMLValidationRequest amlValidationRequest = AMLValidationRequest.builder().amlValidationType(AMLValidationType.LOAD)
                .requestId(coFTopupTxnRequestDomainContext.getClientRequestId())
                .customerAccountId(customerAccountId)
                .amount(amountAssociatedWithGiftCard)
                .build();

        if (BigDecimal.ZERO.compareTo(amountAssociatedWithGiftCard) != 0 && amlConfiguration.amlEvaluationEnabled()) {
            log.info("Evaluating AML validation for CoFTopupTransaction for customerAccountId[{}]", customerAccountId);
            try {
                amlValidationService.validateAMLChecks(amlValidationRequest);
            } catch (BusinessValidationException bve) {
                log.error("AML validation failed for CoFTopupTransaction for customerAccountId[{}]", customerAccountId);
                createCoFTopupTransactionInValidationFailureState(coFTopupTxnRequestDomainContext);
                throw bve;
            }
        }
        log.info("Validated AML restriction for CoFTopupTransaction for customerAccountId[{}]", customerAccountId);
        return true;
    }

    private void createCoFTopupTransactionInValidationFailureState(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnRequestDomainContext.getTransaction();
        DeviceInformation deviceInformation = coFTopupTxnRequestDomainContext.getDeviceInfo();

        CoFTopupTransactionDO cofTopupTransactionDO = new CoFTopupTransactionDO();
        cofTopupTransactionDO.setAmountRequested(coFTopUpTransaction.getAmountRequested().getValue());
        cofTopupTransactionDO.setCurrencyUnit(CurrencyUnit.valueOf(coFTopUpTransaction.getAmountRequested().getCurrencyUnit().name()));
        cofTopupTransactionDO.setCustomerAccountId(coFTopUpTransaction.getCustomer().getCustomerAccountId());
        cofTopupTransactionDO.setState(TransactionStateEnum.FAILURE);
        cofTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.VALIDATION_FAILED);
        cofTopupTransactionDO.setTxnReferenceId(coFTopUpTransaction.getTransactionReferenceId());
        cofTopupTransactionDO.setClientReqId(coFTopupTxnRequestDomainContext.getClientRequestId());
        cofTopupTransactionDO.setDeviceIpAddress(deviceInformation.getIp());
        cofTopupTransactionDO.setDeviceId(deviceInformation.getFingerPrint());
        if (Objects.nonNull(coFTopUpTransaction.getParentTransactionType())) {
            cofTopupTransactionDO.setParentTransactionType(com.walmart.international.wallet.payment.data.constant.enums.TransactionType.valueOf(coFTopUpTransaction.getParentTransactionType().name()));
        }
        coFTopupTransactionRepository.save(cofTopupTransactionDO);
    }
}
