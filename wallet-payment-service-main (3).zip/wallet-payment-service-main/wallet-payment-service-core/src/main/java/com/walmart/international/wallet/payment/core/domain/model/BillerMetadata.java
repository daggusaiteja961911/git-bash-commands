package com.walmart.international.wallet.payment.core.domain.model;

import lombok.Data;

import java.util.List;

@Data
public class BillerMetadata {
    private List<BillTypeValidation> validations;
}
