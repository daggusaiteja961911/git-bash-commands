package com.walmart.international.wallet.payment.core.adapter.kafka.exception;

import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;

public class InvalidKafkaPayloadException extends DataValidationException {
    public InvalidKafkaPayloadException(String errorCode) {
        super(errorCode);
    }
}
