package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.services.payment.core.domain.CardSubTransaction;
import com.walmart.international.services.payment.core.response.LoadResponse;
import com.walmart.international.services.payment.core.response.PayResponse;
import com.walmart.international.services.payment.core.response.ReversalResponse;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardSubTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Transaction;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TransactionMapper {

    TransactionMapper INSTANCE = Mappers.getMapper(TransactionMapper.class);

    @Mapping(target = "amountRequested", ignore = true)
    @Mapping(target = "amountFulfilled", ignore = true)
    void mapPayResponseToTransaction(PayResponse payResponse, @MappingTarget Transaction transaction);

    CardPaymentTransaction.CardSubTransaction mapCardSubTxnFromPaymentCoreResponse(CardSubTransaction cardSubTransaction);

    GiftCardSubTransaction mapGiftCardSubTxnFromPaymentCoreResponse(com.walmart.international.services.payment.core.domain.GiftCardSubTransaction giftCardSubTransaction);

    void mapReversalResponseToTransaction(ReversalResponse reversalResponse, @MappingTarget Transaction transaction);

    default Amount mapAmountToAmountUnit(com.walmart.international.services.payment.core.domain.Amount amount) {
        if (amount == null) {
            return null;
        }
        return Amount.builder()
                .value(amount.getAmount())
                .currencyUnit(CurrencyUnit.valueOf(amount.getCurrencyUnit().name()))
                .build();
    }

    void mapLoadResponseToTransaction(LoadResponse loadResponse, @MappingTarget Transaction transaction);
}
