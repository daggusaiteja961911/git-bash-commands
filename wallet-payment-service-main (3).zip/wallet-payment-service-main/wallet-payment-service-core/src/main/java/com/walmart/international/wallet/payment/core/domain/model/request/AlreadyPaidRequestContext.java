package com.walmart.international.wallet.payment.core.domain.model.request;

import lombok.Builder;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
@Builder
public class AlreadyPaidRequestContext {
    private UUID customerAccountId;
    private UUID customerBillAccountId;
    private Date lastPaidDate;
}
