package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.domain.model.BillPayPaymentOptions;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class BillPayPaymentInstrumentsFetcher implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    ICustomerServiceClient customerServiceClient;

    CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillPayTxnRequestDomainContext billPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        UUID customerAccountId = billPayTxnRequestDomainContext.getTransaction().getCustomer().getCustomerAccountId();
        WalletResponse paymentInstrumentResponse = customerServiceClient.getPaymentInstruments(customerAccountId, true, false);
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = paymentInstrumentResponse.getPaymentInstruments();
        mapPaymentInstruments(paymentInstrumentList, billPayTxnResponseDomainContext);
        return true;
    }

    private void mapPaymentInstruments(List<WalletResponse.PaymentInstrument> paymentInstrumentList, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        List<CardPaymentInstrument> cardPaymentInstrumentList = new ArrayList<>();
        List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList = new ArrayList<>();
        for (WalletResponse.PaymentInstrument paymentInstrument : paymentInstrumentList) {
            if (PaymentInstrumentType.CARD.equals(paymentInstrument.getPaymentInstrumentType())) {
                cardPaymentInstrumentList.add(customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument));
            } else if (PaymentInstrumentType.GIFTCARD.equals(paymentInstrument.getPaymentInstrumentType()) && PaymentInstrumentSubType.CASHI_WALLET.equals(paymentInstrument.getPaymentInstrumentSubType())) {
                giftCardPaymentInstrumentList.add(customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument));
            }
        }

        sortPaymentInstruments(cardPaymentInstrumentList, giftCardPaymentInstrumentList);
        billPayTxnResponseDomainContext.setTransaction(BillPayTransaction.builder()
                .billPayPaymentOptions(BillPayPaymentOptions.builder()
                        .cardPaymentInstruments(CardPaymentInstruments.builder()
                                .cardPaymentInstrumentList(cardPaymentInstrumentList)
                                .build())
                        .build())
                .build());
        billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setGiftCardPaymentInstruments(
                GiftCardPaymentInstruments.builder().giftCardPaymentInstrumentList(giftCardPaymentInstrumentList).build());
    }

    private void sortPaymentInstruments(List<CardPaymentInstrument> cardPaymentInstrumentList, List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList) {
        cardPaymentInstrumentList.sort(new WalletPaymentServiceUtil.CardPaymentInstrumentListSortingComparator());
        giftCardPaymentInstrumentList.sort(new WalletPaymentServiceUtil.GiftCardPaymentInstrumentListSortingComparator());
    }
}
