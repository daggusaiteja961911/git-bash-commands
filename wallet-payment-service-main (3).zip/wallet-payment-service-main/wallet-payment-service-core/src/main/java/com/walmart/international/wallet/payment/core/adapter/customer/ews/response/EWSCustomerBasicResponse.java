package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EWSCustomerBasicResponse {

    private String customerAccountId;

    private String firstName;

    private String lastName;

    private String emailId;

    private String phone;

    private String gender;

    private String dateOfBirth;

    private String createDate;

    private String status;

}