package com.walmart.international.wallet.payment.core.mapper;

import com.google.common.base.Strings;
import com.walmart.international.digiwallet.service.basic.dto.PromotionMappingDTO;
import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Mapper
@Component
public interface BillerPromotionMapper {

    BillerPromotionMapper INSTANCE = Mappers.getMapper(BillerPromotionMapper.class);

    @Mapping(target = "startDate", qualifiedByName = "mapDate")
    @Mapping(target = "endDate", qualifiedByName = "mapDate")
    BillerPromotion mapCaasPromotionResponseToBillerPromotion(PromotionMappingDTO promotionsMappingResponse);

    @Named("mapDate")
    static String getFormattedOutputDateString(String inputDateString) {
        String[] dateStringParts = inputDateString.split("\\.");
        return parseDateString(formatDateString(dateStringParts), getDateTimePrecision(dateStringParts));
    }

    private static int getDateTimePrecision(String[] parts) {
        return parts.length > 1 ? parts[1].length() : 1;
    }

    private static String parseDateString(String resultString, int precision) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss." + "S".repeat(precision));
        LocalDateTime localDateTime = LocalDateTime.parse(resultString, inputFormatter);

        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss." + "S".repeat(precision) + "'Z'");
        return localDateTime.format(outputFormatter);
    }

    private static String formatDateString(String[] parts) {
        String part1 = parts[0];
        String part2 = (parts.length > 1) ? parts[1] : "";
        part2 = addPrecision(part2, getDateTimePrecision(parts));
        return String.format("%s.%s", part1, part2);
    }

    private static String addPrecision(String str, int targetLength) {
        int currentLength = str.length();
        if (currentLength < targetLength) {
            int precisionToAdd = targetLength - currentLength;
            StringBuilder zeros = new StringBuilder(precisionToAdd);
            zeros.append("0".repeat(precisionToAdd));
            return str + zeros;
        } else {
            return str;
        }
    }

    default List<BillerPromotion> mapCaasPromotionResponsesToBillerPromotions(List<PromotionMappingDTO> promotionsList) {
        List<BillerPromotion> response = new ArrayList<>();
        if (promotionsList != null) {
            promotionsList.forEach(promotion -> {
                if (isPromotionActive(promotion, LocalDateTime.now())) {
                    response.add(mapCaasPromotionResponseToBillerPromotion(promotion));
                }
            });
        }
        return response;
    }

    private static boolean isPromotionActive(PromotionMappingDTO promotion, LocalDateTime currentDate) {
        StringBuilder currentDateTime = getDatePartUtil(currentDate.toString().replace("T", " "));
        return !Strings.isNullOrEmpty(promotion.getStartDate()) && !Strings.isNullOrEmpty(promotion.getEndDate())
                && getDatePartUtil(promotion.getStartDate()).compareTo(currentDateTime) <= 0
                && getDatePartUtil(promotion.getEndDate()).compareTo(currentDateTime) >= 0;
    }

    private static StringBuilder getDatePartUtil(String param) {
        return new StringBuilder(param.split("\\.")[0]);
    }

}
