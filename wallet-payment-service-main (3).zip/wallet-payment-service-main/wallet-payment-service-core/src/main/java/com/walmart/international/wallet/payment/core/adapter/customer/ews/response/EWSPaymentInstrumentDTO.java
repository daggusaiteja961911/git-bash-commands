package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import com.walmart.international.wallet.payment.core.adapter.customer.ews.constants.enums.AccountLockedState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EWSPaymentInstrumentDTO implements Serializable {

    private static final long serialVersionUID = 3870114369097084589L;
    private UUID id;
    private String cardType;

    private String giftCardAccount;
    private Balance balance;
    private String pihash;
    private AccountLockedState giftCardAccountLockedState;

    private boolean isActive = true;
    private Date createDate;
    private Date updateDate;
    private Date issuedate;

    private BigDecimal beginningBalance;
    private BigDecimal endingBalance;
    private String currencyUnit;

    private String paymentBrokerTokenId; // tokenId
    private String walletId;

    private String cardHolderName;
    private String nickName; //aliasName
    private String last4Digits;
    private Boolean cvvVerified;
    private Boolean cvvRequired;
    private String maskedCardNumber;
    private String brand;
    private Boolean favoriteCard;

    private String expirationMonth;
    private String expirationYear;
    private BinDetails binDetails;
    private BillingAddress billingAddress;
    private Company company;

    private String requestId;
    private String accertifyTokenId;
    private String accertifySessionId;
    private UUID parentPaymentPreferenceId;
    private Date lastUsedCardDate;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Company {
        String companyName;
        String companyLogo;
        String companyImage;
        String companyColor;
        Boolean isVale;
        String applicableBanners;
        String whiteListedUpcs;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BinDetails {
        String bin;
        String brandName;
        String bankName;
        String brandLogo;
        String bankLogo;
        String bankColor;
        String textColor;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BillingAddress {
        String street;
        String exteriorNum;
        String interiorNum;
        String city;
        String colony;
        String postalCode;
        String stateCode;
        String countryCode;
    }
}
