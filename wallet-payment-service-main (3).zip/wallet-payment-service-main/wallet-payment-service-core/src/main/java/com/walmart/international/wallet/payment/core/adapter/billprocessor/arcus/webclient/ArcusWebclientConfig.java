package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.webclient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.services.digitalwallet.httpclient.util.HttpClientException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.util.DownstreamWebClientErrorHandler;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.DownstreamHTTPClientConfigs;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.impl.WebClientV2Impl;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusCreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusPayBillResponse;
import com.walmart.international.wallet.payment.core.config.ccm.ArcusConfiguration;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import java.util.Objects;

import static com.walmart.international.digiwallet.service.strati.telemetry.service.constants.TelemetryConstants.EMPTY_TAG;

@Slf4j
@Configuration
public class ArcusWebclientConfig {

    public static final String ARCUS = "ARCUS";
    ObjectMapper objectMapper = new ObjectMapper();
    @ManagedConfiguration
    ArcusConfiguration arcusConfiguration;

    @Bean("arcusWebClient")
    WebClientV2 getArcusWalletClient() {
        DownstreamWebClientErrorHandler errorHandler = DownstreamWebClientErrorHandler.builder()
                .clientResponse4xxErrorHandler(errorResponse -> errorResponse.bodyToMono(ArcusCreateBillResponse.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.statusCode()));
                }))
                .clientResponse5xxErrorHandler(errorResponse -> errorResponse.bodyToMono(ArcusCreateBillResponse.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.statusCode()));
                }))
                .isError((httpCode, apiName) -> httpCode < 200 || httpCode >= 300)
                .errorCodeExtractor((responseBody, apiName) -> getErrorCode(responseBody, apiName))
                .build();
        DownstreamHTTPClientConfigs arcusHTTPClientConfigs = DownstreamHTTPClientConfigs.builder()
                .downstreamName(ARCUS)
                .downstreamErrorHandler(errorHandler)
                .connectionTimeoutMillis(arcusConfiguration.getWebClientConnectionTimeoutInMillis())
                .responseTimeoutMillis(arcusConfiguration.getWebClientResponseTimeoutInMillis())
                .isSaveLogsToDBEnabled(arcusConfiguration.isSaveLogsToDBEnabled())
                .build();
        return new WebClientV2Impl(arcusHTTPClientConfigs);
    }

    private String getErrorCode(String responseBody, String apiName) {
        if (ArcusAPIName.CREATE_BILL.name().equals(apiName) || ArcusAPIName.REFRESH_BILL.name().equals(apiName)) {
            try {
                ArcusCreateBillResponse response = objectMapper.readValue(responseBody, ArcusCreateBillResponse.class);
                String errorCode = Objects.nonNull(response.getErrorCode()) ? response.getErrorCode() : response.getCode();
                return errorCode != null ? errorCode : EMPTY_TAG;
            } catch (Exception ex) {
                log.error("getErrorCode::CreateAndRefreshBill:: Error while parsing ArcusCreateBillResponse to fetch error-code", ex);
            }
        } else {
            try {
                ArcusPayBillResponse response = objectMapper.readValue(responseBody, ArcusPayBillResponse.class);
                String errorCode = response.getCode();
                return errorCode != null ? errorCode : EMPTY_TAG;
            } catch (Exception ex) {
                log.error("getErrorCode::PayBill:: Error while parsing ArcusPayBillResponse to fetch error-code", ex);
            }
        }
        return EMPTY_TAG;
    }
}
