package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.CustomerBasicResponse;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.service.BillPayReminderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Objects;


@Component
@Slf4j
public class BillReminderProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    BillPayReminderService billPayReminderService;

    @Autowired
    ICustomerServiceClient customerServiceClient;

    CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {

        BillResponseDomainContext billResponseDomainContext = (BillResponseDomainContext) wpsResponseDomainContext;
        CustomerBillAccount customerBillAccount = billResponseDomainContext.getCustomerBillAccount();
        if (Objects.nonNull(customerBillAccount.getDueAmount()) && customerBillAccount.getDueAmount().compareTo(BigDecimal.ZERO) > 0) {
            try {
                CustomerBasicResponse customerResponse = customerServiceClient.getCustomerBasicDetailsById(customerBillAccount.getCustomerAccountId());
                Customer customer = customerMapper.mapCustomerFromBasicDTOToContext(customerResponse);
                billPayReminderService.raiseS1BillerReminder(customerBillAccount, customer);
            } catch (Exception e) {
                logger.error("Raising reminder Event task failed for : processorBillAccountId[{}], processorBillerId[{}], accountNumber[{}]. Error: {}",
                        customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getProcessorBillerId(), customerBillAccount.getAccountNumber(),
                        e.getCause(), e);
            }
        }
        return true;
    }
}
