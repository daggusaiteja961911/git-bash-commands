package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus;

import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusCreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusPayBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.ArcusGetTxnResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.CreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *  Mapping from Arcus response to generic response
 */
@Component
@Mapper
public interface ArcusMapper {
    ArcusMapper INSTANCE = Mappers.getMapper(ArcusMapper.class);

    @Mapping(target = "processorTransactionId", source = "id")
    @Mapping(target = "extCreatedAt", source = "createdAt")
    @Mapping(target = "authText", source = "ticketText", qualifiedByName = "mapAuthTextFromTicketText")
    @Mapping(target = "serialNumber", source = "ticketText", qualifiedByName = "mapSerialNumberFromTicketText")
    @Mapping(target = "pin", source = "ticketText", qualifiedByName = "mapPinFromTicketText")
    PayBillResponse getPayBillResponse(ArcusPayBillResponse arcusBillPayResponse);

    @Mapping(target = "processorBillAccountId", source = "id")
    @Mapping(target = "dueAmount", source = "balance")
    @Mapping(target = "dueAmountCurrency", source = "balanceCurrency")
    @Mapping(target = "dueInfoUpdatedAt", source = "balanceUpdatedAt")
    @Mapping(target = "processorBillerId", source = "billerId")
    CreateBillResponse getCreateBillResponse(ArcusCreateBillResponse arcusCreateBillResponse);


    @Named("mapArcusGetTxnResponse")
    default List<PayBillResponse> mapArcusGetTxnResponse(ArcusGetTxnResponse arcusGetTxnResponse) {
        List<PayBillResponse> payBillResponseList = new ArrayList<>();
        for (ArcusPayBillResponse arcusPayBillResponse : arcusGetTxnResponse.getTransactions()) {
            payBillResponseList.add(getPayBillResponse(arcusPayBillResponse));
        }
        return payBillResponseList;
    }

    @Named("mapAuthTextFromTicketText")
    default String mapAuthTextFromTicketText(String ticketText) {
        if (Objects.nonNull(ticketText)
                && ticketText.contains(WPSConstants.Biller.AUTH_TEXT_IDENTIFIER)) {
            return ticketText;
        } else {
            return null;
        }
    }

    @Named("mapSerialNumberFromTicketText")
    default String mapSerialNumberFromTicketText(String ticketText) {
        String delimiterRegex = "[|]";
        if (Objects.nonNull(ticketText) && ticketText.contains("|")) {
            String[] tokens = ticketText.split(delimiterRegex);
            for (String token : tokens) {
                if (token.contains(WPSConstants.Biller.TICKET_TEXT_SERIAL_NO)) {
                    String[] serialNo = token.split("\\:");
                    if (Objects.nonNull(serialNo[1]) && !serialNo[1].equalsIgnoreCase(""))
                        return serialNo[1].trim();
                }
            }
        }
        return null;
    }

    @Named("mapPinFromTicketText")
    default String mapPinFromTicketText(String ticketText) {
        String delimiterRegex = "[|]";
        if (Objects.nonNull(ticketText)) {
            if (ticketText.contains("|")) {
                String[] tokens = ticketText.split(delimiterRegex);
                for (String token : tokens) {
                    if (token.contains(WPSConstants.Biller.TICKET_TEXT_PIN)) {
                        String[] pin = token.split("\\:");
                        if (pin[1] != null && !pin[1].equalsIgnoreCase(""))
                            return pin[1].trim();
                    }
                }
            } else if (ticketText.contains(WPSConstants.Biller.TICKET_TEXT_PIN)) {
                String[] pin = ticketText.split("\\:");
                if (Objects.nonNull(pin[1]) && !pin[1].equalsIgnoreCase(""))
                    return pin[1].trim();
            }
        }
        return null;
    }

}
