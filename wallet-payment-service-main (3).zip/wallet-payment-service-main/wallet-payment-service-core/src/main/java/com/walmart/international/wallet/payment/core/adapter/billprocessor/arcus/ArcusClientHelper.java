package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus;

import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@Slf4j
public class ArcusClientHelper {

    private static final String ALGORITHM = "HmacSHA1";

    private static final String DELIMITER = ",";

    private static final String CONTENT_TYPE = "application/json";

    private static final ZoneId DATE_ZONE = ZoneId.of("GMT");

    private static final String DEFAULT_ACCEPT_TYPE = "application/vnd.regalii.v3.1+json";

    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss O").withLocale(Locale.US);

    private static Map<String, String> VERSION_ACCEPT_MAP;

    public static final String VERSION_V1 = "V1";
    public static final String VERSION_V2 = "V2";
    public static final String VERSION_V3 = "V3";
    public static final String VERSION_V3_MX = "V3_MX";
    public static final String VERSION_V3_WMT = "V3_WMT";
    public static final String VERSION_V6 = "V6";

    static {
        Map<String, String> versionAcceptMap = new HashMap<>();
        versionAcceptMap.put(VERSION_V1, "application/vnd.regalii.v1.5+json");
        versionAcceptMap.put(VERSION_V3, "application/vnd.regalii.v3.1+json");
        versionAcceptMap.put(VERSION_V3_WMT, "application/vnd.regalii.v3.wmt+json");
        versionAcceptMap.put(VERSION_V6, "application/vnd.regalii.v1.6+json");
        versionAcceptMap.put(VERSION_V3_MX, "application/vnd.regalii.v3.mx+json");
        VERSION_ACCEPT_MAP = Collections.unmodifiableMap(versionAcceptMap);
    }

    public static HttpHeaders getHeaders(String endpoint, String version, Map<String, String> arcusApiSecretKey) {
        String dateRequest = getDate();
        String hash = generate(null, endpoint, dateRequest, arcusApiSecretKey);
        return createFixedHeaders(version, hash, dateRequest);
    }

    private static HttpHeaders createFixedHeaders(String version, String sendHash, String date) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Accept", VERSION_ACCEPT_MAP.getOrDefault(version, DEFAULT_ACCEPT_TYPE));
        headers.set("Authorization", sendHash);
        headers.set("Content-MD5", "");
        headers.set("Date", date);
        headers.set("CASHI_CONTEXT", "ARCUS");

        return headers;
    }

    private static String generate(final String md5, final String endpoint, final String date,
                                   Map<String, String> arcusApiSecretKey) {
        final String canonicalName =
                String.join(DELIMITER, CONTENT_TYPE, md5 == null ? "" : md5, endpoint, date);
        final String fingerprint = digest(arcusApiSecretKey.get(WPSConstants.Arcus.SECRET_KEY), canonicalName);
        return "APIAuth " + arcusApiSecretKey.get(WPSConstants.Arcus.API_KEY) + ":" + fingerprint;
    }

    private static String digest(final String secret, final String message) {
        final SecretKeySpec keySpec = new SecretKeySpec(secret.getBytes(), ALGORITHM);
        try {
            final Mac mac = Mac.getInstance(ALGORITHM);
            mac.init(keySpec);
            final byte[] result = mac.doFinal(message.getBytes());
            return encode(result);
        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            log.error("Digest error in ArcusClientHelper", e);
            return null;
        }
    }

    private static String encode(final byte[] bytes) {
        return new String(java.util.Base64.getEncoder().encode(bytes));
    }

    private static String getDate() {
        return ZonedDateTime.now().withZoneSameInstant(DATE_ZONE).format(DATE_FORMAT);
    }
}
