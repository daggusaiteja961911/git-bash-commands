package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.CreateBillResponse;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

/**
 * Mapping that involves Domain Entity and DO objects
 */
@Mapper(imports = {WPSConstants.class}, uses = BillPayMapper.class)
@Component
public interface CustomerBillAccountMapper {

    CustomerBillAccountMapper INSTANCE = Mappers.getMapper(CustomerBillAccountMapper.class);

    @Mapping(target = "isSaved", source = "saved")
    @Mapping(target = "isDeleted", source = "deleted")
    @Mapping(target = "dueDate", source = "dueDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueInfoUpdatedAt", source = "dueInfoUpdatedAt", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "lastPaidBillPayTransaction", source = "lastPaidBillPayTransactionDO", qualifiedByName = "mapBillPayTransactionDOtoBillPayTransaction")
    @Mapping(target = "lastPaidDate", source = "lastPaidDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "updateDate", source = "updateDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    CustomerBillAccount customerBillAccountDOToCustomerBillAccount(CustomerBillAccountDO customerBillAccountDO);

    @Mapping(target = "isSaved", source = "saved")
    @Mapping(target = "isDeleted", source = "deleted")
    @Mapping(target = "biller", source = "billerDO", qualifiedByName = "mapBillerDOToBillerWithoutSubBillersAndBillPlans")
    @Mapping(target = "dueDate", source = "dueDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueInfoUpdatedAt", source = "dueInfoUpdatedAt", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "lastPaidBillPayTransaction", source = "lastPaidBillPayTransactionDO", qualifiedByName = "mapBillPayTransactionDOtoBillPayTransaction")
    @Mapping(target = "lastPaidDate", source = "lastPaidDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "updateDate", source = "updateDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    CustomerBillAccount customerBillAccountDOToCustomerBillAccountWithBiller(CustomerBillAccountDO customerBillAccountDO);

    @Mapping(target = "isSaved", source = "saved")
    @Mapping(target = "isDeleted", source = "deleted")
    @Mapping(target = "biller", source = "billerDO", qualifiedByName = "mapBillerDOToBillerWithoutSubBillersAndBillPlans")
    @Mapping(target = "dueDate", source = "dueDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueInfoUpdatedAt", source = "dueInfoUpdatedAt", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "lastPaidBillPayTransaction", source = "lastPaidBillPayTransactionDO", qualifiedByName = "mapBillPayTransactionDOtoBillPayTransaction")
    @Mapping(target = "lastPaidDate", source = "lastPaidDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "updateDate", source = "updateDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    void updateCustomerBillAccountFromCustomerBillAccountDO(CustomerBillAccountDO customerBillAccountDO, @MappingTarget CustomerBillAccount customerBillAccount);

    @Named("mapBillerDOToBillerWithoutSubBillersAndBillPlans")
    @Mapping(target = "billTypeValidation", ignore = true)
    @Mapping(target = "inputType", ignore = true)
    @Mapping(target = "tags", ignore = true)
    @Mapping(target = "subBillers", ignore = true)
    @Mapping(target = "billPlans", ignore = true)
    @Mapping(target = "parentBiller", qualifiedByName = "mapBillerDOToBillerWithoutSubBillersAndBillPlans")
    Biller mapBillerDOToBillerWithoutSubBillersAndBillPlans(BillerDO billerDO) throws ProcessingException;

    CustomerBillAccountDO mapCustomerBillAccountToCustomerBillAccountDOForCreateBill(CustomerBillAccount customerBillAccount);

    @Mapping(target = "saved", source = "isSaved")
    @Mapping(target = "deleted", source = "isDeleted")
    void updateCustomerBillAccountDOFromCustomerBillAccount(CustomerBillAccount customerBillAccount, @MappingTarget CustomerBillAccountDO customerBillAccountDO);

    default void updateCustomerBillAccountDOForAlreadyPaid(CustomerBillAccount customerBillAccount, CustomerBillAccountDO customerBillAccountDO) {
        updateCustomerBillAccountDOFromCustomerBillAccount(customerBillAccount, customerBillAccountDO);
        if (Objects.nonNull(customerBillAccountDO.getLastPaidBillPayTransactionDO())) { // reset the last paid bill pay txn in case of already paid
            if (Objects.isNull(customerBillAccount.getLastPaidBillPayTransaction())) {
                customerBillAccountDO.setLastPaidBillPayTransactionDO(null);
            }
        }
    }

    @Mapping(target = "processorBillAccountId", source = "createBillResponse.processorBillAccountId")
    @Mapping(target = "processorBillerId", source = "createBillResponse.processorBillerId")
    @Mapping(target = "dueAmount", source = "createBillResponse.dueAmount")
    @Mapping(target = "dueAmountCurrencyUnit", source = "createBillResponse.dueAmountCurrency")
    @Mapping(target = "dueInfoUpdatedBy", expression = "java(WPSConstants.Bills.PAYMENT_USER)")
    @Mapping(target = "dueDate", source = "createBillResponse.dueDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueInfoUpdatedAt", source = "createBillResponse.dueInfoUpdatedAt", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "status", source = "createBillResponse.status")
    @Mapping(target = "nameOnAccount", source = "createBillResponse.nameOnAccount")
    @Mapping(target = "billerId", source = "biller.billerId")
    @Mapping(target = "accountNumber", ignore = true)
    @Mapping(target = "updateDate", ignore = true)
    void mapCreateBillResponseToCustomerBillAccount(CreateBillResponse createBillResponse, BillerDO biller, @MappingTarget CustomerBillAccount customerBillAccount);

    default String map(UUID value) {
        return value.toString();
    }

    default UUID map(String value) {
        return UUID.fromString(value);
    }

}
