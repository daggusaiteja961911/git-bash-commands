package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.wallet.payment.core.domain.model.Transaction;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class TransactionResponseDomainContext extends WPSResponseDomainContext {
    Transaction transaction;
}
