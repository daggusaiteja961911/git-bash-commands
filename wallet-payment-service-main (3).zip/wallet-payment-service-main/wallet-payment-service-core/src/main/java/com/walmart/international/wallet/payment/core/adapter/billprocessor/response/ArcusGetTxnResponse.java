package com.walmart.international.wallet.payment.core.adapter.billprocessor.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response.ArcusPayBillResponse;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ArcusGetTxnResponse {
    List<ArcusPayBillResponse> transactions;
}
