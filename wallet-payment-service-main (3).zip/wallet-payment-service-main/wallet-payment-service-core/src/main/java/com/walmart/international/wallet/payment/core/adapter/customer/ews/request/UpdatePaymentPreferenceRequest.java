package com.walmart.international.wallet.payment.core.adapter.customer.ews.request;

import com.walmart.international.wallet.payment.core.constants.enums.AccountLockedState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdatePaymentPreferenceRequest {
    UUID paymentPreferenceId;
    AccountLockedState accountLockedState;
}
