package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.data.constant.enums.InputType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Biller implements Serializable {

    private static final long serialVersionUID = 453921722572901167L;

    private UUID billerId;

    private BigDecimal minAmount;

    private BigDecimal maxAmount;

    private Boolean supportsPartialPayments;

    private BigDecimal partialMinAmount;

    private String billerName;

    private String processor;

    private String processorBillerId;

    private String billType;

    private String billerType;

    private Boolean canCheckBalance;

    private Boolean partialAcceptOnlyPesos;

    private Boolean prepaid;

    private Integer hoursToFulfill;

    private String billerAccountNumber;

    private Integer vendorId;

    private String redeemURL;

    private String termsAndConditions;

    private String information;

    private byte[] metaData;

    private InputType inputType;

    private String inputPlaceholderText;

    private Biller parentBiller;

    private List<Biller> subBillers;

    private List<BillPlan> billPlans;

    private String commission;

    private String productDisplayName;

    private String disclaimer;

    private String redeemInstructions;

    private String topupCommission;

    private int arcusAuthKeyVersion;

    private Boolean enabled;

    private String imageURL;

    private String displayName;

    private String[] tags;

    private Boolean newBiller;

    private Boolean subBillerShownAsProduct;

    private int appDisplaySequenceNumber;

    private String availableTopupAmount;

    private Boolean customAmountEnabled;

    private int popularBillerSequenceNumber;

    private BillTypeValidation billTypeValidation;

    private LocalDateTime maxUpdateTimestamp;

    private String billerBehaviourCode;

    public boolean isBillTypeGiftCard() {
        return WPSConstants.Biller.BILL_TYPE_GIFT_CARD.equals(this.billType);
    }

}
