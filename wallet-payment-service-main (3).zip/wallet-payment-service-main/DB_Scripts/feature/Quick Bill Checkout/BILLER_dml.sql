--- Author: p0s03aq

-- Updating PREPAID values for billers
-- gift_card type billers
UPDATE BILLER SET PREPAID = 1, UPDATE_DATE = CURRENT_TIMESTAMP
WHERE BILL_TYPE = 'gift_card';

-- Updating INPUT_TYPE value for billers
-- Bait parent biller
UPDATE BILLER SET INPUT_TYPE = 'NUMERIC', UPDATE_DATE= CURRENT_TIMESTAMP WHERE PROCESSOR_BILLER_ID = '999988';

-- Updating INPUT_PLACEHOLDER_TEXT value for billers
-- Bait parent biller
UPDATE BILLER SET INPUT_PLACEHOLDER_TEXT = 'Número celular', UPDATE_DATE= CURRENT_TIMESTAMP WHERE PROCESSOR_BILLER_ID = '999988';

-- Telcel parent biller
UPDATE BILLER SET INPUT_PLACEHOLDER_TEXT = 'Número celular', UPDATE_DATE= CURRENT_TIMESTAMP WHERE PROCESSOR_BILLER_ID = '999989';

-- Updating metadata value for billers
-- Bait
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"phone_number","minDigits":10,"maxDigits":10}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999988';

-- Telcel
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"phone_number","minDigits":10,"maxDigits":10}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999989';

-- Cespe
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"account_number:bar_code","minDigits":8,"maxDigits":30}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999994';

-- Telnor
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"phone_number:bar_code","minDigits":10,"maxDigits":20}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999990';

-- Megacable
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"account_number:bar_code","minDigits":10,"maxDigits":26}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999991';

-- Telmex
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"phone_number:bar_code","minDigits":10,"maxDigits":20}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999992';

-- CFE
UPDATE BILLER SET METADATA = CONVERT(VARBINARY(MAX), '{"validations":[{"type":"account_number:bar_code","minDigits":12,"maxDigits":30}]}'),
UPDATE_DATE = CURRENT_TIMESTAMP
WHERE PROCESSOR_BILLER_ID = '999993';
