package com.walmart.international.wallet.payment.stepdefs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.utils.CommonUtils;
import com.walmart.international.wallet.payment.utils.Constants;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.Assert;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import static org.hamcrest.MatcherAssert.assertThat;

@Slf4j
public class StepDefCreateBill {

    Context ctx = new Context();
    ObjectMapper objectMapper = new ObjectMapper();

    public StepDefCreateBill() {
    }

    public StepDefCreateBill(Context context) {
        this.ctx = context;
    }

    CreateBillRequest createBillRequest;

    @Given("Prepare the Create Bill api request from (.+)$")
    public void prepareTheCreateBillApiRequestFromInputFile(String inputFile) throws IOException {
        createBillRequest = CommonUtils.createRequestFromFileAndInitializeApi(objectMapper, CreateBillRequest.class, createBillRequest, inputFile);
        CommonUtils.initializeApi(ctx);
    }

    @When("Submit create bill Request to API")
    public void submitCreateBillRequestToAPI() {
        ctx.response = ctx.request.body(createBillRequest).post(Constants.CREATE_BILL);
        log.info("Response is : [{}]", ctx.response.asPrettyString());
    }

    @And("Verify Response should have Attributes with Not Null Value")
    public void verifyResponseShouldHaveAttributesWithNotNullValue(Map<String, String> result) {
        assertThat(ctx.response.path("billerId"), Matchers.notNullValue());
        Assert.assertEquals(result.get("billerId"), ctx.response.path("billerId"));

        assertThat(ctx.response.path("accountNumber"), Matchers.notNullValue());
        Assert.assertEquals(result.get("accountNumber"), ctx.response.path("accountNumber"));

        assertThat(ctx.response.path("processorBillAccountId"), Matchers.notNullValue());
        assertThat(ctx.response.path("customerBillAccountId"), Matchers.notNullValue());
    }

    @And("Status in Create Bill Response should be {string}")
    public void statusInResponseShouldBe(String status) {
        Assert.assertEquals(status, ctx.response.getBody().path("status"));
    }

    @And("message in create bill response should be {string}")
    public void messageInCreateBillResponseShouldBeStatusMessage(String statusMessage) {
        Assert.assertEquals(statusMessage, ctx.response.getBody().path("statusMessage"));
    }

    @And("Status Code for createBill Should be (.+)$")
    public void statusCodeShouldBeHttpStatusCode(String statusCode) {
        Assert.assertEquals(statusCode, ctx.response.getBody().path("statusCode"));
    }

    @Then("Verify API createBill has return response {int}")
    public void verifyAPIHasReturnResponseHttpStatusCode(int statusCode) {
        Assert.assertEquals(statusCode, ctx.response.getStatusCode());
    }

    @And("Update Create Bill Request Parameter")
    public void updateCreateBillRequestParameter(Map<String, String> params) {
        if (params.containsKey("billerId")) {
            if (params.get("billerId").equals("null")) {
                createBillRequest.setBillerId(null);
            } else {
                createBillRequest.setBillerId(UUID.fromString(params.get("billerId")));
            }
        }
        if (params.containsKey("accountNumber")) {
            if (params.get("accountNumber").equals("null")) {
                createBillRequest.setAccountNumber(null);
            } else {
                createBillRequest.setAccountNumber(params.get("accountNumber"));
            }
        }
        if (params.containsKey("customerAccountId")) {
            if (params.get("customerAccountId").equals("null")) {
                createBillRequest.setCustomerAccountId(null);
            } else {
                createBillRequest.setCustomerAccountId(UUID.fromString(params.get("customerAccountId")));
            }
        }
    }
}
