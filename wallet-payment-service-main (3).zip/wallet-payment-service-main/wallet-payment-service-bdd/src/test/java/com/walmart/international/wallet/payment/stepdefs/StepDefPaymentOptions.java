package com.walmart.international.wallet.payment.stepdefs;

import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.utils.CommonUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;

@Slf4j
public class StepDefPaymentOptions {

    Context ctx = new Context();

    public StepDefPaymentOptions() {
    }

    public static final String FETCH_PAYMENT_OPTIONS = "/services/bill-payment/options";
    private FetchBillPayPaymentInstrumentsResponse response;

    public StepDefPaymentOptions(Context context) {
        this.ctx = context;
    }

    @Given("Prepare Payment Options API Request")
    public void preparePaymentOptionsAPIRequest() {
        CommonUtils.initializeApi(ctx);
    }

    @And("Set query Param")
    public void setQueryParam(Map<String, String> params) {
        ctx.request.queryParams(params);
    }

    @When("User fetch from Payment Options API")
    public void userFetchFromPaymentOptionsAPI() {
        ctx.response = ctx.request.get(FETCH_PAYMENT_OPTIONS);
        log.info("Fetch Payment Options Response:: [{}]", ctx.response.asPrettyString());
    }

    @Then("Verify Payment Options API has return response {int}")
    public void verifyPaymentOptionsAPIHasReturnResponseHttpStatusCode(int statusCode) {
        Assert.assertEquals(statusCode, ctx.response.statusCode());
    }

    @Then("^Status in Payment Options API Response should be (.*)")
    public void status_should_return_in_response(String status) {
        Assert.assertEquals(status, ctx.response.path("status"));
    }

    @And("result map for payment options should have following Non null value")
    public void resultMapShouldHaveFollowingNonNullValue(Map<String, String> result) {
        Map<String, Object> billerDetails = ctx.response.path("billerDetails");
        assertThat(billerDetails, Matchers.notNullValue());
        Assert.assertEquals(result.get("billerId"), billerDetails.get("billerId"));

        Map<String, Object> transaction = ctx.response.path("transaction");
        assertThat(transaction, Matchers.notNullValue());
        Assert.assertEquals(result.get("amount"), String.valueOf(transaction.get("amount")));
        Assert.assertEquals(result.get("amountCurrency"), transaction.get("amountCurrency"));

        ArrayList<Object> paymentOptions = ctx.response.path("paymentOptions");
        assertThat(paymentOptions, Matchers.notNullValue());
    }

    @And("Status Code for Payment Options Should be {string}")
    public void statusCodeForPaymentOptionsShouldBeFailureStatusCode(String statusCode) {
        Assert.assertEquals(statusCode, ctx.response.getBody().path("statusCode"));
    }

    @And("Verify Payment Options API statusMessage as {string}")
    public void verifyPaymentOptionsAPIStatusMessageAs(String statusMessage) {
        Assert.assertEquals(statusMessage, ctx.response.getBody().path("statusMessage"));
    }
}
