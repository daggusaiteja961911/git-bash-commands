package com.walmart.international.wallet.payment.bdd;

import com.walmart.international.digiwallet.service.strati.i8n.database.LanguageEntity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = { "com.walmart.international.wallet.payment.service.bdd",
        "com.walmart.international.wallet.payment.data.dao.entity"}, exclude = {DataSourceAutoConfiguration.class})
@EntityScan(basePackages = {"com.walmart.international.wallet.payment.data.dao.entity"}, basePackageClasses = {LanguageEntity.class})
@EnableJpaRepositories(basePackages = "com.walmart.international.wallet.payment.data.dao.repository.billpay")
public class TestApplicationBdd {

    public static void main(String[] args) {
        SpringApplication.run(TestApplicationBdd.class, args);
    }

}
