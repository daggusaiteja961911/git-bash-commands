package com.walmart.international.wallet.payment.app.controller.billpay;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.wallet.payment.app.auth.WPSAuthValidator;
import com.walmart.international.wallet.payment.app.controller.impl.billpay.BillPaymentControllerImpl;
import com.walmart.international.wallet.payment.app.service.BillPaymentService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ValidatePayBillInitRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.math.BigDecimal;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BillPaymentControllerTest {

    @Mock
    private BillPaymentService billPaymentService;

    @InjectMocks
    private BillPaymentControllerImpl billPaymentController;

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    @Mock
    private WPSAuthValidator wpsAuthValidator;

    @Mock
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(billPaymentController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void test_FetchBillPayPaymentInstruments() throws Exception {
        FetchBillPayPaymentInstrumentsRequest request = FetchBillPayPaymentInstrumentsRequest.builder()
                .customerAccountId(UUID.randomUUID())
                .billerId(UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63"))
                .amount(BigDecimal.valueOf(1000.00))
                .currencyUnit("MX")
                .accountNumber("5849349098")
                .build();

        FetchBillPayPaymentInstrumentsResponse expectedResponse = mock(FetchBillPayPaymentInstrumentsResponse.class);

        MultiValueMap<String, String> headers = getHeaders();

        //when(walletPaymentServiceConfiguration.isHeaderUserIdValidationEnabled()).thenReturn(true);
        when(billPaymentService.fetchBillPayPaymentInstruments(request, headers)).thenReturn(expectedResponse);

        FetchBillPayPaymentInstrumentsResponse actualResponse = billPaymentController.fetchBillPayPaymentInstruments(request, headers);

        mockMvc.perform(MockMvcRequestBuilders.post("/services/bill-payment/v1/options")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request))
                        .headers(HttpHeaders.readOnlyHttpHeaders(headers)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());

        verify(wpsAuthValidator).validateHeaderUserId(request.getCustomerAccountId().toString(), headers);
        verify(billPaymentService).fetchBillPayPaymentInstruments(request, headers);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void shouldTest_FetchBillPayPaymentInstrumentsWithPreselection() throws Exception {
        FetchBillPayPaymentInstrumentsRequest request = new FetchBillPayPaymentInstrumentsRequest();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        mockMvc.perform(MockMvcRequestBuilders.post("/services/bill-payment/v2/options")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .headers(HttpHeaders.readOnlyHttpHeaders(headers))
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());

        //verify(billPaymentService).fetchBillPayPaymentInstrumentsWithPreselection(any(FetchBillPayPaymentInstrumentsRequest.class), any(MultiValueMap.class));
    }

    @Test
    void shouldTest_PayBillInit() throws Exception {
        PayBillInitRequest request = new PayBillInitRequest();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        mockMvc.perform(MockMvcRequestBuilders.post("/services/bill-payment/v1/init")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .headers(HttpHeaders.readOnlyHttpHeaders(headers))
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());

        //verify(billPaymentService).payBillInit(any(PayBillInitRequest.class), any(MultiValueMap.class));
    }

    @Test
    void shouldTest_cancelPayBillInit() throws Exception {
        CancelPayBillInitRequest request = new CancelPayBillInitRequest();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        mockMvc.perform(MockMvcRequestBuilders.post("/services/bill-payment/v1/cancel-init")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .headers(HttpHeaders.readOnlyHttpHeaders(headers))
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());

        //verify(billPaymentService).cancelPayBillInit(any(CancelPayBillInitRequest.class), any(MultiValueMap.class));

    }

    @Test
    void shouldTest_validatePayBillInit() throws Exception {
        ValidatePayBillInitRequest request = new ValidatePayBillInitRequest();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("ContentType", MediaType.APPLICATION_JSON.toString());
        headers.set("Accept", MediaType.APPLICATION_JSON.toString());
        headers.set("wm_qos.correlation_id", UUID.randomUUID().toString());
        headers.set("wm_consumer.id", "123456");

        mockMvc.perform(MockMvcRequestBuilders.post("/services/bill-payment/v1/validate-init")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .headers(HttpHeaders.readOnlyHttpHeaders(headers))
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());

        //verify(billPaymentService).validatePayBillInit(any(ValidatePayBillInitRequest.class), any(MultiValueMap.class));
    }

    public static MultiValueMap<String, String> getHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("ContentType", MediaType.APPLICATION_JSON.toString());
        headers.set("Accept", MediaType.APPLICATION_JSON.toString());
        headers.set("wm_qos.correlation_id", UUID.randomUUID().toString());
        headers.set("wm_consumer.id", UUID.randomUUID().toString());
        return headers;
    }

}