package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.app.MockUtils;
import com.walmart.international.wallet.payment.app.service.impl.mapper.BillerDTOMapper;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerBehaviourCodeUpdateRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.*;

import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BillerServiceImplTest {

    @Mock
    private BillerCoreService billerCoreService;

    @Spy
    @InjectMocks
    private BillerServiceImpl billerServiceImpl;

    @Mock
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @BeforeEach
    public void setUp() {
       ReflectionTestUtils.setField(billerServiceImpl, "walletPaymentServiceConfiguration", walletPaymentServiceConfiguration);
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void shouldTest_GetBillerCategories_EmptyList() {
        int version = 1;
        when(billerCoreService.getBillerCategoriesList(version)).thenReturn(Collections.emptyList());

        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(version);

        assertNotNull(billerCategoriesResponse);
        assertTrue(billerCategoriesResponse.getCategories().isEmpty());
    }
    @Test
    void shouldTest_GetBillerCategoriesFromCache() {
        BillerDTOMapper mapper = mock(BillerDTOMapper.class);
        List<BillerCategory> categories = Collections.singletonList(new BillerCategory());
        Date lastUpdatedAt = new Date();

        when(billerCoreService.getBillerCategoriesList(1)).thenReturn(categories);
        when(billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp()).thenReturn(lastUpdatedAt);
        when(mapper.mapBillerCategoriesListToBillerCategoryDTOList(categories)).thenReturn(Collections.emptyList());

        ReflectionTestUtils.setField(billerServiceImpl, "billerCoreService", billerCoreService);
        ReflectionTestUtils.setField(billerServiceImpl, "billerDTOMapper", mapper);

        BillerCategoriesResponse response = billerServiceImpl.getBillerCategories(1);

        assertNotNull(response);
        assertEquals(lastUpdatedAt, response.getBillerCategoryDataLastUpdatedAt());
    }

    @Test
    void shouldTest_GetPopularBillers_Exception() throws BusinessValidationException {
        when(billerCoreService.getPopularBillers()).thenThrow(new BusinessValidationException("Error"));

        assertThrows(BusinessValidationException.class, () -> {
            billerServiceImpl.getPopularBillers();
        });
    }
    @Test
    void shouldTest_GetPopularBillers() throws BusinessValidationException {
        BillerDTOMapper mapper = mock(BillerDTOMapper.class);
        List<Biller> billers = Collections.singletonList(new Biller());

        when(billerCoreService.getPopularBillers()).thenReturn(billers);
        when(mapper.mapBillerEntityListToGetPopularBillersBillerDTOList(billers)).thenReturn(Collections.emptyList());

        ReflectionTestUtils.setField(billerServiceImpl, "billerCoreService", billerCoreService);
        ReflectionTestUtils.setField(billerServiceImpl, "billerDTOMapper", mapper);

        PopularBillersResponse response = billerServiceImpl.getPopularBillers();

        assertNotNull(response);
        assertTrue(response.getBillers().isEmpty());
    }

    @Test
    void shouldTest_GetBillerById_NullProcessorId() throws ApplicationException {
        UUID billerId = UUID.randomUUID();
        String processorBillerId = null;
        when(billerCoreService.fetchAndCacheBillerData(billerId, null)).thenReturn(new Biller());

        BillerByIdResponse billerByIdResponse = billerServiceImpl.getBillerById(billerId, processorBillerId);
        assertNotNull(billerByIdResponse);
    }
    @Test
    void shouldTest_GetBillerById() throws ApplicationException {
        UUID billerId = UUID.randomUUID();
        String processorBillerId = "123";
        Biller biller = MockUtils.getBiller();
        biller.setMaxUpdateTimestamp(LocalDateTime.now());

        BillerDTOMapper mapper = mock(BillerDTOMapper.class);

        when(billerCoreService.fetchAndCacheBillerData(billerId, processorBillerId)).thenReturn(biller);
        when(mapper.mapBillerInformation(biller)).thenReturn(new BillerInformation());
        when(mapper.mapBillerEntitiesToDTO(anyList())).thenReturn(Collections.emptyList());

        ReflectionTestUtils.setField(billerServiceImpl, "billerCoreService", billerCoreService);
        ReflectionTestUtils.setField(billerServiceImpl, "billerDTOMapper", mapper);

        BillerByIdResponse response = billerServiceImpl.getBillerById(billerId, processorBillerId);

        assertNotNull(response);
        assertNotNull(response.getLastUpdatedAt());
        assertTrue(response.getBillers().isEmpty());
        verify(billerCoreService).fetchAndCacheBillerData(billerId, processorBillerId);
    }
    @Test
    void shouldTest_GetBillerByIdWithNull_UUID_And_ProcessorBillerId() {
        UUID billerId = null;
        String processorBillerId = null;
        BillerByIdResponse response = billerServiceImpl.getBillerById(billerId, processorBillerId);

        assertNull(response);
    }

    @Test
    void shouldTest_GetBillerDataUpdateInfo() {
        Set<String> processorBillerIds = new HashSet<>(Collections.singletonList("processorId"));
        Date lastUpdatedAt = new Date();

        BillerDTOMapper mapper = mock(BillerDTOMapper.class);

        when(billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp()).thenReturn(lastUpdatedAt);
        when(billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp()).thenReturn(lastUpdatedAt);
        when(mapper.mapBillerDataLastUpdatedAtMap(anyMap())).thenReturn(Collections.emptyList());

        BillerDataUpdateInfoRequest request = new BillerDataUpdateInfoRequest();
        ReflectionTestUtils.setField(request, "billerIds", processorBillerIds);

        ReflectionTestUtils.setField(billerServiceImpl, "billerCoreService", billerCoreService);
        ReflectionTestUtils.setField(billerServiceImpl, "billerDTOMapper", mapper);

        BillerDataUpdateInfoResponse response = billerServiceImpl.getBillerDataUpdateInfo(request);

        assertNotNull(response);
        assertEquals(lastUpdatedAt, response.getBillerCategoryDataLastUpdatedAt());
    }

    @Test
    void shouldTest_ReloadCacheForBillerCategoryData() {
        BillerDataCacheReloadRequest request = mock(BillerDataCacheReloadRequest.class);
        when(request.isBillerCategoryDataReloadRequired()).thenReturn(true);
        when(request.isBillerIncorrectSearchKeywordsCacheUpdateRequired()).thenReturn(true);
        when(request.getProcessorBillerIds()).thenReturn(Collections.emptySet());

        when(walletPaymentServiceConfiguration.getBillerCategoryVersions()).thenReturn(Collections.singletonList(1));


        billerServiceImpl.reloadCacheForBillerData(request);

        verify(billerCoreService).reloadCacheForBillerCategoryData(anyList());
    }
    @Test
    void shouldTest_ReloadCacheForBillerData() {
        BillerDataCacheReloadRequest request = new BillerDataCacheReloadRequest();
        ReflectionTestUtils.setField(request, "billerCategoryDataReloadRequired", true);
        ReflectionTestUtils.setField(request, "billerIncorrectSearchKeywordsCacheUpdateRequired", true);
        ReflectionTestUtils.setField(request, "processorBillerIds", new HashSet<>(Arrays.asList("processor_biller_id_1", "processor_biller_id_2")));

        BillerDataCacheAlterResponse response = BillerDataCacheAlterResponse.builder()
                .processorBillerIdsToRetry(null)
                .build();

        BillerDataCacheAlterResponse actualResponse = billerServiceImpl.reloadCacheForBillerData(request);

        assertEquals(response.getProcessorBillerIdsToRetry(), actualResponse.getProcessorBillerIdsToRetry());
    }

    @Test
    void shouldTest_EvictCacheForSpecificBillerIds() {
        ReflectionTestUtils.setField(billerServiceImpl, "billerCoreService", billerCoreService);

        Set<String> processorBillerIds = new HashSet<>(Arrays.asList("biller1", "biller2"));
        BillerDataCacheEvictRequest request = new BillerDataCacheEvictRequest();

        ReflectionTestUtils.setField(request, "processorBillerIds", processorBillerIds);

        Map<String, Set<String>> retryProcessorBillerIds = new HashMap<>();
        when(billerCoreService.evictCacheForBillerAndUpdateTimestampData(anyList(), anyList())).thenReturn(retryProcessorBillerIds);

        BillerDataCacheAlterResponse response = billerServiceImpl.evictCacheForBillerData(request);

        assertNotNull(response);

    }
    @Test
    void shouldTest_EvictCacheForBillerData() {
        BillerDataCacheEvictRequest request = new BillerDataCacheEvictRequest();
        ReflectionTestUtils.setField(request, "processorBillerIds", new HashSet<>(Arrays.asList("1", "2")));
        ReflectionTestUtils.setField(request, "evictCacheForAllBillers", true);

        when(billerCoreService.getBillerIdsAndProcessorBillerIdsOfBillersWhoseDataIsCached()).thenReturn(anyList());

        BillerDataCacheAlterResponse response = billerServiceImpl.evictCacheForBillerData(request);

        assertEquals(new HashSet<>(Arrays.asList()), response.getProcessorBillerIdsToRetry());
    }

    @Test
    void shouldTest_GetBillerIncorrectSearchKeywords() throws ApplicationException {
        HashMap<String, List<String>> keywordsMap = new HashMap<>();
        keywordsMap.put("category1", Arrays.asList("keyword1", "keyword2"));
        Date lastUpdatedAt = new Date();

        when(billerCoreService.fetchBillerIncorrectSearchKeywordMap()).thenReturn(keywordsMap);
        when(billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp()).thenReturn(lastUpdatedAt);

        BillerIncorrectSearchKeywordsResponse response = billerServiceImpl.getBillerIncorrectSearchKeywords();

        assertNotNull(response);
        assertFalse(response.getBillerIncorrectSearchKeywords().isEmpty());
        assertEquals(lastUpdatedAt, response.getBillerIncorrectSearchKeywordsLastUpdatedAt());

    }
    @Test
    void shouldTest_GetBillerIncorrectSearchKeywords_emptymapHandling() {
        when(billerCoreService.fetchBillerIncorrectSearchKeywordMap()).thenReturn(new HashMap<>());
        when(billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp()).thenReturn(new Date());

        BillerIncorrectSearchKeywordsResponse response = billerServiceImpl.getBillerIncorrectSearchKeywords();

        assertNotNull(response);
        assertTrue(response.getBillerIncorrectSearchKeywords().isEmpty());
    }

    @Test
    void shouldTest_FetchesBillerIncorrectSearchKeywordsMapSuccessfully() throws ApplicationException {
        HashMap<String, List<String>> mockMap = new HashMap<>();
        mockMap.put("incorrectKeyword", Arrays.asList("Biller1", "Biller2"));
        when(billerCoreService.fetchBillerIncorrectSearchKeywordMap()).thenReturn(mockMap);
        when(billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp()).thenReturn(new Date());

        BillerIncorrectSearchKeywordsResponse response = billerServiceImpl.getBillerIncorrectSearchKeywords();

        assertNotNull(response);
        assertEquals(1, response.getBillerIncorrectSearchKeywords().size());
        assertTrue(response.getBillerIncorrectSearchKeywords().containsKey("incorrectKeyword"));
    }

    @Test
    void shouldTest_updateBehaviourCodeForAllBillers() {
        BillerBehaviourCodeUpdateRequest request = mock(BillerBehaviourCodeUpdateRequest.class);
        request.setUpdateBehaviourCodeForAllBillers(true);
        Map<String, String> expectedMap = new HashMap<>();
        expectedMap.put("biller1", "code1");
        when(request.isUpdateBehaviourCodeForAllBillers()).thenReturn(true);
        when(billerCoreService.updateBehaviourCodeForAllBillersAndCreateBillerIdToBBCMap()).thenReturn(expectedMap);

        Map<String, String> result = billerServiceImpl.updateBillerBehaviourCode(request);

        assertNotNull(result);
        assertEquals(expectedMap, result);
        assertEquals(1, result.size());
        verify(billerCoreService).updateBehaviourCodeForAllBillersAndCreateBillerIdToBBCMap();
    }

    @Test
    void shouldTest_updateBillerBehaviourCodeForEmpty() {
        BillerBehaviourCodeUpdateRequest request = mock(BillerBehaviourCodeUpdateRequest.class);
        request.setBillerIds(Set.of(UUID.randomUUID(), UUID.randomUUID()));
        request.setUpdateBehaviourCodeForAllBillers(false);

        Map<String, String> result = billerServiceImpl.updateBillerBehaviourCode(request);

        assertEquals(Collections.emptyMap(), result);
        verify(billerCoreService, never()).updateBehaviourCodeForAllBillersAndCreateBillerIdToBBCMap();
        verify(billerCoreService, never()).updateBehaviourCodeForGivenBillerIdsAndCreateBillerIdToBBCMap(anySet());
    }

}