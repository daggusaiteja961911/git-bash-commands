package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.wallet.payment.app.MockUtils;
import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.dto.request.billpay.*;
import com.walmart.international.wallet.payment.dto.response.billpay.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.MultiValueMap;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BillPaymentServiceImplTest {

    @Mock
    private WalletServiceRouter walletServiceRouter;

    @Spy
    @InjectMocks
    private BillPaymentServiceImpl billPaymentService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void shouldTest_FetchBillPayPaymentInstrumentSuccess() {
        FetchBillPayPaymentInstrumentsRequest request = MockUtils.getFetchBillPayPaymentInstrumentsRequest();
        MultiValueMap<String, String> headers = MockUtils.getHeaders();
        FetchBillPayPaymentInstrumentsResponse expectedResponse = mock(FetchBillPayPaymentInstrumentsResponse.class);

        when(walletServiceRouter.fetchBillPayPaymentInstruments(request, headers)).thenReturn(expectedResponse);

        FetchBillPayPaymentInstrumentsResponse response = billPaymentService.fetchBillPayPaymentInstruments(request, headers);

        assertEquals(expectedResponse, response);
        assertEquals("MX", request.getCurrencyUnit());
        assertEquals(BigDecimal.valueOf(1000.00), request.getAmount());
    }

    @Test
    void shouldTest_FetchBillPayPaymentInstrumentWithPreselection() {
        FetchBillPayPaymentInstrumentsRequest request = MockUtils.getFetchBillPayPaymentInstrumentsRequest();
        MultiValueMap<String, String> headers = MockUtils.getHeaders();
        FetchBillPayPaymentInstrumentsWithPreselectionResponse expectedResponse = mock(FetchBillPayPaymentInstrumentsWithPreselectionResponse.class);

        when(walletServiceRouter.fetchBillPayPaymentInstrumentsWithPreselection(request, headers)).thenReturn(expectedResponse);

        FetchBillPayPaymentInstrumentsWithPreselectionResponse response = billPaymentService.fetchBillPayPaymentInstrumentsWithPreselection(request, headers);

        assertEquals(expectedResponse, response);
        assertEquals("5849349098", request.getAccountNumber());
        assertNotNull(request);
    }

    @Test
    void shouldTest_BillPayInitSuccess() {
        PayBillInitRequest request = MockUtils.getPayBillInitRequest();
        MultiValueMap<String, String> headers = MockUtils.getHeaders();
        PayBillInitResponse expectedResponse = mock(PayBillInitResponse.class);

        when(walletServiceRouter.payBillInit(request, headers)).thenReturn(expectedResponse);

        PayBillInitResponse response = billPaymentService.payBillInit(request, headers);

        assertEquals("89475", request.getCustomerBillDetails().getProcessorBillAccountId());
        assertEquals("82459458", request.getCustomerBillDetails().getAccountNumber());
        assertEquals(expectedResponse, response);
    }

    @Test
    void shouldTest_ReconcilePendingBillPayTxn() {
        ReconcilePendingBillPayTxnRequest request = MockUtils.getReconcilePendingBillPayTxnRequest();
        MultiValueMap<String, String> headers = MockUtils.getHeaders();
        ReconcilePendingBillPayTxnResponse expectedResponse = mock(ReconcilePendingBillPayTxnResponse.class);

        when(walletServiceRouter.reconcilePendingBillPayTxn(request, headers)).thenReturn(expectedResponse);

        ReconcilePendingBillPayTxnResponse response = billPaymentService.reconcilePendingBillPayTxn(request, headers);


        assertEquals(expectedResponse, response);
        assertTrue(response instanceof ReconcilePendingBillPayTxnResponse);
    }
    @Test
    void shouldTest_CancelPayBillInit() {
        CancelPayBillInitRequest request = MockUtils.getCancelPayBillInitRequest();
        MultiValueMap<String, String> headers = MockUtils.getHeaders();
        CancelPayBillInitResponse expectedResponse = mock(CancelPayBillInitResponse.class);

        when(walletServiceRouter.cancelPayBillInit(request, headers)).thenReturn(expectedResponse);

        CancelPayBillInitResponse response = billPaymentService.cancelPayBillInit(request, headers);

        assertEquals("abort reason", request.getAbortReason());
        assertEquals(expectedResponse, response);
        assertNotNull(request);
        assertTrue(response instanceof CancelPayBillInitResponse);

    }

    @Test
    void shouldTest_ValidatePayBillInitSuccess() {
        ValidatePayBillInitRequest request = MockUtils.getValidatePayBillInitRequest();
        MultiValueMap<String, String> headers = MockUtils.getHeaders();
        ValidatePayBillInitResponse expectedResponse = mock(ValidatePayBillInitResponse.class);

        when(walletServiceRouter.validatePayBillInit(request, headers)).thenReturn(expectedResponse);

        ValidatePayBillInitResponse response = billPaymentService.validatePayBillInit(request, headers);

        assertEquals(expectedResponse, response);
        assertNotNull(request);
        assertTrue(response instanceof ValidatePayBillInitResponse);
    }

}