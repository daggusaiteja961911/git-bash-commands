package com.walmart.international.wallet.payment.app.controller.billpay;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.app.MockUtils;
import com.walmart.international.wallet.payment.app.controller.impl.billpay.BillerControllerImpl;
import com.walmart.international.wallet.payment.app.service.BillerPromotionService;
import com.walmart.international.wallet.payment.app.service.BillerService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.*;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.text.SimpleDateFormat;
import java.util.*;

@ExtendWith(MockitoExtension.class)
class BillerControllerTest {

    @Mock
    private BillerService billerService;

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BillerPromotionService billerPromotionService;

    @Mock
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @InjectMocks
    private BillerControllerImpl billerController;


    @Test
    void shouldGetBillerCategories_WithData() {
        BillerCategoriesResponse billerCategoriesResponse = MockUtils.getBillerCategoriesResponse();

        when(billerService.getBillerCategories(anyInt())).thenReturn(billerCategoriesResponse);

        BillerCategoriesResponse response = billerController.getBillerCategories(1);

        assertNotNull(response);
        assertEquals("Recarga celular", response.getCategories().get(0).getCategoryName());
        assertEquals(true, response.getCategories().get(0).getHasEnabledBillers());
    }

    @Test
    void shouldGetPopularBillers_WithData() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();

        GetPopularBillersBillerDTO billerDTO = GetPopularBillersBillerDTO.builder()
                .billerId(UUID.randomUUID())
                .processorBillerId("999987")
                .build();
        PopularBillersResponse popularBillersResponse = PopularBillersResponse.builder()
                .billers(Collections.singletonList(billerDTO))
                .build();

        when(billerService.getPopularBillers()).thenReturn(popularBillersResponse);

        mockMvc.perform(get("/services/biller-data/v1/biller/popular")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.billers[0].billerId").exists())
                .andExpect(jsonPath("$.billers[0].processorBillerId").value("999987"));
    }

    @Test
     void shouldTestGetBillerById() {
        UUID billerId = UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63");
        String processorBillerId = "29866";

        BillerByIdResponse mockResponse = MockUtils.getBillerByIdResponse();


        when(billerService.getBillerById(billerId, processorBillerId)).thenReturn(mockResponse);

        BillerByIdResponse response = billerController.getBillerById(billerId, processorBillerId);

        assertNotNull(response);
        assertEquals(mockResponse.getBillerInformation().getDisplayName(), response.getBillerInformation().getDisplayName());
        assertEquals(mockResponse.getBillers().size(), response.getBillers().size());
        assertEquals(mockResponse.getBillers().get(0).getBillPlans().get(0).getPlan(), response.getBillers().get(0).getBillPlans().get(0).getPlan());

        verify(billerService, times(1)).getBillerById(billerId, processorBillerId);

    }
    @Test
     void shouldGetBillerDataUpdateInfo() {
        Set<UUID> billerIds = Set.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID());

        BillerDataUpdateInfoRequest request = new BillerDataUpdateInfoRequest();
        BillerDataUpdateInfoResponse response = BillerDataUpdateInfoResponse.builder()
                .billerCategoryDataLastUpdatedAt(new Date())
                .billerIncorrectSearchKeywordsLastUpdatedAt(new Date())
                .billerPlanDetailUpdateInfoList(MockUtils.getBillerPlanDetailUpdateInfolist())
                .build();

        when(billerService.getBillerDataUpdateInfo(request)).thenReturn(response);

        BillerDataUpdateInfoResponse result = billerController.getBillerDataUpdateInfo(request);

        assertEquals(response, result);
        assertEquals(1, response.getBillerPlanDetailUpdateInfoList().size());
        assertNotNull(response.getBillerPlanDetailUpdateInfoList().get(0).getBillerId());
    }

    @Test
     void shouldGetReloadCacheForBillerData() throws ApplicationException {
        BillerDataCacheReloadRequest request = new BillerDataCacheReloadRequest();
        BillerDataCacheAlterResponse response = MockUtils.getBillerDataCacheAlterResponse();

        when(billerService.reloadCacheForBillerData(any(BillerDataCacheReloadRequest.class))).thenReturn(response);

        BillerDataCacheAlterResponse result = billerController.reloadCacheForBillerData(request);

        assertNotNull(response.getProcessorBillerIdsToRetry());
        assertEquals(response, result);

        verify(billerService, times(1)).reloadCacheForBillerData(any(BillerDataCacheReloadRequest.class));
    }

    @Test
     void shouldGetEvictCacheForBillerData() {
        BillerDataCacheEvictRequest request = new BillerDataCacheEvictRequest();
        BillerDataCacheAlterResponse response = MockUtils.getBillerDataCacheAlterResponse();

        when(billerService.evictCacheForBillerData(any(BillerDataCacheEvictRequest.class))).thenReturn(response);

        BillerDataCacheAlterResponse result = billerController.evictCacheForBillerData(request);

        assertEquals(response, result);
        assertNotNull(response.getBillerIdsToRetry());
        verify(billerService, times(1)).evictCacheForBillerData(any(BillerDataCacheEvictRequest.class));
    }
    @Test
     void shouldTest_GetBillerPromotions() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();
        String billerCategoryIds = "b09f4834-9ae8-11ec-b0bc-fa163e4fd434";
        String processorBillerIds = "999988";

        Map<String, List<BillerPromotionDTO>> promotionMap = new HashMap<>();
        promotionMap.put("category", Arrays.asList(
                BillerPromotionDTO.builder()
                        .campaignId(UUID.randomUUID())
                        .description("promotion")
                        .promotionText("55% off")
                        .startDate("2022-01-21")
                        .endDate("2022-09-13")
                        .build()
        ));

        BillerPromotionsResponse billerPromotionsResponse = BillerPromotionsResponse.builder()
                .promotionMap(promotionMap)
                .build();

        when(billerPromotionService.getBillerPromotions(billerCategoryIds, processorBillerIds, 0)).thenReturn(billerPromotionsResponse);
        BillerPromotionsResponse response = billerController.getBillerPromotions(billerCategoryIds, processorBillerIds);

        mockMvc.perform(get("/services/biller-data/v1/biller/promotions")
                        .param("billerCategoryIds", billerCategoryIds)
                        .param("processorBillerIds", processorBillerIds)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(jsonPath("$.promotionMap.category[0].description").value("promotion"))
                .andExpect(jsonPath("$.promotionMap.category[0].endDate").value("2022-09-13"))
                .andExpect(jsonPath("$.promotionMap.category[0].promotionText").value("55% off"));


        assertNotNull(response);

        verify(billerPromotionService, times(2)).getBillerPromotions(billerCategoryIds, processorBillerIds, walletPaymentServiceConfiguration.getBillerCategoryVersionForPromotions());
    }

    @Test
     void shouldGetBillerIncorrectSearchKeywords_WithData() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();

        HashMap<String, List<String>> incorrectKeywords = new HashMap<>();
        incorrectKeywords.put("Teel", List.of("Telcel", "Telmex"));
        incorrectKeywords.put("Telce", List.of("Telcel"));
        Date lastUpdated = new Date();

        BillerIncorrectSearchKeywordsResponse response = BillerIncorrectSearchKeywordsResponse.builder()
                .billerIncorrectSearchKeywords(incorrectKeywords)
                .billerIncorrectSearchKeywordsLastUpdatedAt(lastUpdated)
                .build();

        when(billerService.getBillerIncorrectSearchKeywords()).thenReturn(response);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String formattedDate = sdf.format(lastUpdated);

        mockMvc.perform(get("/services/biller-data/incorrect-search-keywords"))
                .andExpect(status().isOk())
                .andExpect(content().json("{\"billerIncorrectSearchKeywords\":{\"Teel\":[\"Telcel\",\"Telmex\"],\"Telce\":[\"Telcel\"]},\"billerIncorrectSearchKeywordsLastUpdatedAt\":\"" + formattedDate + "\"}"));
    }

    //edge cases

    @Test
     void testGetBillerById_endpoints_with_mockmvc() throws Exception {
        UUID billerId = UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63");
        String processorBillerId = "29866";

        BillerByIdResponse mockResponse = MockUtils.getBillerByIdResponse();

        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();
        // Mocking the response
        when(billerService.getBillerById(billerId, processorBillerId)).thenReturn(mockResponse);

        mockMvc.perform(get("/services/biller-data/v1/biller/{billerId}", billerId)
                        .param("processorBillerId", processorBillerId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.billerInformation.displayName").value("Bait"))
                .andExpect(jsonPath("$.billers[0].displayName").value("Bait"))
                .andExpect(jsonPath("$.billers[0].billPlans[0].plan").value("Tiempo Aire"))
                .andExpect(jsonPath("$.billers[0].billPlans[0].billDetails[0].name").value("Mi Bait 30"))
                .andDo(print());

        verify(billerService, times(1)).getBillerById(billerId, processorBillerId);
    }

    @Test
     void shouldTestGetBillerById_InvalidBillerId_Format() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();

        String invalidBillerId = "invalid-uuid";

        mockMvc.perform(get("/services/biller-data/v1/biller/" + invalidBillerId))
                .andExpect(status().isBadRequest());
    }

    @Test
     void shouldTest_RejectedGetPopularBillers_WithInvalidAcceptHeader() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();

        mockMvc.perform(get("/services/biller-data/v1/biller/popular")
                        .accept(MediaType.TEXT_PLAIN))
                .andExpect(status().isNotAcceptable());
    }

    @Test
     void shouldTest_ReturnBadRequest_WhenParameterHasInvalidFormat_GetBillerCategories() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(billerController).build();

        mockMvc.perform(get("/services/biller-data/v1/biller/categories")
                        .param("billerCategoryVersion", "invalid_version")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

}