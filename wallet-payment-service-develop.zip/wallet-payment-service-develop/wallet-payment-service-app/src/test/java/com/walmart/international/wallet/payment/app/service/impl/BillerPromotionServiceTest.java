package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import com.walmart.international.wallet.payment.core.service.BillerPromotionCoreService;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BillerPromotionServiceTest {

    @Spy
    @InjectMocks
    private BillerPromotionServiceImpl billerPromotionService;

    @Mock
    private BillerPromotionCoreService billerPromotionCoreService;

    @BeforeEach
    public void setup() {
        ReflectionTestUtils.setField(billerPromotionService, "billerPromotionCoreService", billerPromotionCoreService);
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void shouldTest_RetrievesPromotionsForValidIds() {
        String billerCategoryIds = String.valueOf(UUID.randomUUID());
        String processorBillerIds = "validProcessor";
        int billerCategoryVersion = 1;

        Map<String, List<BillerPromotion>> mockPromotions = new HashMap<>();
        mockPromotions.put("validProcessor", List.of(new BillerPromotion()));
        when(billerPromotionCoreService.getAllPromotionsForPromotionCategory(billerCategoryIds, processorBillerIds, billerCategoryVersion)).thenReturn(mockPromotions);

        BillerPromotionsResponse response = billerPromotionService.getBillerPromotions(billerCategoryIds, processorBillerIds, billerCategoryVersion);

        assertNotNull(response);
        assertFalse(response.getPromotionMap().isEmpty());
    }

    @Test
    void shouldTest_HandlesUnexpectedException() {
        when(billerPromotionCoreService.getAllPromotionsForPromotionCategory(anyString(), anyString(), anyInt())).thenThrow(new RuntimeException("Unexpected exception"));

        assertThrows(Exception.class, () -> {
            billerPromotionService.getBillerPromotions(String.valueOf(UUID.randomUUID()), "billerIds", 1);
        });
    }


}