package com.walmart.international.wallet.payment.app;

import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.dto.request.billpay.*;
import com.walmart.international.wallet.payment.dto.response.billpay.*;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

public class MockUtils {
    public static MultiValueMap<String, String> getHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("ContentType", MediaType.APPLICATION_JSON.toString());
        headers.set("Accept", MediaType.APPLICATION_JSON.toString());
        headers.set("wm_qos.correlation_id", UUID.randomUUID().toString());
        headers.set("wm_consumer.id", UUID.randomUUID().toString());
        return headers;
    }

    public static FetchBillPayPaymentInstrumentsRequest getFetchBillPayPaymentInstrumentsRequest() {
        return FetchBillPayPaymentInstrumentsRequest.builder()
                .customerAccountId(UUID.randomUUID())
                .billerId(UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63"))
                .amount(BigDecimal.valueOf(1000.00))
                .currencyUnit("MX")
                .accountNumber("5849349098")
                .build();
    }

    public static PayBillInitRequest getPayBillInitRequest() {
        PayBillInitRequest payBillInitRequest = new PayBillInitRequest();
        payBillInitRequest.setCustomerAccountId(UUID.randomUUID());
        payBillInitRequest.setCustomerBillDetails(getCustomerBillDetails());
        return payBillInitRequest;
    }

    public static CustomerBillDetails getCustomerBillDetails() {
        return CustomerBillDetails.builder()
                .billDetailId(UUID.randomUUID())
                .accountNumber("82459458")
                .billDetailId(UUID.randomUUID())
                .processorBillAccountId("89475")
                .build();
    }

    public static ReconcilePendingBillPayTxnRequest getReconcilePendingBillPayTxnRequest() {
        ReconcilePendingBillPayTxnRequest reconcilePendingBillPayTxnRequest = new ReconcilePendingBillPayTxnRequest();
        reconcilePendingBillPayTxnRequest.setTxnId(UUID.randomUUID());
        return reconcilePendingBillPayTxnRequest;
    }

    public static ValidatePayBillInitRequest getValidatePayBillInitRequest() {
        ValidatePayBillInitRequest validatePayBillInitRequest = new ValidatePayBillInitRequest();
        validatePayBillInitRequest.setBillPayTransactionId(UUID.randomUUID());
        validatePayBillInitRequest.setCustomerAccountId(UUID.randomUUID());
        return validatePayBillInitRequest;
    }

    public static CancelPayBillInitRequest getCancelPayBillInitRequest() {
        CancelPayBillInitRequest cancelPayBillInitRequest = new CancelPayBillInitRequest();
        cancelPayBillInitRequest.setAbortReason("abort reason");
        cancelPayBillInitRequest.setBillPayTransactionId(UUID.randomUUID());
        cancelPayBillInitRequest.setCustomerAccountId(UUID.randomUUID());
        return cancelPayBillInitRequest;
    }

    public static Biller getBiller() {
        return Biller.builder()
                .billerId(UUID.randomUUID())
                .processorBillerId("35")
                .billerName("CFE")
                .productDisplayName("ABC")
                .parentBiller(
                        Biller.builder()
                                .billerId(UUID.randomUUID())
                                .processorBillerId("37")
                                .productDisplayName("XYZ")
                                .build()
                )
                .build();
    }

    public static List<BillerPlanDetailUpdateInfo> getBillerPlanDetailUpdateInfolist() {
        BillerPlanDetailUpdateInfo billerPlanDetailUpdateInfo = BillerPlanDetailUpdateInfo.builder()
                .billerId(UUID.randomUUID())
                .lastUpdatedAt(LocalDateTime.now())
                .build();
        List<BillerPlanDetailUpdateInfo> billerPlanDetailUpdateInfoList = new ArrayList<>();
        billerPlanDetailUpdateInfoList.add(billerPlanDetailUpdateInfo);
        return billerPlanDetailUpdateInfoList;
    }
    public static BillerPromotionDTO getBillerPromotionDTO() {
        return BillerPromotionDTO
                .builder()
                .campaignId(UUID.randomUUID())
                .promotionText("55% - Promotion")
                .description("Cashi - Promotion")
                .build();
    }
    public static BillerDataCacheAlterResponse getBillerDataCacheAlterResponse() {
        return BillerDataCacheAlterResponse
                .builder()
                .processorBillerIdsToRetry(Set.of("999988", "959967", "719423"))
                .billerIdsToRetry(Set.of(String.valueOf(UUID.randomUUID()), String.valueOf(UUID.randomUUID()), String.valueOf(UUID.randomUUID())))
                .build();
    }

    private static List<BillDetailDTO> billDetailDTOS() {
        BillDetailDTO billDetailDTO = BillDetailDTO
                .builder()
                .billDetailId(UUID.randomUUID())
                .name("Cashi Wallet")
                .description("Bill Detail")
                .build();
        return Collections.singletonList(billDetailDTO);
    }

    private static List<BillPlanDTO> billPlanDTOS() {
        BillPlanDTO billPlanDTO = BillPlanDTO
                .builder()
                .plan("plans")
                .billDetails(billDetailDTOS())
                .build();
        return Collections.singletonList(billPlanDTO);
    }

    private static List<BillerByIdDTO> billerByIdDTOS() {
        BillerByIdDTO billerByIdDTO = BillerByIdDTO
                .builder()
                .billerId(UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63"))
                .processorBillerId("29866")
                .billerType("Internet")
                .billerAccountNumber("956567887")
                .billPlans(billPlanDTOS())
                .build();
        return Collections.singletonList(billerByIdDTO);
    }

    public static BillerInformation getBillerInformation() {
        return BillerInformation
                .builder()
                .billerId(UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63"))
                .termsAndConditions("okay")
                .build();
    }

    public static BillerByIdResponse getBillerByIdResponse() {
        UUID billerId = UUID.fromString("09a09584-2568-11eb-80ff-fa163e3d3c63");
        String processorBillerId = "29866";

        // Creating mock response data
        BillerInformation billerInformation = BillerInformation.builder()
                .billerId(billerId)
                .processorBillerId(processorBillerId)
                .displayName("Bait")
                .productDisplayName("Recarga celular")
                .imageURL("https://cashi.walmart.com/Providers-Icons/PNG_NEW/Bait_080923.png")
                .billerBehaviourCode("BBC_1")
                .termsAndConditions("https://mibait.com/tyc.html")
                .information("<p>Para más información visita <a href=\"https://mibait.com/\">https://mibait.com/</a></p>")
                .disclaimer("Todas las recargas incluyen: Llamadas (Nacionales y larga distancia a EUA y Canadá) SMS y navegación en redes sociales.")
                .build();

        BillDetailDTO billDetail = BillDetailDTO.builder()
                .billDetailId(UUID.fromString("1befa3cb-cbd4-da41-a7c9-d03ec4063e3a"))
                .amount(BigDecimal.valueOf(30.00))
                .name("Mi Bait 30")
                .description("4,000 MB libres / 3 días. 250 Min en llamadas (MEX, EUA y CAN) y 125 SMS")
                .validity("Válido por 3 días")
                .socialMediaIcons(new String[]{"WHATSAPP", "FACEBOOK", "MESSENGER"})
                .build();

        BillPlanDTO billPlan = BillPlanDTO.builder()
                .plan("Tiempo Aire")
                .billDetails(Collections.singletonList(billDetail))
                .build();

        BillerByIdDTO billerByIdDTO = BillerByIdDTO.builder()
                .billerId(billerId)
                .processorBillerId(processorBillerId)
                .displayName("Bait")
                .billerType("Tiempo aire")
                .billType("phone_number")
                .prepaid(true)
                .billPlans(Collections.singletonList(billPlan))
                .inputPlaceholderText("Número celular")
                .topupCommission("0.00")
                .build();

        return BillerByIdResponse.builder()
                .billerInformation(billerInformation)
                .billers(Collections.singletonList(billerByIdDTO))
                .lastUpdatedAt(LocalDateTime.parse("2024-08-21T13:22:22"))
                .build();
    }

    public static BillerCategoriesResponse getBillerCategoriesResponse() {
        GetBillerCategoryBillerDTO biller = GetBillerCategoryBillerDTO.builder()
                .billerId(UUID.randomUUID())
                .processorBillerId("999988")
                .displayName("Bait")
                .billerType("Internet y Tiempo aire")
                .imageURL("https://cashi.walmart.com/Providers-Icons/PNG_NEW/Bait_080923.png")
                .isNewBiller(false)
                .tags(new String[]{"Bait", "Recarga celular"})
                .build();

        BillerCategoryDTO category = BillerCategoryDTO.builder()
                .id(UUID.randomUUID())
                .categoryName("Recarga celular")
                .imageUrl("https://cashi.walmart.com/Providers-SVG-FIXED/Biller-Categories-2/telephone.svg")
                .billerCategoryVersion(1)
                .hasEnabledBillers(true)
                .hasNewBillers(false)
                .billers(Arrays.asList(biller))
                .build();

        return BillerCategoriesResponse.builder()
                .categories(Arrays.asList(category))
                .billerCategoryDataLastUpdatedAt(new Date())
                .build();
    }


}
