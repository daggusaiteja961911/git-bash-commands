package com.walmart.international.wallet.payment.app.controller.impl.topup;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.app.controller.topup.CoFTopupController;
import com.walmart.international.wallet.payment.app.service.CoFTopupService;
import com.walmart.international.wallet.payment.app.auth.WPSAuthValidator;
import com.walmart.international.wallet.payment.core.service.CoFTopupCoreService;
import com.walmart.international.wallet.payment.dto.request.topup.CancelCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.FetchCoFTopupPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class CoFTopupControllerImpl implements CoFTopupController {

    @Autowired
    private CoFTopupService coFTopupService;

    @Autowired
    private CoFTopupCoreService coFTopupCoreService;

    @Autowired
    private WPSAuthValidator wpsAuthValidator;

    @Override
    public CoFTopupResponse coFTopup(CoFTopupRequest coFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(coFTopupRequest.getCustomerAccountId().toString(), headers);
        return coFTopupService.coFTopup(coFTopupRequest, headers);
    }

    @Override
    public CancelCoFTopUpResponse cancelCoFTopup(@RequestBody CancelCoFTopupRequest cancelCoFTopupRequest, @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(cancelCoFTopupRequest.getCustomerAccountId().toString(), headers);
        return coFTopupService.cancelCoFTopup(cancelCoFTopupRequest, headers);
    }

    @Override
    public FetchCoFTopupPaymentInstrumentsResponse fetchCoFTopupPaymentInstruments(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(fetchCoFTopupPaymentInstrumentsRequest.getCustomerAccountId().toString(), headers);
        return coFTopupService.fetchCoFTopupPaymentInstruments(fetchCoFTopupPaymentInstrumentsRequest, headers);
    }

    @Override
    public FetchCoFTopupPaymentInstrumentsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(fetchCoFTopupPaymentInstrumentsRequest.getCustomerAccountId().toString(), headers);
        return coFTopupService.fetchCoFTopupPaymentInstrumentsWithPreselection(fetchCoFTopupPaymentInstrumentsRequest, headers);
    }

    @Override
    public ValidateCoFTopupResponse validateCoFTopup(ValidateCoFTopupRequest validateCoFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(validateCoFTopupRequest.getCustomerAccountId().toString(), headers);
        return coFTopupService.validateCoFTopup(validateCoFTopupRequest, headers);
    }

    @Override
    public void reverseCoFTopupCharge(UUID transactionId, MultiValueMap<String, String> headers) throws ApplicationException {
        coFTopupCoreService.reverseCoFTopUpTransactionCharge(transactionId);
    }
}
