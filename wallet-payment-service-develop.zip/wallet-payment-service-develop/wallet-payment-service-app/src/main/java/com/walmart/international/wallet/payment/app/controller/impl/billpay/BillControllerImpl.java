package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.app.controller.billpay.BillController;
import com.walmart.international.wallet.payment.app.service.BillService;
import com.walmart.international.wallet.payment.app.auth.WPSAuthValidator;
import com.walmart.international.wallet.payment.dto.request.billpay.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.DeleteCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetBillsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetSavedCustomerBillAccountsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountDueInfoRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.DeleteCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetSavedCustomerBillAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountDueInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillControllerImpl implements BillController {

    @Autowired
    private BillService billService;

    @Autowired
    private WPSAuthValidator wpsAuthValidator;

    @Override
    public GetBillsResponse getBills(GetBillsRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(request.getCustomerAccountId().toString(), headers);
        return billService.getBills(request, headers);
    }

    @Override
    public UpdateCustomerBillAccountResponse updateCustomerBillAccount(UpdateCustomerBillAccountRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(request.getCustomerAccountId().toString(), headers);
        return billService.updateCustomerBillAccount(request, headers);
    }

    @Override
    public UpdateCustomerBillAccountDueInfoResponse updateCustomerBillAccountDueInfo(UpdateCustomerBillAccountDueInfoRequest request, MultiValueMap<String, String> headers) throws ApplicationException {
        return billService.updateCustomerBillAccountDueInfo(request, headers);
    }

    @Override
    public DeleteCustomerBillAccountResponse deleteCustomerBillAccount(DeleteCustomerBillAccountRequest deleteCustomerBillAccountRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(deleteCustomerBillAccountRequest.getCustomerAccountId().toString(), headers);
        return billService.deleteCustomerBillAccount(deleteCustomerBillAccountRequest, headers);
    }

    @Override
    public CreateBillResponse createBill(CreateBillRequest createBillRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(createBillRequest.getCustomerAccountId().toString(), headers);
        return billService.createBill(createBillRequest, headers);
    }

    @Override
    public GetSavedCustomerBillAccountsResponse getSavedCustomerBillAccounts(GetSavedCustomerBillAccountsRequest getSavedCustomerBillAccountsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(getSavedCustomerBillAccountsRequest.getCustomerAccountId().toString(), headers);
        return billService.getSavedCustomerBillAccounts(getSavedCustomerBillAccountsRequest, headers);
    }

    @Override
    public AlreadyPaidResponse markAlreadyPaid(AlreadyPaidRequest alreadyPaidRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        wpsAuthValidator.validateHeaderUserId(alreadyPaidRequest.getCustomerAccountId().toString(), headers);
        return billService.markAlreadyPaid(alreadyPaidRequest, headers);
    }
}
