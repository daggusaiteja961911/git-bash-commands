package com.walmart.international.wallet.payment.app.controller.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.DeleteCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetBillsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetSavedCustomerBillAccountsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountDueInfoRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.DeleteCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetSavedCustomerBillAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountDueInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import io.strati.security.jaxrs.ws.rs.core.MediaType;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@RequestMapping("/services/bills")
@Tag(name = "BillController API", description = "APIs to perform Bill related activities.")
public interface BillController {

    @PostMapping(value = "/v1/fetch-bills", consumes = "application/json", produces = "application/json")
    GetBillsResponse getBills(@RequestBody @Valid GetBillsRequest request,
                              @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/update-bill", consumes = "application/json", produces = "application/json")
    UpdateCustomerBillAccountResponse updateCustomerBillAccount(@RequestBody @Valid UpdateCustomerBillAccountRequest request,
                                                                @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/update-bill/due-info", consumes = "application/json", produces = "application/json")
    UpdateCustomerBillAccountDueInfoResponse updateCustomerBillAccountDueInfo(@RequestBody @Valid UpdateCustomerBillAccountDueInfoRequest request,
                                                                              @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/delete-bill", consumes = "application/json", produces = "application/json")
    DeleteCustomerBillAccountResponse deleteCustomerBillAccount(@RequestBody @Valid DeleteCustomerBillAccountRequest deleteCustomerBillAccountRequest,
                                                                @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/v1/create-bill", consumes = "application/json", produces = "application/json")
    CreateBillResponse createBill(@RequestBody @Valid CreateBillRequest createBillRequest,
                                  @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    /**
     * Fetches all saved customer bill account entries for a customer and for a particular biller/combination of {biller, accountNumber}
     */
    @PostMapping(value = "/v1/saved-bill-accounts", consumes = "application/json", produces = "application/json")
    GetSavedCustomerBillAccountsResponse getSavedCustomerBillAccounts(@RequestBody @Valid GetSavedCustomerBillAccountsRequest getSavedCustomerBillAccountsRequest,
                                                                      @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    /**
     * Mark saved bill as already paid for customers who has paid outside of Cashi application
     */
    @PostMapping(value = "/v1/already-paid", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
    AlreadyPaidResponse markAlreadyPaid(@RequestBody AlreadyPaidRequest alreadyPaidRequest,
                                        @RequestHeader MultiValueMap<String, String> headers ) throws ApplicationException;

}
