package com.walmart.international.wallet.payment.app.controller.impl.transactionAudit;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.digiwallet.service.strati.telemetry.service.CashiTelemetryMetrics;
import com.walmart.international.wallet.payment.app.controller.transactionaudit.TransactionAuditController;
import com.walmart.international.wallet.payment.app.service.TransactionAuditService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.dto.request.transaction.audit.TransactionAckRequest;
import com.walmart.international.wallet.payment.dto.request.transaction.audit.TransactionSyncRequest;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnAckResponse;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnSyncResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TransactionAuditControllerImpl implements TransactionAuditController {

    @Autowired
    TransactionAuditService transactionAuditService;

    @Autowired
    CashiTelemetryMetrics cshTelMetrics;

    @ManagedConfiguration
    WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @Override
    @Metered(level1 = "WALLET-PAYMENT-SERVICE", level2 = "TXN_COMPLETED", level3 = "TAS_RESYNC", metricName = "CASHI_TRANSACTION")
    public TxnSyncResponse transactionSync(TransactionSyncRequest transactionSyncRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return transactionAuditService.reSyncTransactionsToTAS(transactionSyncRequest.getTransactionIds(), headers.get(WPSConstants.Headers.CORRELATION_ID.toLowerCase()).get(0));
    }

    @Override
    @Metered(level1 = "WALLET-PAYMENT-SERVICE", level2 = "TXN_COMPLETED", level3 = "TAS_ACK", metricName = "CASHI_TRANSACTION")
    public TxnAckResponse acknowledgeTransactionFromTAS(TransactionAckRequest transactionAckRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return transactionAuditService.acknowledgeProcessedTransactionFromTAS(transactionAckRequest);
    }

}
