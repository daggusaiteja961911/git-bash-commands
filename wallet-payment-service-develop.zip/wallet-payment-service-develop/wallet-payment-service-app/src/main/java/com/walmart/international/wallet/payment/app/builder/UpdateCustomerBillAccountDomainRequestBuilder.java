package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.Objects;

@Component
@Slf4j
public class UpdateCustomerBillAccountDomainRequestBuilder extends BaseDomainRequestBuilder<UpdateCustomerBillAccountRequest, BillRequestDomainContext> {

    @Override
    public BillRequestDomainContext buildDomainRequest(UpdateCustomerBillAccountRequest updateCustomerBillAccountRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        return BillRequestDomainContext.builder()
                .customerBillAccount(CustomerBillAccount.builder()
                        .customerAccountId(updateCustomerBillAccountRequest.getCustomerAccountId())
                        .customerBillAccountId(updateCustomerBillAccountRequest.getCustomerBillAccountId())
                        .alias(Objects.nonNull(updateCustomerBillAccountRequest.getAlias())
                                ? updateCustomerBillAccountRequest.getAlias().trim()    // Adding trim() to alias to handle cases where user opts to update empty string as alias which translates to resetting the alias
                                : null)
                        .build())
                .headers(headers)
                .build();
    }
}
