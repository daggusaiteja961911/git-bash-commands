package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerBehaviourCodeUpdateRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerCategoriesResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataCacheAlterResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataUpdateInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerIncorrectSearchKeywordsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PopularBillersResponse;

import java.util.Map;
import java.util.UUID;

public interface BillerService {

    BillerCategoriesResponse getBillerCategories(int billerCategoryVersion);

    PopularBillersResponse getPopularBillers() throws ApplicationException;

    BillerByIdResponse getBillerById(UUID billerId, String processorBillerId) throws ApplicationException;

    BillerDataUpdateInfoResponse getBillerDataUpdateInfo(BillerDataUpdateInfoRequest billerDataUpdateInfoRequest);

    BillerDataCacheAlterResponse reloadCacheForBillerData(BillerDataCacheReloadRequest billerDataCacheReloadRequest) throws ApplicationException;

    BillerDataCacheAlterResponse evictCacheForBillerData(BillerDataCacheEvictRequest billerDataCacheEvictRequest);

    BillerIncorrectSearchKeywordsResponse getBillerIncorrectSearchKeywords() throws ApplicationException;

    Map<String, String> updateBillerBehaviourCode(BillerBehaviourCodeUpdateRequest billerBehaviourCodeUpdateRequest);

}
