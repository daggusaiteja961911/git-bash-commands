package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.CancelPayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.PayBillInitRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ReconcilePendingBillPayTxnRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.ValidatePayBillInitRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CancelPayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.FetchBillPayPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.ReconcilePendingBillPayTxnResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.ValidatePayBillInitResponse;
import org.springframework.util.MultiValueMap;

public interface BillPaymentService {

    FetchBillPayPaymentInstrumentsResponse fetchBillPayPaymentInstruments(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers);

    FetchBillPayPaymentInstrumentsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers);

    PayBillInitResponse payBillInit(PayBillInitRequest request, MultiValueMap<String, String> headers) throws ApplicationException;

    ReconcilePendingBillPayTxnResponse reconcilePendingBillPayTxn(ReconcilePendingBillPayTxnRequest request, MultiValueMap<String, String> headers) throws ApplicationException;

    CancelPayBillInitResponse cancelPayBillInit(CancelPayBillInitRequest request, MultiValueMap<String, String> headers) throws ApplicationException;

    ValidatePayBillInitResponse validatePayBillInit(ValidatePayBillInitRequest request, MultiValueMap<String, String> headers) throws ApplicationException;
}
