package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.wallet.payment.app.service.BillProcessorService;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.service.BillProcessorCoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class BillProcessorServiceImpl implements BillProcessorService {

    @Autowired
    private BillProcessorCoreService billProcessorCoreService;

    @Override
    public ResponseEntity<PayBillResponse> getTxn(String cashiOrderId, int authKeyVersion) {
        PayBillResponse payBillResponse = billProcessorCoreService.getTxn(cashiOrderId, authKeyVersion);
        if (Objects.isNull(payBillResponse)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(payBillResponse);
        }
    }

    @Override
    public ResponseEntity<GetAccountResponse> getAccount() {
        return ResponseEntity.ok(billProcessorCoreService.getAccount());
    }

    @Override
    public ResponseEntity<GetBillersResponse> getBillers(ProcessorBillerType processorBillerType) {
        return ResponseEntity.ok(billProcessorCoreService.getBillers(processorBillerType));
    }
}
