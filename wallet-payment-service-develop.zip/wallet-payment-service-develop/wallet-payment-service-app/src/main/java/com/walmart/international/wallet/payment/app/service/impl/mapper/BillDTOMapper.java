package com.walmart.international.wallet.payment.app.service.impl.mapper;

import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.DeleteCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.SavedCustomerBillAccountDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface BillDTOMapper {

    BillDTOMapper INSTANCE = Mappers.getMapper(BillDTOMapper.class);

    List<SavedCustomerBillAccountDTO> mapToSavedCustomerBillAccountDTOsFromCustomerBillAccounts(List<CustomerBillAccount> customerBillAccounts);

    @Mapping(target = "billerId", source = "biller.billerId")
    @Mapping(target = "processorBillerId", source = "biller.processorBillerId")
    SavedCustomerBillAccountDTO mapToSavedCustomerBillAccountDTOFromCustomerBillAccount(CustomerBillAccount customerBillAccount);

    DeleteCustomerBillAccountResponse mapCustomerBillAccountToDeleteCustomerBillAccountResponse(CustomerBillAccount customerBillAccount);

    @Mapping(target = "billerId", source = "biller.billerId")
    @Mapping(target = "dueDateUpdatedAt", source = "dueInfoUpdatedAt")
    @Mapping(target = "customerBillAccountUpdatedAt", source = "updateDate")
    @Mapping(target = "lastPaidDate", expression = "java(customerBillAccount.getLastPaidDateValue())")
    AlreadyPaidResponse mapCustomerBillAccountToAlreadyPaidResponse(CustomerBillAccount customerBillAccount);

}
