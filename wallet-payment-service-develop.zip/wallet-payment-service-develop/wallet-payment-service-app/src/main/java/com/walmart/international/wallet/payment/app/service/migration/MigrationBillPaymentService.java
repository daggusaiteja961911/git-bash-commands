package com.walmart.international.wallet.payment.app.service.migration;

import com.walmart.international.wallet.payment.dto.request.migration.CancelPayBillInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchBillPayPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.PayInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeInitRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelPayBillInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchBillPayPaymentInstrumentsResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.ValidateChargeInitResponseEWS;
import org.springframework.util.MultiValueMap;

import java.util.UUID;

public interface MigrationBillPaymentService {
    FetchBillPayPaymentInstrumentsResponseEWS fetchBillPayPaymentInstruments(UUID customerAccountId,
                                                                             FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest,
                                                                             MultiValueMap<String, String> headers);

    PayInitResponseEWS payBillInit(UUID customerAccountId,
                                   PayInitRequestEWS payInitRequestEWS,
                                   MultiValueMap<String, String> headers);

    CancelPayBillInitResponseEWS cancelPaymentInit(UUID customerAccountId, UUID transactionId, CancelPayBillInitRequestEWS cancelPayBillInitRequestEWS, MultiValueMap<String, String> headers);

    ValidateChargeInitResponseEWS validateChargeInit(UUID customerAccountId, ValidateChargeInitRequestEWS validateChargeInitRequestEWS, MultiValueMap<String, String> headers);

    FetchPaymentOptionsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(UUID customerAccountId, FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers);
}
