package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import org.springframework.http.ResponseEntity;

public interface BillProcessorService {

    ResponseEntity<PayBillResponse> getTxn(String cashiOrderId, int arcusAuthKeyVersion);

    ResponseEntity<GetAccountResponse> getAccount();

    ResponseEntity<GetBillersResponse> getBillers(ProcessorBillerType processorBillerType);
}
