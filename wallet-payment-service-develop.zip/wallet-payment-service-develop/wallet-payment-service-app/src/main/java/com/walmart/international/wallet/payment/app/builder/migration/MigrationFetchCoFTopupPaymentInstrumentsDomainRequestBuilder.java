package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.FetchCoFTopupPaymentInstrumentsRequestEWS;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class MigrationFetchCoFTopupPaymentInstrumentsDomainRequestBuilder extends BaseDomainRequestBuilder<FetchCoFTopupPaymentInstrumentsRequestEWS, CoFTopupTxnRequestDomainContext> {

    @Override
    public CoFTopupTxnRequestDomainContext buildDomainRequest(FetchCoFTopupPaymentInstrumentsRequestEWS fetchCoFTopupPaymentInstrumentsRequestEWS, MultiValueMap<String, String> map, Tenant tenant) {
        Customer customer = Customer.builder()
                .customerAccountId(fetchCoFTopupPaymentInstrumentsRequestEWS.getCustomerAccountId())
                .build();

        CoFTopUpTransaction coFTopUpTransaction = CoFTopUpTransaction.builder()
                .customer(customer)
                .build();

        return CoFTopupTxnRequestDomainContext.builder()
                .transaction(coFTopUpTransaction)
                .build();
    }
}
