package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.CancelPayBillInitRequestEWS;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class MigrationCancelPayBillInitTransactionDomainRequestBuilder extends BaseDomainRequestBuilder<CancelPayBillInitRequestEWS, BillPayTxnRequestDomainContext> {
    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(CancelPayBillInitRequestEWS cancelPayBillInitRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        Customer customer = Customer.builder()
                .customerAccountId(cancelPayBillInitRequestEWS.getCustomerAccountId())
                .build();

        BillPayTransaction transaction = BillPayTransaction.builder()
                .transactionId(cancelPayBillInitRequestEWS.getTransactionId())
                .transactionType(TransactionType.BILL_PAY)
                .abortReason(cancelPayBillInitRequestEWS.getAbortReason())
                .customer(customer)
                .build();

        return BillPayTxnRequestDomainContext.builder()
                .transaction(transaction)
                .headers(headers)
                .build();
    }
}
