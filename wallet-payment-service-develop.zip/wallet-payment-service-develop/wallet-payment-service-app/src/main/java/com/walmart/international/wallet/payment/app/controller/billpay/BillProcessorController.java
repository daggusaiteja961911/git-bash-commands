package com.walmart.international.wallet.payment.app.controller.billpay;

import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping("/services/bill-processor")
@Tag(name = "BillProcessorController API", description = "APIs to perform BillProcessor related activities.")
public interface BillProcessorController {

    @GetMapping(value = "/get-txn", produces = "application/json")
    ResponseEntity<PayBillResponse> getTxn(@RequestParam String cashiOrderId, @RequestParam int authKeyVersion);

    @GetMapping(value = "/get-account", produces = "application/json")
    ResponseEntity<GetAccountResponse> getAccount();

    @GetMapping(value = "/get-billers", produces = "application/json")
    ResponseEntity<GetBillersResponse> getBillers(@RequestParam ProcessorBillerType processorBillerType);
}
