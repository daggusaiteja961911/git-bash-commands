package com.walmart.international.wallet.payment.app.controller.impl.billpay.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.billpay.migration.MigrationBillerController;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillerPromotionService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.dto.request.migration.BillerDataUpdatePollRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.BillProviderInfoDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerCategoriesDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerDataUpdatePollResponse;
import com.walmart.international.wallet.payment.dto.response.migration.BillersListResponseDTO;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillerService;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MigrationBillerControllerImpl implements MigrationBillerController {

    @Autowired
    private MigrationBillerService migrationBillerService;

    @Autowired
    private MigrationBillerPromotionService migrationBillerPromotionService;

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    private static final int billerCategoryVersion = 1;

    @Override
    @Metered(level1 = "Biller", level2 = "GetBillerCategories", level3 = "All", metricName = "CASHI_CUSTOMER")
    public BillerCategoriesDTO migrationGetBillerCategories() {
        return migrationBillerService.getBillerCategories(billerCategoryVersion);
    }

    @Override
    @Metered(level1 = "Biller", level2 = "GetPopularBillers", level3 = "All", metricName = "CASHI_CUSTOMER")
    public BillersListResponseDTO migrationGetPopularBillers() throws ApplicationException {
        return migrationBillerService.getPopularBillers();
    }

    @Override
    @Metered(level1 = "Biller", level2 = "GetBillerById", level3 = "All", metricName = "CASHI_CUSTOMER")
    public BillProviderInfoDTO migrationGetBillProviderInfo(String processorBillerId) throws ApplicationException {
        return migrationBillerService.getBillProviderInfo(processorBillerId);
    }

    @Override
    @Metered(level1 = "Biller", level2 = "GetBillerDataUpdateInfo", level3 = "All", metricName = "CASHI_CUSTOMER")
    public BillerDataUpdatePollResponse migrationGetBillerDataUpdateInfo(BillerDataUpdatePollRequest billerDataUpdatePollRequest) {
        return migrationBillerService.getBillerDataUpdateInfo(billerDataUpdatePollRequest);
    }

    @Override
    @Metered(level1 = "Biller", level2 = "GetPromotions", level3 = "All", metricName = "CASHI_CUSTOMER")
    public BillerPromotionsResponse migrationGetPromotions(String billerCategoryIds, String billerIds) {
        return migrationBillerPromotionService.getPromotions(billerCategoryIds, billerIds, walletPaymentServiceConfiguration.getBillerCategoryVersionForPromotions());
    }
}
