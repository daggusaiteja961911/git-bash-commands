package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.wallet.payment.app.controller.billpay.BillProcessorController;
import com.walmart.international.wallet.payment.app.service.BillProcessorService;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillProcessorControllerImpl implements BillProcessorController {

    @Autowired
    private BillProcessorService billProcessorService;

    @Override
    public ResponseEntity<PayBillResponse> getTxn(String cashiOrderId, int authKeyVersion) {
        return billProcessorService.getTxn(cashiOrderId, authKeyVersion);
    }

    @Override
    public ResponseEntity<GetAccountResponse> getAccount() {
        return billProcessorService.getAccount();
    }

    @Override
    public ResponseEntity<GetBillersResponse> getBillers(ProcessorBillerType processorBillerType) {
        return billProcessorService.getBillers(processorBillerType);
    }

}
