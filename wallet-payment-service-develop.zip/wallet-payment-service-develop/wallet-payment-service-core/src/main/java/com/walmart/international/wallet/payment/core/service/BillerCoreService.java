package com.walmart.international.wallet.payment.core.service;

import com.querydsl.core.Tuple;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public interface BillerCoreService {

    Biller fetchAndCacheBillerData(String processorBillerId) throws ApplicationException;

    Biller fetchAndCacheBillerData(UUID billerId, String processorBillerId) throws ApplicationException;

    List<BillerCategory> getBillerCategoriesList(Integer billerCategoryVersion);

    Date fetchBillerCategoryDataLastUpdatedAtTimestamp();

    Map<String, Object> fetchBillerDataLastUpdatedAtMap(List<UUID> billerIds, List<String> processorBillerIds);

    void reloadCacheForBillerCategoryData(List<Integer> billerCategoryVersions);

    void reloadIncorrectSearchDataInCache();

    Map<String, Set<String>> reloadCacheForBillerData(Set<String> processorBillerIds, Set<UUID> billerIds);

    List<Biller> getPopularBillers() throws BusinessValidationException;

    List<Tuple> getBillerIdsAndProcessorBillerIdsOfBillersWhoseDataIsCached();

    Map<String, Set<String>> evictCacheForBillerAndUpdateTimestampData(List<UUID> billerIdsToEvict, List<String> processorBillerIdsToEvict);

    Map<String, List<String>> fetchBillerIncorrectSearchKeywordMap();

    Date fetchBillerIncorrectSearchDataUpdateTimestamp();

    Map<String, String> updateBehaviourCodeForAllBillersAndCreateBillerIdToBBCMap();

    Map<String, String> updateBehaviourCodeForGivenBillerIdsAndCreateBillerIdToBBCMap(Set<UUID> billerIds);
}
