package com.walmart.international.wallet.payment.core.event;

import com.walmart.international.ewallet.services.events.WalletEventService;
import com.walmart.international.wallet.payment.core.event.payload.CampaignRewardEventPayload;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@Slf4j
public class CampaignServiceNotifier {

    @Autowired
    private WalletEventService<CampaignRewardEventPayload> campaignEventService;

    public void notifyCampaignService(CampaignRewardEventPayload campaignRewardEventPayload, UUID customerAccountId) {
        log.info("Raising event for WalletEventType : {}, customerId : {} and transactionId : {}", campaignRewardEventPayload.getEventType(), customerAccountId,
                campaignRewardEventPayload.getRewardRequest().getTransactionId());
        campaignEventService.raiseEvent(campaignRewardEventPayload.getEventType(), campaignRewardEventPayload);
    }
}
