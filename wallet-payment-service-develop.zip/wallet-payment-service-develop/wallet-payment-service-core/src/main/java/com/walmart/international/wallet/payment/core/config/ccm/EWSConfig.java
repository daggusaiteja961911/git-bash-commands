package com.walmart.international.wallet.payment.core.config.ccm;

import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "ews-config")
public interface EWSConfig extends WebClientCCMConfigs{
    @Property(propertyName = "ewallet.service.baseUrl")
    String getBaseUrl();

    @Property(propertyName = WPSConstants.Headers.WM_SVC_NAME)
    String getSvcName();

    @Property(propertyName = WPSConstants.Headers.WM_SVC_ENV)
    String getSvcEnv();

    @Property(propertyName = WPSConstants.Headers.WM_CONSUMER_ID)
    String getSvcConsumerId();

    @Property(propertyName = WPSConstants.Headers.WM_SVC_VERSION)
    String getSvcVersion();
}