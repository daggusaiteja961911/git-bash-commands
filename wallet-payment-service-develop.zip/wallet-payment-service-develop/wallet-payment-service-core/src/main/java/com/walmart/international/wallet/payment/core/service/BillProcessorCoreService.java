package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;

public interface BillProcessorCoreService {

    PayBillResponse getTxn(String cashiOrderId, int authKeyVersion);

    GetAccountResponse getAccount();

    GetBillersResponse getBillers(ProcessorBillerType processorBillerType);
}
