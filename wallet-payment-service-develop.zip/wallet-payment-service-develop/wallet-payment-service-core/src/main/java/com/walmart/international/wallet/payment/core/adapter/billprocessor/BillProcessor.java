package com.walmart.international.wallet.payment.core.adapter.billprocessor;

import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.CreateBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.PayBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.CreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;

import java.util.List;

public interface BillProcessor {

    PayBillResponse payBill(PayBillRequest request, int authKeyVersion) throws BillProcessorException;

    CreateBillResponse createBill(CreateBillRequest request, int authKeyVersion) throws BillProcessorException;

    CreateBillResponse refreshBill(String billId, int authKeyVersion) throws BillProcessorException;

    List<PayBillResponse> getTxn(String cashiOrderId, int authKeyVersion) throws BillProcessorException;

    GetAccountResponse getAccount() throws BillProcessorException;

    GetBillersResponse getBillers(ProcessorBillerType processorBillerType) throws BillProcessorException;
}
