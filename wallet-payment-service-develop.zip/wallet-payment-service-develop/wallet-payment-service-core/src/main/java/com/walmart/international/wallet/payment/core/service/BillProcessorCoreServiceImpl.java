package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessorFactory;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums.ProcessorBillerType;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorValidationException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetAccountResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.GetBillersResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import io.strati.libs.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillProcessorCoreServiceImpl implements BillProcessorCoreService {

    @Autowired
    private BillProcessorFactory billProcessorFactory;

    @Override
    public PayBillResponse getTxn(String cashiOrderId, int authKeyVersion) {
        List<PayBillResponse> payBillResponseList;
        try {
            payBillResponseList = billProcessorFactory.getBillProcessor().getTxn(cashiOrderId, authKeyVersion);
        } catch (BillProcessorException ex) {
            String msg = String.format("Processing error in GetTxns for cashiOrderId[%s] with authKeyVersion[%s]",
                    cashiOrderId, authKeyVersion);
            throw new ProcessingException(ex.getErrorCode(), msg, ex);
        }
        if (CollectionUtils.isNotEmpty(payBillResponseList)) {
            return payBillResponseList.get(0);
        } else {
            return null;
        }
    }

    @Override
    public GetAccountResponse getAccount() {
        try {
            return billProcessorFactory.getBillProcessor().getAccount();
        } catch (BillProcessorValidationException ex) {
            String msg = "Validation error in getAccount";
            throw new BusinessValidationException(ex.getErrorCode(), msg, ex);
        } catch (BillProcessorException ex) {
            String msg = "Processing error in getAccount";
            throw new ProcessingException(ex.getErrorCode(), msg, ex);
        }
    }

    @Override
    public GetBillersResponse getBillers(ProcessorBillerType processorBillerType) {
        try {
            return billProcessorFactory.getBillProcessor().getBillers(processorBillerType);
        } catch (BillProcessorException ex) {
            String msg = String.format("Processing error in getBillers for processorBillerType:[%s]", processorBillerType);
            throw new ProcessingException(ex.getErrorCode(), msg, ex);
        }
    }
}
