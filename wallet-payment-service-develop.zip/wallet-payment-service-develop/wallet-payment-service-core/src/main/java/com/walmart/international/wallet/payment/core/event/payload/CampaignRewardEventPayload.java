package com.walmart.international.wallet.payment.core.event.payload;

import com.walmart.international.campaign.dto.request.RewardRequest;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class CampaignRewardEventPayload {

    private UUID customerAccountId;
    private String eventType;
    private RewardRequest rewardRequest;
}
