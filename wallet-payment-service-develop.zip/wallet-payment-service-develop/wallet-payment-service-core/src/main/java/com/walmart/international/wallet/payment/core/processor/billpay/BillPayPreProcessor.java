package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.ewallet.services.events.WalletEventService;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.notification.txnaggregator.TxnCompletedPayloadGenerator;
import com.walmart.international.services.payment.core.dao.repository.CardTransactionRepository;
import com.walmart.international.services.payment.core.dao.repository.CoreTransactionRepository;
import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import com.walmart.international.services.payment.core.model.CardTransactionDO;
import com.walmart.international.services.payment.core.model.CoreTransactionDO;
import com.walmart.international.services.payment.core.model.GiftCardTransactionDO;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.tas.TxnAggregatorServiceAdapter;
import com.walmart.international.wallet.payment.core.adapter.tas.response.TxnEventRestConsumptionResponse;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.constants.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.core.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.mapper.BillerMapper;
import com.walmart.international.wallet.payment.core.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@Slf4j
public class BillPayPreProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private CustomerBillAccountRepository customerBillAccountRepository;

    @Autowired
    private CardTransactionRepository cardTransactionRepository;

    @Autowired
    CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    CoreTransactionRepository coreTransactionRepository;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    @Autowired
    private TxnCompletedPayloadGenerator txnCompletedPayloadGenerator;

    @Autowired
    TxnAggregatorServiceAdapter txnAggregatorServiceAdapter;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    @Autowired
    private WalletEventService<PayBillInitEventPayload> payBillInitEventService;

    private CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    private BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    private BillerMapper billerMapper = BillerMapper.INSTANCE;

    private CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws BusinessValidationException {
        BillPayTxnRequestDomainContext billPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;

        UUID billPayTransactionId = billPayTxnRequestDomainContext.getTransaction().getTransactionId();
        Optional<UUID> oCardSubTransactionId = billPayTxnRequestDomainContext.getTransaction().getCardSubTransactionId();
        BillPayTransactionDO billPayTransactionDO = null;
        if (Objects.nonNull(billPayTransactionId)) {
            Optional<BillPayTransactionDO> oBillPayTransactionDO = billPayTransactionRepository.findById(billPayTransactionId);
            if (oBillPayTransactionDO.isPresent()) {
                billPayTransactionDO = oBillPayTransactionDO.get();
                mapTransactionDetailsToContextUsingBillPayTxnId(billPayTransactionDO, billPayTxnRequestDomainContext);
                updateTxnStateTo3DSAckAndPublishToTAAS(billPayTransactionDO, billPayTxnRequestDomainContext.getTransaction(), billPayTxnRequestDomainContext.getHeaders().get(WPSConstants.Headers.CORRELATION_ID.toLowerCase()).get(0));
            } else {
                throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_BILL_PAY_TXN_ID);
            }
        } else if (oCardSubTransactionId.isPresent()) {
            billPayTransactionDO = mapTransactionDetailsToContext(oCardSubTransactionId.get(), billPayTxnRequestDomainContext);
            updateTxnStateTo3DSAckAndPublishToTAAS(billPayTransactionDO, billPayTxnRequestDomainContext.getTransaction(), billPayTxnRequestDomainContext.getHeaders().get(WPSConstants.Headers.CORRELATION_ID.toLowerCase()).get(0));
        } else {
            billPayTransactionDO = createBillPayTransactionInInitiatedState(billPayTxnRequestDomainContext);
        }
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        billPayMapper.updateBillPayTransactionFromBillPayTransactionDO(billPayTransactionDO, billPayTransaction);
        billPayTransaction.setPollingInterval(billPaymentConfiguration.getBillPaymentPollingInterval()
                .stream()
                .map(String::valueOf)
                .collect(Collectors.joining(",")));
        CustomerBillAccountDO customerBillAccountDO = validateAndGetCustomerBillAccount(billPayTxnRequestDomainContext);
        customerBillAccountMapper.updateCustomerBillAccountFromCustomerBillAccountDO(customerBillAccountDO, billPayTransaction.getCustomerBillAccount());

        billPayTxnResponseDomainContext.setBillPayTransactionDO(billPayTransactionDO);
        billPayTxnResponseDomainContext.setTransaction(billPayTransaction);
        billPayTxnResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
        billPayTxnResponseDomainContext.setClientRequestId(billPayTxnRequestDomainContext.getClientRequestId());
        billPayTxnResponseDomainContext.setHeaders(billPayTxnRequestDomainContext.getHeaders());

        payBillInitEventService.raiseEvent(WPSConstants.Event.PAY_BILL_INIT,
                getPayBillInitEventPayload(billPayTxnRequestDomainContext, billPayTxnResponseDomainContext));
        return true;
    }

    private void updateTxnStateTo3DSAckAndPublishToTAAS(BillPayTransactionDO billPayTransactionDO, BillPayTransaction billPayTransaction, String correlationId) {
        if (billPayTransactionDO.getState() != com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum.PENDING ||
                billPayTransactionDO.getStateReason() != com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason.TOPUP_3DS_ACKNOWELDGED) {
            billPayTransactionDO.setState(com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum.PENDING);
            billPayTransactionDO.setStateReason(com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason.TOPUP_3DS_ACKNOWELDGED);
            billPayTransactionDO.updateLastEventDate();
            billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
            billPayTransaction.setState(TransactionStateEnum.PENDING);
            billPayTransaction.setStateReason(BillPayTxnStateReason.TOPUP_3DS_ACKNOWELDGED);
        }
        try {
            EventPayload eventPayload = txnCompletedPayloadGenerator.generatePayload(billPayTransactionDO, correlationId);
            TxnEventRestConsumptionResponse response = txnAggregatorServiceAdapter.publishPayloadViaRESTCall(eventPayload);
            if (Objects.isNull(response) || Objects.isNull(response.getId()) || !(response.getId().equals(billPayTransactionDO.getBillPayTransactionId().toString()))) {
                String msg = String.format("Error while publishing updated txn status to TxnAgg for txnId[%s], customerAccountId[%s]",
                        billPayTransactionDO.getBillPayTransactionId(), billPayTransactionDO.getCustomerAccountId());
                throw new BusinessValidationException(ErrorConstants.PayBillInit.FAILURE_IN_PUBLISHING_PAYLOAD_TO_TAS, msg);
            }
        } catch (ApplicationException ae) {
            throw ae;
        } catch (Throwable e) {
            String msg = String.format("Error while publishing updated txn status to TxnAgg for txnId[%s], customerAccountId[%s]",
                    billPayTransactionDO.getBillPayTransactionId(), billPayTransactionDO.getCustomerAccountId());
            throw new BusinessValidationException(ErrorConstants.PayBillInit.FAILURE_IN_PUBLISHING_PAYLOAD_TO_TAS, msg, e);
        }
    }

    private BillPayTransactionDO createBillPayTransactionInInitiatedState(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        DeviceInformation deviceInformation = billPayTxnRequestDomainContext.getDeviceInfo();

        BillPayTransactionDO billPayTransactionDO = new BillPayTransactionDO();
        billPayTransactionDO.setBillerDO(billPayTxnRequestDomainContext.getBillerDO());
        billPayTransactionDO.setAmount(billPayTransaction.getAmountRequested().getValue());
        billPayTransactionDO.setAccountNumber(billPayTransaction.getCustomerBillAccount().getAccountNumber());
        billPayTransactionDO.setCurrencyUnit(CurrencyUnit.valueOf(billPayTransaction.getAmountRequested().getCurrencyUnit().name()));
        billPayTransactionDO.setClientReqId(billPayTxnRequestDomainContext.getClientRequestId());
        billPayTransactionDO.setCustomerAccountId(billPayTransaction.getCustomer().getCustomerAccountId());
        billPayTransactionDO.setState(com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum.INITIATED);
        billPayTransactionDO.setStateReason(com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason.VALIDATION_SUCCESS);
        billPayTransactionDO.setDeviceIpAddress(deviceInformation.getIp());
        billPayTransactionDO.setDeviceId(deviceInformation.getFingerPrint());
        billPayTransactionDO.setBillDetailDO(billPayTxnRequestDomainContext.getBillDetailDO());
        billPayTransactionDO.setVendorId(billPayTransaction.getCustomerBillAccount().getBiller().getVendorId());
        billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
        return billPayTransactionDO;
    }

    private CustomerBillAccountDO validateAndGetCustomerBillAccount(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        UUID customerAccountId = billPayTransaction.getCustomer().getCustomerAccountId();
        String accountNumber = billPayTransaction.getCustomerBillAccount().getAccountNumber();
        BillerDO billerDO = billPayTxnRequestDomainContext.getBillerDO();
        Biller biller = billPayTransaction.getCustomerBillAccount().getBiller();
        Optional<CustomerBillAccountDO> customerBillAccountDOOptional = fetchCustomerBillAccountDO(customerAccountId, accountNumber, billerDO);
        if (biller.isBillTypeGiftCard()) {
            if (customerBillAccountDOOptional.isEmpty()) {
                CustomerBillAccountDO customerBillAccountDO = CustomerBillAccountDO.builder()
                        .billerDO(billerDO)
                        .processorBillerId(billerDO.getProcessorBillerId())
                        .customerAccountId(customerAccountId)
                        .accountNumber(accountNumber)
                        .build();
                return customerBillAccountRepository.save(customerBillAccountDO);
            } else {
                CustomerBillAccountDO customerBillAccountDO = customerBillAccountDOOptional.get();
                if (customerBillAccountDO.isDeleted()) {
                    customerBillAccountDO.setDeleted(false);
                }
                return customerBillAccountDO;
            }
        } else {
            if (customerBillAccountDOOptional.isEmpty()) {
                throw new BusinessValidationException(ErrorConstants.PayBillInit.CUSTOMER_BILL_ACCOUNT_NOT_FOUND);
            } else if (Boolean.FALSE.equals(biller.getSupportsPartialPayments())
                    && Objects.nonNull(customerBillAccountDOOptional.get().getDueAmount())
                    && customerBillAccountDOOptional.get().getDueAmount().compareTo(billPayTransaction.getAmountRequested().getValue()) != 0) {
                throw new BusinessValidationException(ErrorConstants.PayBillInit.BILLER_PARTIAL_PAYMENT_NOT_SUPPORTED);
            } else {
                return customerBillAccountDOOptional.get();
            }
        }
    }

    private Optional<CustomerBillAccountDO> fetchCustomerBillAccountDO(UUID customerAccountId, String accountNumber, BillerDO billerDO) {
        if (billPaymentConfiguration.isUniqueConstraintPresentInCBATable()) {
            return customerBillAccountRepository.findByCustomerAccountIdAndAccountNumberAndBillerDO(customerAccountId, accountNumber, billerDO);
        } else {
            return customerBillAccountRepository.findFirstByCustomerAccountIdAndAccountNumberAndBillerDOOrderByUpdateDateDesc(customerAccountId, accountNumber, billerDO);
        }
    }

    private PayBillInitEventPayload getPayBillInitEventPayload(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext,
                                                               BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        return PayBillInitEventPayload.builder()
                .billPayTxnRequestDomainContext(billPayTxnRequestDomainContext)
                .billPayTxnResponseDomainContext(billPayTxnResponseDomainContext)
                .build();
    }
    private BillPayTransactionDO mapTransactionDetailsToContext(UUID cardSubTransactionId, BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        Customer customer = billPayTxnRequestDomainContext.getTransaction().getCustomer();
        Optional<CardTransactionDO> optionalCoFTopupCardTransactionDO = cardTransactionRepository.findById(cardSubTransactionId);
        if (optionalCoFTopupCardTransactionDO.isEmpty() || !optionalCoFTopupCardTransactionDO.get().getStatus().equals(SubTransactionStatusV2.PAYMENT_3DS_PENDING)) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_CARD_TXN_ID);
        }

        CardTransactionDO coFTopupCardTransactionDO = optionalCoFTopupCardTransactionDO.get();
        CoreTransactionDO coFTopupCoreTransactionDO = coFTopupCardTransactionDO.getCoreTransaction();
        UUID coFTopupTxnId = UUID.fromString(coFTopupCoreTransactionDO.getClientTransactionId().split("_")[0]);

        Optional<CoFTopupTransactionDO> optionalCoFTopupTransactionDO = coFTopupTransactionRepository.findById(coFTopupTxnId);
        if (optionalCoFTopupTransactionDO.isEmpty()) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_COF_TOPUP_TXN_ID);
        }

        if (!optionalCoFTopupTransactionDO.get().getCustomerAccountId().equals(customer.getCustomerAccountId())) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_CUSTOMER_TRANSACTION);
        }

        CoFTopupTransactionDO coFTopupTransactionDO = optionalCoFTopupTransactionDO.get();
        UUID billPayTxnId = UUID.fromString(coFTopupTransactionDO.getTxnReferenceId());
        Optional<BillPayTransactionDO> optionalBillPayTransactionDO = billPayTransactionRepository.findById(billPayTxnId);
        if (optionalBillPayTransactionDO.isEmpty()) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_BILL_PAY_TXN_ID);
        }

        if (!optionalBillPayTransactionDO.get().getCustomerAccountId().equals(customer.getCustomerAccountId())) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_CUSTOMER_TRANSACTION);
        }

        BillPayTransactionDO billPayTransactionDO = optionalBillPayTransactionDO.get();
        CoreTransactionDO billPayCoreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(billPayTxnId.toString());
        List<GiftCardTransactionDO> billPayGiftCardTransactionDOList = billPayCoreTransactionDO.getGiftCardSubTransactionList();
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        billPayTransaction.setTransactionId(billPayTransactionDO.getBillPayTransactionId());
        billPayTxnRequestDomainContext.setBillerDO(billPayTransactionDO.getBillerDO());
        billPayTransaction.setCustomerBillAccount(CustomerBillAccount.builder()
                .processorBillerId(billPayTransactionDO.getBillerDO().getProcessorBillerId())
                .accountNumber(billPayTransactionDO.getAccountNumber())
                .customerAccountId(billPayTransactionDO.getCustomerAccountId()).build());
        billPayTransaction.setBiller(billerMapper.mapBillerDOToBillerWithoutSubBillersAndBillPlans(billPayTransactionDO.getBillerDO()));
        billPayTransaction.setAmountRequested(Amount.builder()
                .value(billPayTransactionDO.getAmount())
                .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(billPayTransactionDO.getCurrencyUnit().name()))
                .build());

        if (Objects.nonNull(billPayTransactionDO.getBillDetailDO())) {
            billPayTransaction.setBillDetail(billerMapper.mapBillDetail(billPayTransactionDO.getBillDetailDO()));
        }

        CardPaymentTransaction cardPaymentTransaction = billPayTransaction.getCardPaymentTransactionList().get(0);
        cardPaymentTransaction.setPaymentInstrumentId(coFTopupCardTransactionDO.getPaymentInstrumentId());
        cardPaymentTransaction.setAmount(Amount.builder()
                .value(coFTopupCardTransactionDO.getAmount())
                .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(coFTopupCardTransactionDO.getCurrency().name()))
                .build());
        cardPaymentTransaction.setAffiliationType(AffiliationType.valueOf(coFTopupCardTransactionDO.getAffiliationType()));
        cardPaymentTransaction.setCardPaymentInstrument(CardPaymentInstrument.builder()
                .adapterMetadata(CardPaymentInstrument.AdapterMetadata.builder()
                        .tokenId(coFTopupCardTransactionDO.getPaymentProviderInstrumentId())
                        .build())
                .build());

        List<GiftCardTransaction> giftCardPaymentTransactionList = new ArrayList<>();
        for (GiftCardTransactionDO giftCardTransactionDO : billPayGiftCardTransactionDOList) {
            GiftCardTransaction giftCardPaymentTransaction = GiftCardTransaction.builder()
                    .paymentInstrumentId(giftCardTransactionDO.getPaymentInstrumentId())
                    .amount(Amount.builder()
                            .value(giftCardTransactionDO.getAmount())
                            .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(giftCardTransactionDO.getCurrency().name()))
                            .build())
                    .giftCardTransactionType(GiftCardTransactionType.PAY)
                    .giftCardPaymentInstrument(GiftCardPaymentInstrument.builder()
                            .adapterMetadata(GiftCardPaymentInstrument.AdapterMetadata.builder()
                                    .piHash(giftCardTransactionDO.getPaymentProviderInstrumentId())
                                    .build())
                            .build())
                    .build();
            giftCardPaymentTransactionList.add(giftCardPaymentTransaction);
        }
        billPayTransaction.setGiftCardPaymentTransactionList(giftCardPaymentTransactionList);

        mapCustomerDataToContext(customer, cardPaymentTransaction, giftCardPaymentTransactionList);

        CoFTopUpTransaction coFTopUpTransaction = CoFTopUpTransaction.builder()
                .transactionType(TransactionType.COF_TOPUP)
                .parentTransaction(billPayTransaction)
                .customer(customer)
                .build();
        coFTopupMapper.updateCoFTopupTransactionFromCoFTopupTransactionDO(coFTopupTransactionDO, coFTopUpTransaction);
        billPayTransaction.setInternalCoFTopupTransaction(coFTopUpTransaction);

        return billPayTransactionDO;
    }

    private void mapTransactionDetailsToContextUsingBillPayTxnId(BillPayTransactionDO billPayTransactionDO, BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        Customer customer = billPayTxnRequestDomainContext.getTransaction().getCustomer();
        UUID billPayTxnId = billPayTransactionDO.getBillPayTransactionId();

        if (!billPayTransactionDO.getCustomerAccountId().equals(customer.getCustomerAccountId())) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_CUSTOMER_TRANSACTION);
        }

        Optional<CoFTopupTransactionDO> optionalCoFTopupTransactionDO = coFTopupTransactionRepository.findByTxnReferenceId(billPayTxnId.toString());
        if (optionalCoFTopupTransactionDO.isEmpty()) {
            String msg = String.format("CoFtopup transaction not found for txnReferenceID[%s]", billPayTransactionDO.getBillPayTransactionId());
            throw new BusinessValidationException(ErrorConstants.PayBillInit.COF_TOPUP_TRANSACTION_NOT_FOUND, msg);
        }

        CoFTopupTransactionDO coFTopupTransactionDO = optionalCoFTopupTransactionDO.get();

        if (!coFTopupTransactionDO.getCustomerAccountId().equals(customer.getCustomerAccountId())) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_CUSTOMER_TRANSACTION);
        }

        isBillPayTxnIn3DSGeneratedState(billPayTransactionDO);
        isCoFTopupTxnIn3DSGeneratedState(coFTopupTransactionDO);

        UUID coFTopupTxnId = coFTopupTransactionDO.getCoFTopupTransactionId();

        CoreTransactionDO coFTopupCoreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(coFTopupTxnId.toString() + "_1");
        CoreTransactionDO billPayCoreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(billPayTxnId.toString());

        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        billPayTxnRequestDomainContext.setBillerDO(billPayTransactionDO.getBillerDO());
        billPayTransaction.setCustomerBillAccount(CustomerBillAccount.builder()
                .processorBillerId(billPayTransactionDO.getBillerDO().getProcessorBillerId())
                .accountNumber(billPayTransactionDO.getAccountNumber())
                .customerAccountId(billPayTransactionDO.getCustomerAccountId()).build());
        billPayTransaction.setBiller(billerMapper.mapBillerDOToBillerWithoutSubBillersAndBillPlans(billPayTransactionDO.getBillerDO()));
        billPayTransaction.setAmountRequested(Amount.builder()
                .value(billPayTransactionDO.getAmount())
                .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(billPayTransactionDO.getCurrencyUnit().name()))
                .build());

        if (Objects.nonNull(billPayTransactionDO.getBillDetailDO())) {
            billPayTransaction.setBillDetail(billerMapper.mapBillDetail(billPayTransactionDO.getBillDetailDO()));
        }

        List<GiftCardTransactionDO> billPayGiftCardTransactionDOList = billPayCoreTransactionDO.getGiftCardSubTransactionList();
        List<GiftCardTransaction> giftCardPaymentTransactionList = new ArrayList<>();
        for (GiftCardTransactionDO giftCardTransactionDO : billPayGiftCardTransactionDOList) {
            GiftCardTransaction giftCardPaymentTransaction = GiftCardTransaction.builder()
                    .paymentInstrumentId(giftCardTransactionDO.getPaymentInstrumentId())
                    .amount(Amount.builder()
                            .value(giftCardTransactionDO.getAmount())
                            .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(giftCardTransactionDO.getCurrency().name()))
                            .build())
                    .giftCardTransactionType(GiftCardTransactionType.PAY)
                    .giftCardPaymentInstrument(GiftCardPaymentInstrument.builder()
                            .adapterMetadata(GiftCardPaymentInstrument.AdapterMetadata.builder()
                                    .piHash(giftCardTransactionDO.getPaymentProviderInstrumentId())
                                    .build())
                            .build())
                    .build();
            giftCardPaymentTransactionList.add(giftCardPaymentTransaction);
        }
        billPayTransaction.setGiftCardPaymentTransactionList(giftCardPaymentTransactionList);

        CardTransactionDO coFTopupCardTransactionDO =  coFTopupCoreTransactionDO.getCardSubTransactionList().get(0);
        List<CardPaymentTransaction> cardPaymentTransactionList = new ArrayList<>();
        CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                .cardSubTransaction(CardPaymentTransaction.CardSubTransaction.builder()
                        .id(coFTopupCardTransactionDO.getSubTransactionId())
                        .build())
                .paymentInstrumentId(coFTopupCardTransactionDO.getPaymentInstrumentId())
                .amount(Amount.builder()
                        .value(coFTopupCardTransactionDO.getAmount())
                        .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(coFTopupCardTransactionDO.getCurrency().name()))
                        .build())
                .affiliationType(AffiliationType.valueOf(coFTopupCardTransactionDO.getAffiliationType()))
                .cardPaymentInstrument(CardPaymentInstrument.builder()
                        .adapterMetadata(CardPaymentInstrument.AdapterMetadata.builder()
                                .tokenId(coFTopupCardTransactionDO.getPaymentProviderInstrumentId())
                                .build())
                        .build())
                .build();
        cardPaymentTransactionList.add(cardPaymentTransaction);
        billPayTransaction.setCardPaymentTransactionList(cardPaymentTransactionList);

        mapCustomerDataToContext(customer, cardPaymentTransaction, giftCardPaymentTransactionList);

        CoFTopUpTransaction coFTopUpTransaction = CoFTopUpTransaction.builder()
                .transactionType(TransactionType.COF_TOPUP)
                .parentTransaction(billPayTransaction)
                .customer(customer)
                .build();
        coFTopupMapper.updateCoFTopupTransactionFromCoFTopupTransactionDO(coFTopupTransactionDO, coFTopUpTransaction);
        billPayTransaction.setInternalCoFTopupTransaction(coFTopUpTransaction);
    }

    private void isCoFTopupTxnIn3DSGeneratedState(CoFTopupTransactionDO coFTopupTransactionDO) {
        if (!coFTopupTransactionDO.getState().equals(com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum.PENDING) || !coFTopupTransactionDO.getStateReason().equals(CoFTopupTxnStateReason.DEBIT_3DS_GENERATED)) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_COF_TOPUP_TXN_STATE);
        }
    }

    private void isBillPayTxnIn3DSGeneratedState(BillPayTransactionDO billPayTransactionDO) {
        if (!billPayTransactionDO.getState().equals(com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum.PENDING) || !billPayTransactionDO.getStateReason().equals(com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason.TOPUP_3DS_GENERATED)) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.INVALID_BILL_PAY_TXN_STATE);
        }
    }

    private void mapCustomerDataToContext(Customer customer, CardPaymentTransaction cardPaymentTransaction,
                                          List<GiftCardTransaction> giftCardPaymentTransactionList) {
        log.info("Mapping customer data to context for customerAccountId:[{}]", customer.getCustomerAccountId());
        CustomerResponse customerResponse = customerServiceClient.getCustomerDetailsById(customer.getCustomerAccountId());
        if (customerResponse == null) {
            throw new BusinessValidationException(ErrorConstants.PayBillInit.CUSTOMER_ACCOUNT_NOT_FOUND);
        }
        customerMapper.updateCustomerDataInContext(customerResponse, customer);
        mapPaymentInstrumentsToCustomerContext(customer, customerResponse);
        setCardAndGiftCardPaymentInstrumentInContextFromCustomerResponse(cardPaymentTransaction, giftCardPaymentTransactionList, customerResponse);
    }

    private void mapPaymentInstrumentsToCustomerContext(Customer customer, CustomerResponse customerResponse) {
        log.info("Mapping payment instruments to customer context for customerAccountId:[{}]", customer.getCustomerAccountId());
        customerMapper.mapPaymentInstrumentsToCustomerContext(customer, customerResponse);
    }

    private void setCardAndGiftCardPaymentInstrumentInContextFromCustomerResponse(CardPaymentTransaction cardPaymentTransaction,
                                                                                  List<GiftCardTransaction> giftCardPaymentTransactionList,
                                                                                  CustomerResponse customerResponse) {
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = customerResponse.getWalletAccountDTO().getWalletResponse().getPaymentInstruments();
        paymentInstrumentList.forEach (paymentInstrument -> {
        if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.CARD) &&
                paymentInstrument.getAdapterMetadata().getTokenId().equals(cardPaymentTransaction.getCardPaymentInstrument().getAdapterMetadata().getTokenId())) {
            cardPaymentTransaction.setPaymentInstrumentId(paymentInstrument.getPaymentInstrumentId());
            cardPaymentTransaction.setCardPaymentInstrument(customerMapper.mapPaymentInstrumentToCardPaymentInstrument(paymentInstrument));
            cardPaymentTransaction.setProviderWalletId(paymentInstrument.getAdapterMetadata().getWalletId());
        } else if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.GIFTCARD)
                && paymentInstrument.getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CASHI_WALLET)) {
                for (GiftCardTransaction giftCardTransaction : giftCardPaymentTransactionList) {
                    if (paymentInstrument.getAdapterMetadata().getPiHash().equals(giftCardTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash())) {
                        giftCardTransaction.setPaymentInstrumentId(paymentInstrument.getPaymentInstrumentId());
                        giftCardTransaction.setGiftCardPaymentInstrument(customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument));
                    }
                }
            }
        });
    }
}
