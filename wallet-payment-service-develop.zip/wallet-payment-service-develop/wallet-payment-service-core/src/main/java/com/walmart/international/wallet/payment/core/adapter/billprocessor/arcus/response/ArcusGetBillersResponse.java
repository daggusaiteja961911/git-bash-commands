package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response;

import lombok.Data;

import java.util.List;

@Data
public class ArcusGetBillersResponse {

    private List<ArcusBillerResponse> billers;
}
