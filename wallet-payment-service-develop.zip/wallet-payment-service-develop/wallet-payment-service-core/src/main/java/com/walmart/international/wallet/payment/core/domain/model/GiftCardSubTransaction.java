package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
public class GiftCardSubTransaction {
    private UUID id;
    // pi hash which is passed on to payment core
    private String paymentProviderInstrumentId;
    private UUID paymentInstrumentId;
    private SubTransactionStatusV2 status;
    private String authCode;
    private Amount amount;
    private String failureCode;
    private String failureDescription;
    private Date createDate;
    private Date updateDate;
    private UUID parentSubTransactionId;
}
