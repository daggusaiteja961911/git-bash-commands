package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class ChargeEventDetails {
    private String requestId;
    private String orderId;
    private String banner;
    private String paymentGateway;
    private String profileId;
    private String orderChannel;
    private String paymentBrokerParentId;
    private String externalOrderReference;
    private List<CardDetails> cards;
    private List<PaymentDetails> payments;
    private FraudDetailsV2 fraudDetails;

    @Data
    public static class PaymentDetails {
        private String paymentBrokerId;
        private String paymentId;
        private String paymentType;
        private String externalOrderReference;
        private GatewayDetails gateway;
        private Boolean paymentWithPoints;
        private String cardId;
        private String creationDate;
        private String description;
        private String method;
        private PaymentStatus status;
        private String currency;
        private String operationDate;
        private BigDecimal amount;
        private Boolean isMSI;
        private ErrorDetails error;
        private Boolean auth;
        private Integer msi;
        private String fraudStatus;
    }
}
