package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.webclient;

import com.walmart.international.services.digitalwallet.httpclient.wallet.constants.ApiName;

public enum ArcusAPIName implements ApiName {
    CREATE_BILL, REFRESH_BILL, PAY_BILL, GET_TXNS, GET_ACCOUNT, GET_UTILITIES, GET_TOPUPS, GET_GIFT_CARDS;

    @Override
    public String getApiName() {
        return this.name();
    }
}
