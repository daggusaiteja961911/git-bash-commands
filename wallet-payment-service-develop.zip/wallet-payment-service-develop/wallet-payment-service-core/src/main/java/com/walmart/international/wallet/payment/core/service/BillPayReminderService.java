package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.notification.ReminderAdapter;
import com.walmart.international.notification.constants.MessagingEvent;
import com.walmart.international.notification.dto.ReminderPayloadDTO;
import com.walmart.international.notification.exceptions.ReminderServiceException;
import com.walmart.international.services.notificationservice.naas.ReminderSubCategoryType;
import com.walmart.international.wallet.payment.core.config.ccm.BillReminderConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.dto.NotificationContentDTO;
import com.walmart.international.wallet.payment.core.dto.ReminderCategoryDTO;
import com.walmart.international.wallet.payment.core.service.helper.BillPayReminderHelper;
import com.walmart.international.wallet.payment.core.utils.WPSDateUtils;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentCategory;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentIdentifier;
import com.walmart.international.wallet.payment.data.dao.entity.NotificationContentDO;
import com.walmart.international.wallet.payment.data.dao.repository.NotificationContentRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.commons.lang.exception.ExceptionUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.OffsetTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BillPayReminderService {
    @Autowired
    private ReminderAdapter reminderAdapter;

    @Autowired
    private NotificationContentRepository notificationContentRepository;

    @Autowired
    private BillPayReminderHelper billPayReminderHelper;

    @ManagedConfiguration
    private BillReminderConfiguration billReminderConfiguration;

    public void raiseS1BillerReminder(CustomerBillAccount customerBillAccount, Customer customer) throws ReminderServiceException {
        Date currentDate = new Date();
        SimpleDateFormat newFormat = BillPayReminderHelper.getNotificationContentNewDateFormat();
        String formattedExpiryDate = newFormat.format(customerBillAccount.getDueDate());
        //notification  content
        List<NotificationContentDO> notificationContentDOS = notificationContentRepository.getNotificationContentBySegmentOrBiller(NotificationContentIdentifier.S1.name(), customerBillAccount.getProcessorBillerId());
        if (notificationContentDOS != null && !notificationContentDOS.isEmpty()) {
            notificationContentDOS = billPayReminderHelper.filterAndSortNotificationContentDOList(notificationContentDOS);
            NotificationContentDTO notificationContentDTO = prepareNotificationContentDTO(customerBillAccount, null, formattedExpiryDate, null, NotificationContentIdentifier.S1);
            List<NotificationContentDO> filteredNotificationContentDOs = billPayReminderHelper.getFilteredNotificationContentDOS(notificationContentDOS, notificationContentDTO);
            int reminderCount = 1;
            for (NotificationContentDO notificationContentDO : filteredNotificationContentDOs) {
                log.info("Processing notificationContentDO for S1 Billers: {}", notificationContentDO);
                Date reminderDate = null;
                billPayReminderHelper.setNotificationContentDetails(notificationContentDO, notificationContentDTO);
                ReminderCategoryDTO reminderCategoryDTO = getReminderCategoryDetails(reminderCount, NotificationContentCategory.REMINDER);
                reminderDate = billPayReminderHelper.getReminderDateBasedOnSubcategory(notificationContentDO, customerBillAccount.getDueDate(), currentDate);
                raiseAddBillPayPushReminderEvent(customerBillAccount, notificationContentDTO, reminderCategoryDTO, reminderDate);
                reminderCount++;
            }
        }
        raiseEventForFirstBillPayEmailReminderNotification(customerBillAccount, customer);
        raiseEventForSecondBillPayEmailReminderNotification(customerBillAccount, customer);
        raiseEventForDueTodayBillPayEmailReminderNotification(customerBillAccount, customer);
    }

    public void raiseS2BillerReminder(CustomerBillAccount customerBillAccount, Customer customer, BillDetail billDetail) throws ReminderServiceException {
        try {
            Date dueDate = customerBillAccount.getDueDate();
            SimpleDateFormat newFormat = BillPayReminderHelper.getNotificationContentNewDateFormat();
            String formattedExpiryDate = newFormat.format(dueDate);
            List<NotificationContentDO> notificationContentDOS = notificationContentRepository.getNotificationContentBySegmentOrBiller(NotificationContentIdentifier.S2.name(), customerBillAccount.getProcessorBillerId());

            if (notificationContentDOS != null && !notificationContentDOS.isEmpty()) {
                notificationContentDOS = billPayReminderHelper.filterAndSortNotificationContentDOList(notificationContentDOS);
                NotificationContentDTO notificationContentDTO = prepareNotificationContentDTO(customerBillAccount, billDetail, formattedExpiryDate, null, NotificationContentIdentifier.S2);
                int reminderCount = 1;
                List<NotificationContentDO> filteredNotificationContentDOs = billPayReminderHelper.getFilteredNotificationContentDOS(notificationContentDOS, notificationContentDTO);
                for (NotificationContentDO notificationContentDO : filteredNotificationContentDOs) {
                    log.info("Processing notificationContentDO for S2 billers: {}", notificationContentDO);
                    Date reminderDate;
                    billPayReminderHelper.setNotificationContentDetails(notificationContentDO, notificationContentDTO);
                    ReminderCategoryDTO reminderCategoryDTO = getReminderCategoryDetails(reminderCount, NotificationContentCategory.REMINDER);
                    reminderDate = billPayReminderHelper.getReminderDateBasedOnSubcategory(notificationContentDO, customerBillAccount.getDueDate(), new Date());
                    if (isPushReminderNeededForBillPay(dueDate, notificationContentDO, reminderDate)) {
                        raiseAddBillPayPushReminderEvent(customerBillAccount, notificationContentDTO, reminderCategoryDTO, reminderDate);
                    }
                    reminderCount++;
                }
            }
            raiseEventForFirstBillPayEmailReminderNotification(customerBillAccount, customer);
            raiseEventForSecondBillPayEmailReminderNotification(customerBillAccount, customer);
            raiseEventForDueTodayBillPayEmailReminderNotification(customerBillAccount, customer);

        } catch (ReminderServiceException rse) {
            throw rse;
        }
        catch (Exception e) {
            log.error(String.format("Raising reminder Event task failed for : customerBillId[%s], billerId[%s], accountNumber[%s]. Generic Error: {%s}",
                customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getBillerId(), customerBillAccount.getAccountNumber(), e.getCause()));
            throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_GENERIC_EXCEPTION, ExceptionUtils.getRootCauseMessage(e), e);
        }
    }

    public void raiseS3S4BillerNudges(CustomerBillAccount customerBillAccount, Customer customer, NotificationContentIdentifier notificationContentIdentifier) throws ReminderServiceException {
        SimpleDateFormat newFormat = BillPayReminderHelper.getNotificationContentNewDateFormat();
        String lastPaidDate = newFormat.format(customerBillAccount.getLastPaidDateValue());

        //notification  content
        List<NotificationContentDO> notificationContentDOS = notificationContentRepository.getNotificationContentBySegmentOrBiller(notificationContentIdentifier.name(), customerBillAccount.getProcessorBillerId());
        if (notificationContentDOS != null && !notificationContentDOS.isEmpty()) {
            notificationContentDOS = billPayReminderHelper.filterAndSortNotificationContentDOList(notificationContentDOS);
            NotificationContentDTO notificationContentDTO = prepareNotificationContentDTO(customerBillAccount, null, null, lastPaidDate, NotificationContentIdentifier.S1);

            int reminderCount = 1;
            List<Integer> daysForBillPaymentNudgeList = billReminderConfiguration.getDaysOfMonthForBillPaymentNudge() != null ? Arrays.stream(billReminderConfiguration.getDaysOfMonthForBillPaymentNudge().split(",")).map(Integer::valueOf).sorted().collect(Collectors.toList()) : Collections.emptyList();
            LocalDate lastPaidLocalDate = WPSDateUtils.dateToLocalDate(customerBillAccount.getLastPaidDateValue());
            LocalDate dateOfNudge = billPayReminderHelper.getFirstDateOfNudge(lastPaidLocalDate, daysForBillPaymentNudgeList, customerBillAccount);
            for (NotificationContentDO notificationContentDO : notificationContentDOS) {
                log.info("Processing Nudges notificationContentDO: {}", notificationContentDO);
                Date nudgeDate = Date.from(dateOfNudge.atTime(OffsetTime.now()).toInstant());
                billPayReminderHelper.setNotificationContentDetails(notificationContentDO, notificationContentDTO);
                ReminderCategoryDTO reminderCategoryDTO = getReminderCategoryDetails(reminderCount, NotificationContentCategory.NUDGE);
                raiseAddBillPayPushReminderEvent(customerBillAccount, notificationContentDTO, reminderCategoryDTO, nudgeDate);
                raiseAddBillPayEmailReminderEvent(customerBillAccount, customer, reminderCategoryDTO.getReminderSubCategoryType(), nudgeDate, reminderCategoryDTO.getMessagingEvent());
                dateOfNudge = billPayReminderHelper.getNextDateOfNudge(dateOfNudge, daysForBillPaymentNudgeList);
                reminderCount++;
            }
        } else {
            log.info("NotificationContentDO not found for identifier segment {}", notificationContentIdentifier);
        }
    }

    private void raiseAddBillPayPushReminderEvent(CustomerBillAccount customerBillAccount, NotificationContentDTO notificationContentDTO,
                                                  ReminderCategoryDTO reminderCategoryDTO, Date reminderDate) throws ReminderServiceException {
        log.info("Raising Event [{}] for processorBillAccountId: [{}] billerId: [{}] accountNumber: [{}]. Client Request Id: [{}]",
            reminderCategoryDTO.getMessagingEvent().toString(), customerBillAccount.getCustomerBillAccountId(),
            customerBillAccount.getBiller().getBillerId(),  customerBillAccount.getAccountNumber(), customerBillAccount.getCustomerBillAccountId());

        ReminderPayloadDTO reminderPayload = billPayReminderHelper.generateNewBillPayPushReminderPayload(customerBillAccount, notificationContentDTO, reminderCategoryDTO, reminderDate);
        reminderAdapter.setReminder(reminderPayload);
    }

    private void raiseEventForFirstBillPayEmailReminderNotification(CustomerBillAccount customerBillAccount, Customer customer) throws ReminderServiceException {
        Date reminderDate = billPayReminderHelper.getFirstBillPayReminderDate(customerBillAccount, new Date());
        if (reminderDate != null) {
            raiseAddBillPayEmailReminderEvent(customerBillAccount, customer, ReminderSubCategoryType.BILL_PAY_FIRST_NOTIFICATION, reminderDate, MessagingEvent.BILL_PAY_FIRST_REMINDER);
        }
    }

    private void raiseEventForSecondBillPayEmailReminderNotification(CustomerBillAccount customerBillAccount, Customer customer) throws ReminderServiceException {
        Date reminderDate = billPayReminderHelper.getSecondBillPayReminderDate(customerBillAccount, new Date());
        if (reminderDate != null) {
            raiseAddBillPayEmailReminderEvent(customerBillAccount, customer, ReminderSubCategoryType.BILL_PAY_SECOND_NOTIFICATION, reminderDate, MessagingEvent.BILL_PAY_SECOND_REMINDER);
        }
    }
    private void raiseEventForDueTodayBillPayEmailReminderNotification(CustomerBillAccount customerBillAccount, Customer customer) throws ReminderServiceException {
        Date reminderDate = customerBillAccount.getDueDate();
        if (reminderDate != null) {
            raiseAddBillPayEmailReminderEvent(customerBillAccount, customer, ReminderSubCategoryType.BILL_PAY_NOTIFICATION_ON_DUE_DATE, reminderDate, MessagingEvent.BILL_PAY_REMINDER_ON_DUE_DATE);
        }
    }

    private void raiseAddBillPayEmailReminderEvent(CustomerBillAccount customerBillAccount, Customer customer, ReminderSubCategoryType reminderSubCategory,
                                                   Date reminderDate, MessagingEvent messagingEvent) throws ReminderServiceException {
        if (!billReminderConfiguration.isBillPayEmailReminderEnabled()) {
            log.info("Did not raise add email bill pay reminder event. Bill pay email reminder disabled.");
            return;
        }

        if (!billPayReminderHelper.isEmailCommunicationEnabled(messagingEvent)) {
            log.info("Did not raise add email bill pay reminder for [{}] as it is disabled. (billpay-reminder-config)", messagingEvent);
            return;
        }

        log.info("Raising Event [{}] for customerBillId: [{}] billerId: [{}] accountNumber: [{}]. Creating email bill pay reminder",
            messagingEvent, customerBillAccount.getProcessorBillAccountId(),
            customerBillAccount.getBillerId(), customerBillAccount.getAccountNumber());

        ReminderPayloadDTO reminderEmailPayload = billPayReminderHelper.generateNewBillPayEmailReminderPayload(customerBillAccount, customer, reminderSubCategory, reminderDate, messagingEvent);
        reminderAdapter.setReminder(reminderEmailPayload);
    }

    private boolean isPushReminderNeededForBillPay(Date dueDate, NotificationContentDO notificationContentDO, Date reminderDate) {
        return reminderDate.before(dueDate) || (reminderDate.equals(dueDate) && billPayReminderHelper.isNotificationContentSubcategoryForDueToday(notificationContentDO.getSubcategory()));
    }

    private ReminderCategoryDTO getReminderCategoryDetails(int reminderCount, NotificationContentCategory notificationContentCategory) throws ReminderServiceException {
        ReminderCategoryDTO reminderCategoryDTO;
        if (notificationContentCategory == NotificationContentCategory.REMINDER) {
            switch (reminderCount) {
                case 1:
                    reminderCategoryDTO = ReminderCategoryDTO.builder()
                            .reminderSubCategoryType(ReminderSubCategoryType.BILL_PAY_FIRST_NOTIFICATION)
                            .messagingEvent(MessagingEvent.BILL_PAY_FIRST_REMINDER)
                            .build();
                    return reminderCategoryDTO;
                case 2:
                    reminderCategoryDTO = ReminderCategoryDTO.builder()
                            .reminderSubCategoryType(ReminderSubCategoryType.BILL_PAY_SECOND_NOTIFICATION)
                            .messagingEvent(MessagingEvent.BILL_PAY_SECOND_REMINDER)
                            .build();
                    return reminderCategoryDTO;
                case 3:
                    reminderCategoryDTO = ReminderCategoryDTO.builder()
                            .reminderSubCategoryType(ReminderSubCategoryType.BILL_PAY_NOTIFICATION_ON_DUE_DATE)
                            .messagingEvent(MessagingEvent.BILL_PAY_REMINDER_ON_DUE_DATE)
                            .build();
                    return reminderCategoryDTO;
                default:
                    throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_CATEGORY_NULL, "Reminder category dto is null. Reminder count: " + reminderCount);
            }
        } else {
            switch (reminderCount) {
                case 1:
                    reminderCategoryDTO = ReminderCategoryDTO.builder()
                            .reminderSubCategoryType(ReminderSubCategoryType.BILL_PAY_FIRST_NUDGE)
                            .messagingEvent(MessagingEvent.BILL_PAY_NUDGE)
                            .build();
                    return reminderCategoryDTO;
                case 2:
                    reminderCategoryDTO = ReminderCategoryDTO.builder()
                            .reminderSubCategoryType(ReminderSubCategoryType.BILL_PAY_SECOND_NUDGE)
                            .messagingEvent(MessagingEvent.BILL_PAY_NUDGE)
                            .build();
                    return reminderCategoryDTO;
                case 3:
                    reminderCategoryDTO = ReminderCategoryDTO.builder()
                            .reminderSubCategoryType(ReminderSubCategoryType.BILL_PAY_THIRD_NUDGE)
                            .messagingEvent(MessagingEvent.BILL_PAY_NUDGE)
                            .build();
                    return reminderCategoryDTO;
                default:
                    throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_CATEGORY_NULL, "Reminder nudge category dto is null. Reminder count: " + reminderCount);
            }
        }
    }

    private NotificationContentDTO prepareNotificationContentDTO(CustomerBillAccount customerBillAccount, BillDetail billDetail,
                                                                 String formattedExpiryDate, String formattedLastPaidDate,
                                                                 NotificationContentIdentifier notificationContentIdentifier) {
        return NotificationContentDTO.builder()
                .billerName(customerBillAccount.getBiller().getDisplayName())
                .formattedDueDate(formattedExpiryDate)
                .dueDate(customerBillAccount.getDueDate())
                .alias(customerBillAccount.getAlias())
                .amount(!Objects.isNull(customerBillAccount.getDueAmount()) ? customerBillAccount.getDueAmount() : customerBillAccount.getLastPaidAmountValue())
                .identifier(notificationContentIdentifier.name())
                .validity(Objects.nonNull(billDetail) ? billDetail.getValidity() : null)
                .itemDescription(Objects.nonNull(billDetail) ? billDetail.getDescription() : null)
                .lastPaidDate(formattedLastPaidDate)
                .lastPaidAmount(customerBillAccount.getLastPaidAmountValue())
                .product(customerBillAccount.getBiller().getDisplayName())
                .build();
    }

    public void raiseBillPayReminderNotificationsEvents(BillPayTransaction billPayTransaction) throws ReminderServiceException {
        CustomerBillAccount customerBillAccount = billPayTransaction.getCustomerBillAccount();
        Biller biller = customerBillAccount.getBiller();
        try {
            customerBillAccount.setDueAmount(null);
            customerBillAccount.setDueAmountCurrencyUnit(null);
            Date topUpExpiryDate = billPayReminderHelper.getTopUpExpiryDate(billPayTransaction.getBillDetail(), new Date());
            if (biller.getCanCheckBalance()) {
                customerBillAccount.setDueDate(null);
                customerBillAccount.setDueInfoUpdatedAt(new Date());
                raiseDeleteBillPayReminderEvent(customerBillAccount);
            } else if (topUpExpiryDate != null) {
                customerBillAccount.setDueDate(topUpExpiryDate);
                customerBillAccount.setDueInfoUpdatedAt(new Date());
                raiseS2BillerReminder(billPayTransaction.getCustomerBillAccount(), billPayTransaction.getCustomer(), billPayTransaction.getBillDetail());
            } else {
                customerBillAccount.setDueDate(null);
                customerBillAccount.setDueInfoUpdatedAt(null);
                customerBillAccount.setSkipReminderTillDate(null);
                NotificationContentIdentifier notificationContentIdentifier = billPayReminderHelper.isConsumptionBasedBiller(biller) ? NotificationContentIdentifier.S3 : NotificationContentIdentifier.S4;
                raiseS3S4BillerNudges(billPayTransaction.getCustomerBillAccount(), billPayTransaction.getCustomer(), notificationContentIdentifier);
            }
        } catch (ReminderServiceException rse) {
            throw rse;
        } catch (Exception ex) {
            log.error("Caught generic exception before calling raise bill pay reminder/nudge events. ex: {}", ex.getMessage(), ex);
            throw new ReminderServiceException(ErrorConstants.PayBillInit.BILL_PAY_REMINDER_GENERIC_EXCEPTION, ExceptionUtils.getRootCauseMessage(ex), ex);
        }
    }

    public void raiseDeleteBillPayReminderEvent(CustomerBillAccount customerBillAccount) throws ReminderServiceException {
        log.info("Raising Event to delete reminder for customerBillId: [{}] billerId: [{}] accountNumber: [{}]", customerBillAccount.getCustomerBillAccountId(),
            customerBillAccount.getBillerId(), customerBillAccount.getAccountNumber());

        ReminderPayloadDTO reminderPayload = billPayReminderHelper.getDeleteReminderPayload(customerBillAccount);
        reminderAdapter.setReminder(reminderPayload);
    }

    public void raiseDeleteBillPayReminderForSubcategoryEvent(CustomerBillAccount customerBillAccount, ReminderSubCategoryType reminderSubCategory) throws ReminderServiceException{
        log.info("Raising Event to delete reminder with subCategory: [{}] for customerBillId: [{}] billerId: [{}] accountNumber: [{}]", reminderSubCategory.name(), customerBillAccount.getCustomerBillAccountId(),
                customerBillAccount.getBillerId(), customerBillAccount.getAccountNumber());

        ReminderPayloadDTO reminderPayload = billPayReminderHelper.getDeleteReminderPayload(customerBillAccount);
        reminderPayload.setSubCategory(reminderSubCategory.name());
        reminderAdapter.setReminder(reminderPayload);
    }
}