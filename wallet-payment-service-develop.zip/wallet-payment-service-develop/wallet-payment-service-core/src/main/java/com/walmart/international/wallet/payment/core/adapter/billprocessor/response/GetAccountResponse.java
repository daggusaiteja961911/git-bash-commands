package com.walmart.international.wallet.payment.core.adapter.billprocessor.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetAccountResponse {

    private String name;

    private BigDecimal balance;

    private BigDecimal minimumBalance;

    private String currency;
    
}
