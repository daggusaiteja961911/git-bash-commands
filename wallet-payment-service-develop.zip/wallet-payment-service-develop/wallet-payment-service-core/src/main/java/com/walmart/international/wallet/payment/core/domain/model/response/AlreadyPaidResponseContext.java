package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AlreadyPaidResponseContext {
    private CustomerBillAccount customerBillAccount;
}
