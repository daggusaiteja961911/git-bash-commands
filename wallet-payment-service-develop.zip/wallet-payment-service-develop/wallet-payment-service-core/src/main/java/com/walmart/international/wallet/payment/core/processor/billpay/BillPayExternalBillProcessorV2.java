package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentSubType;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.services.payment.core.dao.repository.CoreTransactionRepository;
import com.walmart.international.services.payment.core.model.CoreTransactionDO;
import com.walmart.international.services.payment.core.model.GiftCardTransactionDO;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessorFactory;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.mapper.BillerMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillDetailDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillDetailRepository;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class BillPayExternalBillProcessorV2 implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private BillProcessorFactory billProcessorFactory;

    private BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    private BillerMapper billerMapper = BillerMapper.INSTANCE;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    @Autowired
    CoreTransactionRepository coreTransactionRepository;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Autowired
    private BillDetailRepository billDetailRepository;

    @Autowired
    private CustomerBillAccountRepository customerBillAccountRepository;

    private CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillPayTxnRequestDomainContext reconcileBillPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext reconcileBillPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        BillPayTransaction billPayTransaction = reconcileBillPayTxnRequestDomainContext.getTransaction();
        UUID billPayTransactionId = billPayTransaction.getTransactionId();
        BillPayTransactionDO billPayTransactionDO;

        if (Objects.nonNull(billPayTransactionId)) {
            Optional<BillPayTransactionDO> oBillPayTransactionDO = billPayTransactionRepository.findById(billPayTransactionId);
            if (oBillPayTransactionDO.isPresent()) {
                billPayTransactionDO = oBillPayTransactionDO.get();
            } else {
                throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.INVALID_BILL_PAY_TXN_ID);
            }
        } else {
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.BILL_PAY_TXN_ID_NOT_FOUND);
        }
        validateBillPayTxnForReconciliation(billPayTransactionDO);
        reconcileBillPayTxnResponseDomainContext.setBillPayTransactionDO(billPayTransactionDO);
        billPayMapper.updateBillPayTransactionFromBillPayTransactionDO(billPayTransactionDO, billPayTransaction);
        reconcileBillPayTxnResponseDomainContext.setTransaction(billPayTransaction);

        BillerDO billerDO = billPayTransactionDO.getBillerDO();
        if (Objects.isNull(billerDO)) {
            logger.error("Biller with billpayTxnId[{}] is null", billPayTransactionDO.getBillPayTransactionId());
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.BILLER_NOT_FOUND_OR_NOT_ENABLED);
        }

        List<PayBillResponse> payBillResponseList;
        try {
            payBillResponseList = callBillProcessorGetTxn(billPayTransactionDO.getCashiOrderId(), billPayTransactionDO.getBillerDO().getArcusAuthKeyVersion());
            if (payBillResponseList.isEmpty()) {
                log.info("Arcus billpay response is empty for cashiOrderId:[{}]", billPayTransactionDO.getCashiOrderId());
                return false;
            }
        } catch (BusinessValidationException ae) {
            log.error("Arcus call to fetch pending txn failed for transactionId:[{}], with errorCode:[{}}. message:[{}]",
                    billPayTransactionId, ae.getErrorCode(), ae.getMessage());
            return false;
        }

        try {
            for (PayBillResponse payBillResponse : payBillResponseList) {
                handleBillProcessorSuccessResponse(payBillResponse, reconcileBillPayTxnResponseDomainContext);
            }
        } catch (ProcessingException pe) {
            log.error("Recon bill pay process success response failed for transactionId:[{}], with errorCode:[{}}. StackTrace:[{}]",
                    reconcileBillPayTxnResponseDomainContext.getTransaction().getTransactionId(), pe.getErrorCode(), ExceptionUtils.getStackTrace(pe));
            return false;
        }

        CustomerBillAccountDO customerBillAccountDO = buildDataForReconcilePayBillFlow(billPayTransactionDO, billPayTransaction);
        reconcileBillPayTxnResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);

        return true;
    }

    private List<PayBillResponse> callBillProcessorGetTxn(String cashiOrderId, int arcusAuthKeyVersion) {
        List<PayBillResponse> payBillResponseList;
        try {
            payBillResponseList = billProcessorFactory.getBillProcessor().getTxn(cashiOrderId, arcusAuthKeyVersion);
        } catch (BillProcessorException ex) {
            String msg = String.format("Processing error in GetTxns for cashiOrderId[%s]", cashiOrderId);
            throw new ProcessingException(ex.getErrorCode(), msg, ex);
        }
        return payBillResponseList;
    }

    private void handleBillProcessorSuccessResponse(PayBillResponse payBillResponse, BillPayTxnResponseDomainContext wpsResponseDomainContext) {
        log.info("Recon Handling success response from bill processor for BillPayTransaction with txnId[{}]",
                wpsResponseDomainContext.getBillPayTransactionDO().getBillPayTransactionId());
        try {
            billPayMapper.mapPayBillResponseToBillPayTransactionDO(payBillResponse, wpsResponseDomainContext.getBillPayTransactionDO());
            updateBillPayTxnState(wpsResponseDomainContext,
                    TransactionStateEnum.SUCCESS,
                    BillPayTxnStateReason.BILL_PROCESSOR_PAYMENT_SUCCESS);
        } catch (Exception ex) {
            String msg = String.format("Error in recon bill pay while updating BillPayTransaction with txnId[%s] to SUCCESS",
                    wpsResponseDomainContext.getBillPayTransactionDO().getBillPayTransactionId());
            throw new ProcessingException(ErrorConstants.ReconcileBillPayTxn.RECON_PAY_BILL_DB_UPDATE_FAILURE, msg, ex);
        }
    }

    private void updateBillPayTxnState(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext,
                                       TransactionStateEnum state,
                                       BillPayTxnStateReason stateReason) {
        BillPayTransactionDO billPayTransactionDO = billPayTxnResponseDomainContext.getBillPayTransactionDO();
        log.info("Recon Updating BillPayTransaction with txnId:[{}] with state:[{}] and stateReason:[{}]",
                billPayTransactionDO.getBillPayTransactionId(), state, stateReason);
        if (!state.equals(billPayTransactionDO.getState())
                && (state.equals(TransactionStateEnum.FAILURE) || state.equals(TransactionStateEnum.SUCCESS))) {
            billPayTransactionDO.updateTxnReqCompletedDate();
        }

        billPayTransactionDO = walletPaymentServiceUtil.updateLastEventDateCheck(billPayTransactionDO, state, stateReason);

        billPayTransactionDO.setState(state);
        billPayTransactionDO.setStateReason(stateReason);
        billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
        billPayTxnResponseDomainContext.setBillPayTransactionDO(billPayTransactionDO);
    }

    private void validateBillPayTxnForReconciliation(BillPayTransactionDO billPayTransactionDO) throws BusinessValidationException {
        if (Objects.isNull(billPayTransactionDO.getState()) || Objects.isNull(billPayTransactionDO.getStateReason())) {
            logger.error("Bill Pay Txn does not have valid state/stateReason.");
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.INVALID_BILL_PAY_TXN_STATE_OR_STATE_REASON);
        } else if (!billPayTransactionDO.getState().equals(TransactionStateEnum.PENDING)) {
            logger.error("Bill Pay Txn is not in PENDING state. Current state = [{}]", billPayTransactionDO.getState());
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.BILL_PAY_TXN_STATE_NOT_PENDING);
        }
    }

    private CustomerBillAccountDO buildDataForReconcilePayBillFlow(BillPayTransactionDO billPayTransactionDO, BillPayTransaction billPayTransaction) throws ProcessingException {
        CustomerBillAccountDO customerBillAccountDO;
        Optional<CustomerBillAccountDO> oCustomerBillAccountDO = customerBillAccountRepository.findByCustomerAccountIdAndAccountNumberAndBillerDO(billPayTransactionDO.getCustomerAccountId(), billPayTransactionDO.getAccountNumber(), billPayTransactionDO.getBillerDO());

        if (oCustomerBillAccountDO.isEmpty()) {
            log.info("Recon pay bill flow, customerBillAccountDO for customerAccountId:[{}], accountNumber:[{}], billerDO:[{}]", "customerAccountId", "accountNumber", "billerDO");
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.CUSTOMER_BILL_ACCOUNT_NOT_FOUND);
        }

        customerBillAccountDO = oCustomerBillAccountDO.get();

        CustomerBillAccount customerBillAccount = customerBillAccountMapper.customerBillAccountDOToCustomerBillAccountWithBiller(customerBillAccountDO);
        BillDetailDO billDetailDO = getBillDetailDOForReconcilePayBill(billPayTransactionDO);
        CustomerResponse customerResponse = getCustomerResponseForReconcilePayBill(billPayTransactionDO);
        Customer customer = customerMapper.mapCustomerFromDTOToContext(customerResponse);

        billPayTransaction.setCustomerBillAccount(customerBillAccount);
        billPayTransaction.setBillDetail(billerMapper.mapBillDetail(billDetailDO));

        customerMapper.updateCustomerDataInContext(customerResponse, customer);
        billPayTransaction.setCustomer(customer);
        billPayMapper.updateBillPayTransactionFromBillPayTransactionDO(billPayTransactionDO, billPayTransaction);
        billPayTransaction.setAmountFulfilled(Amount.builder()
                .value(billPayTransactionDO.getAmount())
                .currencyUnit(CurrencyUnit.valueOf(billPayTransactionDO.getCurrencyUnit().name()))
                .build());
        billPayTransaction.setCardPaymentTransactionList(null);

        CoreTransactionDO billPayCoreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(billPayTransaction.getTransactionId().toString());
        List<GiftCardTransactionDO> billPayGiftCardTransactionDOList = billPayCoreTransactionDO.getGiftCardSubTransactionList();
        List<GiftCardTransaction> giftCardPaymentTransactionList = new ArrayList<>();
        for (GiftCardTransactionDO giftCardTransactionDO : billPayGiftCardTransactionDOList) {
            GiftCardTransaction giftCardPaymentTransaction = GiftCardTransaction.builder()
                    .paymentInstrumentId(giftCardTransactionDO.getPaymentInstrumentId())
                    .amount(Amount.builder()
                            .value(giftCardTransactionDO.getAmount())
                            .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(giftCardTransactionDO.getCurrency().name()))
                            .build())
                    .giftCardTransactionType(GiftCardTransactionType.PAY)
                    .giftCardPaymentInstrument(GiftCardPaymentInstrument.builder()
                            .adapterMetadata(GiftCardPaymentInstrument.AdapterMetadata.builder()
                                    .piHash(giftCardTransactionDO.getPaymentProviderInstrumentId())
                                    .build())
                            .build())
                    .build();
            giftCardPaymentTransactionList.add(giftCardPaymentTransaction);
        }
        setGiftCardPaymentInstrumentInContextFromCustomerResponse(giftCardPaymentTransactionList, customerResponse);
        billPayTransaction.setGiftCardPaymentTransactionList(giftCardPaymentTransactionList);
        return customerBillAccountDO;
    }

    private CustomerResponse getCustomerResponseForReconcilePayBill(BillPayTransactionDO billPayTransactionDO) {
        UUID customerAccountId = billPayTransactionDO.getCustomerAccountId();
        CustomerResponse customerResponse = customerServiceClient.getCustomerDetailsById(customerAccountId);

        if (Objects.isNull(customerResponse)) {
            log.info("Recon pay bill flow, customerResponse for customerAccountId:[{}] is empty", customerAccountId);
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.CUSTOMER_ACCOUNT_NOT_FOUND);
        }

        return customerResponse;
    }

    private BillDetailDO getBillDetailDOForReconcilePayBill(BillPayTransactionDO billPayTransactionDO) {
        UUID billDetailId = billPayTransactionDO.getBillDetailDO().getBillDetailId();
        Optional<BillDetailDO> oBillDetailDO = billDetailRepository.findById(billDetailId);

        if (oBillDetailDO.isEmpty()) {
            log.info("Recon pay bill flow, billDetailDO for billDetailId:[{}] is empty", billDetailId);
            throw new BusinessValidationException(ErrorConstants.ReconcileBillPayTxn.BILL_DETAIL_DATA_NOT_FOUND);
        }
        return oBillDetailDO.get();
    }

    private void setGiftCardPaymentInstrumentInContextFromCustomerResponse(List<GiftCardTransaction> giftCardPaymentTransactionList, CustomerResponse customerResponse) {
        List<WalletResponse.PaymentInstrument> paymentInstrumentList = customerResponse.getWalletAccountDTO().getWalletResponse().getPaymentInstruments();
        paymentInstrumentList.forEach (paymentInstrument -> {
                if (paymentInstrument.getPaymentInstrumentType().equals(PaymentInstrumentType.GIFTCARD)
                    && paymentInstrument.getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CASHI_WALLET)) {
                for (GiftCardTransaction giftCardTransaction : giftCardPaymentTransactionList) {
                    if (paymentInstrument.getAdapterMetadata().getPiHash().equals(giftCardTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash())) {
                        giftCardTransaction.setPaymentInstrumentId(paymentInstrument.getPaymentInstrumentId());
                        giftCardTransaction.setGiftCardPaymentInstrument(customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument));
                    }
                }
            }
        });
    }
}
