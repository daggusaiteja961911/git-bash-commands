package com.walmart.international.wallet.payment.core.adapter.billprocessor.exception;

public class BillProcessorRequestRateException extends BillProcessorProcessingException {
    public BillProcessorRequestRateException(String errorCode, String message) {
        super(errorCode, message);
    }

    public BillProcessorRequestRateException(String errorCode, String message, Object[] args) {
        super(errorCode, message, args);
    }

    public BillProcessorRequestRateException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }

    public BillProcessorRequestRateException(String errorCode, String message, Object[] args, Throwable cause) {
        super(errorCode, message, args, cause);
    }
}
