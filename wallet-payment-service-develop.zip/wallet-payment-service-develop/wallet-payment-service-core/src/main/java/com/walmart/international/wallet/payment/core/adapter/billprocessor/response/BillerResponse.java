package com.walmart.international.wallet.payment.core.adapter.billprocessor.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BillerResponse {

    private String type;

    private String processorBillerId;

    private String billerName;

    private String billerType;

    private String billType;

    private String country;

    private String currency;

    private boolean requiresNameOnAccount;

    private int hoursToFulfill;

    private String accountNumberDigits;

    private String mask;

    private boolean canCheckBalance;

    private boolean supportsPartialPayments;

    private boolean hasXData;

    private Object availableTopupAmounts;

    private BigDecimal topupCommission;

    private Object availableGiftCardAmounts;

    private BigDecimal giftCardCommission;
}
