package com.walmart.international.wallet.payment.core.config.kafka;

import com.walmart.international.wallet.payment.core.adapter.kafka.consumer.PBChargeKafkaListener;
import com.walmart.international.wallet.payment.core.adapter.kafka.consumer.PBRefundKafkaListener;
import com.walmart.kafka.consumer.annotation.CreateDRKafkaConsumer;
import com.walmart.kafka.consumer.annotation.KafkaDRConsumer;
import org.springframework.stereotype.Component;

@Component
@CreateDRKafkaConsumer(consumerConfigs = {
        @KafkaDRConsumer(propertyName = "kafkaConsumerForCharge", consumer = PBChargeKafkaListener.class, beanName = "pbChargeConsumerV2"),
        @KafkaDRConsumer(propertyName = "kafkaConsumerForRefund", consumer = PBRefundKafkaListener.class, beanName = "pbRefundConsumerV2"),
})
public class PbKafkaConsumersConfig {
}
