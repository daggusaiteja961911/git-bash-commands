package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;
import io.strati.ccm.utils.client.annotation.UseObjectMapper;

@Configuration(configName = "paymentbroker-config", externalFileName = "paymentbroker-config.properties")
public interface PaymentBrokerConfiguration extends WebClientCCMConfigs {
    @Property(propertyName = "env")
    String getEnvironment();

    @Property(propertyName = "base.url")
    String getBaseUrl();

    @Property(propertyName = "name")
    String getServiceName();

    @Property(propertyName = "key.version")
    String getServiceKeyVersion();

    @Property(propertyName = "application.name")
    String getApplicationName();

    @Property(propertyName = "kafka.bootstrap.servers")
    String getBootStrapServers();

    @Property(propertyName = "kafka.topic")
    String getTopic();

    @Property(propertyName = "kafka.session.timeout")
    int getSessionTimeout();

    @Property(propertyName = "kafka.group.id")
    String getGroupId();

    @Property(propertyName = "refund.enterprise.code")
    String getEnterpriseCode();

    @Property(propertyName = "refund.channel")
    String getChannel();

    @Property(propertyName = "mock.enabled")
    Boolean mockEnabled();

    @UseObjectMapper
    @Property(propertyName = "charge.card.timeout")
    Long getChargeCardTimeout();

    @UseObjectMapper
    @Property(propertyName = "charge.card.timeout.batch.size")
    Long getChargeCardTimeoutBatchSize();

    @Property(propertyName = "ewallet.service.reverse.card.txn.api")
    String getReverseCardTxnAPI();

    // this will be read from external file
    @Property(propertyName = "auth.basic.username")
    String getAuthUserName();

    // this will be read from external file
    @Property(propertyName = "auth.basic.password")
    String getAuthPassword();

    @Property(propertyName = "dr.enabled.kafka.topic.enabled")
    Boolean getProduceToDREnabledKafka();

    @Property(propertyName = "abort.3ds.redirect.cof.topup")
    Boolean isAbort3DSCoFTopup();

    @Property(propertyName = "abort.3ds.redirect.bill.pay")
    Boolean isAbort3DSBillPay();

    @Property(propertyName = "redirect.cashi.url")
    String getRedirectCashiURL();

    @Property(propertyName = "card.payment.3ds.timeout.minutes")
    Integer getTimeoutMinsFor3ds();

    @Property(propertyName = "txn.recon.immediate", defaultValue = "true")
    Boolean getImmediateRecon();

    //Service Mesh Auth Headers
    @Property(propertyName = "service.mesh.enabled", defaultValue = "true")
    Boolean getServiceMeshEnabled();

    // this will be read from external file
    @Property(propertyName = "security.private.key")
    String getPrivateKey();

    // this will be read from external file
    @Property(propertyName = "consumer.id")
    String getConsumerId();
}
