package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

import java.util.List;

@Configuration(configName = TxnAggregatorResiliencyConfig.CCM_ENTRY_NAME)
public interface TxnAggregatorResiliencyConfig {

    String CCM_ENTRY_NAME = "txn-aggregator-resiliency-config";

    @Property(propertyName = "txn.aggregator.resiliency.enabled")
    boolean isTxnResiliencyFeatureEnabled();

    @Property(propertyName = "txn.aggregator.resiliency.kafka.enabled")
    boolean isTxnResiliencyThroughKafkaEnabled();

    @Property(propertyName = "txn.aggregator.resiliency.max.allowed.txns.sync")
    int maxAllowedTransactionsForSync();

}
