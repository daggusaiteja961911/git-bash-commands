package com.walmart.international.wallet.payment.core.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillDetail implements Serializable {

    private static final long serialVersionUID = -1176548560032707383L;

    private UUID billDetailId;

    private BigDecimal amount;

    private String name;

    private String description;

    private String validity;

    private String[] socialMediaIcons;

    private Integer duration;

    private DurationUnit durationUnit;

    public enum DurationUnit {
        DAY, MONTH, YEAR
    }
}
