package com.walmart.international.wallet.payment.core.event.listener;

import com.walmart.international.digiwallet.service.strati.telemetry.GenericEventMeter;
import com.walmart.international.digiwallet.service.strati.telemetry.util.CashiServiceGenericEventTypes;
import com.walmart.international.ewallet.services.events.config.Listener;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.core.service.BillPaymentCoreService;
import com.walmart.international.wallet.payment.core.service.JPASessionManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class CancelBillPaymentInitiatedListener {
    @Autowired
    BillPaymentCoreService billPaymentCoreService;

    @Autowired
    private JPASessionManagementService sessionManagementService;

    @Listener(types = {WPSConstants.Event.CANCEL_PAY_BILL_INIT})
    @GenericEventMeter(eventType = CashiServiceGenericEventTypes.ASYNC)
    public void handleCancelPayBillInitAsync(PayBillInitEventPayload payBillInitEventPayload) {
        if (Objects.isNull(payBillInitEventPayload)) {
            log.error("Failed to process CANCEL_PAY_BILL_INIT event as payload is null");
            return;
        }
        executeWithinSession(payBillInitEventPayload);
    }

    private void executeWithinSession(PayBillInitEventPayload payBillInitEventPayload) {
        UUID sessionId = UUID.randomUUID();
        try {
            sessionManagementService.openSession(sessionId.toString());
            log.info("Successfully opened session with id:[{}]", sessionId);

            billPaymentCoreService.processCancelBillPaymentInitEvent(payBillInitEventPayload);
        } finally {
            sessionManagementService.closeSession(sessionId.toString());
            log.info("Successfully closed session with id:[{}]", sessionId);
        }
    }
}


