package com.walmart.international.wallet.payment.core.processor.validator.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@Slf4j
public class UpdateCustomerBillAccountDueInfoInputValidator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {
    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillRequestDomainContext billRequestDomainContext = (BillRequestDomainContext) wpsRequestDomainContext;

        CustomerBillAccount customerBillAccount = billRequestDomainContext.getCustomerBillAccount();

        if (StringUtils.isEmpty(customerBillAccount.getProcessorBillAccountId())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.PROCESSOR_BILL_ACCOUNT_ID_NULL);
        }
        if (StringUtils.isEmpty(customerBillAccount.getProcessorBillerId())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.PROCESSOR_BILLER_ID_NULL);
        }
        if (StringUtils.isEmpty(customerBillAccount.getAccountNumber())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.ACCOUNT_NUMBER_NULL);
        }
        if (Objects.isNull(customerBillAccount.getDueDate())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.DUE_DATE_NULL);
        }

        return true;
    }
}
