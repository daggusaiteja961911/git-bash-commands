package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.AlreadyPaidRequestContext;
import com.walmart.international.wallet.payment.core.domain.model.request.UpdateCustomerBillDueInfoRequestContext;
import com.walmart.international.wallet.payment.core.domain.model.response.AlreadyPaidResponseContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CustomerBillAccountsByType;
import com.walmart.international.wallet.payment.data.constant.enums.BillType;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface BillCoreService {

    CustomerBillAccount deleteCustomerBillAccount(UUID customerBillAccountId, UUID customerAccountId) throws BusinessValidationException;

    // called from MigrationBillServiceImpl
    List<CustomerBillAccount> getAllSavedCustomerBillAccounts(String processorBillerId, UUID customerAccountId, String accountNumber) throws ApplicationException;

    // called from BillServiceImpl
    List<CustomerBillAccount> getSavedCustomerBillAccounts(UUID billerId, UUID customerAccountId, String accountNumber) throws ApplicationException;

    CustomerBillAccountsByType getCustomerBillAccountsByType(UUID customerAccountId, List<BillType> billTypes, int dueBillsDaysLimit,
                                                             int maxDaysForNudge, int minDaysForNudge, Pageable pageable);

    AlreadyPaidResponseContext updateCustomerBillAccountAsAlreadyPaidAndSendReminders(AlreadyPaidRequestContext alreadyPaidRequestContext) throws ApplicationException;

    void updateCustomerBillAccountDueInfoAndRaiseReminders(UpdateCustomerBillDueInfoRequestContext requestContext) throws ApplicationException;
}
