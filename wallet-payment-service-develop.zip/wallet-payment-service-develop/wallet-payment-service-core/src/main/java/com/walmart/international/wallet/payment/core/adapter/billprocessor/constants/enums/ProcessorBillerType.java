package com.walmart.international.wallet.payment.core.adapter.billprocessor.constants.enums;

public enum ProcessorBillerType {
    UTILITY, TOPUP, GIFTCARD
}
