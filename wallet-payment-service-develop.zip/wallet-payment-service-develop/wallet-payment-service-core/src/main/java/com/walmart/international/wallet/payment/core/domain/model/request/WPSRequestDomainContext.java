package com.walmart.international.wallet.payment.core.domain.model.request;

import com.walmart.international.digiwallet.service.flow.domain.model.IRequestDomainContext;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.util.MultiValueMap;

import java.util.Map;
import java.util.Objects;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class WPSRequestDomainContext implements IRequestDomainContext {
    MultiValueMap<String, String> headers;
    Map<String, Boolean> flags;
    String clientRequestId;
    String clientName;
    boolean testUser;
    Map<String, Boolean> decisions;

    /**
     * Returns the header value by header name. In case headers are not present or key is not present ,
     * it returns null
     * @param key - header name
     * @return
     */
    public String getHeaderValue(String key) {
        return this.getHeaders() != null && this.getHeaders().containsKey(key) ?
                this.getHeaders().get(key).get(0) :
                null;
    }

    public DeviceInformation getDeviceInfo() {
        String ip = getHeaderValue(WPSConstants.Headers.X_FORWARDED_FOR);
        return DeviceInformation.builder()
                .fingerPrint(getHeaderValue(WPSConstants.Headers.DEVICE_FINGERPRINT))
                .platform(getHeaderValue(WPSConstants.Headers.DEVICE_PLATFORM))
                .ip(Objects.nonNull(ip) ? ip.split(",")[0] : null)
                .build();
    }
}
