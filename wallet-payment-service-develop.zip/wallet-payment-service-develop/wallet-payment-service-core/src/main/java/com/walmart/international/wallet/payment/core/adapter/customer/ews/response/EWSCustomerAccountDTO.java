package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlElement;
import java.util.Date;
import java.util.UUID;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EWSCustomerAccountDTO {
    String customerAccountId;

    private String firstName;

    private String lastName;

    private String dob;

    private String emailId;

    private String phone;

    private Boolean phoneVerified;

    private Boolean emailVerified2;

    private String gender;

    private Date createDate;

    private String referrerCode;

    private String status;

    private String state;

    private int validity;

    private String authToken;

    private int failPasswordCount;

    private Date lastLoggedIn;

    private CustomerAddress addressDTO;

    private CustomerResponse.TermsAndConditions termsAndConditions;

    private WalletAccountDTO walletAccountDTO;

//    List<MerchantCustomerLinkInfo> externalProfiles;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CustomerAddress {
        @JsonProperty("id")
        private String id;

        @JsonProperty("isValid")
        private boolean valid;

        @JsonProperty("street")
        private String street;

        @JsonProperty("exteriorNum")
        private String exteriorNum;

        @JsonProperty("interiorNum")
        private String interiorNum;

        @JsonProperty("city")
        private String city;

        @JsonProperty("colony")
        private String colony;

        @JsonProperty("postalCode")
        private String postalCode;

        @JsonProperty("stateCode")
        private String stateCode;

        @JsonProperty("country_code")
        private String countryCode;

        @JsonProperty("delegation")
        private String delegation;

        @JsonProperty("inputCompleteness")
        private String inputCompleteness;

        @JsonProperty("error")
        @XmlElement(name = "error")
        private String error;

        @JsonProperty("customerAccountId")
        private UUID customerAccountId;

        @JsonProperty("addressId")
        private UUID addressId;
    }

}
