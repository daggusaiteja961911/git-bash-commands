package com.walmart.international.wallet.payment.core.processor.coftopup;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.notification.NotificationAdapter;
import com.walmart.international.notification.constants.MessagingEvent;
import com.walmart.international.notification.constants.MessagingType;
import com.walmart.international.notification.constants.TypeMessage;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.notification.dto.PushNotificationEventDTO;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataDetails;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.domain.AffiliationType;
import com.walmart.international.services.payment.core.domain.CardMetaData;
import com.walmart.international.services.payment.core.domain.CardPayment;
import com.walmart.international.services.payment.core.domain.CardPayments;
import com.walmart.international.services.payment.core.domain.CardSubTransaction;
import com.walmart.international.services.payment.core.domain.CoreTransactionStatusV2;
import com.walmart.international.services.payment.core.domain.CoreTransactionType;
import com.walmart.international.services.payment.core.domain.Customer;
import com.walmart.international.services.payment.core.domain.Device;
import com.walmart.international.services.payment.core.domain.GiftCardLoad;
import com.walmart.international.services.payment.core.domain.GiftCardLoads;
import com.walmart.international.services.payment.core.domain.GiftCardSubTransaction;
import com.walmart.international.services.payment.core.domain.InitiatedByType;
import com.walmart.international.services.payment.core.domain.Order;
import com.walmart.international.services.payment.core.domain.PayRequestMetaData;
import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.request.ContinuePayRequest;
import com.walmart.international.services.payment.core.request.LoadRequest;
import com.walmart.international.services.payment.core.request.PayRequest;
import com.walmart.international.services.payment.core.request.ReversalRequest;
import com.walmart.international.services.payment.core.response.LoadResponse;
import com.walmart.international.services.payment.core.response.PayResponse;
import com.walmart.international.services.payment.core.response.ReversalResponse;
import com.walmart.international.wallet.payment.core.adapter.cohort.CustomerCohortAdapter;
import com.walmart.international.wallet.payment.core.adapter.cohort.response.CustomerCohort;
import com.walmart.international.wallet.payment.core.config.ccm.PangaeaConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentBrokerConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AccountLockedState;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.core.mapper.TransactionMapper;
import com.walmart.international.wallet.payment.core.service.TxnAggregatorDataSyncService;
import com.walmart.international.wallet.payment.core.service.helper.PangeaServiceHelper;
import com.walmart.international.wallet.payment.core.utils.FeatureMetricUtil;
import com.walmart.international.wallet.payment.core.utils.NotificationUtil;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.commons.collections.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.validator.routines.InetAddressValidator;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class CoFTopupProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    private PaymentCoreService paymentCoreService;

    @ManagedConfiguration
    private PangaeaConfiguration pangaeaConfiguration;

    @ManagedConfiguration
    private PaymentBrokerConfiguration paymentBrokerConfiguration;

    @Autowired
    private NotificationAdapter<NotificationPayload> notificationPayloadNotificationAdapter;

    @Autowired
    private TxnAggregatorDataSyncService txnAggregatorDataSyncService;

    @Autowired
    private CustomerCohortAdapter customerCohortAdapter;

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    @Autowired
    private PangeaServiceHelper pangeaServiceHelper;

    private CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    private TransactionMapper transactionMapper = TransactionMapper.INSTANCE;

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

    @Autowired
    private FeatureMetricUtil featureMetricUtil;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
        if (isTxnInPending3DSAckState(coFTopupTxnResponseDomainContext.getTransaction())) {
            validateCharge(coFTopupTxnResponseDomainContext);
            try {
                loadWallet(coFTopupTxnResponseDomainContext);
            } catch (ProcessingException ex) {
                log.error("CoF Topup txn failed for transactionId:[{}], with errorCode:[{}]. StackTrace:[{}}",
                        coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().getCoFTopupTransactionId(), ex.getErrorCode(), ExceptionUtils.getStackTrace(ex));
                return false;
            }
        } else {
            chargeCard(coFTopupTxnResponseDomainContext);
            if (isTxnInPending3DSGeneratedState(coFTopupTxnResponseDomainContext.getTransaction())) {
                log.info("CoF Topup txn with transactionId:[{}] in DEBIT_3DS_GENERATED state", coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().getCoFTopupTransactionId());
                txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);
                return false;
            } else {
                try {
                    loadWallet(coFTopupTxnResponseDomainContext);
                } catch (ProcessingException ex) {
                    log.error("CoF Topup txn failed for transactionId:[{}], with errorCode:[{}]. StackTrace:[{}}",
                            coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().getCoFTopupTransactionId(), ex.getErrorCode(), ExceptionUtils.getStackTrace(ex));
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isTxnInPending3DSGeneratedState(CoFTopUpTransaction coFTopUpTransaction) {
        return coFTopUpTransaction.getState().equals(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.PENDING)
                && coFTopUpTransaction.getStateReason().equals(com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason.DEBIT_3DS_GENERATED);
    }

    private boolean isTxnInPending3DSAckState(CoFTopUpTransaction coFTopUpTransaction) {
        return coFTopUpTransaction.getState().equals(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.PENDING)
                && coFTopUpTransaction.getStateReason().equals(com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason.DEBIT_3DS_ACKNOWLEDGED);
    }

    private void chargeCard(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        UUID clientTransactionId = coFTopUpTransaction.getTransactionId();
        try {
            PayRequest payRequest = getPayRequest(clientTransactionId, coFTopupTxnResponseDomainContext);
            updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                    TransactionStateEnum.PENDING,
                    CoFTopupTxnStateReason.DEBIT_INITIATED);
            PayResponse payResponse = paymentCoreService.pay(payRequest);
            mapPayResponseToContext(payResponse, coFTopUpTransaction);
            if (CoreTransactionStatusV2.SUCCEEDED.equals(payResponse.getStatus())) {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.PENDING,
                        CoFTopupTxnStateReason.DEBIT_SUCCESS);
                addSuccessCvvMetrics(coFTopUpTransaction);
            } else if (CoreTransactionStatusV2.PAYMENT_3DS_PENDING.equals(payResponse.getStatus())) {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.PENDING,
                        CoFTopupTxnStateReason.DEBIT_3DS_GENERATED);
            } else {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.FAILURE,
                        CoFTopupTxnStateReason.DEBIT_FAILED);
                txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);
                addFailureCvvMetrics(coFTopUpTransaction);
                String msg = String.format("Failed to complete chargeCard for CoFTopupTransaction with txnId[%s]", coFTopUpTransaction.getTransactionId());
                walletPaymentServiceUtil.throwExceptionForCardPaymentFailureBasedOnFailureCode(payResponse.getFailureCode(), msg, false);
            }
        } catch (ApplicationException ae) {
            addFailureCvvMetrics(coFTopUpTransaction);
            throw ae;
        } catch (Exception ex) {
            addFailureCvvMetrics(coFTopUpTransaction);
            String msg = String.format("Failed to complete chargeCard for CoFTopupTransaction with txnId[%s]", coFTopUpTransaction.getTransactionId());
            throw new ProcessingException(ErrorConstants.CoFTopup.CHARGE_CARD_PAYMENT_CORE_PAY_FAILED, msg, ex);
        }
    }

    private PayRequest getPayRequest(UUID clientTransactionId, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        PayRequest.PayRequestBuilder payRequestBuilder = PayRequest.builder()
                .clientTransactionId(String.join("_", String.valueOf(clientTransactionId), "1"))
                .clientTransactionUUID(clientTransactionId)
                .allowPartial(Boolean.FALSE)
                .storeId(pangaeaConfiguration.getSystemStoreId())
                .coreTransactionType(CoreTransactionType.PAY)
                .initiatedBy(InitiatedByType.ONLINE);
        UUID customerAccountId = coFTopUpTransaction.getCustomer().getCustomerAccountId();
        try {
            payRequestBuilder.accountingDate(DATE_FORMAT.parse(DATE_FORMAT.format(new Date())));
        } catch (ParseException pe) {
            log.error("Error while parsing accounting date for customerAccountId[{}] for creating payRequest for CoFTopupTransaction with txnId[{}]",
                    customerAccountId, coFTopUpTransaction.getTransactionId());
        }

        Customer customer = Customer.builder()
                .customerId(customerAccountId.toString())
                .email(coFTopUpTransaction.getCustomer().getEmailId())
                .firstName(coFTopUpTransaction.getCustomer().getFirstName())
                .lastName(coFTopUpTransaction.getCustomer().getLastName())
                .accountCreationDate(coFTopUpTransaction.getCustomer().getCreateDate())
                .phoneNumber(coFTopUpTransaction.getCustomer().getPhone())
                .birthDate(coFTopUpTransaction.getCustomer().getCreateDate())
                .build();
        payRequestBuilder.customer(customer);

        String providerWalletId = null;
        String inAuthId = null;
        CardPayments.CardPaymentsBuilder cardPaymentsBuilder = CardPayments.builder();
        for (CardPaymentTransaction cardPaymentTransaction : coFTopUpTransaction.getCardPaymentTransactionList()) {
            CardPayment cardPayment = CardPayment.builder()
                    .cardTokenInformation(coFTopupMapper.mapCardTokenInfoFromContextToPayRequest(cardPaymentTransaction.getCardTokenInformation()))
                    .affiliationType(AffiliationType.valueOf(cardPaymentTransaction.getAffiliationType().name()))
                    .billingAddress(coFTopupMapper.mapBillingAddressFromContextToPayRequest(cardPaymentTransaction.getCardPaymentInstrument().getBillingAddress(), customer))
                    .usePoints(Boolean.FALSE)
                    .capture(Boolean.TRUE)
                    .build();
            if (Objects.nonNull(cardPaymentTransaction.getMsiInfo())) {
                CardPayment.MsiInfo msiInfo = new CardPayment.MsiInfo();
                msiInfo.setMsiSchemeId(UUID.fromString(cardPaymentTransaction.getMsiInfo().getSchemeId()));
                msiInfo.setInstallment(cardPaymentTransaction.getMsiInfo().getInstallment());
                msiInfo.setDiscountAmount(cardPaymentTransaction.getMsiInfo().getAmount());
                cardPayment.setMsiInfo(msiInfo);
            }
            cardPayment.setPaymentProviderInstrumentId(String.valueOf(cardPaymentTransaction.getCardPaymentInstrument().getAdapterMetadata().getTokenId()));
            cardPayment.setPaymentInstrumentId(cardPaymentTransaction.getPaymentInstrumentId());
            com.walmart.international.services.payment.core.domain.Amount amount = com.walmart.international.services.payment.core.domain.Amount.builder()
                    .amount(cardPaymentTransaction.getAmount().getValue())
                    .currencyUnit(com.walmart.international.services.payment.core.domain.Amount.CurrencyUnit.valueOf(cardPaymentTransaction.getAmount().getCurrencyUnit().name()))
                    .build();
            cardPayment.setAmount(amount);
            cardPaymentsBuilder.cardPaymentList(cardPayment);
            providerWalletId = cardPaymentTransaction.getProviderWalletId();
            inAuthId = cardPaymentTransaction.getFraudInfo().getInAuthId();
        }
        cardPaymentsBuilder.cardMetaData(CardMetaData.builder().providerWalletId(providerWalletId).build());
        payRequestBuilder.cardPayments(cardPaymentsBuilder.build());

        DeviceInformation deviceInformation = coFTopupTxnResponseDomainContext.getDeviceInfo();
        Device.DeviceBuilder deviceBuilder = Device.builder()
                .deviceId(deviceInformation.getFingerPrint())
                .deviceType(deviceInformation.getPlatform())
                .inAuthId(inAuthId);
        if (Objects.nonNull(deviceInformation.getIp())) {
            if (InetAddressValidator.getInstance().isValidInet4Address(deviceInformation.getIp())) {
                deviceBuilder.ipv4(deviceInformation.getIp())
                        .realipv4(deviceInformation.getIp());
            } else if (InetAddressValidator.getInstance().isValidInet6Address(deviceInformation.getIp())) {
                deviceBuilder.ipv6(deviceInformation.getIp())
                        .realipv6(deviceInformation.getIp());
            }
        }
        payRequestBuilder.device(deviceBuilder.build());

        Order order = Order.builder()
                .orderId(coFTopUpTransaction.getCashiOrderId())
                .storeUrl(walletPaymentServiceConfiguration.getStoreURL())
                .orderType(Order.OrderType.LOAD_MONEY)
                .build();
        if (Objects.nonNull(coFTopUpTransaction.getParentTransactionType())) {
            order.setParentOrderType(resolveParentOrderType(coFTopUpTransaction.getParentTransactionType()));
        }
        payRequestBuilder.order(order);

        payRequestBuilder.metaData(getPayRequestMetaData(coFTopUpTransaction.getCustomer()));
        return payRequestBuilder.build();
    }

    private Order.OrderType resolveParentOrderType(TransactionType parentTransactionType) {
        switch (parentTransactionType) {
            case BILL_PAY:
                return Order.OrderType.BILL_PAY;
            case MERCHANT_PAY:
                return Order.OrderType.MERCHANT;
            default:
                return null;
        }
    }

    private PayRequestMetaData getPayRequestMetaData(com.walmart.international.wallet.payment.core.domain.model.Customer customer) {
        PayRequestMetaData metaData = new PayRequestMetaData();
        try {
            CustomerCohort customerCohort = customerCohortAdapter.getCustomerCohort(customer.getCustomerAccountId());
            if (customerCohort != null) {
                metaData.setRecurrentStoreId(customerCohort.getRecurrentStoreId());
                metaData.setCustomerOrdersTotalSpend(customerCohort.getAveragePaymentAmount());
                metaData.setCustomerOrdersCount(customerCohort.getLoadTransactionCount());
                metaData.setCustomerBillPaymentTransactionsCount(customerCohort.getBillPaymentCount());
                metaData.setNumberOfAccountsOnDevice(customerCohort.getAccountPerDevice());
                metaData.setCustomerPaymentTransactionCount(customerCohort.getNonBillPaymentCount());
            }
        } catch (Exception wde) {
            logger.error("Failed to Customer Cohort values from MeghaCache for the account number : CustomerAccountId[{}]", customer.getCustomerAccountId(), wde);
        }
        if (CollectionUtils.isNotEmpty(customer.getGiftCardPaymentInstrumentList())) {
            metaData.setB2BCardPresentForCustomer(customer.getGiftCardPaymentInstrumentList().stream().anyMatch(pi -> PaymentInstrumentSubType.CORP_CARD.equals(pi.getPaymentInstrumentSubType())));
        }
        // mapping of wallet balance is not required, hence setting to Optional.empty() to avoid NPE at this point of time
        metaData.setWalletBalance(Optional.empty());
        return metaData;
    }

    private void mapPayResponseToContext(PayResponse payResponse, CoFTopUpTransaction coFTopUpTransaction) {
        transactionMapper.mapPayResponseToTransaction(payResponse, coFTopUpTransaction);
        for (CardSubTransaction cardSubTransaction : payResponse.getCardSubTransactions()) {
            Optional<CardPaymentTransaction> oCardPaymentTransaction = coFTopUpTransaction.getCardPaymentTransactionList().stream()
                    .filter(cardPaymentTransaction ->
                            cardPaymentTransaction.getCardPaymentInstrument().getAdapterMetadata().getTokenId()
                                    .equals(cardSubTransaction.getPaymentProviderInstrumentId()))
                    .findFirst();
            oCardPaymentTransaction.ifPresent(cardPaymentTransaction -> {
                cardPaymentTransaction.setCardSubTransaction(transactionMapper.mapCardSubTxnFromPaymentCoreResponse(cardSubTransaction));
                if (payResponse.getStatus().equals(CoreTransactionStatusV2.PAYMENT_3DS_PENDING)) {
                    cardPaymentTransaction.setRedirect3DSURL(payResponse.getRedirect3DSURL());
                    cardPaymentTransaction.setRedirectCashiURL(paymentBrokerConfiguration.getRedirectCashiURL());
                    cardPaymentTransaction.setTimeoutMinsFor3ds(paymentBrokerConfiguration.getTimeoutMinsFor3ds());
                }
            });
        }
    }


    private void loadWallet(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) throws ProcessingException {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        UUID clientTransactionId = coFTopUpTransaction.getTransactionId();
        try {
            LoadRequest loadRequest = getLoadRequest(clientTransactionId, coFTopupTxnResponseDomainContext);
            updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                    TransactionStateEnum.PENDING,
                    CoFTopupTxnStateReason.CREDIT_INITIATED);
            pangeaServiceHelper.makePangeaUnlockCallForLockedGiftCardPaymentInstrument(coFTopUpTransaction.getGiftCardLoadTransactionList(), loadRequest.getStoreId(), loadRequest.getTerminalId());
            LoadResponse loadResponse = paymentCoreService.load(loadRequest);
            mapLoadResponseToContext(loadResponse, coFTopUpTransaction);
            if (CoreTransactionStatusV2.SUCCEEDED.equals(loadResponse.getStatus())) {
                coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().setAmountProcessed(loadResponse.getAmount().getAmount());
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.SUCCESS,
                        CoFTopupTxnStateReason.CREDIT_SUCCESS);
            } else if (CoreTransactionStatusV2.SUCCEEDED_WITH_LOCK.equals(loadResponse.getStatus())) {
                coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().setAmountProcessed(loadResponse.getAmount().getAmount());
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.SUCCESS,
                        CoFTopupTxnStateReason.CREDIT_SUCCESS_WITH_LOCK);
                sendGiftCardUnlockFailurePushNotification(coFTopUpTransaction.getCustomer().getCustomerAccountId().toString());
                List<GiftCardTransaction> giftCardTransactionList = coFTopUpTransaction.getGiftCardLoadTransactionList();
                for (GiftCardTransaction giftCardTransaction : giftCardTransactionList) {
                    if (SubTransactionStatusV2.LOAD_SUCCEEDED_WITH_LOCK.equals(giftCardTransaction.getGiftCardSubTransaction().getStatus())) {
                        pangeaServiceHelper.updateGiftCardStatus(giftCardTransaction.getGiftCardPaymentInstrument().getPaymentInstrumentId(), AccountLockedState.LOCKED);
                    }
                }

            } else {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.FAILURE,
                        CoFTopupTxnStateReason.CREDIT_FAILED);
                UUID clientTransactionIdForPay = coFTopUpTransaction.getTransactionId();
                reverseChargeCard(clientTransactionIdForPay, coFTopupTxnResponseDomainContext);
                txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);
                String msg = String.format("Failed to complete loadWallet for CoFTopupTransaction with txnId[%s]", coFTopupTxnResponseDomainContext.getTransaction().getTransactionId());
                throw new ProcessingException(ErrorConstants.CoFTopup.LOAD_TO_WALLET_PAYMENT_CORE_LOAD_FAILED, msg);
            }
        } catch (ProcessingException pe) {
            throw pe;
        } catch (Exception ex) {
            String msg = String.format("Failed to complete loadWallet for CoFTopupTransaction with txnId[%s]", coFTopupTxnResponseDomainContext.getTransaction().getTransactionId());
            throw new ProcessingException(ErrorConstants.CoFTopup.LOAD_TO_WALLET_PAYMENT_CORE_LOAD_FAILED, msg, ex);
        }
    }

    private LoadRequest getLoadRequest(UUID clientTransactionId, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) throws ParseException {
        GiftCardLoads.GiftCardLoadsBuilder giftCardLoads = GiftCardLoads.builder();
        for (GiftCardTransaction giftCardLoadTransaction : coFTopupTxnResponseDomainContext.getTransaction().getGiftCardLoadTransactionList()) {
            GiftCardLoad giftCardLoad = GiftCardLoad.builder()
                    .paymentProviderInstrumentId(giftCardLoadTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash())
                    .paymentInstrumentId(giftCardLoadTransaction.getPaymentInstrumentId())
                    .amount(com.walmart.international.services.payment.core.domain.Amount.builder()
                            .amount(giftCardLoadTransaction.getAmount().getValue())
                            .currencyUnit(com.walmart.international.services.payment.core.domain.Amount.CurrencyUnit.valueOf(giftCardLoadTransaction.getAmount().getCurrencyUnit().name()))
                            .build())
                    .build();
            giftCardLoads.giftCardLoadList(giftCardLoad);
        }
        return LoadRequest.builder()
                .clientTransactionId(String.join("_", String.valueOf(clientTransactionId), "2"))
                .clientTransactionUUID(clientTransactionId)
                .orderId(coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO().getCashiOrderId())
                .accountingDate(DATE_FORMAT.parse(DATE_FORMAT.format(new Date())))
                .giftCardLoads(giftCardLoads.build())
                .storeId(pangaeaConfiguration.getSystemStoreId())
                .terminalId(pangaeaConfiguration.getSystemTerminalId())
                .lockAccountAfterLoad(Boolean.FALSE)
                .initiatedBy(InitiatedByType.ONLINE)
                .build();
    }

    private void mapLoadResponseToContext(LoadResponse loadResponse, CoFTopUpTransaction coFTopUpTransaction) {
        transactionMapper.mapLoadResponseToTransaction(loadResponse, coFTopUpTransaction);
        for (GiftCardSubTransaction giftCardSubTransaction : loadResponse.getGiftCardSubTransactions()) {
            Optional<GiftCardTransaction> oGiftCardLoadTransaction = coFTopUpTransaction.getGiftCardLoadTransactionList().stream()
                    .filter(giftCardLoadTransaction ->
                            giftCardLoadTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash()
                                    .equals(giftCardSubTransaction.getPaymentProviderInstrumentId()))
                    .findFirst();
            oGiftCardLoadTransaction.ifPresent(giftCardLoadTransaction ->
                    giftCardLoadTransaction.setGiftCardSubTransaction(transactionMapper.mapGiftCardSubTxnFromPaymentCoreResponse(giftCardSubTransaction)));
        }
    }

    private void validateCharge(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        UUID clientTransactionId = coFTopUpTransaction.getTransactionId();
        try {
            ContinuePayRequest continuePayRequest = getContinuePayRequest(clientTransactionId, coFTopupTxnResponseDomainContext);
            PayResponse payResponse = paymentCoreService.continuePay(continuePayRequest);
            mapPayResponseToContext(payResponse, coFTopUpTransaction);
            if (CoreTransactionStatusV2.SUCCEEDED.equals(payResponse.getStatus())) {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.PENDING,
                        CoFTopupTxnStateReason.DEBIT_SUCCESS);
            } else {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.FAILURE,
                        CoFTopupTxnStateReason.DEBIT_3DS_FAILED);
                txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);
                String msg = String.format("Failed to complete validateCharge for CoFTopupTransaction with txnId[%s]", coFTopUpTransaction.getTransactionId());
                walletPaymentServiceUtil.throwExceptionForCardPaymentFailureBasedOnFailureCode(payResponse.getFailureCode(), msg, true);
            }
        } catch (ApplicationException ae) {
            throw ae;
        } catch (Exception ex) {
            String msg = String.format("Failed to complete validateCharge for CoFTopupTransaction with txnId[%s]", coFTopUpTransaction.getTransactionId());
            throw new ProcessingException(ErrorConstants.ValidateCoFTopup.VALIDATE_CHARGE_PAYMENT_CORE_CONTINUE_PAY_FAILED, msg, ex);
        }
    }

    private ContinuePayRequest getContinuePayRequest(UUID clientTransactionId, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        Customer customer = Customer.builder()
                .customerId(coFTopUpTransaction.getCustomer().getCustomerAccountId().toString())
                .email(coFTopUpTransaction.getCustomer().getEmailId())
                .firstName(coFTopUpTransaction.getCustomer().getFirstName())
                .lastName(coFTopUpTransaction.getCustomer().getLastName())
                .accountCreationDate(coFTopUpTransaction.getCustomer().getCreateDate())
                .birthDate(coFTopUpTransaction.getCustomer().getCreateDate())
                .phoneNumber(coFTopUpTransaction.getCustomer().getPhone())
                .build();

        return ContinuePayRequest.builder()
                .clientTransactionId(String.join("_", String.valueOf(clientTransactionId), "1"))
                .clientTransactionUUID(clientTransactionId)
                .customer(customer)
                .build();
    }

    private void updateCoFTopupTxnState(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext,
                                        TransactionStateEnum state,
                                        CoFTopupTxnStateReason stateReason) {
        CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO();
        coFTopupTransactionDO.setState(state);
        coFTopupTransactionDO.setStateReason(stateReason);

        coFTopupTransactionDO = walletPaymentServiceUtil.updateLastEventDateCheck(coFTopupTransactionDO, state, stateReason);

        coFTopupTransactionDO = coFTopupTransactionRepository.save(coFTopupTransactionDO);
        coFTopupTxnResponseDomainContext.setCoFTopupTransactionDO(coFTopupTransactionDO);

        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        coFTopUpTransaction.setState(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.valueOf(state.name()));
        coFTopUpTransaction.setStateReason(com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason.valueOf(stateReason.name()));
        if (state.equals(TransactionStateEnum.SUCCESS)) {
            coFTopUpTransaction.setAmountFulfilled(Amount.builder()
                    .value(coFTopupTransactionDO.getAmountProcessed())
                    .currencyUnit(CurrencyUnit.valueOf(coFTopupTransactionDO.getCurrencyUnit().name()))
                    .build());
        }
    }

    private void reverseChargeCard(UUID clientTransactionId, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        try {
            ReversalRequest reversalRequest = ReversalRequest.builder()
                    .clientTransactionId(String.join("_", String.valueOf(clientTransactionId), "1"))
                    .clientTransactionUUID(clientTransactionId)
                    .build();
            updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    CoFTopupTxnStateReason.DEBIT_REVERSAL_INITIATED);
            ReversalResponse reversalResponse = paymentCoreService.reverse(reversalRequest);
            mapReversalResponseToContext(reversalResponse, coFTopupTxnResponseDomainContext.getTransaction());
            sendCardPaymentFailurePushNotification(coFTopupTxnResponseDomainContext.getTransaction().getCustomer().getCustomerAccountId().toString());
            if (reversalResponse.getStatus().equals(CoreTransactionStatusV2.FAILED)) {
                updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                        TransactionStateEnum.FAILURE,
                        CoFTopupTxnStateReason.DEBIT_REVERSAL_INIT_FAILED);
                txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);
                throw new ProcessingException(ErrorConstants.CoFTopup.CHARGE_CARD_PAYMENT_CORE_REVERSAL_FAILED, reversalResponse.getFailureDescription());
            }
            updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    CoFTopupTxnStateReason.DEBIT_REVERSAL_PENDING);
        } catch (PaymentCoreServiceException ex) {
            updateCoFTopupTxnState(coFTopupTxnResponseDomainContext,
                    TransactionStateEnum.FAILURE,
                    CoFTopupTxnStateReason.DEBIT_REVERSAL_INIT_FAILED);
            txnAggregatorDataSyncService.pushTransactionDataToTAAS(coFTopupTxnResponseDomainContext);
            sendCardPaymentFailurePushNotification(coFTopupTxnResponseDomainContext.getTransaction().getCustomer().getCustomerAccountId().toString());
            throw new ProcessingException(ErrorConstants.CoFTopup.CHARGE_CARD_PAYMENT_CORE_REVERSAL_FAILED, ex.getMessage());
        }
    }

    private void mapReversalResponseToContext(ReversalResponse reversalResponse, CoFTopUpTransaction coFTopUpTransaction) {
        transactionMapper.mapReversalResponseToTransaction(reversalResponse, coFTopUpTransaction);
        for (CardSubTransaction cardSubTransaction : reversalResponse.getCardSubTransactions()) {
            Optional<CardPaymentTransaction> oCardPaymentTransaction = coFTopUpTransaction.getCardPaymentTransactionList().stream()
                    .filter(cardPaymentTransaction -> cardPaymentTransaction.getCardPaymentInstrument().getAdapterMetadata().getTokenId().equals(cardSubTransaction.getPaymentProviderInstrumentId()))
                    .findFirst();
            oCardPaymentTransaction.ifPresent(cardPaymentTransaction -> cardPaymentTransaction.setCardSubTransaction(transactionMapper.mapCardSubTxnFromPaymentCoreResponse(cardSubTransaction)));
        }
        for (GiftCardSubTransaction giftCardSubTransaction : reversalResponse.getGiftCardSubTransactions()) {
            Optional<GiftCardTransaction> oGiftCardLoadTransaction = coFTopUpTransaction.getGiftCardLoadTransactionList().stream()
                    .filter(giftCardLoadTransaction -> giftCardLoadTransaction.getGiftCardPaymentInstrument().getAdapterMetadata().getPiHash().equals(giftCardSubTransaction.getPaymentProviderInstrumentId()))
                    .findFirst();
            oGiftCardLoadTransaction.ifPresent(giftCardLoadTransaction -> giftCardLoadTransaction.setGiftCardSubTransaction(transactionMapper.mapGiftCardSubTxnFromPaymentCoreResponse(giftCardSubTransaction)));
        }
    }

    private void sendGiftCardUnlockFailurePushNotification(String customerAccountId) {
        try {
            NOCMetaDataDetails nocMetaDataDetails = NotificationUtil.getNOCMetaData(MessagingEvent.ACCOUNT_LOCKED,
                    WPSConstants.Notification.ACTION_CALL_HELP, null, null);
            PushNotificationEventDTO eventDTO = PushNotificationEventDTO.builder()
                    .event(MessagingEvent.ACCOUNT_LOCKED)
                    .customerId(customerAccountId)
                    .typeMessage(TypeMessage.TEXT)
                    .action(WPSConstants.Notification.ACTION_CALL_HELP)
                    .nocMetadata(nocMetaDataDetails)
                    .message(WPSConstants.Notification.ACCOUNT_LOCKED_MESSAGE)
                    .title(WPSConstants.Notification.ACCOUNT_LOCKED_TITLE)
                    .build();
            NotificationPayload notificationPayload = NotificationPayload.builder()
                    .pushEventType(WalletEventType.ACCOUNT_LOCKED)
                    .pushNotiEventDTO(eventDTO)
                    .build();
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error while sending giftCard unlock failure push notification for customerAccountId[{}]. StackTrace: [{}}", customerAccountId, ExceptionUtils.getStackTrace(ex));
        }
    }

    private void sendCardPaymentFailurePushNotification(String customerAccountId) {
        try {
            PushNotificationEventDTO eventDTO = PushNotificationEventDTO.builder()
                    .event(MessagingEvent.FAILED_TRY_AGAIN)
                    .typeMessage(TypeMessage.TEXT)
                    .customerId(customerAccountId)
                    .title(WPSConstants.Notification.CARD_PAYMENT_FAILURE_TITLE)
                    .message(WPSConstants.Notification.CARD_PAYMENT_FAULURE_MESSAGE)
                    .build();
            NotificationPayload notificationPayload = NotificationPayload.builder()
                    .pushEventType(WalletEventType.ACCOUNT_LOCKED)
                    .pushNotiEventDTO(eventDTO)
                    .build();
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error while card payment failure push notification for customerAccountId[{}]. StackTrace: [{}}", customerAccountId, ExceptionUtils.getStackTrace(ex));
        }
    }

    public void addSuccessCvvMetrics(CoFTopUpTransaction coFTopUpTransaction) {
        if (!is3DSFlow(coFTopUpTransaction) && null != coFTopUpTransaction.getCardPaymentTransactionList() &&
                coFTopUpTransaction.getCardPaymentTransactionList().size() > 0 &&
                null != coFTopUpTransaction.getCardPaymentTransactionList().get(0)) {
            featureMetricUtil.addResultCvvMetrics(coFTopUpTransaction.getCardPaymentTransactionList().get(0).getAffiliationType(), "SUCCESS");
        }
    }

    public void addFailureCvvMetrics(CoFTopUpTransaction coFTopUpTransaction) {
        if (!is3DSFlow(coFTopUpTransaction) && null != coFTopUpTransaction.getCardPaymentTransactionList() &&
                coFTopUpTransaction.getCardPaymentTransactionList().size() > 0 &&
                null != coFTopUpTransaction.getCardPaymentTransactionList().get(0)) {
            featureMetricUtil.addResultCvvMetrics(coFTopUpTransaction.getCardPaymentTransactionList().get(0).getAffiliationType(), "FAILURE");
        }
    }

    private boolean is3DSFlow(CoFTopUpTransaction coFTopupTransaction) {
        return com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.PENDING.equals(coFTopupTransaction.getState())
                && com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason.DEBIT_3DS_GENERATED.equals(coFTopupTransaction.getStateReason());
    }
}
