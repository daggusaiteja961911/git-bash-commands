package com.walmart.international.wallet.payment.core.processor.validator.coftopup;

import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.flow.validator.Validator;
import com.walmart.international.services.payment.core.dao.repository.CardTransactionRepository;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.config.ccm.TopupConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.exception.DataConstraintViolationException;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.utils.FeatureMetricUtil;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.commons.collections.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class CoFTopupValidator implements Validator<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    @ManagedConfiguration
    private TopupConfiguration topupConfiguration;

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    private CardTransactionRepository cardTransactionRepository;
  
    @Autowired
    private FeatureMetricUtil featureMetricUtil;

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    @Override
    public boolean validate(WPSRequestDomainContext wpsRequestDomainContext) {
        CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext = (CoFTopupTxnRequestDomainContext) wpsRequestDomainContext;
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnRequestDomainContext.getTransaction();
        Customer customer = coFTopUpTransaction.getCustomer();
        TransactionType parentTransactionType = coFTopUpTransaction.getParentTransactionType();

        addTopupCvvMetric(coFTopUpTransaction);
        try {
            if (Boolean.FALSE.equals(topupConfiguration.getCoFTopupToWalletEnabled())) {
                throw new BusinessValidationException(ErrorConstants.CoFTopup.COF_TOPUP_TO_WALLET_DISABLED);
            }

            if (Objects.isNull(customer.getCustomerAccountId())) {
                throw new DataValidationException(ErrorConstants.CoFTopup.CUSTOMER_ACCOUNT_ID_NULL);
            }

            if (isAmountLessThanMinAmountForCoFTopup(coFTopUpTransaction.getAmountRequested().getValue(), parentTransactionType)) {
                throw new BusinessValidationException(ErrorConstants.CoFTopup.MIN_AMOUNT_LIMIT_ERROR);
            }
            if (Objects.isNull(parentTransactionType)) {
                if (StringUtils.isEmpty(coFTopupTxnRequestDomainContext.getClientRequestId())) {
                    throw new DataConstraintViolationException(ErrorConstants.CoFTopup.MISSING_CLIENT_REQ_ID);
                }
                Optional<CoFTopupTransactionDO> coFTopupTransactionDO = coFTopupTransactionRepository.findByClientReqId(coFTopupTxnRequestDomainContext.getClientRequestId());
                if (coFTopupTransactionDO.isPresent()) {
                    throw new DataConstraintViolationException(ErrorConstants.CoFTopup.DUPILCATE_CLIENT_REQ_ID);
                }
            }

            CustomerResponse customerResponse = customerServiceClient.getCustomerDetailsById(customer.getCustomerAccountId());
            if (customerResponse == null) {
                throw new BusinessValidationException(ErrorConstants.CoFTopup.CUSTOMER_ACCOUNT_NOT_FOUND);
            }
            customerMapper.updateCustomerDataInContext(customerResponse, customer);
            mapPaymentInstrumentsToCustomerContext(customer, customerResponse);
            validatePaymentInstrumentsInContext(customer, coFTopUpTransaction);
        } catch (DataConstraintViolationException e) {
            throw e;
        } catch (ApplicationException ae) {
            createCoFTopupTransactionInValidationFailureState(coFTopupTxnRequestDomainContext);
            throw ae;
        }
        return true;
    }

    private void addTopupCvvMetric(CoFTopUpTransaction coFTopUpTransaction) {
        if (null != coFTopUpTransaction.getCardPaymentTransactionList() &&
                coFTopUpTransaction.getCardPaymentTransactionList().size() > 0 &&
                null != coFTopUpTransaction.getCardPaymentTransactionList().get(0)) {
            featureMetricUtil.addCvvTotalCountMetric(coFTopUpTransaction.getCardPaymentTransactionList().get(0).getAffiliationType());
        }
    }

    private void mapPaymentInstrumentsToCustomerContext(Customer customer, CustomerResponse customerResponse) {
        log.info("Mapping payment instruments to customer context for customerAccountId:[{}]", customer.getCustomerAccountId());
        customerMapper.mapPaymentInstrumentsToCustomerContext(customer, customerResponse);
    }

    private boolean isAmountLessThanMinAmountForCoFTopup(BigDecimal amount, TransactionType parentTransactionType) {
        if (Objects.nonNull(parentTransactionType)) {
            if (TransactionType.BILL_PAY.equals(parentTransactionType)) {
                return amount.compareTo(BigDecimal.valueOf(topupConfiguration.getCoFTopupToWalletMinAmountForBillPay())) < 0;
            } else if (TransactionType.MERCHANT_PAY.equals(parentTransactionType)) {
                return amount.compareTo(BigDecimal.valueOf(topupConfiguration.getCoFTopupToWalletMinAmountForMerchantPay())) < 0;
            }
        }
        return amount.compareTo(BigDecimal.valueOf(topupConfiguration.getCoFTopupToWalletMinAmount())) < 0;
    }

    private void validatePaymentInstrumentsInContext(Customer customer, CoFTopUpTransaction coFTopUpTransaction) {
        UUID customerAccountId = customer.getCustomerAccountId();
        if (CollectionUtils.isEmpty(coFTopUpTransaction.getCardPaymentTransactionList())) {
            String msg = "Requires atleast one card payment transaction to perform CoF topup";
            throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_TXN_EMPTY, msg);
        }

        List<CardPaymentInstrument> cardPaymentInstrumentList = customer.getCardPaymentInstrumentList();
        List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList = customer.getGiftCardPaymentInstrumentList();

        if (CollectionUtils.isEmpty(cardPaymentInstrumentList) && CollectionUtils.isEmpty(giftCardPaymentInstrumentList)) {
            String msg = String.format("No payment instrument exists for customerAccountId[%s]",  customerAccountId);
            throw new BusinessValidationException(ErrorConstants.CoFTopup.PAYMENT_INSTRUMENTS_NOT_FOUND_FOR_CUSTOMER, msg);
        }

        List<CardPaymentTransaction> cardPaymentTransactionList = coFTopUpTransaction.getCardPaymentTransactionList();
        for (CardPaymentTransaction cardPaymentTransaction : cardPaymentTransactionList) {
            Optional<CardPaymentInstrument> optionalCardPaymentInstrument = cardPaymentInstrumentList.stream()
                    .filter(cardPaymentInstrument ->
                            cardPaymentInstrument.getPaymentInstrumentId().equals(cardPaymentTransaction.getPaymentInstrumentId().toString()))
                    .findFirst();
            if (optionalCardPaymentInstrument.isPresent()) {
                cardPaymentTransaction.setCardPaymentInstrument(optionalCardPaymentInstrument.get());
                cardPaymentTransaction.setProviderWalletId(optionalCardPaymentInstrument.get().getAdapterMetadata().getWalletId());
            } else {
                String msg = String.format("Card payment instrument with paymentInstrumentId[%s] not found for customerAccountId[%s]",
                        cardPaymentTransaction.getPaymentInstrumentId(), customerAccountId);
                throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_INSTRUMENT_NOT_FOUND, msg);
            }
            doAffiliationTypeValidation(customerAccountId, cardPaymentTransaction);
        }
        if (CollectionUtils.isNotEmpty(coFTopUpTransaction.getGiftCardLoadTransactionList())) {
            List<GiftCardTransaction> giftCardLoadTransactionList = coFTopUpTransaction.getGiftCardLoadTransactionList();
            for (GiftCardTransaction giftCardLoadTransaction : giftCardLoadTransactionList) {
                Optional<GiftCardPaymentInstrument> optionalGiftCardPaymentInstrument = giftCardPaymentInstrumentList.stream()
                        .filter(giftCardPaymentInstrument ->
                                giftCardPaymentInstrument.getPaymentInstrumentId().equals(giftCardLoadTransaction.getPaymentInstrumentId().toString()))
                        .findFirst();
                if (optionalGiftCardPaymentInstrument.isEmpty()) {
                    String msg = String.format("Gift card payment instrument with paymentInstrumentId[%s] not found for customerAccountId[%s]",
                            giftCardLoadTransaction.getPaymentInstrumentId(), customerAccountId);
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.GIFT_CARD_PAYMENT_INSTRUMENT_NOT_FOUND, msg);
                } else {
                    // TODO: could have different max balance checks for different non primary gift-cards
                    if (isTopupExceedingMaxWalletBalanceForUser(coFTopUpTransaction.getAmountRequested().getValue(), optionalGiftCardPaymentInstrument.get())) {
                        String msg = "Topup to wallet exceeds max allowed wallet balance";
                        throw new BusinessValidationException(ErrorConstants.CoFTopup.MAX_WALLET_BALANCE_ALLOWED_EXCEEDED,
                                msg, new Object[]{topupConfiguration.getMaxWalletBalanceAllowed()});
                    }
                    giftCardLoadTransaction.setGiftCardPaymentInstrument(optionalGiftCardPaymentInstrument.get());
                }
            }
        } else {
            Optional<GiftCardPaymentInstrument> primaryGiftCardPaymentInstrument = giftCardPaymentInstrumentList.stream()
                    .filter(giftCardPaymentInstrument ->
                            giftCardPaymentInstrument.getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CASHI_WALLET))
                    .findFirst();
            if (primaryGiftCardPaymentInstrument.isPresent()) {
                if (isTopupExceedingMaxWalletBalanceForUser(coFTopUpTransaction.getAmountRequested().getValue(), primaryGiftCardPaymentInstrument.get())) {
                    String msg = "Topup to wallet exceeds max allowed wallet balance";
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.MAX_WALLET_BALANCE_ALLOWED_EXCEEDED,
                            msg, new Object[]{String.valueOf(topupConfiguration.getMaxWalletBalanceAllowed())});
                }
                GiftCardTransaction giftCardLoadTransaction = GiftCardTransaction.builder()
                        .paymentInstrumentId(UUID.fromString(primaryGiftCardPaymentInstrument.get().getPaymentInstrumentId()))
                        .amount(coFTopUpTransaction.getAmountRequested())
                        .giftCardPaymentInstrument(primaryGiftCardPaymentInstrument.get())
                        .giftCardTransactionType(GiftCardTransactionType.LOAD)
                        .build();
                coFTopUpTransaction.setGiftCardLoadTransactionList(Collections.singletonList(giftCardLoadTransaction));
            } else {
                String msg = String.format("Primary gift card payment instrument not found for customerAccountId[%s]", customerAccountId);
                throw new BusinessValidationException(ErrorConstants.CoFTopup.PRIMARY_GIFT_CARD_PAYMENT_INSTRUMENT_NOT_FOUND, msg);
            }
        }
    }

    private void doAffiliationTypeValidation(UUID customerAccountId, CardPaymentTransaction cardPaymentTransaction) {
        AffiliationType affiliationType = cardPaymentTransaction.getAffiliationType();
        if (affiliationType == AffiliationType.CVV) {
            validateCardTokenPresenceForCVVTransaction(customerAccountId, cardPaymentTransaction);
        } else if (affiliationType == AffiliationType.CVV_LESS || affiliationType == AffiliationType.NON_CVV_CUST_NP) {
            validateCardTokenAbsenceForNonCVVTransaction(customerAccountId, cardPaymentTransaction);
            validateCardUserEligibilityForNonCVVTransaction(customerAccountId, cardPaymentTransaction);
        }
    }

    private void validateCardUserEligibilityForNonCVVTransaction(UUID customerAccountId, CardPaymentTransaction cardPaymentTransaction) {
        Boolean cvvRequired = cardPaymentTransaction.getCardPaymentInstrument().getMetadata().getCvvRequired();
        boolean hasPaymentInstrumentIdFailuresInLast24Hours = hasPaymentInstrumentIdFailuresInLast24Hours(cardPaymentTransaction.getPaymentInstrumentId());
        if (cvvRequired || hasPaymentInstrumentIdFailuresInLast24Hours) {
            String msg = String.format("User-Card is ineligible for non CVV transaction with paymentInstrumentId[%s] for customerAccountId[%s]",
                    cardPaymentTransaction.getPaymentInstrumentId(), customerAccountId);
            throw new BusinessValidationException(ErrorConstants.CoFTopup.CVV_LESS_TRANSACTION_NOT_ALLOWED, msg);
        }
    }

    private static void validateCardTokenAbsenceForNonCVVTransaction(UUID customerAccountId, CardPaymentTransaction cardPaymentTransaction) {
        if (Objects.nonNull(cardPaymentTransaction.getCardTokenInformation())) {
            String msg = String.format("Card Token Information not required for payment instrument with paymentInstrumentId[%s] for customerAccountId[%s]",
                    cardPaymentTransaction.getPaymentInstrumentId(), customerAccountId);
            throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_TOKEN_INFORMATION_NOT_REQUIRED, msg);
        }
    }

    private static void validateCardTokenPresenceForCVVTransaction(UUID customerAccountId, CardPaymentTransaction cardPaymentTransaction) {
        if (Objects.isNull(cardPaymentTransaction.getCardTokenInformation())) {
            String msg = String.format("Card Token Information missing for payment instrument with paymentInstrumentId[%s] for customerAccountId[%s]",
                    cardPaymentTransaction.getPaymentInstrumentId(), customerAccountId);
            throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_TOKEN_INFORMATION_MISSING, msg);
        }
    }

    private boolean isTopupExceedingMaxWalletBalanceForUser(BigDecimal topupAmount, GiftCardPaymentInstrument giftCardPaymentInstrument) {
        BigDecimal currentBalance = giftCardPaymentInstrument.getBalance().getCurrencyAmount();
        BigDecimal maxWalletBalance = BigDecimal.valueOf(topupConfiguration.getMaxWalletBalanceAllowed());
        return currentBalance.add(topupAmount).compareTo(maxWalletBalance) > 0;
    }

    private boolean hasPaymentInstrumentIdFailuresInLast24Hours(UUID cvvLessAllowedPaymentInstrumentId) {
        Date currentDate = new Date();
        List<UUID> cardPaymentInstrumentIdsWithFailureInDuration;
        if (CollectionUtils.isNotEmpty(walletPaymentServiceConfiguration.getCvvLessTechnicalErrorCodes())) {
            cardPaymentInstrumentIdsWithFailureInDuration =
                    cardTransactionRepository.getCardPaymentInstrumentIdsWithFailureInDurationAndErrorCodeNotIn(Collections.singletonList(cvvLessAllowedPaymentInstrumentId),
                            new Date(currentDate.getTime() - 24 * 3600 * 1000), currentDate,
                            walletPaymentServiceConfiguration.getCvvLessTechnicalErrorCodes());
        } else {
            cardPaymentInstrumentIdsWithFailureInDuration =
                    cardTransactionRepository.getCardPaymentInstrumentIdsWithFailureInDuration(Collections.singletonList(cvvLessAllowedPaymentInstrumentId),
                            new Date(currentDate.getTime() - 24 * 3600 * 1000), currentDate);
        }
        return CollectionUtils.isNotEmpty(cardPaymentInstrumentIdsWithFailureInDuration);
    }

    private void createCoFTopupTransactionInValidationFailureState(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnRequestDomainContext.getTransaction();
        DeviceInformation deviceInformation = coFTopupTxnRequestDomainContext.getDeviceInfo();

        CoFTopupTransactionDO cofTopupTransactionDO = new CoFTopupTransactionDO();
        cofTopupTransactionDO.setAmountRequested(coFTopUpTransaction.getAmountRequested().getValue());
        cofTopupTransactionDO.setCurrencyUnit(CurrencyUnit.valueOf(coFTopUpTransaction.getAmountRequested().getCurrencyUnit().name()));
        cofTopupTransactionDO.setCustomerAccountId(coFTopUpTransaction.getCustomer().getCustomerAccountId());
        cofTopupTransactionDO.setState(TransactionStateEnum.FAILURE);
        cofTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.VALIDATION_FAILED);
        cofTopupTransactionDO.setTxnReferenceId(coFTopUpTransaction.getTransactionReferenceId());
        cofTopupTransactionDO.setClientReqId(coFTopupTxnRequestDomainContext.getClientRequestId());
        cofTopupTransactionDO.setDeviceIpAddress(deviceInformation.getIp());
        cofTopupTransactionDO.setDeviceId(deviceInformation.getFingerPrint());
        if (Objects.nonNull(coFTopUpTransaction.getParentTransactionType())) {
            cofTopupTransactionDO.setParentTransactionType(com.walmart.international.wallet.payment.data.constant.enums.TransactionType.valueOf(coFTopUpTransaction.getParentTransactionType().name()));
        }
        coFTopupTransactionRepository.save(cofTopupTransactionDO);
    }
}
