package com.walmart.international.wallet.payment.core.adapter.billprocessor.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateBillRequest {

    private String processorBillerId;

    private String accountNumber;
}
