package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class ArcusBillerResponse {

    private String type;

    private int id;

    private String name;

    @JsonProperty("biller_type")
    private String billerType;

    @JsonProperty("bill_type")
    private String billType;

    private String country;

    private String currency;

    @JsonProperty("requires_name_on_account")
    private boolean requiresNameOnAccount;

    @JsonProperty("hours_to_fulfill")
    private int hoursToFulfill;

    @JsonProperty("account_number_digits")
    private String accountNumberDigits;

    private String mask;

    @JsonProperty("can_check_balance")
    private boolean canCheckBalance;

    @JsonProperty("supports_partial_payments")
    private boolean supportsPartialPayments;

    @JsonProperty("has_xdata")
    private boolean hasXData;

    @JsonDeserialize(using = AvailableAmountDeserializer.class)
    @JsonProperty("available_topup_amounts")
    private Object availableTopupAmounts;

    @JsonProperty("topup_commission")
    private BigDecimal topupCommission;

    @JsonDeserialize(using = AvailableAmountDeserializer.class)
    @JsonProperty("available_gift_card_amounts")
    private Object availableGiftCardAmounts;

    @JsonProperty("gift_card_commission")
    private BigDecimal giftCardCommission;

    private static class AvailableAmountDeserializer extends JsonDeserializer<Object> {

        @Override
        public Object deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
            JsonNode node = jsonParser.getCodec().readTree(jsonParser);
            if (node.isArray()) {
                List<String> topupAmounts = new ArrayList<>();
                for (JsonNode jsonNode : node) {
                    topupAmounts.add(jsonNode.asText());
                }
                return topupAmounts;
            } else {
                return node.asText();
            }
        }
    }
}
