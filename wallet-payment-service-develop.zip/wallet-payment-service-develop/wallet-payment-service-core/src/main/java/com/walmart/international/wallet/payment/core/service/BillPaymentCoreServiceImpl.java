package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.notification.constants.EventDownstream;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.txnaggregator.TxnCompletedPayloadGenerator;
import com.walmart.international.notification.utils.EventHelper;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.domain.CoreTransactionStatusV2;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.request.CancelRequest;
import com.walmart.international.services.payment.core.response.CancelResponse;
import com.walmart.international.wallet.payment.core.adapter.tas.TxnAggregatorServiceAdapter;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class BillPaymentCoreServiceImpl implements BillPaymentCoreService {

    @Autowired
    PaymentCoreService paymentCoreService;

    @Autowired
    CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    TxnAggregatorServiceAdapter txnAggregatorServiceAdapter;

    @Autowired
    EventHelper eventHelper;

    @Autowired
    private TxnCompletedPayloadGenerator txnCompletedPayloadGenerator;

    @Override public void processCancelBillPaymentInitEvent(PayBillInitEventPayload payBillInitEventPayload) {
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = payBillInitEventPayload.getBillPayTxnResponseDomainContext();
        CoFTopupTransactionDO coFTopupTransactionDO = billPayTxnResponseDomainContext.getCoFTopupTransactionDO();
        BillPayTransactionDO billPayTransactionDO = billPayTxnResponseDomainContext.getBillPayTransactionDO();
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        cancelCoFTopupCoreTransaction(coFTopupTransactionDO);
        updateCoFTopupTransaction(coFTopupTransactionDO, billPayTransaction);
        cancelBillPayCoreTransactionRequest(billPayTransactionDO);
        updateBillPayTransaction(billPayTxnResponseDomainContext, payBillInitEventPayload.getBillPayTxnRequestDomainContext().getHeaderValue(WPSConstants.Headers.CORRELATION_ID));
    }

    @Override public void updateBillPayTransactionStateForReversal(UUID transactionId, BillPayTxnStateReason billPayTxnStateReason) {
        try {
            Optional<BillPayTransactionDO> billPayTransactionDOOptional = billPayTransactionRepository.findById(transactionId);
            if (billPayTransactionDOOptional.isPresent()) {
                BillPayTransactionDO billPayTransactionDO = billPayTransactionDOOptional.get();
                billPayTransactionDO.setStateReason(billPayTxnStateReason);
                billPayTransactionRepository.save(billPayTransactionDO);
            } else {
                log.error("Bill pay transaction does not exist for transactionID :{}, can not update refund state", transactionId);
            }
        } catch (Exception ex) {
            log.error("Error occurred while updating cof top up transaction : {} for refund status", transactionId, ex);
        }
    }

    private void cancelCoFTopupCoreTransaction(CoFTopupTransactionDO coFTopupTransactionDO) throws ProcessingException {
        UUID transactionId = coFTopupTransactionDO.getCoFTopupTransactionId();
        log.info("Calling PaymentCore cancel for CoFTopup transactionId : {}", transactionId);
        try {
            CancelRequest cancelRequest = CancelRequest.builder()
                    .clientTransactionId(String.join("_", String.valueOf(transactionId), "1"))
                    .clientTransactionUUID(transactionId)
                    .build();
            CancelResponse cancelResponse = paymentCoreService.cancel(cancelRequest);
            if (!CoreTransactionStatusV2.CANCELLED.equals(cancelResponse.getStatus())) {
                String msg = String.format("PaymentCore cancel failed for CoFTopup transactionId [%s] transactionStatus[%s]", transactionId, cancelResponse.getStatus());
                throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.PAYMENT_CORE_CANCEL_PAYMENT_FAILED, msg);
            }
        } catch (PaymentCoreServiceException ex) {
            String msg = String.format("PaymentCore cancel failed for CoFTopup transactionId : [%s]", transactionId);
            throw new ProcessingException(ErrorConstants.CancelPayBillInitTransaction.PAYMENT_CORE_CANCEL_PAYMENT_FAILED, msg, ex);
        }
    }

    private void cancelBillPayCoreTransactionRequest(BillPayTransactionDO billPayTransactionDO) {
        String transactionId = String.valueOf(billPayTransactionDO.getBillPayTransactionId());
        log.info("Calling PaymentCore CancelPayRequest for BillPay transactionId : {}", transactionId);
        try {;
            CancelRequest cancelRequest = CancelRequest.builder()
                    .clientTransactionId(String.valueOf(billPayTransactionDO.getBillPayTransactionId()))
                    .clientTransactionUUID(billPayTransactionDO.getBillPayTransactionId())
                    .build();
            CancelResponse cancelResponse = paymentCoreService.cancelPayRequest(cancelRequest);
            if (!CoreTransactionStatusV2.CANCELLED.equals(cancelResponse.getStatus())) {
                String msg = String.format("PaymentCore cancelPayRequest failed for BillPay transactionId [%s] transactionStatus[%s]", transactionId, cancelResponse.getStatus());
                throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.PAYMENT_CORE_CANCEL_PAYMENT_FAILED, msg);
            }
        } catch (PaymentCoreServiceException ex) {
            String msg = String.format("PaymentCore cancelPayRequest failed for BillPay transactionId : [%s]", transactionId);
            throw new ProcessingException(ErrorConstants.CancelPayBillInitTransaction.PAYMENT_CORE_CANCEL_PAYMENT_FAILED, msg, ex);
        }
    }

    private void updateCoFTopupTransaction(CoFTopupTransactionDO coFTopupTransactionDO, BillPayTransaction billPayTransaction) {
        coFTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.DEBIT_FAILED);
        coFTopupTransactionDO.setState(TransactionStateEnum.FAILURE);
        coFTopupTransactionDO.setAbortReason(billPayTransaction.getAbortReason());
        coFTopupTransactionDO.updateLastEventDate();
        log.info("Updating coFTopup transaction [{}] for cancelled billPay Transaction, transactionId : [{}]", coFTopupTransactionDO.getCoFTopupTransactionId(), billPayTransaction.getTransactionId());
        coFTopupTransactionDO = coFTopupTransactionRepository.save(coFTopupTransactionDO);
        eventHelper.publishAsync(coFTopupTransactionDO.getCoFTopupTransactionId().toString(), coFTopupTransactionDO, WalletEventType.TXN_COMPLETED, List.of(EventDownstream.TXN_AGGREGATER_SERVICE));
    }

    private void updateBillPayTransaction(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext, String correlationId) {
        BillPayTransactionDO billPayTransactionDO = billPayTxnResponseDomainContext.getBillPayTransactionDO();
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        billPayTransactionDO.setState(TransactionStateEnum.FAILURE);
        billPayTransactionDO.setStateReason(BillPayTxnStateReason.TOPUP_3DS_CANCELLED);
        billPayTransactionDO.setAbortReason(billPayTransaction.getAbortReason());
        billPayTransactionDO.updateLastEventDate();
        log.info("Updating billPay transaction for cancelled bill pay Transaction, transactionId : {}", billPayTransactionDO.getBillPayTransactionId());
        billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
        txnAggregatorServiceAdapter.syncBillPayTransaction(billPayTransactionDO);
        try {
            // Doing this since we need to create the EventPayload before the Session is closed in CancelBillPaymentInitiatedListener
            EventPayload eventPayload = txnCompletedPayloadGenerator.generatePayload(billPayTransactionDO, correlationId);
            eventHelper.publishAsync(billPayTransactionDO.getBillPayTransactionId().toString(), eventPayload, WalletEventType.TXN_COMPLETED, List.of(EventDownstream.TXN_AGGREGATER_SERVICE));
        } catch (Throwable e) {
            String msg = String.format("CRITICAL :: Error while publishing cancelled txn status to TxnAgg for txnId[%s], customerAccountId[%s], correlationID[%s]",
                    billPayTransactionDO.getBillPayTransactionId(), billPayTransactionDO.getCustomerAccountId(), correlationId);
            log.error(msg, e);
        }
    }
}
