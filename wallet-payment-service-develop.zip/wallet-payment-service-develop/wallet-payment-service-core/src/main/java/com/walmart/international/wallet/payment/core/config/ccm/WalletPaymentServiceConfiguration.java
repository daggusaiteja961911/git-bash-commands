package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

import java.util.List;

@Configuration(configName = WalletPaymentServiceConfiguration.CCM_ENTRY_NAME)
public interface WalletPaymentServiceConfiguration {

    String CCM_ENTRY_NAME = "wallet-payment-service-config";

    @Property(propertyName = "biller.category.versions")
    List<Integer> getBillerCategoryVersions();

    @Property(propertyName = "biller.category.version.promotions")
    Integer getBillerCategoryVersionForPromotions();

    @Property(propertyName = "current.application.name")
    String getApplicationName();

    @Property(propertyName = "store.url", defaultValue = "cashi.com.mx")
    String getStoreURL();

    @Property(propertyName = "header.user.id.validation.enabled", defaultValue = "true")
    boolean isHeaderUserIdValidationEnabled();

    @Property(propertyName = "cvv.less.technical.error.codes")
    List<String> getCvvLessTechnicalErrorCodes();
}
