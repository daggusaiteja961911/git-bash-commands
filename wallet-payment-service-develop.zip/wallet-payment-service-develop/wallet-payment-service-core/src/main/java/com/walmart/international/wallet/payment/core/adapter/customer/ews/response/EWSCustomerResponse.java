package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EWSCustomerResponse {
    String status;

    String message;

    EWSCustomerAccountDTO result;
}
