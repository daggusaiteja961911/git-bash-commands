package com.walmart.international.wallet.payment.core.service;

import com.querydsl.core.types.Predicate;
import com.walmart.commons.collections.CollectionUtils;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.notification.exceptions.ReminderServiceException;
import com.walmart.international.services.notificationservice.naas.ReminderSubCategoryType;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.CustomerServiceClientForEWS;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.CustomerBasicResponse;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.BillReminderConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.BillerType;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.BillPlan;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.AlreadyPaidRequestContext;
import com.walmart.international.wallet.payment.core.domain.model.request.UpdateCustomerBillDueInfoRequestContext;
import com.walmart.international.wallet.payment.core.domain.model.response.AlreadyPaidResponseContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CustomerBillAccountsByType;
import com.walmart.international.wallet.payment.core.mapper.BillerMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.service.helper.BillPayReminderHelper;
import com.walmart.international.wallet.payment.core.utils.WPSDateUtils;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.BillType;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.constant.enums.NotificationContentIdentifier;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillerRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import com.walmart.international.wallet.payment.data.helper.CustomerBillAccountHelper;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.joda.time.DateTimeComparator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.time.OffsetTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BillCoreServiceImpl implements BillCoreService {

    @Autowired
    CustomerBillAccountRepository customerBillAccountRepository;

    @Autowired
    BillerRepository billerRepository;

    @Autowired
    BillPayReminderService billPayReminderService;

    @Autowired
    private CustomerServiceClientForEWS customerServiceClientForEWS;

    @Autowired
    private BillPayReminderHelper billPayReminderHelper;

    @Autowired
    private CustomerBillAccountHelper customerBillAccountHelper;

    @ManagedConfiguration
    private BillReminderConfiguration billReminderConfiguration;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    private final CustomerMapper customerMapper = CustomerMapper.INSTANCE;

    private BillerMapper billerMapper = BillerMapper.INSTANCE;

    @Override
    public CustomerBillAccount deleteCustomerBillAccount(UUID customerBillAccountId, UUID customerAccountId) throws BusinessValidationException {

        CustomerBillAccountDO customerBillAccountDO = customerBillAccountRepository.findByCustomerBillAccountIdAndIsSavedTrue(customerBillAccountId);

        if (Objects.isNull(customerBillAccountDO)) {
            String msg = String.format("Record not found for customerBillAccountID[%s]", customerBillAccountId);
            throw new BusinessValidationException(ErrorConstants.DeleteCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_NOT_FOUND, msg);
        }

        if (!customerBillAccountDO.getCustomerAccountId().equals(customerAccountId)) {
            String msg = String.format("customerAccountID[%s] associated with customer bill account doesn't match with customerAccountId[%s] in request", customerBillAccountDO.getCustomerAccountId(), customerAccountId);
            throw new BusinessValidationException(ErrorConstants.DeleteCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_CUSTOMER_ACCOUNT_ID_MISMATCH, msg);
        }

        if (customerBillAccountDO.isDeleted()) {
            String msg = String.format("Customer bill account with customerBillAccountId[%s] is already deleted", customerBillAccountId);
            throw new BusinessValidationException(ErrorConstants.DeleteCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_ALREADY_DELETED, msg);
        }

        customerBillAccountDO.setDeleted(true);
        customerBillAccountDO.setSaved(false);
        customerBillAccountRepository.save(customerBillAccountDO);

        return customerBillAccountMapper.customerBillAccountDOToCustomerBillAccount(customerBillAccountDO);
    }

    // called from MigrationBillServiceImpl
    @Override
    public List<CustomerBillAccount> getAllSavedCustomerBillAccounts(String processorBillerId, UUID customerAccountId, String accountNumber) throws ApplicationException {
        if (Objects.isNull(processorBillerId)) {
            throw new DataValidationException(ErrorConstants.GetSavedCustomerBillAccounts.PROCESSOR_BILLER_ID_IS_NULL);
        }
        BillerDO billerDO = getBillerDOFromProcessorBillerId(processorBillerId);
        List<String> processorBillerIds = getProcessorBillerIdsOfSubBillersIfExist(billerDO);
        List<CustomerBillAccountDO> customerBillAccountDOList;
        try {
            if (Objects.isNull(accountNumber)) {
                log.info("Fetching all saved customer bill account entries from DB for processorBillerId[{}] and customerAccountId[{}]",
                        processorBillerId, customerAccountId);
                customerBillAccountDOList =
                        customerBillAccountRepository.findByProcessorBillerIdInAndIsSavedTrueAndIsDeletedFalseAndCustomerAccountIdOrderByLastPaidDateDesc(
                                processorBillerIds, customerAccountId);
            } else {
                log.info("Fetching saved customer bill account entries from DB for processorBillerId[{}], accountNumber[{}] and customerAccountId[{}]",
                        processorBillerId, accountNumber, customerAccountId);
                customerBillAccountDOList =
                        customerBillAccountRepository.findByProcessorBillerIdInAndAccountNumberAndIsSavedTrueAndIsDeletedFalseAndCustomerAccountIdOrderByLastPaidDateDesc(
                                processorBillerIds, accountNumber, customerAccountId);
            }
        } catch (Exception ex) {
            String msg = String.format("Error while fetching customer bill account entries from DB for processorBillerId[%s], accountNumber[%s] and customerAccountId[%s]",
                    processorBillerId, accountNumber, customerAccountId);
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg);
        }
        Collection<CustomerBillAccountDO> deDupedCustomerBillAccountDOList = getDeDupedCBAEntries(customerBillAccountDOList);
        List<CustomerBillAccount> customerBillAccountList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(deDupedCustomerBillAccountDOList)) {
            for (CustomerBillAccountDO customerBillAccountDO : deDupedCustomerBillAccountDOList) {
                customerBillAccountList.add(customerBillAccountMapper.customerBillAccountDOToCustomerBillAccountWithBiller(customerBillAccountDO));
            }
        }
        return customerBillAccountList;
    }

    private Collection<CustomerBillAccountDO> getDeDupedCBAEntries(List<CustomerBillAccountDO> customerBillAccountDOList) {
        if (billPaymentConfiguration.isUniqueConstraintPresentInCBATable()) {
            return customerBillAccountDOList;
        } else {
            return WalletPaymentServiceUtil.deDupeCBAEntriesBasedOnUniqueConstraint(customerBillAccountDOList);
        }
    }


    // called from BillServiceImpl
    @Override
    public List<CustomerBillAccount> getSavedCustomerBillAccounts(UUID billerId, UUID customerAccountId, String accountNumber) throws ApplicationException {
        if (Objects.isNull(billerId)) {
            throw new DataValidationException(ErrorConstants.GetSavedCustomerBillAccounts.BILLER_ID_IS_NULL);
        }
        BillerDO billerDO = getBillerDOFromBillerId(billerId);
        List<BillerDO> billerDOs = getBillerDOsOfSubBillersIfExist(billerDO);
        if (CollectionUtils.isEmpty(billerDOs)) {
            throw new BusinessValidationException(ErrorConstants.GetSavedCustomerBillAccounts.NO_ENABLED_BILLERS_FOUND);
        }
        List<CustomerBillAccountDO> customerBillAccountDOList;
        try {
            if (Objects.isNull(accountNumber)) {
                log.info("Fetching all saved customer bill account entries from DB for billerId[{}] and customerAccountId[{}]", billerId, customerAccountId);
                customerBillAccountDOList =
                        customerBillAccountRepository.findByBillerDOInAndIsSavedTrueAndIsDeletedFalseAndCustomerAccountIdOrderByLastPaidDateDesc(
                                billerDOs, customerAccountId);
            } else {
                log.info("Fetching saved customer bill account entries from DB for billerId[{}], accountNumber[{}] and customerAccountId[{}]",
                        billerId, accountNumber, customerAccountId);
                customerBillAccountDOList =
                        customerBillAccountRepository.findByBillerDOInAndAccountNumberAndIsSavedTrueAndIsDeletedFalseAndCustomerAccountIdOrderByLastPaidDateDesc(
                                billerDOs, accountNumber, customerAccountId);
            }
        } catch (Exception ex) {
            String msg = String.format("Error while fetching customer bill account entries from DB for billerId[%s], accountNumber[%s] and customerAccountId[%s]",
                    billerId, accountNumber, customerAccountId);
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg);
        }
        Collection<CustomerBillAccountDO> deDupedCustomerBillAccountDOList = getDeDupedCBAEntries(customerBillAccountDOList);
        List<CustomerBillAccount> customerBillAccountList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(deDupedCustomerBillAccountDOList)) {
            for (CustomerBillAccountDO customerBillAccountDO : deDupedCustomerBillAccountDOList) {
                customerBillAccountList.add(customerBillAccountMapper.customerBillAccountDOToCustomerBillAccountWithBiller(customerBillAccountDO));
            }
        }
        return customerBillAccountList;
    }

    private BillerDO getBillerDOFromBillerId(UUID billerId) throws ApplicationException {
        BillerDO billerDO;
        try {
            log.info("Fetching biller info from DB for billerId[{}]", billerId);
            billerDO = billerRepository.getByBillerIdAndEnabled(billerId, Boolean.TRUE).orElseThrow(() ->
                    new BusinessValidationException(ErrorConstants.BillerData.BILLER_NOT_FOUND_OR_NOT_ENABLED,
                            String.format("Biller record not found/not enabled for billerId: [%s]", billerId)));
        } catch (BusinessValidationException bve) {
            throw bve;
        } catch (Exception ex) {
            String msg = String.format("Exception while fetching billerDO from DB for billerId: [%s]", billerId);
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
        return billerDO;
    }

    private List<BillerDO> getBillerDOsOfSubBillersIfExist(BillerDO billerDO) {
        log.info("Fetching subBillers billerDOs if exists for biller with billerId[{}]", billerDO.getBillerId());
        List<BillerDO> billerDOs = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(billerDO.getSubBillers())) {
            billerDOs = billerDO.getSubBillers().stream().filter(BillerDO::getEnabled).collect(Collectors.toList());
        } else {
            billerDOs.add(billerDO);
        }
        return billerDOs;
    }

    private List<String> getProcessorBillerIdsOfSubBillersIfExist(BillerDO billerDO) {
        log.info("Fetching processorBillerIds of subBillers if exists for biller with processorBillerId[{}]", billerDO.getProcessorBillerId());
        List<String> processorBillerIds = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(billerDO.getSubBillers())) {
            processorBillerIds = billerDO.getSubBillers().stream().filter(BillerDO::getEnabled).map(BillerDO::getProcessorBillerId)
                    .collect(Collectors.toList());
        } else {
            processorBillerIds.add(billerDO.getProcessorBillerId());
        }
        return processorBillerIds;
    }

    private BillerDO getBillerDOFromProcessorBillerId(String processorBillerId) throws ApplicationException {
        BillerDO billerDO;
        try {
            log.info("Fetching biller info from DB for processorBillerId[{}]", processorBillerId);
            billerDO = billerRepository.getByProcessorBillerIdAndEnabled(processorBillerId, Boolean.TRUE).orElseThrow(() -> new BusinessValidationException(
                    ErrorConstants.BillerData.BILLER_NOT_FOUND_OR_NOT_ENABLED, String.format("Biller record not found/not enabled for processorBillerId: [%s]", processorBillerId)));
        } catch (BusinessValidationException bve) {
            throw bve;
        } catch (Exception ex) {
            String msg = String.format("Exception while fetching billerDO from DB for processorBillerId: [%s]", processorBillerId);
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
        return billerDO;
    }

    @Override
    public CustomerBillAccountsByType getCustomerBillAccountsByType(UUID customerAccountId, List<BillType> billTypes, int dueBillsDaysLimit,
                                                                    int maxDaysForNudge, int minDaysForNudge, Pageable pageable) {
        List<CustomerBillAccount> overdueBills = new ArrayList<>();
        List<CustomerBillAccount> dueBills = new ArrayList<>();
        List<CustomerBillAccount> paidBills = new ArrayList<>();
        String nudgeBucket = getNudgeBucket();
        Predicate getBillsPredicate = customerBillAccountHelper.getDuePaidAndOverdueBillsPredicate(customerAccountId, billTypes, dueBillsDaysLimit, nudgeBucket, maxDaysForNudge, minDaysForNudge);
        Page<CustomerBillAccountDO> customerBillAccountDOPage = customerBillAccountRepository.findAll(getBillsPredicate, pageable);
        Collection<CustomerBillAccountDO> deDupedCustomerBillAccountDOList = getDeDupedCBAEntries(customerBillAccountDOPage.toList());
        List<CustomerBillAccount> customerBillAccountList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(deDupedCustomerBillAccountDOList)) {
            for (CustomerBillAccountDO customerBillAccountDO : deDupedCustomerBillAccountDOList) {
                CustomerBillAccount customerBillAccount = customerBillAccountMapper.customerBillAccountDOToCustomerBillAccount(customerBillAccountDO);
                customerBillAccount.setBiller(billerMapper.mapBillerDOToBillerWithoutSubBillersAndBillPlans(customerBillAccountDO.getBillerDO()));
                customerBillAccountList.add(customerBillAccount);
            }
        }

        if (billTypes.size() == 1 && !billTypes.get(0).name().equalsIgnoreCase(BillType.ALL.name())) {
            if (billTypes.get(0).name().equalsIgnoreCase(BillType.OVERDUE.name())) {
                overdueBills.addAll(customerBillAccountList);
            } else if (billTypes.get(0).name().equalsIgnoreCase(BillType.DUE.name())) {
                dueBills.addAll(customerBillAccountList);
            } else if (billTypes.get(0).name().equalsIgnoreCase(BillType.PAID.name())) {
                paidBills.addAll(customerBillAccountList);
            }
        } else {
            customerBillAccountList.forEach(customerBillAccount -> {
                if (isOverdue(customerBillAccount)) {
                    overdueBills.add(customerBillAccount);
                } else if (isDue(customerBillAccount, dueBillsDaysLimit, nudgeBucket, maxDaysForNudge, minDaysForNudge)) {
                    dueBills.add(customerBillAccount);
                } else if (isPaid(customerBillAccount, dueBillsDaysLimit)) {
                    paidBills.add(customerBillAccount);
                }
            });
        }
        //TODO sorting should be moved to query for accurate result. Currently, consistent with V1 impl.
        overdueBills.sort(new CustomerBillAccount.OverdueBillsComparator());
        dueBills.sort(new CustomerBillAccount.DueBillsComparator());
        paidBills.sort(new CustomerBillAccount.PaidBillsComparator());

        return CustomerBillAccountsByType.builder()
                .overdueBills(overdueBills)
                .dueBills(dueBills)
                .paidBills(paidBills).build();
    }

    private String getNudgeBucket() {
        LocalDate currentDate = LocalDate.now();
        int nudgeDayOfMonth;

        List<Integer> daysForBillPaymentNudgeList = billReminderConfiguration.getDaysOfMonthForBillPaymentNudge() != null ? Arrays.stream(billReminderConfiguration.getDaysOfMonthForBillPaymentNudge().split(",")).map(Integer::valueOf).sorted().collect(Collectors.toList()) : Collections.emptyList();
        int reminderDaysCount = billReminderConfiguration.getReminderDaysCountForBillpayNudge();
        String bucket = null;
        for (int i = 0; i < daysForBillPaymentNudgeList.size(); i++) {
            //Mid of month
            if (i != daysForBillPaymentNudgeList.size() - 1) {
                nudgeDayOfMonth = daysForBillPaymentNudgeList.get(i);
                if (currentDate.getDayOfMonth() >= nudgeDayOfMonth && currentDate.getDayOfMonth() <= nudgeDayOfMonth + reminderDaysCount) {
                    bucket = "B".concat(Integer.toString(i + 1));
                    break;
                }
            } else {
                nudgeDayOfMonth = daysForBillPaymentNudgeList.get(i);
                int lastDayofMonth = currentDate.with(TemporalAdjusters.lastDayOfMonth()).getDayOfMonth();
                LocalDate lastNudgeDate;
                if (currentDate.getMonth() == Month.FEBRUARY && lastDayofMonth < nudgeDayOfMonth) {
                    nudgeDayOfMonth = lastDayofMonth;
                }
                lastNudgeDate = LocalDate.now().withDayOfMonth(nudgeDayOfMonth).plusDays(reminderDaysCount);
                if (currentDate.getDayOfMonth() >= nudgeDayOfMonth && (currentDate.isBefore(lastNudgeDate) || currentDate.isEqual(lastNudgeDate))) {
                    bucket = "B".concat(Integer.toString(i + 1));
                    break;
                }
            }
        }
        return bucket;
    }

    private boolean isPaid(CustomerBillAccount customerBillAccount, int dueBillsDaysLimit) {
        Biller biller = customerBillAccount.getBiller();
        Boolean result = Boolean.FALSE;
        if (customerBillAccount.getDueDate() == null) {
            result = Boolean.TRUE;
        } else if (customerBillAccount.getDueInfoUpdatedAt() != null
                && customerBillAccount.getLastPaidDateValue() != null
                && customerBillAccount.getLastPaidDateValue().after(customerBillAccount.getDueInfoUpdatedAt())) {
            result = Boolean.TRUE;
        } else if (!biller.getCanCheckBalance() || WPSDateUtils.dateToLocalDate(customerBillAccount.getDueDate()).isAfter(LocalDate.now().plusDays(dueBillsDaysLimit))) {
            result = Boolean.TRUE;
        }
        return result;

    }

    private boolean isDue(CustomerBillAccount customerBillAccount, int dueBillsDaysLimit, String nudgeBucket, int maxDaysForNudge, int minDaysForNudge) {
        Biller biller = customerBillAccount.getBiller();

        LocalDate dueDate = customerBillAccount.getDueDate() != null ? WPSDateUtils.dateToLocalDate(customerBillAccount.getDueDate()) : null;
        LocalDate lastPaidDate = customerBillAccount.getLastPaidDateValue() != null ? WPSDateUtils.dateToLocalDate(customerBillAccount.getLastPaidDateValue()) : null;
        Boolean result = Boolean.FALSE;

        if (dueDate != null || customerBillAccount.getNudgeBucket() != null) {
            if (customerBillAccount.getNudgeBucket() != null && customerBillAccount.getNudgeBucket().equalsIgnoreCase(nudgeBucket)) {
                if (lastPaidDate != null && lastPaidDate.isAfter(LocalDate.now().minusDays(maxDaysForNudge)) && lastPaidDate.isBefore(LocalDate.now().minusDays(minDaysForNudge))) {
                    if (customerBillAccount.getSkipReminderTillDate() == null || WPSDateUtils.dateToLocalDate(customerBillAccount.getSkipReminderTillDate()).isBefore(LocalDate.now())) {
                        result = Boolean.TRUE;
                    }
                }

            } else if (dueDate != null) {
                if (dueDate.isAfter(LocalDate.now()) || dueDate.equals(LocalDate.now())) {
                    if (biller.getCanCheckBalance() || dueDate.isBefore(LocalDate.now().plusDays(dueBillsDaysLimit)) || dueDate.equals(LocalDate.now().plusDays(dueBillsDaysLimit))) {
                        if (customerBillAccount.getDueInfoUpdatedAt() != null
                                && customerBillAccount.getLastPaidDateValue() != null
                                && customerBillAccount.getLastPaidDateValue().before(customerBillAccount.getDueInfoUpdatedAt())) {
                            result = Boolean.TRUE;
                        }
                    }
                }
            }
        }
        return result;
    }

    private boolean isOverdue(CustomerBillAccount customerBillAccount) {
        Date dueDate = customerBillAccount.getDueDate();
        return Objects.nonNull(dueDate) && Objects.nonNull(customerBillAccount.getDueInfoUpdatedAt())
                && customerBillAccount.getLastPaidDateValue() != null
                && WPSDateUtils.dateToLocalDate(dueDate).isBefore(LocalDate.now())
                && customerBillAccount.getLastPaidDateValue().before(customerBillAccount.getDueInfoUpdatedAt());
    }

    @Override
    public AlreadyPaidResponseContext updateCustomerBillAccountAsAlreadyPaidAndSendReminders(AlreadyPaidRequestContext alreadyPaidRequestContext) throws ApplicationException {
        Date lastPaidDate = null;
        try {
            if (Objects.nonNull(alreadyPaidRequestContext.getLastPaidDate())) {
                lastPaidDate = alreadyPaidRequestContext.getLastPaidDate();
            }
            log.info("Marking customerBillAccountId:[{}] as already paid by customer with customerAccountId:[{}]",
                    alreadyPaidRequestContext.getCustomerBillAccountId(), alreadyPaidRequestContext.getCustomerAccountId());
            CustomerBillAccountDO customerBillAccountDO = customerBillAccountRepository.findByCustomerBillAccountIdAndIsSavedTrue(alreadyPaidRequestContext.getCustomerBillAccountId());
            if (customerBillAccountDO == null) {
                log.info("Record not found for customerBillAccountId[{}]", alreadyPaidRequestContext.getCustomerBillAccountId());
                throw new ProcessingException(ErrorConstants.AlreadyPaid.SAVED_BILLER_ACCOUNT_NOT_FOUND);
            }
            CustomerBillAccount customerBillAccount = mapCustomerBillAccountFromDOInAlreadyPaidFlow(customerBillAccountDO);
            BillDetail billDetail = fetchBillDetail(customerBillAccount.getBiller().getBillPlans(), customerBillAccount.getLastPaidAmountValue());
            DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();
            if (lastPaidDate != null && dateTimeComparator.compare(lastPaidDate, new Date()) > 0) {
                log.error("Last paid date cannot be a future date : customerBillAccountId[{}], customerId[{}], lastPaidDate[{}].",
                        customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getCustomerAccountId(), lastPaidDate);
                throw new BusinessValidationException(ErrorConstants.AlreadyPaid.INVALID_LAST_PAID_DATE);
            }
            Date topUpExpiryDate = billPayReminderHelper.getTopUpExpiryDate(billDetail, lastPaidDate != null ? lastPaidDate : customerBillAccount.getLastPaidDateValue());
            BillerType billerType = getBillerType(customerBillAccount.getBiller().getCanCheckBalance(), customerBillAccount.getProcessorBillAccountId(), topUpExpiryDate);
            if (lastPaidDate != null) {
                if (billerType == BillerType.POSTPAID) {
                    customerBillAccount.setDueDate(null);
                    customerBillAccount.setDueInfoUpdatedAt(new Date());
                    raiseDeleteBillPayReminderEvent(customerBillAccount, null);
                } else if (billerType == BillerType.PREPAID) {
                    customerBillAccount.setDueDate(topUpExpiryDate);
                    customerBillAccount.setDueInfoUpdatedAt(new Date());
                    Customer customer = getCustomerByIdMapper(customerBillAccount.getCustomerAccountId());
                    raiseBillPayReminderForBillerType(billerType, customerBillAccount, customer, billDetail, null);
                } else {
                    customerBillAccount.setDueDate(null);
                    customerBillAccount.setDueInfoUpdatedAt(null);
                    customerBillAccount.setSkipReminderTillDate(null);
                    NotificationContentIdentifier notificationContentIdentifier = checkIsConsumptionBasedBiller(customerBillAccount.getBiller().getDisplayName()) ? NotificationContentIdentifier.S3 : NotificationContentIdentifier.S4;
                    Customer customer = getCustomerByIdMapper(customerBillAccount.getCustomerAccountId());
                    raiseBillPayReminderForBillerType(billerType, customerBillAccount, customer, null, notificationContentIdentifier);
                }
            } else {
                if (billerType == BillerType.POSTPAID || billerType == BillerType.PREPAID) {
                    customerBillAccount.setDueDate(null);
                    customerBillAccount.setDueInfoUpdatedAt(new Date());
                    raiseDeleteBillPayReminderEvent(customerBillAccount, null);
                } else {
                    customerBillAccount.setDueDate(null);
                    customerBillAccount.setDueInfoUpdatedAt(null);
                    int nudgeCount = 1;
                    List<Integer> daysForBillPaymentNudgeList = billReminderConfiguration.getDaysOfMonthForBillPaymentNudge() != null ? Arrays.stream(billReminderConfiguration.getDaysOfMonthForBillPaymentNudge().split(",")).map(Integer::valueOf).sorted().collect(Collectors.toList()) : Collections.emptyList();
                    int reminderDaysCount = billReminderConfiguration.getReminderDaysCountForBillpayNudge();
                    LocalDate lastPaidLocalDate = WPSDateUtils.dateToLocalDate(customerBillAccount.getLastPaidDateValue());
                    LocalDate nudgeDate = billPayReminderHelper.getFirstDateOfNudge(lastPaidLocalDate, daysForBillPaymentNudgeList, customerBillAccount);
                    while (nudgeCount <= 3) {
                        if (LocalDate.now().isBefore(nudgeDate.plusDays(reminderDaysCount + 1)))
                            break;
                        nudgeDate = billPayReminderHelper.getNextDateOfNudge(nudgeDate, daysForBillPaymentNudgeList);
                        nudgeCount++;
                    }
                    Date skipNudgeTillDate = Date.from(nudgeDate.plusDays(reminderDaysCount).atTime(OffsetTime.now()).toInstant());
                    customerBillAccount.setSkipReminderTillDate(skipNudgeTillDate);
                    ReminderSubCategoryType reminderSubCategory;

                    if (nudgeCount == 1) {
                        reminderSubCategory = ReminderSubCategoryType.BILL_PAY_FIRST_NUDGE;
                    } else if (nudgeCount == 2) {
                        reminderSubCategory = ReminderSubCategoryType.BILL_PAY_SECOND_NUDGE;
                    } else {
                        reminderSubCategory = ReminderSubCategoryType.BILL_PAY_THIRD_NUDGE;
                    }
                    raiseDeleteBillPayReminderEvent(customerBillAccount, reminderSubCategory);
                }
            }
            customerBillAccount.setLastPaidDateAndResetLastPaidBillPayTxn(lastPaidDate);
            customerBillAccountMapper.updateCustomerBillAccountDOForAlreadyPaid(customerBillAccount, customerBillAccountDO);
            customerBillAccountRepository.save(customerBillAccountDO);
            log.info("Updation of customerBillAccount process success for customerBillAccountId:[{}] of customerAccountId:[{}]",
                    customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getCustomerAccountId());
            return AlreadyPaidResponseContext.builder()
                    .customerBillAccount(customerBillAccount)
                    .build();
        } catch (BusinessValidationException bve) {
            log.error("Failed to mark already paid for customerBillAccountId {}", alreadyPaidRequestContext.getCustomerBillAccountId());
            throw bve;
        } catch (Exception e) {
            log.error("Failed to mark already paid for customerBillAccountId {}", alreadyPaidRequestContext.getCustomerBillAccountId());
            String msg = String.format("Exception while marking Already paid for customerBillAccountId: [%s]", alreadyPaidRequestContext.getCustomerBillAccountId());
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, e);
        }
    }

    private CustomerBillAccount mapCustomerBillAccountFromDOInAlreadyPaidFlow(CustomerBillAccountDO customerBillAccountDO) {
        CustomerBillAccount customerBillAccount = customerBillAccountMapper.customerBillAccountDOToCustomerBillAccountWithBiller(customerBillAccountDO);
        Biller biller = customerBillAccount.getBiller();
        biller.setBillPlans(billerMapper.mapBillPlans(customerBillAccountDO.getBillerDO()));
        customerBillAccount.setBiller(biller);
        return customerBillAccount;
    }

    private BillerType getBillerType(boolean isCanCheckBalance, String customerBillId, Date expiryDate) {
        if (isCanCheckBalance && StringUtils.isNotEmpty(customerBillId)) {
            return BillerType.POSTPAID;
        }
        if (expiryDate != null) {
            return BillerType.PREPAID;
        }
        return BillerType.OTHER;
    }

    private boolean checkIsConsumptionBasedBiller(String billerDisplayName) {
        if (billerDisplayName == null)
            return false;
        return billerDisplayName.contains(WPSConstants.Biller.CINEPOLIS);
    }

    private Customer getCustomerByIdMapper(UUID customerAccountId) {
        CustomerBasicResponse customerResponse = customerServiceClientForEWS.getCustomerBasicDetailsById(customerAccountId);
        if (customerResponse == null) {
            throw new DataValidationException(ErrorConstants.PayBillInit.CUSTOMER_ACCOUNT_NOT_FOUND);
        }
        return customerMapper.mapCustomerFromBasicDTOToContext(customerResponse);
    }

    private BillDetail fetchBillDetail(List<BillPlan> billPlans, BigDecimal amount) {
        if (CollectionUtils.isEmpty(billPlans)) {
            return null;
        }
        for (BillPlan billPlan : billPlans) {
            Optional<BillDetail> billDetail = billPlan.getBillDetails().stream().filter(billDetail1 -> billDetail1.getAmount().compareTo(amount) == 0).findFirst();
            if (billDetail.isPresent()) {
                return billDetail.get();
            }
        }
        return null;
    }

    private void raiseDeleteBillPayReminderEvent(CustomerBillAccount customerBillAccount, ReminderSubCategoryType reminderSubCategory) {
        try {
            if (!Objects.isNull(reminderSubCategory)) {
                billPayReminderService.raiseDeleteBillPayReminderForSubcategoryEvent(customerBillAccount, reminderSubCategory);
            } else {
                billPayReminderService.raiseDeleteBillPayReminderEvent(customerBillAccount);
            }
        } catch (ReminderServiceException e) {
            log.error("Raise Bill Pay Delete Reminder event failed with Error: {}", e.getMessage(), e);
        }
    }

    private void raiseBillPayReminderForBillerType(BillerType billerType, CustomerBillAccount customerBillAccount, Customer customer,
                                                  BillDetail billDetail, NotificationContentIdentifier notificationContentIdentifier) {
        try {
            if (billerType == BillerType.PREPAID) {
                billPayReminderService.raiseS2BillerReminder(customerBillAccount, customer, billDetail);
            } else {
                billPayReminderService.raiseS3S4BillerNudges(customerBillAccount, customer, notificationContentIdentifier);
            }
        } catch (ReminderServiceException e) {
            log.error("Raise Bill Pay Reminder event failed with Error: {}", e.getMessage(), e);
        }
    }

    @Override
    public void updateCustomerBillAccountDueInfoAndRaiseReminders(UpdateCustomerBillDueInfoRequestContext requestContext) throws ApplicationException {
        try {
            validateRequestContextForUpdateDueInfo(requestContext);
            List<CustomerBillAccountDO> savedCustomerBillAccountDOList =
                    fetchSavedCustomerBillAccountDOListUsingProcessorBillAccountId(requestContext.getProcessorBillAccountId());
            if (CollectionUtils.isNotEmpty(savedCustomerBillAccountDOList)) {
                List<CustomerBillAccountDO> customerBillAccountDOsToUpdate = new ArrayList<>();
                boolean allRecordsFailedBusinessValidation = true;
                for (CustomerBillAccountDO customerBillAccountDO : savedCustomerBillAccountDOList) {
                    try {
                        customerBillAccountUpdateBusinessValidation(customerBillAccountDO, requestContext);
                    } catch (BusinessValidationException bve) {
                        log.error("BusinessValidationException occurred for customerBillAccount with customerBillAccountId:[{}], processorBillAccountId:[{}]",
                                customerBillAccountDO.getCustomerBillAccountId(), customerBillAccountDO.getProcessorBillAccountId(), bve);
                        continue;
                    }
                    if (allRecordsFailedBusinessValidation) {
                        allRecordsFailedBusinessValidation = false;
                    }
                    updateCustomerBillAccountDetails(customerBillAccountDO, requestContext);
                    customerBillAccountDOsToUpdate.add(customerBillAccountDO);
                    raiseReminderEventForCustomerBillAccount(customerBillAccountMapper.customerBillAccountDOToCustomerBillAccountWithBiller(customerBillAccountDO));
                }
                if (allRecordsFailedBusinessValidation) {
                    String msg = String.format("All customerBillAccounts with processorBillAccountId[%s] failed business validation", requestContext.getProcessorBillAccountId());
                    throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.ALL_CUSTOMER_BILL_ACCOUNTS_FAILED_BUSINESS_VALIDATION, msg);
                }
                if (CollectionUtils.isNotEmpty(customerBillAccountDOsToUpdate)) {
                    customerBillAccountRepository.saveAll(customerBillAccountDOsToUpdate);
                }
            } else {
                String msg = String.format("Saved customerBillAccounts not found for processorBillAccountId[%s]", requestContext.getProcessorBillAccountId());
                throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.SAVED_CUSTOMER_BILL_ACCOUNT_NOT_FOUND, msg);
            }
        } catch (BusinessValidationException bve) {
            throw bve;
        } catch (Exception ex) {
            String msg = String.format("Error occurred in updateCustomerBillAccountDueInfo API for processorBillAccountId:[%s]",
                    requestContext.getProcessorBillAccountId());
            throw new ProcessingException(ErrorConstants.UpdateCustomerBillAccountDueInfo.GENERIC_ERROR, msg, ex);
        }
    }

    private void validateRequestContextForUpdateDueInfo(UpdateCustomerBillDueInfoRequestContext requestContext) {
        if (StringUtils.isEmpty(requestContext.getProcessorBillAccountId())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.PROCESSOR_BILL_ACCOUNT_ID_NULL);
        }
        if (StringUtils.isEmpty(requestContext.getProcessorBillerId())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.PROCESSOR_BILLER_ID_NULL);
        }
        if (StringUtils.isEmpty(requestContext.getAccountNumber())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.ACCOUNT_NUMBER_NULL);
        }
        if (Objects.isNull(requestContext.getDueDate())) {
            throw new DataValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.DUE_DATE_NULL);
        }
        Date currentDate = new Date();
        if (DateTimeComparator.getDateOnlyInstance().compare(requestContext.getDueDate(), currentDate) < 0) {
            String msg = String.format("Due date to be updated [%s] is past the current date[%s]", requestContext.getDueDate(), currentDate);
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.WPS_INVALID_DUE_DATE_ERROR_PAST_DATE, msg);
        }
    }

    private List<CustomerBillAccountDO> fetchSavedCustomerBillAccountDOListUsingProcessorBillAccountId(String processorBillAccountId) {
        List<CustomerBillAccountDO> customerBillAccountDOList = customerBillAccountRepository.findByProcessorBillAccountId(processorBillAccountId);
        if (CollectionUtils.isNotEmpty(customerBillAccountDOList)) {
            return customerBillAccountDOList.stream()
                    .filter(customerBillAccountDO -> customerBillAccountDO.isSaved() && !customerBillAccountDO.isDeleted())
                    .collect(Collectors.toList());
        } else {
            String msg = String.format("CustomerBillAccounts not found for processorBillAccountId[%s]", processorBillAccountId);
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_NOT_FOUND, msg);
        }
    }

    private void customerBillAccountUpdateBusinessValidation(CustomerBillAccountDO customerBillAccountDO,
                                                             UpdateCustomerBillDueInfoRequestContext requestContext) throws BusinessValidationException {
        log.info("Business Validation started for CustomerBillAccount with processorBillAccountId:[{}] processorBillerId:[{}] accountNumber:[{}]",
                requestContext.getProcessorBillAccountId(), requestContext.getProcessorBillerId(), requestContext.getAccountNumber());
        validateProcessorBillerIdAndAccountNumberInRequestContext(customerBillAccountDO, requestContext);
        validateDueDateInRequestContext(customerBillAccountDO, requestContext);
    }

    private void validateProcessorBillerIdAndAccountNumberInRequestContext(CustomerBillAccountDO customerBillAccountDO, UpdateCustomerBillDueInfoRequestContext requestContext) {
        if (!customerBillAccountDO.getAccountNumber().equals(requestContext.getAccountNumber())) {
            String msg = String.format("Mismatch of accountNumber from DO:[%s] and accountNumber from request:[%s]", customerBillAccountDO.getAccountNumber(), requestContext.getAccountNumber());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_ACCOUNT_NUMBER_MISMATCH, msg);
        }
        if (!customerBillAccountDO.getProcessorBillerId().equals(requestContext.getProcessorBillerId())) {
            String msg = String.format("Mismatch of processorBillerId from DO:[%s] and processorBillerId from request:[%s]", customerBillAccountDO.getBillerDO().getProcessorBillerId(), requestContext.getProcessorBillerId());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_PROCESSOR_BILLER_ID_MISMATCH, msg);
        }
    }

    private void validateDueDateInRequestContext(CustomerBillAccountDO customerBillAccountDO, UpdateCustomerBillDueInfoRequestContext requestContext) {
        if (Objects.nonNull(customerBillAccountDO.getDueDate()) && DateUtils.isSameDay(customerBillAccountDO.getDueDate(), requestContext.getDueDate())) {
            String msg = String.format("Due date to be updated [%s] is same as existing due date[%s]", requestContext.getDueDate(), customerBillAccountDO.getDueDate());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccountDueInfo.WPS_INVALID_DUE_DATE_ERROR_DUPLICATE, msg);
        }
    }

    private void updateCustomerBillAccountDetails(CustomerBillAccountDO customerBillAccountDO, UpdateCustomerBillDueInfoRequestContext requestContext) {
        log.info("Mapping details from request context to DO for processorBillAccountId:[{}], processorBillerId:[{}], accountNumber:[{}]",
                requestContext.getProcessorBillAccountId(), requestContext.getProcessorBillerId(), requestContext.getAccountNumber());

        if (Objects.nonNull(requestContext.getDueDate())) {
            customerBillAccountDO.setDueDate(requestContext.getDueDate());
            customerBillAccountDO.setDueInfoUpdatedAt(new Date());
        }
        if (Objects.nonNull(requestContext.getDueAmount())) {
            customerBillAccountDO.setDueAmount(requestContext.getDueAmount());
            customerBillAccountDO.setDueAmountCurrencyUnit(CurrencyUnit.valueOf(requestContext.getDueAmountCurrencyUnit()));
        }
        if (StringUtils.isNotEmpty(requestContext.getDueInfoUpdatedBy())) {
            customerBillAccountDO.setDueInfoUpdatedBy(requestContext.getDueInfoUpdatedBy());
        }
        if (Objects.nonNull(requestContext.getProcessorBillAccountId()) && (Objects.isNull(requestContext.getDueAmount()) || requestContext.getDueAmount().equals(BigDecimal.ZERO))) {
            customerBillAccountDO.setDueDate(null);
        }
    }

    private void raiseReminderEventForCustomerBillAccount(CustomerBillAccount customerBillAccount) {
        if (Objects.nonNull(customerBillAccount.getDueAmount()) && customerBillAccount.getDueAmount().compareTo(BigDecimal.ZERO) > 0) {
            try {
                CustomerBasicResponse customerResponse = customerServiceClient.getCustomerBasicDetailsById(customerBillAccount.getCustomerAccountId());
                Customer customer = customerMapper.mapCustomerFromBasicDTOToContext(customerResponse);
                billPayReminderService.raiseS1BillerReminder(customerBillAccount, customer);
            } catch (Exception e) {
                log.error("Raising reminder event task failed for processorBillAccountId:[{}], processorBillerId:[{}], accountNumber[{}].",
                        customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getProcessorBillerId(),
                        customerBillAccount.getAccountNumber(), e);
            }
        }
    }

}
