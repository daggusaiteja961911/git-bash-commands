package com.walmart.international.wallet.payment.core.adapter.caas;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.campaign.config.CampaignServiceClientConfig;
import com.walmart.international.campaign.dto.response.CAASErrorResponse;
import com.walmart.international.services.digitalwallet.httpclient.util.HttpClientException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.util.DownstreamWebClientErrorHandler;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.DownstreamHTTPClientConfigs;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.impl.WebClientV2Impl;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import static com.walmart.international.digiwallet.service.strati.telemetry.service.constants.TelemetryConstants.EMPTY_TAG;

@Slf4j
@Configuration
public class CAASWebClientConfig {

    public static final String CAAS = "CAAS";

    ObjectMapper objectMapper = new ObjectMapper();

    @ManagedConfiguration
    CampaignServiceClientConfig caasConfiguration;

    @Bean("caasWebClient")
    WebClientV2 getCaasWebclient() {
        DownstreamWebClientErrorHandler errorHandler = DownstreamWebClientErrorHandler.builder()
                .clientResponse4xxErrorHandler(errorResponse -> errorResponse.bodyToMono(Object.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.rawStatusCode()));
                }))
                .clientResponse5xxErrorHandler(errorResponse -> errorResponse.bodyToMono(Object.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.rawStatusCode()));
                }))
                .isError((httpCode, apiName) -> httpCode < 200 || httpCode >= 300)
                .errorCodeExtractor((responseBody, apiName) -> getErrorCode(responseBody, apiName))
                .build();
        DownstreamHTTPClientConfigs caasHTTPClientConfigs = DownstreamHTTPClientConfigs.builder()
                .downstreamName(CAAS)
                .downstreamErrorHandler(errorHandler)
                .connectionTimeoutMillis(caasConfiguration.getWebClientConnectionTimeoutInMillis())
                .responseTimeoutMillis(caasConfiguration.getWebClientResponseTimeoutInMillis())
                .isSaveLogsToDBEnabled(caasConfiguration.isSaveLogsToDBEnabled())
                .build();
        return new WebClientV2Impl(caasHTTPClientConfigs);
    }

    private String getErrorCode(String responseBody, String apiName) {
        try {
            CAASErrorResponse response = objectMapper.readValue(responseBody, CAASErrorResponse.class);
            String errorCode = response.getError().getCode();
            return errorCode != null ? errorCode : EMPTY_TAG;
        } catch (Exception ex) {
            log.error("CaasWebClientConfig::getErrorCode : Error while parsing response for api: [{}] to fetch error-code", apiName, ex);
        }
        return EMPTY_TAG;

    }

}
