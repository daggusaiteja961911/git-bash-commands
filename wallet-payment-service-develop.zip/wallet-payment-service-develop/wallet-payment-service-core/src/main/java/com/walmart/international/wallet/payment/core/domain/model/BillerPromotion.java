package com.walmart.international.wallet.payment.core.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillerPromotion {
    UUID campaignId;
    String description;
    String promotionText;
    //TODO should be Date
    String startDate;
    String endDate;

    public static class BillerPromotionComparator implements Comparator<BillerPromotion> {
        private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        @Override
        public int compare(BillerPromotion o1, BillerPromotion o2) {
            LocalDateTime startDate1 = LocalDateTime.parse(o1.getStartDate(), formatter);
            LocalDateTime startDate2 = LocalDateTime.parse(o2.getStartDate(), formatter);
            return startDate1.compareTo(startDate2);
        }
    }
}
