package com.walmart.international.wallet.payment.core.adapter.billprocessor.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class GetBillersResponse {

    private List<BillerResponse> billers;
}
