package com.walmart.international.wallet.payment.core.domain.model.request;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
public class UpdateCustomerBillDueInfoRequestContext {
    private String processorBillAccountId;
    private String processorBillerId;
    private String accountNumber;
    private Date dueDate;
    private BigDecimal dueAmount;
    private String dueAmountCurrencyUnit;
    private String dueInfoUpdatedBy;
}