package com.walmart.international.wallet.payment.core.adapter.customer;

import com.walmart.international.digiwallet.customer.api.dto.request.paymentInstrument.UpdateCardLastUsedDateRequest;
import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.request.UpdatePaymentPreferenceRequest;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.response.CustomerBasicResponse;

import java.util.UUID;

public interface ICustomerServiceClient {

    CustomerResponse getCustomerDetailsById(UUID customerAccountId) throws ApplicationException;

    CustomerBasicResponse getCustomerBasicDetailsById(UUID customerAccountId) throws ApplicationException;

    WalletResponse getPaymentInstruments(UUID customerAccountId, Boolean includeWallet, Boolean includeB2BCards) throws ApplicationException;

    WalletResponse getPaymentInstruments(UUID customerAccountId, Boolean includeWallet, Boolean includeB2BCards, boolean fetchBalance) throws ApplicationException;

    //WalletResponse getPaymentInstrumentByIds(UUID customerAccountId, List<UUID> paymentInstrumentIds, boolean fetchBalance) throws ApplicationException;

    void updateCardLastUsedDate(UUID customerId, UpdateCardLastUsedDateRequest updateCardLastUsedDateRequest) throws ApplicationException;

    void updatePaymentPreference(UpdatePaymentPreferenceRequest request) throws ApplicationException;
}
