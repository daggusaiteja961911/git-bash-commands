package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.utils.WPSDateUtils;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
public class CustomerBillAccount {

    private UUID customerBillAccountId;

    private String processorBillAccountId;

    private UUID customerAccountId;

    private Biller biller;

    private BillPayTransaction lastPaidBillPayTransaction;

    // TODO: should move to inside biller
    private UUID billerId;

    // TODO: should move to inside biller
    private String processorBillerId;

    private String accountNumber;

    private String revisedAccountNumber;

    private BigDecimal dueAmount;

    private String dueAmountCurrencyUnit;

    private BigDecimal lastPaidAmount;

    private String lastPaidAmountCurrencyUnit;

    private Date dueInfoUpdatedAt;

    private String dueInfoUpdatedBy;

    private String status;

    private Date dueDate;

    private String nameOnAccount;

    private String alias;

    private Date lastPaidDate;

    private Date skipReminderTillDate;

    private String nudgeBucket;

    private Boolean isSaved;

    private Boolean isDeleted;

    private Date updateDate;

    private Boolean hasUserOptedToSave;

    private Boolean isAliasUpdateRequired;

    public CustomerBillAccount(Biller biller) {
        this.biller = biller;
    }

    public static class OverdueBillsComparator implements Comparator<CustomerBillAccount> {
        @Override
        public int compare(CustomerBillAccount b1, CustomerBillAccount b2) {

            Date dueDate1 = b1.getDueDate() == null ? null : b1.getDueDate();
            Date dueDate2 = b2.getDueDate() == null ? null : b2.getDueDate();
            if (dueDate1 == null && dueDate2 == null) {
                return 0;
            } else if (dueDate1 == null) {
                return 1;
            } else if (dueDate2 == null) {
                return -1;
            } else {
                int result = dueDate2.compareTo(dueDate1);
                if (result == 0) {
                    if ((b1.getProcessorBillAccountId() != null && b2.getProcessorBillAccountId() != null)
                            || (b1.getProcessorBillAccountId() == null && b2.getProcessorBillAccountId() == null)) {
                        return 0;
                    } else if (b2.getProcessorBillAccountId() != null) {
                        return 1;
                    } else {
                        return -1;
                    }
                }
                return result;
            }
        }
    }

    public static class DueBillsComparator implements Comparator<CustomerBillAccount> {
        @Override
        public int compare(CustomerBillAccount b1, CustomerBillAccount b2) {
            Date currentDate = new Date();
            Date dueDate1 = b1.getDueDate() == null ? null : b1.getDueDate();
            Date dueDate2 = b2.getDueDate() == null ? null : b2.getDueDate();
            if (dueDate1 == null && dueDate2 == null) {
                return 0;
            } else if (dueDate1 == null) {
                if (dueDate2.equals(currentDate))
                    return 1;
                return currentDate.compareTo(dueDate2);
            } else if (dueDate2 == null) {
                if (dueDate1.equals(currentDate))
                    return -1;
                return dueDate1.compareTo(currentDate);
            } else {
                int result = dueDate1.compareTo(dueDate2);
                if (result == 0) {
                    if ((b1.getProcessorBillAccountId() != null && b2.getProcessorBillAccountId() != null)
                            || (b1.getProcessorBillAccountId() == null && b2.getProcessorBillAccountId() == null)) {
                        return 0;
                    } else if (b2.getProcessorBillAccountId() != null) {
                        return 1;
                    } else {
                        return -1;
                    }
                }
                return result;
            }
        }
    }

    public static class PaidBillsComparator implements Comparator<CustomerBillAccount> {
        @Override
        public int compare(CustomerBillAccount b1, CustomerBillAccount b2) {
            Date dueDate1 = b1.getDueDate() == null ? null : b1.getDueDate();
            Date dueDate2 = b2.getDueDate() == null ? null : b2.getDueDate();
            Date lastPaidDate1 = b1.getLastPaidDateValue();
            Date lastPaidDate2 = b2.getLastPaidDateValue();
            if (dueDate1 == null && dueDate2 == null)
                return lastPaidDate2.compareTo(lastPaidDate1);
            if (dueDate1 == null)
                return 1;
            if (dueDate2 == null)
                return -1;
            return dueDate1.compareTo(dueDate2);
        }
    }

    public void setLastPaidBillPayTransactionAndResetLastPaidFields(BillPayTransaction billPayTransaction) {
        if (Objects.isNull(billPayTransaction)) {
            return;
        }
        lastPaidBillPayTransaction = billPayTransaction;
        lastPaidAmount = null;
        lastPaidDate = null;
        lastPaidAmountCurrencyUnit = null;
    }

    public Date getLastPaidDateValue() {
        if (Objects.nonNull(lastPaidBillPayTransaction) && Objects.nonNull(lastPaidBillPayTransaction.getTxnReqCompletedDate())) {
            return WPSDateUtils.localDateTimeToDate(lastPaidBillPayTransaction.getTxnReqCompletedDate());
        }
        return lastPaidDate;
    }

    public BigDecimal getLastPaidAmountValue() {
        if (Objects.nonNull(lastPaidBillPayTransaction) && Objects.nonNull(lastPaidBillPayTransaction.getAmountFulfilled())) {
            return lastPaidBillPayTransaction.getAmountFulfilled().getValue();
        }
        return lastPaidAmount;
    }

    public String getLastPaidAmountCurrencyUnitValue() {
        if (Objects.nonNull(lastPaidBillPayTransaction) && Objects.nonNull(lastPaidBillPayTransaction.getAmountFulfilled())) {
            return lastPaidBillPayTransaction.getAmountFulfilled().getCurrencyUnit().name();
        }
        return lastPaidAmountCurrencyUnit;
    }

    public void setLastPaidDateAndResetLastPaidBillPayTxn(Date lastPaidDate) {
        resetLastPaidBillPayTransactionAndSetLastPaidFields(lastPaidDate);
    }

    /*
    This method is useful to maintain the constraint on the lastPaidBillPayTransaction, lastPaidAmount, lastPaidAmountCurrencyUnit, and lastPaidDate.
     */
    private void resetLastPaidBillPayTransactionAndSetLastPaidFields(Date lastPaidDate) {
        if (Objects.nonNull(lastPaidBillPayTransaction)) {
            this.lastPaidDate = WPSDateUtils.localDateTimeToDate(Objects.nonNull(lastPaidBillPayTransaction.getTxnReqCompletedDate()) ? lastPaidBillPayTransaction.getTxnReqCompletedDate() :
                    (Objects.nonNull(lastPaidBillPayTransaction.getLastEventDate()) ? lastPaidBillPayTransaction.getLastEventDate() : lastPaidBillPayTransaction.getCreateDate()));
            lastPaidAmount = Objects.nonNull(lastPaidBillPayTransaction.getAmountFulfilled()) ? lastPaidBillPayTransaction.getAmountFulfilled().getValue() : null;
            lastPaidAmountCurrencyUnit = Objects.nonNull(lastPaidBillPayTransaction.getAmountFulfilled()) ? lastPaidBillPayTransaction.getAmountFulfilled().getCurrencyUnit().name() : null;
            lastPaidBillPayTransaction = null;
        }
        if (Objects.nonNull(lastPaidDate)) {
            this.lastPaidDate = lastPaidDate; // Override the date from bill pay transaction
        }
    }
}
