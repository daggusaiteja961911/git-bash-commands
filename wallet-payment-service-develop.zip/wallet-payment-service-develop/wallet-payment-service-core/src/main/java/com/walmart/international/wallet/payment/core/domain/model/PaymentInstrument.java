package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentStatus;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentStatusReason;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Date;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentInstrument {
     private String paymentInstrumentId;
     private PaymentInstrumentType paymentInstrumentType;
     private PaymentInstrumentSubType paymentInstrumentSubType;

     private PaymentInstrumentStatus status;
     private PaymentInstrumentStatusReason statusReason;

     private Date createDate;
     private Boolean isPreSelected;
     private BigDecimal preSelectedAmount;
     private String tag;
}