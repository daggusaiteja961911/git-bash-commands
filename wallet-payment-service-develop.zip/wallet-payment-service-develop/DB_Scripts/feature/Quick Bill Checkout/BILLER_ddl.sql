--- Author: p0s03aq

-- Adding BBC column in BILLER table
ALTER TABLE BILLER
ADD BILLER_BEHAVIOUR_CODE varchar(255);