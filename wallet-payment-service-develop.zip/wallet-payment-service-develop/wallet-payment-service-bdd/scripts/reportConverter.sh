#!/bin/sh

cd "$(dirname "$0")"

echo "Report Converter"

chmod 777 ./reportConverter.sh

BDDModule=$1

BDDBuildDir=../target

ReportDir=$BDDBuildDir/jacoco-report

mkdir -p $ReportDir

Report=$BDDBuildDir/jacoco-it.exec

ProjectBuildDir=../../wallet-payment-service-api/target/com/walmart/international/wallet/payment/service
ProjectBuildDirCore=../../wallet-payment-service-core/target/com/walmart/international/wallet/payment/service



if [ -e "$Report" ]
then
  java -jar $BDDBuildDir/jacoco-agent/org.jacoco.cli-nodeps.jar report $BDDBuildDir/jacoco-it.exec --classfiles  $ProjectBuildDir --xml $ReportDir/report.xml

  java -jar $BDDBuildDir/jacoco-agent/org.jacoco.cli-nodeps.jar report $BDDBuildDir/jacoco-it.exec --classfiles  $ProjectBuildDirCore --xml $ReportDir/report.xml

  java -jar $BDDBuildDir/jacoco-agent/org.jacoco.cli-nodeps.jar report $BDDBuildDir/jacoco-it.exec\
  --classfiles  $ProjectBuildDir/controller\
  --classfiles  $ProjectBuildDir/service\
  --classfiles  $ProjectBuildDir/mapper\
  --classfiles  $ProjectBuildDir/router\
  --html $ReportDir

  java -jar $BDDBuildDir/jacoco-agent/org.jacoco.cli-nodeps.jar report $BDDBuildDir/jacoco-it.exec\
    --classfiles  $ProjectBuildDirCore/utils/event\
    --classfiles  $ProjectBuildDirCore/external\
    --classfiles  $ProjectBuildDirCore/post\
    --classfiles  $ProjectBuildDirCore/processor\
    --classfiles  $ProjectBuildDirCore/validator\
    --classfiles  $ProjectBuildDirCore/mapper\
    --classfiles  $ProjectBuildDirCore/service\
    --classfiles  $ProjectBuildDirCore/http\
    --html $ReportDir

  echo $(ls $ReportDir)
fi