package com.walmart.international.wallet.payment.utils;

import com.walmart.international.wallet.payment.environment.Environment;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {
    public String BASE_URL = Environment.getApiBaseUrl() + "/wallet-service";
    public String GET_BILLS = "/services/v1/bills";
    public static final String POPULAR_BILLER_API = "/services/bill-payment/biller/popular";

    public String CANCEL_BILL_PAY = "/services/v1/bill-payment/abort";

    public String GET_BILL_BY_ID = "/services/bill-payment/biller/{billerId}";

    public String CREATE_BILL = "/services/bill-payment/bill";

}
