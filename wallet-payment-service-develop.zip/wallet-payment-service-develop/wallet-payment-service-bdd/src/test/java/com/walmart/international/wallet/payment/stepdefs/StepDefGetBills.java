package com.walmart.international.wallet.payment.stepdefs;

import com.walmart.international.wallet.payment.utils.CommonUtils;
import com.walmart.international.wallet.payment.utils.Constants;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;

import java.io.IOException;
import java.util.Map;

@Slf4j
public class StepDefGetBills {
    private Context ctx;

    public StepDefGetBills(Context ctx){
        this.ctx = ctx;
    }

    @Given("Prepare GetBills Request")
    public void prepareGetBillsRequestFrom() throws IOException {
        CommonUtils.initializeApi(ctx);
    }

    @And("Update Request Parameter for GetBills")
    public void updateRequestParameterForGetBills(Map<String, String> params) {
        ctx.request.queryParams(params);
    }

    @When("User Submit Request to GetBills API")
    public void userSubmitRequestToGetBillsAPI() {
        ctx.response = ctx.request.get(Constants.GET_BILLS);
        log.info("Response is : [{}]", ctx.response.asPrettyString());
    }

    @Then("Verify GetBills API has return response {int}")
    public void verifyGetBillsAPIHasReturnResponse(int statusCode) {
        Assert.assertEquals(statusCode, ctx.getResponse().statusCode());
    }

    @And("Status in GetBills Response should be {string}")
    public void statusInGetBillsResponseShouldBe(String failure) {
        Assert.assertEquals(failure, ctx.response.getStatusCode());
    }

    @And("Status Code in GetBills Response Should be {string}")
    public void statusCodeInGetBillsResponseShouldBe(String errorCode) {
        org.junit.Assert.assertTrue(ctx.getResponse().path("statusCode").toString().contains(errorCode));
    }
}
