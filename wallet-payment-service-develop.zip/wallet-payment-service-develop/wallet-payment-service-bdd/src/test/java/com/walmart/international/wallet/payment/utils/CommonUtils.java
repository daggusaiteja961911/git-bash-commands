package com.walmart.international.wallet.payment.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.wallet.payment.stepdefs.Context;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CommonUtils {
    public static <T> T createRequestFromFileAndInitializeApi(ObjectMapper objectMapper, Class<T> classType, T requestFromFile, String filename) throws IOException {
        if (requestFromFile == null) {
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            requestFromFile =  objectMapper.readValue(ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "requests/" + filename),
                    classType);
        }
        return requestFromFile;
    }

    public static void initializeApi(Context ctx) {
        RestAssured.baseURI = Constants.BASE_URL;
        ctx.request = RestAssured.given();
        ctx.request.header("Content-Type", "application/json");
    }

    public static Headers createHeaders(Map<String, String> headersMap) {
        List<Header> headerList = new ArrayList<>();
        for (Map.Entry<String, String> entry : headersMap.entrySet()) {
            Header header = new Header(entry.getKey(), entry.getValue());
            headerList.add(header);
        }

        return new Headers(headerList);
    }

}
