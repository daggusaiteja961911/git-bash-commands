package com.walmart.international.wallet.payment.client;

import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

public interface WalletPaymentServiceClient {

    ResponseEntity<CoFTopupResponse> coFTopUp(CoFTopupRequest topupRequest, HttpHeaders headers);

    ValidateCoFTopupResponse validateCoFTopup(ValidateCoFTopupRequest validateCoFTopupRequest, HttpHeaders headers);
}
