package com.walmart.international.wallet.payment.app.service.migration.impl.mapper;

import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.dto.response.migration.AlreadyPaidResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface MigrationBillDTOMapper {

    MigrationBillDTOMapper INSTANCE = Mappers.getMapper(MigrationBillDTOMapper.class);

    @Mapping(target = "id", source = "customerBillAccountId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(ignore = true, target = "lastPaidDate")
    SavedBillerAccountResponseDTO mapCustomerBillAccountToSavedBillerAccountResponseDTO(CustomerBillAccount customerBillAccount);

    List<SavedBillerAccountDTO> mapCustomerBillAccountsToSavedBillerAccountDTOs(List<CustomerBillAccount> customerBillAccounts);

    @Mapping(target = "id", source = "customerBillAccountId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "accountAlias", source = "alias")
    @Mapping(target = "productName", source = "biller.productDisplayName")
    SavedBillerAccountDTO mapToSavedBillerAccountDTOFromCustomerBillAccount(CustomerBillAccount customerBillAccount);

    @Mapping(target = "id", source = "customerBillAccountId")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "dueDateUpdatedAt", source = "dueInfoUpdatedAt")
    @Mapping(target = "billerAccountUpdatedAt", source = "updateDate")
    AlreadyPaidResponseEWS mapAlreadyPaidResponseFromDomainResponseToDTO(CustomerBillAccount customerBillAccount);
}
