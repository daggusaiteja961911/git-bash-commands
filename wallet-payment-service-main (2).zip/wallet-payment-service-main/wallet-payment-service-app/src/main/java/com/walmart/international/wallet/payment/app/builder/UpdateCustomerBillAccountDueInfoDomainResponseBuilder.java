package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.digiwallet.service.web.rest.i8n.local.SimpleMessageResolver;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountDueInfoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@Slf4j
public class UpdateCustomerBillAccountDueInfoDomainResponseBuilder extends BaseDomainResponseBuilder<UpdateCustomerBillAccountDueInfoResponse, BillRequestDomainContext, BillResponseDomainContext> {

    @Autowired
    SimpleMessageResolver msgResolver;

    @Override
    public BillResponseDomainContext buildDomainResponse(BillRequestDomainContext billRequestDomainContext) {

        return BillResponseDomainContext.builder().build();
    }

    @Override
    public UpdateCustomerBillAccountDueInfoResponse buildDomainResponse(BillRequestDomainContext billRequestDomainContext, BillResponseDomainContext billResponseDomainContext) {
        return UpdateCustomerBillAccountDueInfoResponse.builder()
                .status("SUCCESS")
                .message(WPSConstants.Bills.CUSTOMER_BILL_ACCOUNT_UPDATE_SUCCESSFUL).build();
    }

    @Override
    public UpdateCustomerBillAccountDueInfoResponse buildDomainResponse(BillRequestDomainContext billRequestDomainContext, BillResponseDomainContext billResponseDomainContext, ApplicationException e) {
        if (e instanceof BusinessValidationException) {
            if (Objects.equals(e.getErrorCode(), com.walmart.international.wallet.payment.core.constants.ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_NOT_FOUND)) {
                return UpdateCustomerBillAccountDueInfoResponse.builder()
                        .status("Failed")
                        .message(msgResolver.getMsg(ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_NOT_FOUND))
                        .build();
            }
        }
        throw e;
    }
}