package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import org.springframework.stereotype.Component;

@Component
public class FetchCoFTopupPaymentInstrumentsWithPreselectionFlowFactory extends FlowFactory<CoFTopupTxnRequestDomainContext> {

    @Override
    public FlowType deriveFlow(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext, Tenant tenant) throws ProcessingException {
        switch (tenant) {
            case MX:
                return MXFlowType.FETCH_COFTOPUP_PAYMENT_INSTRUMENTS_WITH_PRESELECTION;
            case CA:
            case UNKNOWN:
            default:
                String msg = String.format("Invalid tenantId [%s] for FetchCoFTopupPaymentInstruments flow", tenant);
                throw new ProcessingException(ErrorConstants.FetchCoFTopupPaymentInstruments.FLOW_FACTORY_INVALID_TENANT_ID, msg);
        }
    }
}