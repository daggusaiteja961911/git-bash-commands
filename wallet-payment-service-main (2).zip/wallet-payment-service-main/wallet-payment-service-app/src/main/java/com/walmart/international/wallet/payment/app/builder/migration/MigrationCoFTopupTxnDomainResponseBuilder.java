package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationCoFTopupMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MigrationCoFTopupTxnDomainResponseBuilder extends BaseDomainResponseBuilder<UnifiedPaymentResponse, CoFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext> {

    private MigrationCoFTopupMapper migrationCoFTopupMapper = MigrationCoFTopupMapper.INSTANCE;

    @Override
    public CoFTopupTxnResponseDomainContext buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) throws ApplicationException {
        return CoFTopupTxnResponseDomainContext.builder().build();
    }

    @Override
    public UnifiedPaymentResponse buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) throws ApplicationException {
        return migrationCoFTopupMapper.mapToMigrationLoadMoneyResponseFromContext(coFTopupTxnResponseDomainContext);
    }
}
