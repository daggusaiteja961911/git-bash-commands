package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.migration.mapper.MigrationBillPayMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.FetchBillPayPaymentInstrumentsResponseEWS;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MigrationFetchBillPayPaymentInstrumentsDomainResponseBuilder extends BaseDomainResponseBuilder<FetchBillPayPaymentInstrumentsResponseEWS, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    MigrationBillPayMapper billPayMapper = MigrationBillPayMapper.INSTANCE;

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public FetchBillPayPaymentInstrumentsResponseEWS buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        return FetchBillPayPaymentInstrumentsResponseEWS.builder()
                .transaction(billPayMapper.mapTransactionToTransactionDTO(billPayTxnResponseDomainContext.getTransaction()))
                .cardPaymentOptions(billPayMapper.mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getCardPaymentInstruments().getCardPaymentInstrumentList()))
                .giftCardPaymentOptions(billPayMapper.mapGiftCardPaymentInstrumentListToGiftCardPaymentInstrumentDTOList(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getGiftCardPaymentInstruments().getGiftCardPaymentInstrumentList()))
                .isMSIAllowedForSplit(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getIsMSIAllowedForSplitPayment())
                .allowCoFBillPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowCoFForBillPayment())
                .allowB2BSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowB2BForSplitPayment())
                .allowMultipleB2BSplitPayment(billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowMultipleB2BForSplitPayment()).build();
    }
}