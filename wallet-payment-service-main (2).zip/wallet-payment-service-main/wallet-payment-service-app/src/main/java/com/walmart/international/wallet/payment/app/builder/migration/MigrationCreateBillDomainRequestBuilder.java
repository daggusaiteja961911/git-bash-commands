package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.dto.request.migration.CreateBillRequestEWS;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class MigrationCreateBillDomainRequestBuilder extends BaseDomainRequestBuilder<CreateBillRequestEWS, BillRequestDomainContext> {
    @Override
    public BillRequestDomainContext buildDomainRequest(CreateBillRequestEWS createBillRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        CustomerBillAccount customerBillAccount = CustomerBillAccount.builder()
                .accountNumber(createBillRequestEWS.getAccountNumber())
                .customerAccountId(createBillRequestEWS.getCustomerAccountId())
                .processorBillerId(createBillRequestEWS.getBillerId().toString())
                .build();
        return BillRequestDomainContext.builder()
                .customerBillAccount(customerBillAccount)
                .build();
    }
}
