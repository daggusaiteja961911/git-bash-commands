package com.walmart.international.wallet.payment.app.controller.billpay.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.migration.AlreadyPaidRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.CreateBillRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.DueAndSavedBillerRequest;
import com.walmart.international.wallet.payment.dto.request.migration.GetSavedBillerAccountsRequest;
import com.walmart.international.wallet.payment.dto.response.migration.AlreadyPaidResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.dto.response.migration.DueAndSavedBillsDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import io.strati.security.jaxrs.ws.rs.core.MediaType;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.UUID;

@RequestMapping("/ews-internal")
@Tag(name = "MigrationBillController API", description = "Migration APIs to perform Bill related activities.")
public interface MigrationBillController {

    @PostMapping(value = "/V2/account/{customerAccountId}/createBill", consumes = "application/json", produces = "application/json")
    CreateBillV2DTO createBill(@PathVariable UUID customerAccountId,
                               @RequestBody CreateBillRequestEWS createBillRequestEWS,
                               @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @DeleteMapping(value = "/account/{customerAccountId}/saved-bills/{savedBillerAccountId}", produces = "application/json")
    SavedBillerAccountResponseDTO deleteSavedBillerAccount(@PathVariable("customerAccountId") UUID customerAccountId,
                                                           @PathVariable("savedBillerAccountId") UUID savedBillerAccountId) throws ApplicationException;

    @PostMapping(value = "/account/{customerAccountId}/saved-biller-accounts")
    SavedBillerAccountsResponse getAllSavedBillerAccountsForBiller(@PathVariable UUID customerAccountId,
                                                                   @RequestBody GetSavedBillerAccountsRequest getSavedBillerAccountsRequest) throws ApplicationException;

    @PutMapping(value = "/account/{customerAccountId}/saved-bills/{savedBillerAccountId}", consumes = "application/json", produces = "application/json")
    SavedBillerAccountResponseDTO updateSavedBillerAccount(@PathVariable("customerAccountId") UUID customerAccountId,
                                                           @PathVariable("savedBillerAccountId") UUID savedBillerAccountId,
                                                           @RequestBody UpdateSavedBillerAccountRequest updateSavedBillerAccountRequest,
                                                           @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/V4/account/{customerAccountId}/bills", consumes = "application/json", produces = "application/json")
    DueAndSavedBillsDTO getBills(@RequestBody(required = false) @Valid DueAndSavedBillerRequest request,
                                 @PathVariable UUID customerAccountId,
                                 @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    /*Mark saved bill as already paid for customers who has paid outside of Cashi application*/
    @PostMapping(value = "/account/{customerAccountId}/saved-bills/{savedBillerAccountId}/alreadyPaid", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
    AlreadyPaidResponseEWS markAlreadyPaid(@RequestBody AlreadyPaidRequestEWS alreadyPaidRequest, @PathVariable("customerAccountId") UUID customerAccountId,
                                           @PathVariable("savedBillerAccountId") UUID savedBillerAccountId, @RequestHeader MultiValueMap<String, String> headers ) throws ApplicationException;

}
