package com.walmart.international.wallet.payment.app.service.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.migration.AlreadyPaidRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.CreateBillRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.DueAndSavedBillerRequest;
import com.walmart.international.wallet.payment.dto.request.migration.GetSavedBillerAccountsRequest;
import com.walmart.international.wallet.payment.dto.response.migration.AlreadyPaidResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.dto.response.migration.DueAndSavedBillsDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import org.springframework.util.MultiValueMap;

import java.util.UUID;

public interface MigrationBillService {

    CreateBillV2DTO createBill(UUID customerAccountId, CreateBillRequestEWS createBillRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException;

    SavedBillerAccountResponseDTO deleteSavedBillerAccount(UUID customerAccountId, UUID savedBillerAccountId) throws ApplicationException;

    SavedBillerAccountsResponse getAllSavedBillerAccountsForBiller(UUID customerAccountId, GetSavedBillerAccountsRequest getSavedBillerAccountsRequest) throws ApplicationException;

    SavedBillerAccountResponseDTO updateSavedBillerAccount(UUID customerAccountId, UUID savedBillerAccountId, UpdateSavedBillerAccountRequest updateSavedBillerAccountRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    DueAndSavedBillsDTO getBills(DueAndSavedBillerRequest request, UUID customerAccountId, MultiValueMap<String, String> headers);

    AlreadyPaidResponseEWS markAlreadyPaid(AlreadyPaidRequestEWS alreadyPaidRequest, UUID customerAccountId, UUID customerBillAccountId, MultiValueMap<String, String> headers) throws ApplicationException;
}
