package com.walmart.international.wallet.payment.app.builder.mapper;

import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountDueInfoRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

/**
 *  Mapping from ResponseContext to API response - to be used in Builder classes
 */
@Mapper
public interface BillMapper {

    BillMapper INSTANCE = Mappers.getMapper(BillMapper.class);

    @Mapping(target = "dueAmountCurrency", source = "dueAmountCurrencyUnit")
    @Mapping(target = "billPaidDate", source = "lastPaidDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Mapping(target = "dueInfoUpdatedAt", dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    CreateBillResponse customerBillAccountToCreateBillResponse(CustomerBillAccount customerBillAccount);

    CustomerBillAccount updateCustomerBillAccountRequestToCustomerBillAccount(UpdateCustomerBillAccountRequest updateCustomerBillAccountRequest);

    @Mapping(target = "dueDate", source = "dueDate", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    CustomerBillAccount updateCustomerBillAccountDueInfoRequestToCustomerBillAccount(UpdateCustomerBillAccountDueInfoRequest updateCustomerBillAccountDueInfoRequest);

    @Mapping(target = "customerBillAccountUpdatedAt", source = "updateDate")
    UpdateCustomerBillAccountResponse customerBillAccountToUpdateCustomerBillAccountResponse(CustomerBillAccount customerBillAccount);

}
