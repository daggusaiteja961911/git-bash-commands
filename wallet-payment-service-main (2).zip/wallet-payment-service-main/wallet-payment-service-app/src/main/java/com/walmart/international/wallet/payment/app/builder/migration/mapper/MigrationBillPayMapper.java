package com.walmart.international.wallet.payment.app.builder.migration.mapper;

import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.CardBinDTO;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.PaymentPreferenceDTO;
import com.walmart.international.wallet.payment.dto.response.migration.TransactionDTO;
import com.walmart.international.wallet.payment.dto.response.migration.enums.Brand;
import com.walmart.international.wallet.payment.dto.response.migration.enums.PaymentType;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Mapper
@Component
public interface MigrationBillPayMapper {
    MigrationBillPayMapper INSTANCE = Mappers.getMapper(MigrationBillPayMapper.class);

    @Mapping(target = "cashiTransactionId", source = "transaction.transactionId")
    @Mapping(target = "pollingInterval", source = "transaction.pollingInterval")
    PayInitResponseEWS mapToPayInitResponseEWS(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext);

    @Mapping(target = "currencyUnit", source = "amountRequested.currencyUnit")
    @Mapping(target = "accountNumber", source = "billAccountNumber")
    @Mapping(target = "billerId", source = "processorBillerId")
    @Mapping(target = "amount", source = "amountRequested.value")
    TransactionDTO mapTransactionToTransactionDTO(BillPayTransaction transaction);

    List<PaymentPreferenceDTO> mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(List<CardPaymentInstrument> cardPaymentInstrumentList);

    @Mapping(target = "paymentId", source = "paymentInstrumentId")
    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "cardholderName", source = "metadata.cardholderName")
    @Mapping(target = "aliasName", source = "metadata.aliasName")
    @Mapping(target = "cardNumber", source = "metadata.cardNumber")
    @Mapping(target = "last4Digits", source = "metadata.last4Digits")
    @Mapping(target = "tokenId", source = "adapterMetadata.tokenId")
    @Mapping(target = "cvvVerified", source = "metadata.cvvVerified")
    @Mapping(target = "cvvRequired", source = "metadata.cvvRequired")
    @Mapping(target = "billingAddress.exteriorNum", source = "billingAddress.streetExtNum")
    @Mapping(target = "billingAddress.interiorNum", source = "billingAddress.streetIntNum")
    @Mapping(target = "billingAddress.countryCode", source = "billingAddress.country")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "brand", source = "metadata.brand", qualifiedByName = "getBrandFromMetadataBrand")
    @Mapping(target = "paymentType", source = "cardPaymentInstrument", qualifiedByName = "mapCardPaymentType")
    @Mapping(target = "binDetails", source = "binDetails", qualifiedByName = "mapBinDetails")
    @Mapping(target = "tag", source = "tag", qualifiedByName = "mapToTag")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    PaymentPreferenceDTO mapCardPaymentInstrumentToPaymentPreferenceDTO(CardPaymentInstrument cardPaymentInstrument);

    @Named("mapToTag")
    default String mapToTag(String tag) {
        if (PaymentInstrumentType.CARD.name().equals(tag)) {
            return "COF";
        }
        return tag;
    }

    @Named("mapBinDetails")
    default CardBinDTO binDetailsToCardBinDTO(CardPaymentInstrument.BinDetails binDetails) {
        if ( binDetails == null ) {
            return null;
        }

        CardBinDTO cardBinDTO = new CardBinDTO();

        if ( binDetails.getBin() != null ) {
            cardBinDTO.setBin( Integer.parseInt( binDetails.getBin() ) );
        }
        if (StringUtils.isNotEmpty(binDetails.getBankName())) {
            cardBinDTO.setBankName(binDetails.getBankName());
        }
        if (StringUtils.isNotEmpty(binDetails.getBankLogo())) {
            cardBinDTO.setBankLogo(binDetails.getBankLogo());
        }
        cardBinDTO.setBrandName( binDetails.getBrandName() );
        cardBinDTO.setBrandLogo( binDetails.getBrandLogo() );
        cardBinDTO.setBankColor( binDetails.getBankColor() );
        cardBinDTO.setTextColor( binDetails.getTextColor() );

        return cardBinDTO;
    }

    List<PaymentPreferenceDTO> mapGiftCardPaymentInstrumentListToGiftCardPaymentInstrumentDTOList(List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList);

    @Mapping(target = "paymentId", source = "paymentInstrumentId")
    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "paymentType", source = "giftCardPaymentInstrument", qualifiedByName = "mapGiftCardPaymentType")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    PaymentPreferenceDTO mapGiftCardPaymentInstrumentToPaymentPreferenceDTO(GiftCardPaymentInstrument giftCardPaymentInstrument);

    @Named("getBrandFromMetadataBrand")
    default Brand getBrandFromMetadataBrand(String brand) {
        return Brand.resolve(brand, false);
    }

    @Named("mapGiftCardPaymentType")
    default PaymentType mapGiftCardPaymentType(GiftCardPaymentInstrument giftCardPaymentInstrument) {

        if (Objects.nonNull(giftCardPaymentInstrument.getPaymentInstrumentType()) && Objects.nonNull(giftCardPaymentInstrument.getPaymentInstrumentSubType())) {
            PaymentType paymentType = null;
            switch (giftCardPaymentInstrument.getPaymentInstrumentSubType()) {
                case CASHI_WALLET:
                    paymentType = PaymentType.GIFTCARD;
                    break;
                case CORP_CARD:
                case ASSOCIATE_FOOD_VOUCHER:
                    paymentType = PaymentType.CORPGIFTCARD;
                    break;
            }
            return paymentType;
        }
        if (Objects.nonNull(giftCardPaymentInstrument.getPaymentInstrumentType())) {
            PaymentType.resolve(giftCardPaymentInstrument.getPaymentInstrumentType().toString());
        }

        return null;
    }

    @Named("mapCardPaymentType")
    default PaymentType mapCardPaymentType(CardPaymentInstrument cardPaymentInstrument) {

        if (Objects.nonNull(cardPaymentInstrument.getPaymentInstrumentType()) && Objects.nonNull(cardPaymentInstrument.getPaymentInstrumentSubType())) {
            PaymentType paymentType = null;
            switch (cardPaymentInstrument.getPaymentInstrumentSubType()) {
                case DEBIT_CARD:
                    paymentType = PaymentType.DEBIT;
                    break;
                case CREDIT_CARD:
                    paymentType = PaymentType.CREDIT;
                    break;
            }
            return paymentType;
        }
        if (Objects.nonNull(cardPaymentInstrument.getPaymentInstrumentType())) {
            PaymentType.resolve(cardPaymentInstrument.getPaymentInstrumentType().toString());
        }

        return null;
    }

    @Mapping(target = "cashiTransactionId", source = "transaction.transactionId")
    @Mapping(target = "pollingInterval", source = "transaction.pollingInterval")
    PayInitResponseEWS mapToMigrationPayInitResponseEWSFromContext(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext);

    default String map(UUID value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return value.toString();
    }

    default UUID map(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        return UUID.fromString(value);
    }
}
