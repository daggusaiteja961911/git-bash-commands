package com.walmart.international.wallet.payment.app.builder.mapper;

import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardSubTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.dto.response.common.GiftCardPaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.common.CardPaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.common.CardTxnDTO;
import com.walmart.international.wallet.payment.dto.response.common.GiftCardTxnDTO;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupTransactionDTO;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import org.codehaus.plexus.util.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Mapper
public interface CoFTopupMapper {

    CoFTopupMapper INSTANCE = Mappers.getMapper(CoFTopupMapper.class);

    @Named("mapUUIDtoString")
    default String mapUUIDtoString(UUID uuid) {
        return String.valueOf(uuid);
    }

    List<CardPaymentInstrumentDTO> mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(List<CardPaymentInstrument> cardPaymentInstrumentList);

    @Mapping(target = "cardholderName", source = "metadata.cardholderName")
    @Mapping(target = "aliasName", source = "metadata.aliasName")
    @Mapping(target = "cardNumber", source = "metadata.cardNumber")
    @Mapping(target = "last4Digits", source = "metadata.last4Digits")
    @Mapping(target = "brand", source = "metadata.brand")
    @Mapping(target = "tokenId", source = "adapterMetadata.tokenId")
    @Mapping(target = "cvvVerified", source = "metadata.cvvVerified")
    @Mapping(target = "cvvRequired", source = "metadata.cvvRequired")
    @Mapping(target = "billingAddress.countryCode", source = "billingAddress.country")
    @Mapping(target = "binDetails", source = "binDetails", qualifiedByName = "mapBinDetails")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    CardPaymentInstrumentDTO mapCardPaymentInstrumentToPaymentInstrumentDTO(CardPaymentInstrument cardPaymentInstrument);

    @Named("mapBinDetails")
    default CardPaymentInstrumentDTO.BinDetails binDetailsToBinDetails(CardPaymentInstrument.BinDetails binDetails) {
        if ( binDetails == null ) {
            return null;
        }

        CardPaymentInstrumentDTO.BinDetails binDetails1 = new CardPaymentInstrumentDTO.BinDetails();

        if (Objects.nonNull(binDetails.getBin())) {
            binDetails1.setBin(binDetails.getBin());
        }

        if (StringUtils.isNotEmpty(binDetails.getBankName())) {
            binDetails1.setBankName(binDetails.getBankName());
        }
        if (StringUtils.isNotEmpty(binDetails.getBankLogo())) {
            binDetails1.setBankLogo(binDetails.getBankLogo());
        }
        binDetails1.setBrandName( binDetails.getBrandName() );
        binDetails1.setBrandLogo( binDetails.getBrandLogo() );
        binDetails1.setBankColor( binDetails.getBankColor() );
        binDetails1.setTextColor( binDetails.getTextColor() );

        return binDetails1;
    }

    @Mapping(target = "transaction", source = ".", qualifiedByName = "mapCoFTopupTransaction")
    @Mapping(target = "cardPaymentDetails", source = "transaction", qualifiedByName = "mapCardPaymentDetails")
    @Mapping(target = "errorCode", source = "transaction.failureCode")
    @Mapping(target = "displayMessage", source = "coFTopupTransactionDO.state", qualifiedByName = "mapDisplayMessage")
    CoFTopupResponse mapToCoFTopupResponseFromContext(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    @Mapping(target = "transaction", source = ".", qualifiedByName = "mapCoFTopupTransaction")
    @Mapping(target = "cardPaymentDetails", source = "transaction", qualifiedByName = "mapCardPaymentDetails")
    @Mapping(target = "errorCode", source = "transaction.failureCode")
    @Mapping(target = "displayMessage", source = "coFTopupTransactionDO.state", qualifiedByName = "mapDisplayMessage")
    ValidateCoFTopupResponse mapToValidateCoFTopupResponseFromContext(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    @Named("mapCoFTopupTransaction")
    @Mapping(target = "coFTopupTxnId", source = "coFTopupTransactionDO.coFTopupTransactionId", qualifiedByName = "mapUUIDtoString")
    @Mapping(target = "cashiOrderId", source = "coFTopupTransactionDO.cashiOrderId")
    @Mapping(target = "amount", source = "coFTopupTransactionDO" , qualifiedByName = "mapAmount")
    @Mapping(target = "currencyUnit", source = "coFTopupTransactionDO.currencyUnit")
    @Mapping(target = "transactionState", source = "coFTopupTransactionDO.state")
    @Mapping(target = "beginningBalance", source = "transaction", qualifiedByName = "mapBeginningBalanceFromTopupTransaction")
    @Mapping(target = "endingBalance", source = "transaction", qualifiedByName = "mapEndingBalanceFromTopupTransaction")
    @Mapping(target = "giftCardLoadDetails", source = "transaction", qualifiedByName = "mapGiftCardLoadDetails")
    CoFTopupTransactionDTO mapCoFTopupTransaction(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    @Named("mapAmount")
    default BigDecimal mapAmount(CoFTopupTransactionDO coFTopupTransactionDO) {
        if ( coFTopupTransactionDO == null ) {
            return null;
        }
        BigDecimal amountProcessed = coFTopupTransactionDO.getAmountProcessed();
        if ( amountProcessed == null ) {
            return coFTopupTransactionDO.getAmountRequested();
        }
        return amountProcessed;
    }

    @Named("mapBeginningBalanceFromTopupTransaction")
    default BigDecimal mapBeginningBalanceFromTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        return coFTopUpTransaction.getGiftCardLoadTransactionList().get(0).getGiftCardPaymentInstrument().getBalance().getCurrencyAmount();
    }

    @Named("mapEndingBalanceFromTopupTransaction")
    default BigDecimal mapEndingBalanceFromTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        BigDecimal beginningBalance = coFTopUpTransaction.getGiftCardLoadTransactionList().get(0).getGiftCardPaymentInstrument().getBalance().getCurrencyAmount();
        if (coFTopUpTransaction.getAmountFulfilled() != null) {
            return beginningBalance.add(coFTopUpTransaction.getAmountFulfilled().getValue());
        } else {
            return beginningBalance;
        }
    }

    @Named("mapGiftCardLoadDetails")
    default List<GiftCardTxnDTO> mapGiftCardLoadDetails(CoFTopUpTransaction coFTopUpTransaction) {
        List<GiftCardTxnDTO> giftCardTxnDTOList = new ArrayList<>();
        if (coFTopUpTransaction.getState().equals(com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum.SUCCESS)) {
            for (GiftCardTransaction giftCardLoadTransaction : coFTopUpTransaction.getGiftCardLoadTransactionList()) {
                GiftCardTxnDTO giftCardTxnDTO = mapGiftCardTxnDetailForTopup(giftCardLoadTransaction.getGiftCardSubTransaction());
                giftCardTxnDTO.setGiftCardPaymentInstrument(mapGiftCardPaymentInstrumentToDTO(giftCardLoadTransaction.getGiftCardPaymentInstrument()));
                giftCardTxnDTOList.add(giftCardTxnDTO);
            }
        }
        return giftCardTxnDTOList;
    }

    @Named("mapDisplayMessage")
    default String mapDisplayMessage(TransactionStateEnum state) {
        if (Objects.nonNull(state) && state.equals(TransactionStateEnum.SUCCESS)) {
            return WPSConstants.CoFTopup.COF_TOPUP_SUCCESSFUL_DISPLAY_MESSAGE;
        } else if (Objects.nonNull(state) && state.equals(TransactionStateEnum.PENDING)) {
            return WPSConstants.CoFTopup.COF_TOPUP_PENDING_3DS_GENERATED_DISPLAY_MESSAGE;
        } else {
            return WPSConstants.CoFTopup.COF_TOPUP_FAILED_GENERIC_DISPLAY_MESSAGE;
        }
    }

    @Mapping(target = "giftCardTxnId", source = "id", qualifiedByName = "mapUUIDtoString")
    @Mapping(target = "giftCardTxnStatus", source = "status")
    @Mapping(target = "amount", source = "amount.value")
    @Mapping(target = "currencyUnit", source = "amount.currencyUnit")
    @Mapping(target = "giftCardTxnType", constant = "ADD_BALANCE")
    GiftCardTxnDTO mapGiftCardTxnDetailForTopup(GiftCardSubTransaction giftCardSubTransaction);

    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "isPreSelected", ignore = true)
    @Mapping(target = "preSelectedAmount", ignore = true)
    @Mapping(target = "tag", ignore = true)
    @Mapping(target = "balance", ignore = true)
    GiftCardPaymentInstrumentDTO mapGiftCardPaymentInstrumentToDTO(GiftCardPaymentInstrument giftCardPaymentInstrument);

    @Named("mapCardPaymentDetails")
    default List<CardTxnDTO> mapCardPaymentDetails(CoFTopUpTransaction coFTopUpTransaction) {
        List<CardTxnDTO> cardTxnDTOList = new ArrayList<>();
        for (CardPaymentTransaction cardPaymentTransaction : coFTopUpTransaction.getCardPaymentTransactionList()) {
            CardTxnDTO cardTxnDTO = mapCardTxnDetailForTopup(cardPaymentTransaction.getCardSubTransaction());
            cardTxnDTO.setCardPaymentInstrument(mapCardPaymentInstrumentToPaymentInstrumentDTO(cardPaymentTransaction.getCardPaymentInstrument()));
            if (StringUtils.isNotEmpty(cardPaymentTransaction.getRedirect3DSURL())) {
                cardTxnDTO.setRedirect3DSURL(cardPaymentTransaction.getRedirect3DSURL());
                cardTxnDTO.setRedirectCashiURL(cardPaymentTransaction.getRedirectCashiURL());
                cardTxnDTO.setTimeoutMinsFor3ds(cardPaymentTransaction.getTimeoutMinsFor3ds());
            }
            cardTxnDTOList.add(cardTxnDTO);
        }
        return cardTxnDTOList;
    }

    @Mapping(target = "cardTxnId", source = "id", qualifiedByName = "mapUUIDtoString")
    @Mapping(target = "cardTxnStatus", source = "status")
    @Mapping(target = "amount", source = "amount.value")
    @Mapping(target = "currencyUnit", source = "amount.currencyUnit")
    @Mapping(target = "msiInfo", source = ".", qualifiedByName = "mapToCardTxnDetailMsiInfo")
    CardTxnDTO mapCardTxnDetailForTopup(CardPaymentTransaction.CardSubTransaction cardSubTransaction);

    @Named("mapToCardTxnDetailMsiInfo")
    @Mapping(target = "installments", source = "msiInstallmentCount")
    @Mapping(target = "amount", source = "msiAmount")
    CardTxnDTO.MsiInfo mapToCardTxnDetailMsiInfo(CardPaymentTransaction.CardSubTransaction cardSubTransaction);

    @Mapping(target = "clientRequestId", source = "coFTopupTransactionDO.clientReqId")
    @Mapping(target = "transaction", source = ".", qualifiedByName = "mapToCancelCoFTopupTransaction")
    CancelCoFTopUpResponse mapToCancelCoFTopupResponseFromContext(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    @Named("mapToCancelCoFTopupTransaction")
    @Mapping(target = "coFTopupTxnId", source = "coFTopupTransactionDO.coFTopupTransactionId")
    @Mapping(target = "cashiOrderId", source = "coFTopupTransactionDO.cashiOrderId")
    @Mapping(target = "amount", source = "coFTopupTransactionDO" , qualifiedByName = "mapAmount")
    @Mapping(target = "currencyUnit", source = "coFTopupTransactionDO.currencyUnit")
    @Mapping(target = "state", source = "coFTopupTransactionDO.state")
    @Mapping(target = "stateReason", source = "coFTopupTransactionDO.stateReason")
    @Mapping(target = "type", source = "transaction.transactionType")
    CancelCoFTopUpResponse.Transaction mapToCancelCoFTopupTransaction(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);
}