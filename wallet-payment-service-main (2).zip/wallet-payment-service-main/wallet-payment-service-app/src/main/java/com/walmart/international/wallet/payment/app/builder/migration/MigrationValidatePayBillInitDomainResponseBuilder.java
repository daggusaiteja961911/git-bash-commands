package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.migration.ValidateChargeInitResponseEWS;
import org.springframework.stereotype.Component;

@Component
public class MigrationValidatePayBillInitDomainResponseBuilder extends BaseDomainResponseBuilder<ValidateChargeInitResponseEWS, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {
    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) throws ApplicationException {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public ValidateChargeInitResponseEWS buildDomainResponse(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) throws ApplicationException {
        return ValidateChargeInitResponseEWS.builder()
                .cashiTransactionId(billPayTxnResponseDomainContext.getTransaction().getTransactionId().toString()).build();
    }
}
