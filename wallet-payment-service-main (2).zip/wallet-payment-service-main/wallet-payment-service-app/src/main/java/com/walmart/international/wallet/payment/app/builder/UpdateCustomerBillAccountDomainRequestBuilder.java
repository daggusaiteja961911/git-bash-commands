package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.BillMapper;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class UpdateCustomerBillAccountDomainRequestBuilder extends BaseDomainRequestBuilder<UpdateCustomerBillAccountRequest, BillRequestDomainContext> {

    BillMapper billMapper = BillMapper.INSTANCE;

    @Override
    public BillRequestDomainContext buildDomainRequest(UpdateCustomerBillAccountRequest updateCustomerBillAccountRequest, MultiValueMap<String, String> headers, Tenant tenant) {

        return BillRequestDomainContext.builder()
                .customerBillAccount(billMapper.updateCustomerBillAccountRequestToCustomerBillAccount(updateCustomerBillAccountRequest))
                .headers(headers)
                .build();
    }
}
