package com.walmart.international.wallet.payment.app.service.impl;


import com.walmart.commons.collections.CollectionUtils;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.notification.constants.EventDownstream;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.txnaggregator.TxnCompletedPayloadGenerator;
import com.walmart.international.notification.utils.EventHelper;
import com.walmart.international.wallet.payment.app.builder.CoFTopupTxnDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.CoFTopupTxnDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.service.TransactionAuditService;
import com.walmart.international.wallet.payment.core.adapter.tas.TxnAggregatorServiceAdapter;
import com.walmart.international.wallet.payment.core.config.ccm.TxnAggregatorResiliencyConfig;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionSyncType;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.TxnAckEventAuditDO;
import com.walmart.international.wallet.payment.data.dao.entity.TxnEventAuditDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import com.walmart.international.wallet.payment.data.dao.repository.TxnAckEventAuditRepository;
import com.walmart.international.wallet.payment.data.dao.repository.TxnEventAuditRepository;
import com.walmart.international.wallet.payment.dto.request.transaction.audit.TransactionAckRequest;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnAckResponse;
import com.walmart.international.wallet.payment.dto.response.transaction.audit.TxnSyncResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.OptimisticLockException;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;


@Component
@Slf4j
public class TransactionAuditServiceImpl implements TransactionAuditService {


    @ManagedConfiguration
    private TxnAggregatorResiliencyConfig txnAggregatorConfiguration;

    @Autowired
    private TxnEventAuditRepository txnEventAuditRepository;

    @Autowired
    private TxnAckEventAuditRepository txnAckEventAuditRepository;

    @Autowired
    CoFTopupTxnDomainRequestBuilder coFTopupTxnDomainRequestBuilder;

    @Autowired
    CoFTopupTxnDomainResponseBuilder coFTopupTxnDomainResponseBuilder;

    @Autowired
    CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private EventHelper eventHelper;

    @Autowired
    private TxnCompletedPayloadGenerator txnCompletedPayloadGenerator;

    @Autowired
    TxnAggregatorServiceAdapter txnAggregatorServiceAdapter;

    private BillPayMapper billPayMapper = BillPayMapper.INSTANCE;


    private void updateRetryCountsForTransactions(List<UUID> transactionIds) throws ProcessingException {
        try {
            List<TxnEventAuditDO> txnEventAuditDOS = txnEventAuditRepository.findAllById(transactionIds);
            txnEventAuditDOS.forEach(t -> t.setRetryCount(t.getRetryCount() + 1));
            txnEventAuditRepository.saveAll(txnEventAuditDOS);
        } catch (Exception ex) {
            throw new ProcessingException(ErrorConstants.TransactionAudit.TRANSACTION_SYNC_GENERIC_FAILURE, ex.getMessage());
        }
    }


    @Override
    public TxnSyncResponse reSyncTransactionsToTAS(List<UUID> transactionIds, String correlationId) throws ApplicationException {
        if (CollectionUtils.isEmpty(transactionIds)) {
            throw new BusinessValidationException(ErrorConstants.TransactionAudit.EMPTY_TRANSACTION_LIST);
        }

        if (transactionIds.size() > txnAggregatorConfiguration.maxAllowedTransactionsForSync()) {
            throw new BusinessValidationException(ErrorConstants.TransactionAudit.MAX_ALLOWED_TRANSACTIONS_EXCEEDED);
        }
        Set<UUID> transactionIdSet = new HashSet<>(transactionIds);

        try {
            List<TxnEventAuditDO> txnEventAuditDOs = txnEventAuditRepository.findAllById(transactionIds);

            Map<Boolean, List<TxnEventAuditDO>> loadMoneyList = txnEventAuditDOs.stream()
                    .collect(Collectors.partitioningBy(e -> e.getTransactionSyncType().equals(TransactionSyncType.LOAD_MONEY)));

            Set<UUID> cofTransactionIds = loadMoneyList.get(true).stream().map(TxnEventAuditDO::getTransactionId).collect(Collectors.toSet());
            if (!cofTransactionIds.isEmpty())
                this.syncCofTopupTransactions(cofTransactionIds, correlationId);


            Set<UUID> billTransactionIds = loadMoneyList.get(false).stream().map(TxnEventAuditDO::getTransactionId).collect(Collectors.toSet());
            if (!billTransactionIds.isEmpty())
                this.syncBillPayTransactions(billTransactionIds, correlationId);

            Set<UUID> successfulTxnIds = new HashSet<>(cofTransactionIds);
            successfulTxnIds.addAll(billTransactionIds);

            List<UUID> failedTxns = transactionIdSet.stream().filter(v -> !successfulTxnIds.contains(v)).collect(Collectors.toList());
            TxnSyncResponse response = new TxnSyncResponse();
            if (failedTxns.isEmpty()) {
                response.setStatus("SUCCESS");
            } else {
                response.setStatus(failedTxns.size() == transactionIds.size() ? "FAILED" : "PARTIALLY_SUCCESS");
                response.setFailedTransactions(failedTxns);
            }
            return response;
        } catch (Exception e) {
            throw new ProcessingException(ErrorConstants.TransactionAudit.TRANSACTION_SYNC_GENERIC_FAILURE, "Exception in reSyncTransactionsToTAS", e);
        }
    }

    private Set<UUID> syncCofTopupTransactions(Set<UUID> transactionIds, String correlationId) throws Exception {

        //start processing - lookup in db and extract relevant txn do
        List<CoFTopupTransactionDO> coFTopupTransactionDOs = coFTopupTransactionRepository.findAllById(transactionIds);

        List<UUID> coFTopupTransactionDOIds = coFTopupTransactionDOs.stream().map(CoFTopupTransactionDO::getCoFTopupTransactionId).collect(Collectors.toList());

        if (coFTopupTransactionDOIds.isEmpty())
            throw new BusinessValidationException(ErrorConstants.TransactionAudit.EMPTY_TRANSACTION_LIST);

        this.updateRetryCountsForTransactions(coFTopupTransactionDOIds);

        return coFTopupTransactionDOs.stream()
                .map(c -> {
                    try {
                        return this.sendTransactionToTAS(c, correlationId);
                    } catch (Throwable e) {
                        throw new ProcessingException(ErrorConstants.TransactionAudit.TRANSACTION_SYNC_GENERIC_FAILURE, e.getMessage());
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

    }

    private Set<UUID> syncBillPayTransactions(Set<UUID> transactionIds, String correlationId) throws Exception {

        //start processing - lookup in db and extract relevant txn do
        List<BillPayTransactionDO> billPayTransactionDOs = billPayTransactionRepository.findAllById(transactionIds);

        List<UUID> billPayTransactionDOIds = billPayTransactionDOs.stream().map(BillPayTransactionDO::getBillPayTransactionId).collect(Collectors.toList());

        if (billPayTransactionDOIds.isEmpty())
            throw new BusinessValidationException(ErrorConstants.TransactionAudit.EMPTY_TRANSACTION_LIST, "Transactions IDs cannot be empty");

        this.updateRetryCountsForTransactions(billPayTransactionDOIds);

        return billPayTransactionDOs.stream()
                .map(c -> {
                    try {
                        return this.sendTransactionToTAS(c, correlationId);
                    } catch (Throwable e) {
                        throw new ProcessingException(ErrorConstants.TransactionAudit.TRANSACTION_SYNC_GENERIC_FAILURE, e.getMessage());
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

    }

    private UUID sendTransactionToTAS(Object transactionDO, String correlationId) throws Throwable {
        if (transactionDO instanceof CoFTopupTransactionDO) {
            CoFTopupTransactionDO coFTopupTransactionDO = (CoFTopupTransactionDO) transactionDO;
            CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = new CoFTopupTxnResponseDomainContext();
            coFTopupTxnResponseDomainContext.setCoFTopupTransactionDO(coFTopupTransactionDO);

            if (txnAggregatorConfiguration.isTxnResiliencyThroughKafkaEnabled())
                eventHelper.publishAsync(coFTopupTransactionDO.getCoFTopupTransactionId().toString(), coFTopupTxnResponseDomainContext, WalletEventType.TXN_COMPLETED,
                        Collections.singletonList(EventDownstream.TXN_AGGREGATER_SERVICE));
            else {
                EventPayload eventPayload = txnCompletedPayloadGenerator.generatePayload(coFTopupTransactionDO, correlationId);
                txnAggregatorServiceAdapter.publishPayloadViaRESTCall(eventPayload);
            }
            return coFTopupTransactionDO.getCoFTopupTransactionId();
        }
        else  {
            BillPayTransactionDO billPayTransactionDO = (BillPayTransactionDO) transactionDO;
            BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = new BillPayTxnResponseDomainContext();
            billPayTxnResponseDomainContext.setBillPayTransactionDO(billPayTransactionDO);
            billPayTxnResponseDomainContext.setTransaction(new BillPayTransaction());

            BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
            billPayMapper.updateBillPayTransactionFromBillPayTransactionDO(billPayTransactionDO, billPayTransaction);
            String transactionId = billPayTransaction.getTransactionId().toString();

            if (txnAggregatorConfiguration.isTxnResiliencyThroughKafkaEnabled())
                eventHelper.publishAsync(transactionId, billPayTransaction, WalletEventType.TXN_COMPLETED,
                        Collections.singletonList(com.walmart.international.notification.constants.EventDownstream.TXN_AGGREGATER_SERVICE));
            else {
                EventPayload eventPayload = txnCompletedPayloadGenerator.generatePayload(billPayTransactionDO, correlationId);
                txnAggregatorServiceAdapter.publishPayloadViaRESTCall(eventPayload);
            }
            return billPayTransactionDO.getBillPayTransactionId();
        }
    }

    @Override
    public TxnAckResponse acknowledgeProcessedTransactionFromTAS(TransactionAckRequest transactionAckRequest) {
        try {

            Optional<TxnAckEventAuditDO> existingTxnEntity = txnAckEventAuditRepository.findById(transactionAckRequest.getTransactionId());
            Date ackDate = new Date(transactionAckRequest.getAcknowledgementEventDate());
            TxnAckEventAuditDO updatedTxnDO = null;
            if (existingTxnEntity.isPresent()) {
                TxnAckEventAuditDO existingTxnDO = existingTxnEntity.get();
                if (existingTxnDO.getLastAckDate() == null || ackDate.compareTo(existingTxnDO.getLastAckDate()) > 0) {
                    //current last ack is greater than existing one
                    existingTxnDO.setLastAckDate(ackDate);
                    existingTxnDO.setLastAcknowledgedEventDesc(transactionAckRequest.getAcknowledgedEvent());
                    updatedTxnDO = existingTxnDO;
                } else {
                    log.info("Txn event already existed for this with existing last Ack Date : {} and incoming ack date : {}", existingTxnDO.getLastAckDate(), ackDate);
                }
            } else {
                //insert
                log.info("No existing txn ack DO found for acknowledgement status update, inserting a new one for txn : {}", transactionAckRequest.getTransactionId());
                updatedTxnDO = new TxnAckEventAuditDO();
                updatedTxnDO.setTransactionId(transactionAckRequest.getTransactionId());
                updatedTxnDO.setLastAckDate(ackDate);
                updatedTxnDO.setLastAcknowledgedEventDesc(transactionAckRequest.getAcknowledgedEvent());
            }
            if (updatedTxnDO == null){
                log.error("Exception in updateAckStatusOfTransaction for transactionId : {} ", transactionAckRequest.getTransactionId());
                throw new ProcessingException(ErrorConstants.TransactionAudit.TRANSACTION_SYNC_GENERIC_FAILURE, "Null value, Exception in updateAckStatusOfTransaction for transactionId");
            }
            txnAckEventAuditRepository.save(updatedTxnDO);
            return new TxnAckResponse(WPSConstants.Common.ACK_SUCCESS);
        } catch (OptimisticLockException ex) {
            throw new ProcessingException(ErrorConstants.TransactionAudit.TRANSACTION_SYNC_GENERIC_FAILURE, String.format("Optimistic lock exception on TxnEventAudit Entity while performing an update for acknowledged txn : {}", transactionAckRequest.getTransactionId()), ex);
        } catch (ApplicationException ex) {
            log.error("Exception in updateAckStatusOfTransaction for transactionId : {} error::{} ", transactionAckRequest.getTransactionId(), ex.getMessage(), ex);
            throw ex;
        }
    }

}
