package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.billpay.BillerController;
import com.walmart.international.wallet.payment.app.service.BillerPromotionService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerCategoriesResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataCacheAlterResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataUpdateInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.PopularBillersResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerIncorrectSearchKeywordsResponse;
import com.walmart.international.wallet.payment.app.service.BillerService;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class BillerControllerImpl implements BillerController {

    @Autowired
    private BillerService billerService;

    @Autowired
    private BillerPromotionService billerPromotionService;

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @Override
    public BillerCategoriesResponse getBillerCategories(int billerCategoryVersion) {
        return billerService.getBillerCategories(billerCategoryVersion);
    }

    @Override
    public PopularBillersResponse getPopularBillers() throws ApplicationException {
        return billerService.getPopularBillers();
    }

    @Override
    public BillerByIdResponse getBillerById(UUID billerId, String processorBillerId) throws ApplicationException {
        return billerService.getBillerById(billerId, processorBillerId);
    }

    @Override
    public BillerDataUpdateInfoResponse getBillerDataUpdateInfo(BillerDataUpdateInfoRequest billerDataUpdateInfoRequest) {
        return billerService.getBillerDataUpdateInfo(billerDataUpdateInfoRequest);
    }

    @Override
    public BillerDataCacheAlterResponse reloadCacheForBillerData(BillerDataCacheReloadRequest billerDataCacheReloadRequest) throws ApplicationException {
        return billerService.reloadCacheForBillerData(billerDataCacheReloadRequest);
    }

    @Override
    public BillerDataCacheAlterResponse evictCacheForBillerData(BillerDataCacheEvictRequest billerDataCacheEvictRequest) {
        return billerService.evictCacheForBillerData(billerDataCacheEvictRequest);
    }

    @Override
    public BillerPromotionsResponse getBillerPromotions(String billerCategoryIds, String processorBillerIds) {
        return billerPromotionService.getBillerPromotions(billerCategoryIds, processorBillerIds, walletPaymentServiceConfiguration.getBillerCategoryVersionForPromotions());
    }

    @Override
    public BillerIncorrectSearchKeywordsResponse getBillerIncorrectSearchKeywords() throws ApplicationException{
        return billerService.getBillerIncorrectSearchKeywords();
    }
}
