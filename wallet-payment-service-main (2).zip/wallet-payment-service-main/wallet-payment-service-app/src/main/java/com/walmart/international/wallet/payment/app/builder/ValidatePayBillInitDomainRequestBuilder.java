package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.billpay.ValidatePayBillInitRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class ValidatePayBillInitDomainRequestBuilder extends BaseDomainRequestBuilder<ValidatePayBillInitRequest, BillPayTxnRequestDomainContext> {
    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(ValidatePayBillInitRequest validatePayBillInitRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        return BillPayTxnRequestDomainContext.builder()
                .transaction(BillPayTransaction.builder()
                        .transactionType(TransactionType.BILL_PAY)
                        .transactionId(validatePayBillInitRequest.getBillPayTransactionId())
                        .customer(Customer.builder()
                                .customerAccountId(validatePayBillInitRequest.getCustomerAccountId())
                                .build())
                        .build())
                .headers(headers)
                .build();
    }
}