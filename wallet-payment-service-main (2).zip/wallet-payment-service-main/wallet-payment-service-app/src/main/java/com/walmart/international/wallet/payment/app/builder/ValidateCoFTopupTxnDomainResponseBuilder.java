package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import org.springframework.stereotype.Component;

@Component
public class ValidateCoFTopupTxnDomainResponseBuilder extends BaseDomainResponseBuilder<ValidateCoFTopupResponse, CoFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext> {

    private CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    @Override
    public CoFTopupTxnResponseDomainContext buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext) throws ApplicationException {
        return CoFTopupTxnResponseDomainContext.builder().build();
    }

    @Override
    public ValidateCoFTopupResponse buildDomainResponse(CoFTopupTxnRequestDomainContext coFTopupTxnRequestDomainContext, CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) throws ApplicationException {
        return coFTopupMapper.mapToValidateCoFTopupResponseFromContext(coFTopupTxnResponseDomainContext);
    }
}
