package com.walmart.international.wallet.payment.app.builder.migration.mapper;

import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardSubTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.dto.common.migration.PaymentDetails;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CardBinDTO;
import com.walmart.international.wallet.payment.dto.response.migration.CardPaymentDetails;
import com.walmart.international.wallet.payment.dto.response.migration.GiftcardPaymentDetailsDTO;
import com.walmart.international.wallet.payment.dto.response.migration.PaymentPreferenceDTO;
import com.walmart.international.wallet.payment.dto.response.migration.RelatedTransactionsDTO;
import com.walmart.international.wallet.payment.dto.response.migration.TransactionDTO;
import com.walmart.international.wallet.payment.dto.response.migration.TransactionDTOV2;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import com.walmart.international.wallet.payment.dto.response.migration.enums.Brand;
import com.walmart.international.wallet.payment.dto.response.migration.enums.CardTxnState;
import com.walmart.international.wallet.payment.dto.response.migration.enums.GiftCardTxnState;
import com.walmart.international.wallet.payment.dto.response.migration.enums.GiftCardTxnStateReason;
import com.walmart.international.wallet.payment.dto.response.migration.enums.PaymentType;
import com.walmart.international.wallet.payment.dto.response.migration.enums.TransactionStatus;
import com.walmart.international.wallet.payment.dto.response.migration.enums.WalletTransactionState;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Mapper
public interface MigrationCoFTopupMapper {

    MigrationCoFTopupMapper INSTANCE = Mappers.getMapper(MigrationCoFTopupMapper.class);

    List<PaymentPreferenceDTO> mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(List<CardPaymentInstrument> cardPaymentInstrumentList);

    @Mapping(target = "paymentId", source = "paymentInstrumentId")
    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "cardholderName", source = "metadata.cardholderName")
    @Mapping(target = "aliasName", source = "metadata.aliasName")
    @Mapping(target = "cardNumber", source = "metadata.cardNumber")
    @Mapping(target = "last4Digits", source = "metadata.last4Digits")
    @Mapping(target = "brand", source = "metadata.brand", qualifiedByName = "getBrandFromMetadataBrand")
    @Mapping(target = "tokenId", source = "adapterMetadata.tokenId")
    @Mapping(target = "cvvVerified", source = "metadata.cvvVerified")
    @Mapping(target = "cvvRequired", source = "metadata.cvvRequired")
    @Mapping(target = "billingAddress.countryCode", source = "billingAddress.country")
    @Mapping(target = "billingAddress.exteriorNum", source = "billingAddress.streetExtNum")
    @Mapping(target = "billingAddress.interiorNum", source = "billingAddress.streetIntNum")
    @Mapping(target = "paymentType", source = "cardPaymentInstrument", qualifiedByName = "mapPaymentType")
    @Mapping(target = "binDetails", source = "binDetails", qualifiedByName = "mapBinDetails")
    @Mapping(target = "tag", source = "tag", qualifiedByName = "mapToTag")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    PaymentPreferenceDTO mapCardPaymentInstrumentToPaymentPreferenceDTO(CardPaymentInstrument cardPaymentInstrument);

    @Named("mapToTag")
    default String mapToTag(String tag) {
        if (PaymentInstrumentType.CARD.name().equals(tag)) {
            return "COF";
        }
        return tag;
    }

    @Named("mapBinDetails")
    default CardBinDTO binDetailsToCardBinDTO(CardPaymentInstrument.BinDetails binDetails) {
        if ( binDetails == null ) {
            return null;
        }

        CardBinDTO cardBinDTO = new CardBinDTO();

        if ( Objects.nonNull(binDetails.getBin())) {
            cardBinDTO.setBin( Integer.parseInt( binDetails.getBin() ) );
        }
        if (StringUtils.isNotEmpty(binDetails.getBankName())) {
            cardBinDTO.setBankName(binDetails.getBankName());
        }
        if (StringUtils.isNotEmpty(binDetails.getBankLogo())) {
            cardBinDTO.setBankLogo(binDetails.getBankLogo());
        }
        cardBinDTO.setBrandName( binDetails.getBrandName() );
        cardBinDTO.setBrandLogo( binDetails.getBrandLogo() );
        cardBinDTO.setBankColor( binDetails.getBankColor() );
        cardBinDTO.setTextColor( binDetails.getTextColor() );

        return cardBinDTO;
    }

    @Named("getBrandFromMetadataBrand")
    default Brand getBrandFromMetadataBrand(String brand) {
        return Brand.resolve(brand, false);
    }

    @Named("mapPaymentType")
    default PaymentType mapPaymentType(CardPaymentInstrument cardPaymentInstrument) {
        if (Objects.nonNull(cardPaymentInstrument.getPaymentInstrumentType()) && Objects.nonNull(cardPaymentInstrument.getPaymentInstrumentSubType())) {
            PaymentType paymentType = null;
            switch (cardPaymentInstrument.getPaymentInstrumentSubType()) {
                case DEBIT_CARD:
                    paymentType = PaymentType.DEBIT;
                    break;
                case CREDIT_CARD:
                    paymentType = PaymentType.CREDIT;
                    break;
            }
            return paymentType;
        }
        if (Objects.nonNull(cardPaymentInstrument.getPaymentInstrumentType())) {
                PaymentType.resolve(cardPaymentInstrument.getPaymentInstrumentType().toString());
            }

        return null;
    }

    @Mapping(target = "transaction", source = "transaction", qualifiedByName = "mapTransaction")
    @Mapping(target = "paymentDetails", source = "transaction.cardPaymentTransactionList", qualifiedByName = "mapTopUpTransactionCardTxnDetails")
    @Mapping(target = "errorCode", source = "transaction.failureCode")
    @Mapping(target = "displayMessage", source = "transaction.state", qualifiedByName = "mapDisplayMessage")
    UnifiedPaymentResponse mapToMigrationLoadMoneyResponseFromContext(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    @Named("mapDisplayMessage")
    default String mapDisplayMessage(TransactionStateEnum state) {
        if (Objects.nonNull(state) && state.equals(TransactionStateEnum.SUCCESS)) {
            return WPSConstants.CoFTopup.COF_TOPUP_SUCCESSFUL_DISPLAY_MESSAGE;
        } else if (Objects.nonNull(state) && state.equals(TransactionStateEnum.PENDING)) {
            return WPSConstants.CoFTopup.COF_TOPUP_PENDING_3DS_GENERATED_DISPLAY_MESSAGE;
        } else {
            return WPSConstants.CoFTopup.COF_TOPUP_FAILED_GENERIC_DISPLAY_MESSAGE;
        }
    }

    @Named("mapTransaction")
    @Mapping(target = "id", source = "transactionId", qualifiedByName = "mapUUIDtoString")
    @Mapping(target = "amount", source = "." , qualifiedByName = "mapAmount")
    @Mapping(target = "cashiConfirmationNumber", source = "cashiOrderId")
    @Mapping(target = "currencyUnit", source = "amountRequested.currencyUnit")
    @Mapping(target = "walletTransactionType", constant = "LOAD_MONEY")
    @Mapping(target = "beginningBalance", source = ".", qualifiedByName = "mapBeginningBalanceFromTopupTransaction")
    @Mapping(target = "currentBalance", source = ".", qualifiedByName = "mapEndingBalanceFromTopupTransaction")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapWalletTxnState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapWalletTxnStateReason")
    @Mapping(target = "relatedTransactions", source = ".", qualifiedByName = "mapTopUpTransactionGiftCardTxnDetailsFromContext")
    TransactionDTOV2 mapCoFTopupTransaction(CoFTopUpTransaction coFTopUpTransaction);

    @Named("mapWalletTxnState")
    default WalletTransactionState mapWalletTxnState(TransactionStateEnum state) {
        switch (state) {
            case FAILURE:
                return WalletTransactionState.FAILURE;
            case SUCCESS:
                return WalletTransactionState.SUCCESS;
            default:
                return WalletTransactionState.PENDING;
        }
    }

    @Named("mapWalletTxnStateReason")
    default TransactionStatus mapWalletTxnStateReason(CoFTopupTxnStateReason stateReason) {
        switch (stateReason) {
            case DEBIT_PENDING:
            case DEBIT_3DS_GENERATED:
                return TransactionStatus.PENDING_3DS_GENERATED;
            case DEBIT_FAILED:
                return TransactionStatus.CARD_SYSTEM_ERROR;
            case CREDIT_FAILED:
            case DEBIT_REVERSAL_INITIATED:
            case DEBIT_REVERSAL_INIT_FAILED:
            case DEBIT_REVERSAL_FAILED:
                return TransactionStatus.GIFTCARD_SYSTEM_ERROR;
            case CREDIT_SUCCESS:
            case CREDIT_SUCCESS_WITH_LOCK:
                return TransactionStatus.PAYMENT_AUTHORIZED;
            default:
                return TransactionStatus.TOP_UP_SYSTEM_ERROR;
        }
    }

    @Named("mapUUIDtoString")
    default String mapUUIDtoString(UUID uuid) {
        return String.valueOf(uuid);
    }

    @Named("mapAmount")
    default BigDecimal mapAmount(CoFTopupTransactionDO coFTopupTransactionDO) {
        if ( coFTopupTransactionDO == null ) {
            return null;
        }
        BigDecimal amountProcessed = coFTopupTransactionDO.getAmountProcessed();
        if ( amountProcessed == null ) {
            return coFTopupTransactionDO.getAmountRequested();
        }
        return amountProcessed;
    }

    @Named("mapAmount")
    default BigDecimal mapAmount(CoFTopUpTransaction coFTopUpTransaction) {
        if (Objects.isNull(coFTopUpTransaction)) {
            return null;
        }
        if (Objects.isNull(coFTopUpTransaction.getAmountFulfilled())
                || Objects.isNull(coFTopUpTransaction.getAmountFulfilled().getValue())) {
            return coFTopUpTransaction.getAmountRequested().getValue();
        }
        return coFTopUpTransaction.getAmountFulfilled().getValue();
    }

    @Named("mapBeginningBalanceFromTopupTransaction")
    default BigDecimal mapBeginningBalanceFromTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        TransactionStateEnum state = coFTopUpTransaction.getState();
        if (state.equals(TransactionStateEnum.SUCCESS) || state.equals(TransactionStateEnum.FAILURE)) {
            return coFTopUpTransaction.getGiftCardLoadTransactionList().get(0).getGiftCardPaymentInstrument().getBalance().getCurrencyAmount();
        }
        return null;
    }

    @Named("mapEndingBalanceFromTopupTransaction")
    default BigDecimal mapEndingBalanceFromTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        TransactionStateEnum state = coFTopUpTransaction.getState();
        if (state.equals(TransactionStateEnum.SUCCESS)) {
            BigDecimal beginningBalance = coFTopUpTransaction.getGiftCardLoadTransactionList().get(0).getGiftCardPaymentInstrument().getBalance().getCurrencyAmount();
            if (coFTopUpTransaction.getAmountFulfilled() != null) {
                return beginningBalance.add(coFTopUpTransaction.getAmountFulfilled().getValue());
            } else {
                return beginningBalance;
            }
        }
        return null;
    }

    @Named("mapTopUpTransactionGiftCardTxnDetailsFromContext")
    default RelatedTransactionsDTO mapTopUpTransactionGiftCardTxnDetailsFromContext(CoFTopUpTransaction coFTopUpTransaction) {
        if (Objects.nonNull(coFTopUpTransaction) && coFTopUpTransaction.getState().equals(TransactionStateEnum.SUCCESS)) {
            return mapTopUpTransactionGiftCardTxnDetails(coFTopUpTransaction.getGiftCardLoadTransactionList());
        }
        return null;
    }

    default RelatedTransactionsDTO mapTopUpTransactionGiftCardTxnDetails(List<GiftCardTransaction> giftCardLoadTransactionList) {
        RelatedTransactionsDTO relatedTransactionsDTO = new RelatedTransactionsDTO();
        List<GiftcardPaymentDetailsDTO> giftcardPaymentDetails = new ArrayList<>();
        for (GiftCardTransaction giftCardLoadTransaction : giftCardLoadTransactionList) {
            GiftcardPaymentDetailsDTO giftcardPaymentDetailsDTO = mapGiftCardPaymentDetailForTopup(giftCardLoadTransaction.getGiftCardSubTransaction());
            giftcardPaymentDetailsDTO.setPaymentPreference(mapGiftCardPaymentInstrumentToPaymentPreferenceDTO(giftCardLoadTransaction.getGiftCardPaymentInstrument()));
            giftcardPaymentDetails.add(giftcardPaymentDetailsDTO);
        }
        TransactionDTO topupTransaction = TransactionDTO.builder()
                .giftcardPaymentDetails(giftcardPaymentDetails)
                .build();
        relatedTransactionsDTO.setTopupTransaction(topupTransaction);
        return relatedTransactionsDTO;
    }

    @Mapping(target = "giftCardTxnId", source = "id")
    @Mapping(target = "giftCardTxnState", source = "status", qualifiedByName = "mapGiftCardTxnState")
    @Mapping(target = "amountSettled", source = "amount.value")
    @Mapping(target = "amountSettledCurrencyCode", source = "amount.currencyUnit")
    @Mapping(target = "approvalCode", source = "authCode")
    @Mapping(target = "giftCardTxnType", constant = "ADD_BALANCE")
    @Mapping(target = "giftCardTxnStateReason", source = "status", qualifiedByName = "mapGiftCardTxnStateReason")
    GiftcardPaymentDetailsDTO mapGiftCardPaymentDetailForTopup(GiftCardSubTransaction giftCardSubTransaction);

    @Named("mapGiftCardTxnState")
    default GiftCardTxnState mapGiftCardTxnState(SubTransactionStatusV2 status) {
        if (Objects.nonNull(status)) {
            switch (status) {
                case LOAD_SUCCESS_WITH_LOCK:
                case LOAD_SUCCEEDED:
                    return GiftCardTxnState.SETTLED;
                case LOAD_FAILED:
                    return GiftCardTxnState.FAILED;
                default:
                    return GiftCardTxnState.PENDING;
            }
        } else {
            return GiftCardTxnState.PENDING;
        }
    }

    @Named("mapGiftCardTxnStateReason")
    default GiftCardTxnStateReason mapGiftCardTxnStateReason(SubTransactionStatusV2 status) {
        if (Objects.nonNull(status)) {
            switch (status) {
                case LOAD_SUCCESS_WITH_LOCK:
                    return GiftCardTxnStateReason.UNLOCK_FAIL;
                case LOAD_SUCCEEDED:
                    return GiftCardTxnStateReason.UNLOCK_SUCCESS;
                case LOAD_FAILED:
                    return GiftCardTxnStateReason.ADD_BALANCE_FAIL;
                default:
                    return GiftCardTxnStateReason.ADD_BALANCE_INITIATED;
            }
        } else {
            return GiftCardTxnStateReason.ADD_BALANCE_INITIATED;
        }
    }

    @Mapping(target = "paymentId", source = "paymentInstrumentId")
    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "paymentType", source = "giftCardPaymentInstrument", qualifiedByName = "mapGiftCardPaymentType")
    @Mapping(target = "balance", ignore = true)
    @Mapping(target = "parentPaymentPreferenceId", source = "parentPaymentPreferenceId", qualifiedByName = "mapUUIDtoString")
    @Mapping(target = "isLoadAllowed", constant = "true")
    @Mapping(target = "kycStatus", constant = "PENDING")
    PaymentPreferenceDTO mapGiftCardPaymentInstrumentToPaymentPreferenceDTO(GiftCardPaymentInstrument giftCardPaymentInstrument);

    @Named("mapGiftCardPaymentType")
    default PaymentType mapGiftCardPaymentType(GiftCardPaymentInstrument giftCardPaymentInstrument) {

        if (Objects.nonNull(giftCardPaymentInstrument.getPaymentInstrumentType()) && Objects.nonNull(giftCardPaymentInstrument.getPaymentInstrumentSubType())) {
            PaymentType paymentType = null;
            switch (giftCardPaymentInstrument.getPaymentInstrumentSubType()) {
                case CASHI_WALLET:
                    paymentType = PaymentType.GIFTCARD;
                    break;
                case CORP_CARD:
                case ASSOCIATE_FOOD_VOUCHER:
                    paymentType = PaymentType.CORPGIFTCARD;
                    break;
            }
            return paymentType;
        }
        if (Objects.nonNull(giftCardPaymentInstrument.getPaymentInstrumentType())) {
            PaymentType.resolve(giftCardPaymentInstrument.getPaymentInstrumentType().toString());
        }

        return null;
    }

    @Named("mapTopUpTransactionCardTxnDetails")
    default PaymentDetails mapTopUpTransactionCardTxnDetails(List<CardPaymentTransaction> cardPaymentTransactionList) {
        PaymentDetails paymentDetails = new PaymentDetails();
        List<CardPaymentDetails> cardPaymentDetailsList = new ArrayList<>();
        for (CardPaymentTransaction cardPaymentTransaction : cardPaymentTransactionList) {
            CardPaymentDetails cardPaymentDetails = mapCardPaymentDetailForTopup(cardPaymentTransaction.getCardSubTransaction());
            SubTransactionStatusV2 status = cardPaymentTransaction.getCardSubTransaction().getStatus();
            if (Objects.nonNull(status) && status.equals(SubTransactionStatusV2.PAYMENT_3DS_PENDING)) {
                cardPaymentDetails.setThreeDSUrl(cardPaymentTransaction.getRedirect3DSURL());
                cardPaymentDetails.setRedirectUrl(cardPaymentTransaction.getRedirectCashiURL());
                cardPaymentDetails.setTimeoutMinsFor3ds(cardPaymentTransaction.getTimeoutMinsFor3ds());
            }
            cardPaymentDetails.setPaymentPreference(mapCardPaymentInstrumentToPaymentPreferenceDTO(cardPaymentTransaction.getCardPaymentInstrument()));
            cardPaymentDetailsList.add(cardPaymentDetails);
        }
        paymentDetails.setCardPaymentDetails(cardPaymentDetailsList);
        return paymentDetails;
    }

    @Mapping(target = "id", source = "id")
    @Mapping(target = "state", source = "status", qualifiedByName = "mapCardTxnState")
    @Mapping(target = "stateReason", source = "status", qualifiedByName = "mapCardTxnStateReason")
    @Mapping(target = "isTopUpTransaction", source = "status", qualifiedByName = "mapIsTopUpTransaction")
    @Mapping(target = "updateDate", ignore = true)
    CardPaymentDetails mapCardPaymentDetailForTopup(CardPaymentTransaction.CardSubTransaction cardSubTransaction);

    @Named("mapIsTopUpTransaction")
    default Boolean mapIsTopUpTransaction(SubTransactionStatusV2 status) {
        if (Objects.nonNull(status)) {
            switch (status) {
                case PAYMENT_SUCCEEDED:
                    return Boolean.TRUE;
                default:
                    return null;
            }
        } else {
            return null;
        }
    }

    @Named("mapCardTxnState")
    default CardTxnState mapCardTxnState(SubTransactionStatusV2 status) {
        if (Objects.nonNull(status)) {
            switch (status) {
                case TXN_REQUEST_REJECTED:
                case PAYMENT_REJECTED:
                case PAYMENT_FAILED:
                    return CardTxnState.FAILED;
                case PAYMENT_3DS_PENDING:
                    return CardTxnState.PENDING_3DS_GENERATED;
                case PAYMENT_SUCCEEDED:
                    return CardTxnState.SETTLED;
                case REVERSAL_INITIATED:
                    return CardTxnState.REVERSAL_INITIATED;
                case REVERSAL_FAILED:
                    return CardTxnState.REVERSAL_FAILED;
                case REVERSAL_PROCESSING:
                case REVERSAL_INITIATION_ATTEMPTED:
                    return CardTxnState.REVERSAL_PENDING;
                default:
                    return CardTxnState.PENDING;
            }
        } else {
            return CardTxnState.PENDING;
        }
    }

    @Named("mapCardTxnStateReason")
    default TransactionStatus mapCardTxnStateReason(SubTransactionStatusV2 status) {
        if (Objects.nonNull(status)) {
            switch (status) {
                case PAYMENT_SUCCEEDED:
                    return TransactionStatus.PAYMENT_AUTHORIZED;
                case PAYMENT_3DS_PENDING:
                    return TransactionStatus.PENDING_3DS_GENERATED;
                default:
                    return TransactionStatus.CARD_SYSTEM_ERROR;
            }
        } else {
            return TransactionStatus.CARD_SYSTEM_ERROR;
        }
    }

    @Mapping(target = "currencyAmount", source = "value")
    CardPaymentDetails.Amount mapAmountUnitToCardPaymentDetailsAmount(Amount amount);

    @Named("mapToString")
    default String mapToString(Object o) {
        return String.valueOf(o);
    }

    @Named("mapStringToUUID")
    default UUID mapStringToUUID(String string) {
        return UUID.fromString(string);
    }

    @Mapping(target = "clientRequestId", source = "coFTopupTransactionDO.clientReqId")
    @Mapping(target = "transaction", source = ".", qualifiedByName = "mapToCancelCoFTopupTransaction")
    CancelCoFTopupResponseEWS mapToCancelCoFTopupResponseFromContext(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    @Named("mapToCancelCoFTopupTransaction")
    @Mapping(target = "id", source = "coFTopupTransactionDO.coFTopupTransactionId")
    @Mapping(target = "cashiConfirmationNumber", source = "coFTopupTransactionDO.cashiOrderId")
    @Mapping(target = "amount", source = "coFTopupTransactionDO" , qualifiedByName = "mapAmount")
    @Mapping(target = "currencyUnit", source = "coFTopupTransactionDO.currencyUnit")
    CancelCoFTopupResponseEWS.CancelTransaction mapToCancelCoFTopupTransaction(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext);

    default String map(UUID value) {
        return value.toString();
    }

    default UUID map(String value) {
        return UUID.fromString(value);
    }
}
