package com.walmart.international.wallet.payment.data.constant.enums;

public enum TransactionStateEnum {
    INITIATED,
    PENDING,
    FAILURE,
    SUCCESS,
    CANCELLED
}
