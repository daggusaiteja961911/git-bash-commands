package com.walmart.international.wallet.payment.data.constant.enums;

import java.util.Arrays;
import java.util.List;

public enum NotificationContentSubcategory {

    ARCUS_DATE_WITH_ALIAS,

    ARCUS_DATE_WITHOUT_ALIAS,

    DUE_TODAY_WITH_ALIAS,

    DUE_TODAY_WITHOUT_ALIAS,
    DUE_SOON_WITH_ALIAS,
    DUE_SOON_WITHOUT_ALIAS,

    NUDGE1, NUDGE2, NUDGE3;

    public static List<NotificationContentSubcategory> getNotificationContentSubcategoryWithAlias() {
        return Arrays.asList(ARCUS_DATE_WITH_ALIAS, DUE_SOON_WITH_ALIAS, DUE_TODAY_WITH_ALIAS);
    }

    public static List<NotificationContentSubcategory> getNotificationContentSubcategoryWithoutAlias() {
        return Arrays.asList(ARCUS_DATE_WITHOUT_ALIAS, DUE_SOON_WITHOUT_ALIAS, DUE_TODAY_WITHOUT_ALIAS);
    }
}
