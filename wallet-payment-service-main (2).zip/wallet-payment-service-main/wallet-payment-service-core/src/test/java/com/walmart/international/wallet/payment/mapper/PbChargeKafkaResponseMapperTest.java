package com.walmart.international.wallet.payment.mapper;

import com.walmart.international.services.payment.core.kafka.response.AsyncChargeKafkaPayload;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.ChargeEventDetails;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PBChargeKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PaymentStatus;
import com.walmart.international.wallet.payment.core.mapper.PBChargeKafkaResponseMapperImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class PbChargeKafkaResponseMapperTest {
    @InjectMocks
    PBChargeKafkaResponseMapperImpl mapper;

    @Test
    public void shouldTestIfKafkaResponseIsCorrectlyMapped() {
        PBChargeKafkaResponse response = getKafkaChargeResponse();
        //
        AsyncChargeKafkaPayload.AsyncChargeKafkaResponse result = mapper.mapPBKafkaResponseToPaymentCoreRequest(response);
        Assertions.assertNotNull(result);
    }

    private PBChargeKafkaResponse getKafkaChargeResponse() {
        PBChargeKafkaResponse response = new PBChargeKafkaResponse();
        response.setEventType("charge.success");
        ChargeEventDetails eventPayload = new ChargeEventDetails();
        eventPayload.setBanner("EA");
        eventPayload.setOrderId("235324653456");
        eventPayload.setExternalOrderReference("2353453hbj345");
        ChargeEventDetails.PaymentDetails paymentDetails = new ChargeEventDetails.PaymentDetails();
        paymentDetails.setPaymentId("8cc02e71-f4ba-4231-bb23-72e8491e41d2");
        paymentDetails.setAmount(BigDecimal.valueOf(30));
        paymentDetails.setStatus(PaymentStatus.FAILED);
        eventPayload.setPayments(List.of(paymentDetails));
        eventPayload.setPaymentGateway("PB123092hb2308323");
        response.setEventPayload(eventPayload);
        return response;
    }

}
