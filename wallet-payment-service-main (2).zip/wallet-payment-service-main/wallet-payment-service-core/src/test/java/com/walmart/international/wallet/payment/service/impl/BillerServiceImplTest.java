//package com.walmart.international.wallet.payment.service.impl;
//
//import com.walmart.international.digiwallet.service.web.rest.i8n.local.SimpleMessageResolver;
//import com.walmart.international.wallet.payment.MockUtils;
//import com.walmart.international.wallet.payment.api.dto.response.billpay.BillerCategoriesResponse;
//import com.walmart.international.wallet.payment.api.impl.service.impl.BillerServiceImpl;
//import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
//import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
//import com.walmart.international.wallet.payment.core.mapper.BillerEntityMapper;
//import com.walmart.international.wallet.payment.core.service.BillerCoreService;
//import com.walmart.international.wallet.payment.dao.entity.BillerCategoryVersionMappingDO;
//import com.walmart.international.wallet.payment.dao.repository.BillerCategoryVersionMappingRepository;
//import com.walmart.international.wallet.payment.dto.AdditionalInfoForBillPaymentMapping;
//import com.walmart.international.wallet.payment.core.utils.WalletPaymentConstants;
//import net.spy.memcached.WmClient;
//import net.spy.memcached.internal.OperationFuture;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mapstruct.factory.Mappers;
//import org.mockito.ArgumentMatchers;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.Date;
//import java.util.List;
//
//
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyList;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//public class BillerServiceImplTest {
//
//    @InjectMocks
//    BillerServiceImpl billerServiceImpl;
//
//    @Mock
//    BillerCoreService billerCoreService;
//
//    @Mock
//    WmClient wmClient;
//
//    @Mock
//    SimpleMessageResolver simpleMessageResolver;
//
//    @Mock
//    BillerCategoryVersionMappingRepository billerCategoryVersionMappingRepository;
//
//    @Mock
//    BillerEntityMapper billPayMapper = Mappers.getMapper(BillerEntityMapper.class);
//
//    @Mock
//    BillPaymentConfiguration billPaymentConfiguration;
//
//    @Mock
//    OperationFuture<Boolean> mockFuture;
//
//    @Test
//    public void shouldReturnBillerCategoriesMapFromCache() {
//
//        //given
//        List <Integer> versions = List.of(1);
//        //when
//        List<BillerCategory> billerCategoryList = List.of(MockUtils.getBillerCategory());
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenReturn(billerCategoryList);
//
//        //then
//        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(versions.get(0));
//        assertEquals("SUCCESS", billerCategoriesResponse.getStatus());
//        assertNotNull(billerCategoriesResponse.getCategories());
//    }
//
//    @Test
//    public void shouldReturnBillerCategoriesMapAlongWithTimestampFromCache() {
//        //given
//        List <Integer> versions = List.of(2);
//
//        //when
//        List<BillerCategory> billerCategoryList = List.of(MockUtils.getBillerCategory());
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenReturn(billerCategoryList);
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY)).thenReturn(new Date());
//
//        //then
//        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(versions.get(0));
//        assertEquals("SUCCESS", billerCategoriesResponse.getStatus());
//        assertNotNull(billerCategoriesResponse.getCategories());
//        assertNotNull(billerCategoriesResponse.getBillerCategoryDataLastUpdatedAt());
//    }
//
//    @Test
//    public void shouldReturnBillerCategoriesMapFromDB() {
//        //given
//        List <Integer> versions = List.of(1);
//        String cacheKey = WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0);
//        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList = List.of(MockUtils.getBillerCategoryVersionMappingDO());
//        List<BillerCategory> billerCategoryList = List.of(MockUtils.getBillerCategory());
//
//        //when
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenReturn(null);
//        when(billerCategoryVersionMappingRepository.getBillerCategoriesWithBillers(versions)).thenReturn(billerCategoryVersionMappingDOList);
//        when(billPaymentConfiguration.getBillerCategoryVersionsEligibleToShowProductBillers()).thenReturn(versions);
//        when(billPayMapper.mapBillerCategoryVersionMappingsDOsToBillerCategoryEntityList(ArgumentMatchers.anyList(), any(AdditionalInfoForBillPaymentMapping.class))).thenReturn(billerCategoryList);
//        when(wmClient.set(anyString(), anyInt(), anyList())).thenReturn(mockFuture);
//
//        //then
//        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(versions.get(0));
//        assertEquals("SUCCESS", billerCategoriesResponse.getStatus());
//        assertNotNull(billerCategoriesResponse.getCategories());
//    }
//
//    @Test
//    public void shouldReturnBillerCategoriesMapAlongWithTimestampFromDB() {
//        //given
//        List <Integer> versions = List.of(2);
//        String cacheKey = WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0);
//        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList = List.of(MockUtils.getBillerCategoryVersionMappingDO());
//        billerCategoryVersionMappingDOList.get(0).setBillerCategoryVersion(versions.get(0));
//        List<BillerCategory> billerCategoryList = List.of(MockUtils.getBillerCategory());
//        billerCategoryList.get(0).setBillerCategoryVersion(versions.get(0));
//        //when
//
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenReturn(null);
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY)).thenReturn(null);
//        when(billerCategoryVersionMappingRepository.getBillerCategoriesWithBillers(versions)).thenReturn(billerCategoryVersionMappingDOList);
//        when(billerCategoryVersionMappingRepository.getBillerCategoryDataUpdateTimestamp()).thenReturn(new Date());
//        when(billPaymentConfiguration.getBillerCategoryVersionsEligibleToShowProductBillers()).thenReturn(versions);
//        when(billPayMapper.mapBillerCategoryVersionMappingsDOsToBillerCategoryEntityList(ArgumentMatchers.anyList(), any(AdditionalInfoForBillPaymentMapping.class))).thenReturn(billerCategoryList);
//        when(wmClient.set(anyString(), anyInt(), anyList())).thenReturn(mockFuture);
//        when(wmClient.set(anyString(), anyInt(), any(Date.class))).thenReturn(mockFuture);
//
//        //then
//        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(versions.get(0));
//        assertEquals("SUCCESS", billerCategoriesResponse.getStatus());
//        assertNotNull(billerCategoriesResponse.getCategories());
//        assertNotNull(billerCategoriesResponse.getBillerCategoryDataLastUpdatedAt());
//    }
//
//    @Test
//    public void shouldReturnBillerCategoriesMapAlongWithTimestampFromDBAsWmClientThrowsException() {
//        //given
//        List <Integer> versions = List.of(2);
//        String cacheKey = WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0);
//        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList = List.of(MockUtils.getBillerCategoryVersionMappingDO());
//        billerCategoryVersionMappingDOList.get(0).setBillerCategoryVersion(versions.get(0));
//        List<BillerCategory> billerCategoryList = List.of(MockUtils.getBillerCategory());
//        billerCategoryList.get(0).setBillerCategoryVersion(versions.get(0));
//        //when
//
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenThrow(new RuntimeException());
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORY_DATA_UPDATED_AT_CACHE_KEY)).thenThrow(new RuntimeException());
//        when(billerCategoryVersionMappingRepository.getBillerCategoriesWithBillers(versions)).thenReturn(billerCategoryVersionMappingDOList);
//        when(billerCategoryVersionMappingRepository.getBillerCategoryDataUpdateTimestamp()).thenReturn(new Date());
//        when(billPaymentConfiguration.getBillerCategoryVersionsEligibleToShowProductBillers()).thenReturn(versions);
//        when(billPayMapper.mapBillerCategoryVersionMappingsDOsToBillerCategoryEntityList(ArgumentMatchers.anyList(), any(AdditionalInfoForBillPaymentMapping.class))).thenReturn(billerCategoryList);
//        when(wmClient.set(anyString(), anyInt(), anyList())).thenReturn(mockFuture);
//        when(wmClient.set(anyString(), anyInt(), any(Date.class))).thenReturn(mockFuture);
//
//        //then
//        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(versions.get(0));
//        assertEquals("SUCCESS", billerCategoriesResponse.getStatus());
//        assertNotNull(billerCategoriesResponse.getCategories());
//        assertNotNull(billerCategoriesResponse.getBillerCategoryDataLastUpdatedAt());
//    }
//
//
//    @Test
//    public void shouldThrowExceptionAsDBCallFails() {
//        //given
//        List <Integer> versions = List.of(1);
//
//        //when
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenReturn(null);
//        when(billerCategoryVersionMappingRepository.getBillerCategoriesWithBillers(versions)).thenThrow(new RuntimeException("Failed to connect"));
//
//        //then
//        assertThrows(RuntimeException.class, () -> billerServiceImpl.getBillerCategories(versions.get(0)));
//    }
//
//    @Test
//    public void shouldNotReturnBillerCategoriesMapFromDBAsDBcallTofetchBillerCategoryVersionMappingDOReturnsNull() {
//        //given
//        List <Integer> versions = List.of(1);
//
//        //when
//        when(wmClient.get(WalletPaymentConstants.BILLER_CATEGORIES_MAP_CACHE_KEY + versions.get(0))).thenReturn(null);
//        when(billerCategoryVersionMappingRepository.getBillerCategoriesWithBillers(versions)).thenReturn(null);
//
//        //then
//        BillerCategoriesResponse billerCategoriesResponse = billerServiceImpl.getBillerCategories(versions.get(0));
//        assertEquals("FAILED", billerCategoriesResponse.getStatus());
//    }
//}
