package com.walmart.international.wallet.payment.mapper;

import com.walmart.international.wallet.payment.MockUtils;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.mapper.BillerMapperImpl;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryVersionMappingDO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class BillPayMapperTest {

    @InjectMocks
    BillerMapperImpl billEntityMapperImpl;

    @Test
    public void shouldMapBillerCategoryVersionMappingDOListToBillerCategoriesList() {
        //given
        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList = List.of(MockUtils.getBillerCategoryVersionMappingDO());
        billerCategoryVersionMappingDOList.get(0).setBillerCatgeoryMappings(null);

        //then
        List<BillerCategory> billerCategoryList = billEntityMapperImpl.mapBillerCategoryVersionMappingsDOsToBillerCategoryList(billerCategoryVersionMappingDOList);
        assertNotNull(billerCategoryList);
        assertNotNull(billerCategoryList.get(0));
        assertThat(billerCategoryList.get(0)).isNotNull()
                .hasFieldOrPropertyWithValue("id", billerCategoryVersionMappingDOList.get(0).getBillerCategory().getCategoryId())
                .hasFieldOrPropertyWithValue("categoryName", billerCategoryVersionMappingDOList.get(0).getBillerCategory().getCategoryName());
    }

    @Test
    public void shouldReturnNullAsBillerCategoryVersionMappingDOListisNull() {
        //given
        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList = null;

        //then
        List<BillerCategory> billerCategoryList = billEntityMapperImpl.mapBillerCategoryVersionMappingsDOsToBillerCategoryList(billerCategoryVersionMappingDOList);
        assertNull(billerCategoryList);
    }

    @Test
    public void shouldReturnEmptyListAsBillerCategoryVersionMappingDOListisEmpty() {
        //given
        List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList = Collections.emptyList();

        //then
        List<BillerCategory> billerCategoryList = billEntityMapperImpl.mapBillerCategoryVersionMappingsDOsToBillerCategoryList(billerCategoryVersionMappingDOList);
        assertTrue(billerCategoryList.isEmpty());
    }
}
