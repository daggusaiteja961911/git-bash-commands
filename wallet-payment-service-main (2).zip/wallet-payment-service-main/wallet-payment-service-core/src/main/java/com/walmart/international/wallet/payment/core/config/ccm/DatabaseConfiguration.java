package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = DatabaseConfiguration.CCM_ENTRY_NAME)
public interface DatabaseConfiguration {
    String CCM_ENTRY_NAME = "database-config";

    @Property(propertyName = "inmemory.jpa.pool.driver")
    String getDriver();

    @Property(propertyName = "inmemory.jpa.pool.jdbcUrl")
    String getJdbcUrl();

    @Property(propertyName = "max.pool.size")
    Integer getMaxPoolSize();

    @Property(propertyName = "idle.timeout.ms")
    Long getIdleTimeoutMs();

    @Property(propertyName = "max.lifetime.ms")
    Long getMaxLifetimeMs();

    @Property(propertyName = "connection.timeout.ms")
    Long getConnectionTimeoutMs();
}
