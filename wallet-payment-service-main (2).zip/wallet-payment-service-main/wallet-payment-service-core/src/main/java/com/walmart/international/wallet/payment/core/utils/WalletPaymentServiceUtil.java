package com.walmart.international.wallet.payment.core.utils;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Component
public class WalletPaymentServiceUtil {

    public static class GiftCardPaymentInstrumentListSortingComparator implements Comparator<GiftCardPaymentInstrument> {
        @Override
        public int compare(GiftCardPaymentInstrument o1, GiftCardPaymentInstrument o2) {
            if (o1.equals(o2))
                return 0;

            if (isB2BCard(o1) && isB2BCard(o2)) {
                if (o1.getCompany().getIsVale())
                    return -1;
                if (o2.getCompany().getIsVale())
                    return 1;
                int amountComparison = o2.getBalance().getCurrencyAmount().compareTo(o1.getBalance().getCurrencyAmount());
                if (amountComparison != 0)
                    return amountComparison;
                if (o1.getCompany().getCompanyName() != null && o2.getCompany().getCompanyName() != null) {
                    return o1.getCompany().getCompanyName().compareTo(o2.getCompany().getCompanyName());
                }
            }
            return o2.getCreateDate().compareTo(o1.getCreateDate());
        }
    }

    public static class CardPaymentInstrumentListSortingComparator implements Comparator<CardPaymentInstrument> {
        @Override
        public int compare(CardPaymentInstrument o1, CardPaymentInstrument o2) {
            if (o1.equals(o2))
                return 0;
            if (o1.getMetadata().getFavoriteCard() != null && o1.getMetadata().getFavoriteCard())
                return -1;
            if (o2.getMetadata().getFavoriteCard() != null && o2.getMetadata().getFavoriteCard())
                return 1;

            return o2.getCreateDate().compareTo(o1.getCreateDate());
        }
    }

    public static boolean isB2BCard(GiftCardPaymentInstrument paymentInstrument) {
        return paymentInstrument.getPaymentInstrumentSubType() != null && paymentInstrument.getPaymentInstrumentSubType().name().equals(PaymentInstrumentSubType.CORP_CARD.name());
    }

    public CoFTopupTransactionDO updateLastEventDateCheck(CoFTopupTransactionDO transactionDO, TransactionStateEnum state,
                                                          CoFTopupTxnStateReason stateReason) {
        if (state.equals(TransactionStateEnum.FAILURE)
                || state.equals(TransactionStateEnum.CANCELLED)
                || state.equals(TransactionStateEnum.SUCCESS)
                || (state.equals(TransactionStateEnum.PENDING) && stateReason.equals(CoFTopupTxnStateReason.DEBIT_3DS_GENERATED))) {
            transactionDO.updateLastEventDate();
            return transactionDO;
        }
        return transactionDO;
    }

    public BillPayTransactionDO updateLastEventDateCheck(BillPayTransactionDO transactionDO, TransactionStateEnum state, BillPayTxnStateReason stateReason){
        if (state.equals(TransactionStateEnum.FAILURE)
                || state.equals(TransactionStateEnum.CANCELLED)
                || state.equals(TransactionStateEnum.SUCCESS)
                || (state.equals(TransactionStateEnum.PENDING) && stateReason.equals(BillPayTxnStateReason.TOPUP_3DS_GENERATED ))) {
            transactionDO.updateLastEventDate();
            return transactionDO;
        }
        return transactionDO;
    }

    public void throwExceptionForCardPaymentFailureBasedOnFailureCode(String failureCode, String msg, boolean isValidateCharge) {
        if (Objects.nonNull(failureCode)) {
            switch (failureCode) {
                case "CHARGE-10001":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_REFER_TO_CARD_ISSUER, msg);
                case "VALIDATECHARGE-10001":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_REFER_TO_CARD_ISSUER, msg);
                case "CHARGE-10003":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_DO_NOT_HONOR, msg);
                case "VALIDATECHARGE-10003":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_DO_NOT_HONOR, msg);
                case "CHARGE-10005":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_CARD_FORMAT_ERROR, msg);
                case "VALIDATECHARGE-10005":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_CARD_FORMAT_ERROR, msg);
                case "CHARGE-10009":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_EXPIRED_CARD, msg);
                case "VALIDATECHARGE-10009":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_EXPIRED_CARD, msg);
                case "CHARGE-10012":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_INCORRECT_CVV, msg);
                case "VALIDATECHARGE-10012":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_INCORRECT_CVV, msg);
                case "CHARGE-10024":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_INSUFFICIENT_FUNDS, msg);
                case "VALIDATECHARGE-10024":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_INSUFFICIENT_FUNDS, msg);
                case "CHARGE-10031":
                    throw new BusinessValidationException(ErrorConstants.CoFTopup.CARD_PAYMENT_FAILURE_RESTRICTED_CARD, msg);
                case "VALIDATECHARGE-10031":
                    throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.CARD_PAYMENT_FAILURE_RESTRICTED_CARD, msg);
                default:
                    if (isValidateCharge) {
                        throw new BusinessValidationException(ErrorConstants.ValidateCoFTopup.VALIDATE_CHARGE_PAYMENT_CORE_CONTINUE_PAY_FAILED, msg);
                    } else {
                        throw new BusinessValidationException(ErrorConstants.CoFTopup.CHARGE_CARD_PAYMENT_CORE_PAY_FAILED, msg);
                    }
            }
        } else {
            if (isValidateCharge) {
                throw new ProcessingException(ErrorConstants.ValidateCoFTopup.VALIDATE_CHARGE_PAYMENT_CORE_CONTINUE_PAY_FAILED, msg);
            } else {
                throw new ProcessingException(ErrorConstants.CoFTopup.CHARGE_CARD_PAYMENT_CORE_PAY_FAILED, msg);
            }
        }
    }

    public static Collection<CustomerBillAccountDO> deDupeCBAEntriesBasedOnUniqueConstraint(List<CustomerBillAccountDO> customerBillAccountDOList) {
        Map<String, CustomerBillAccountDO> map = new HashMap<>();
        customerBillAccountDOList.forEach(customerBillAccountDO -> {
            if (map.containsKey(customerBillAccountDO.getUniqueKeyUsingBillerIdAndAccountNumber())) {
                CustomerBillAccountDO customerBillAccountDOFromMap = map.get(customerBillAccountDO.getUniqueKeyUsingBillerIdAndAccountNumber());
                if (customerBillAccountDOFromMap.getUpdateDate().isAfter(customerBillAccountDO.getUpdateDate())) {
                    return;
                }
            }
            map.put(customerBillAccountDO.getUniqueKeyUsingBillerIdAndAccountNumber(), customerBillAccountDO);
        });
        return map.values();
    }
}
