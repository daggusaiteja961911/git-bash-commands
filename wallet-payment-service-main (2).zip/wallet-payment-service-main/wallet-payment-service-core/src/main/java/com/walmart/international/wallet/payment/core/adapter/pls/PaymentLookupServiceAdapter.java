package com.walmart.international.wallet.payment.core.adapter.pls;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentLookupServiceConfig;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.request.AMLValidationRequest;
import com.walmart.international.wallet.payment.core.domain.model.response.AMLValidationResponse;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
public class PaymentLookupServiceAdapter {

    @Autowired
    @Qualifier("plsWebClient")
    private WebClientV2 webClientV2;

    @ManagedConfiguration
    private PaymentLookupServiceConfig lookupServiceConfig;

    private HttpHeaders getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("WM_QOS.CORRELATION_ID", MDC.get("WM_QOS.CORRELATION_ID"));

        return headers;
    }

    public Optional<AMLValidationResponse> validateTransactionForAmlCheck(AMLValidationRequest amlValidationRequest) throws BusinessValidationException, ProcessingException {

        log.info("Calling AMl validation  for request : [{}]", amlValidationRequest);
        HttpHeaders headers = getHeaders();
        ResponseEntity<AMLValidationResponse> amlValidationResponseResponseEntity = null;
        String amlEvalConnectionString = lookupServiceConfig.lookupServiceBaseURL() + "/v1/validate/AML";
        Optional<AMLValidationResponse> amlValidationResponse = Optional.empty();
        try {
            amlValidationResponseResponseEntity = webClientV2.post(amlEvalConnectionString, null, headers, amlValidationRequest, AMLValidationResponse.class, PLSAPIName.VALIDATE_AML);
        } catch (Throwable e) {
            log.error("Error while calling validateTransactionForAmlCheck API ", e);
            throw new ProcessingException(ErrorConstants.AML.ERROR_PROCESSING_AML_CALL, e.getMessage());
        }

        if (Objects.nonNull(amlValidationResponseResponseEntity) && amlValidationResponseResponseEntity.hasBody()
                && amlValidationResponseResponseEntity.getStatusCode() == HttpStatus.OK) {
            amlValidationResponse = Optional.of(amlValidationResponseResponseEntity.getBody());
            if (amlValidationResponse.isPresent()) {
                return amlValidationResponse;
            }
        } else if (Objects.nonNull(amlValidationResponseResponseEntity) && amlValidationResponseResponseEntity.hasBody() && amlValidationResponseResponseEntity.getStatusCode() != HttpStatus.OK) {
            handleException(amlValidationResponseResponseEntity);
        } else if (Objects.isNull(amlValidationResponseResponseEntity)) {
            handleException(amlValidationResponseResponseEntity);
        }
        return amlValidationResponse;
    }

    private void handleException(ResponseEntity<AMLValidationResponse> amlValidationResponseResponseEntity) throws BusinessValidationException, ProcessingException {

        if (Objects.isNull(amlValidationResponseResponseEntity)){
            throw new ProcessingException(ErrorConstants.AML.ERROR_PROCESSING_AML_CALL);
        }
         else if (amlValidationResponseResponseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
                || amlValidationResponseResponseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
            throw new ProcessingException(ErrorConstants.AML.ERROR_PROCESSING_AML_CALL,
                    amlValidationResponseResponseEntity.getBody().getStatusMessage());
        }
    }
}
