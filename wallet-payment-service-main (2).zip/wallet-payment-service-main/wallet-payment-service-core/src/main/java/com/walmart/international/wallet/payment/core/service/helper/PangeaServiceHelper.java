package com.walmart.international.wallet.payment.core.service.helper;

import com.walmart.international.ewallet.payment.api.GiftCardPaymentAdapter;
import com.walmart.international.ewallet.payment.api.request.UnlockGiftCardRequest;
import com.walmart.international.ewallet.payment.api.response.UnlockGiftCardResponse;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.customer.ews.request.UpdatePaymentPreferenceRequest;
import com.walmart.international.wallet.payment.core.constants.enums.AccountLockedState;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class PangeaServiceHelper {

    @Autowired
    GiftCardPaymentAdapter giftCardPaymentAdapter;

    @Autowired
    ICustomerServiceClient customerServiceClient;

    public void makePangeaUnlockCallForLockedGiftCardPaymentInstrument(List<GiftCardTransaction> giftCardTransactions, String storeId, String terminalId) {
        for (GiftCardTransaction giftCardTransaction : giftCardTransactions) {
            GiftCardPaymentInstrument giftCardPaymentInstrument = giftCardTransaction.getGiftCardPaymentInstrument();
            if (Objects.nonNull(giftCardPaymentInstrument.getGiftCardAccountLockedState()) && AccountLockedState.LOCKED.equals(giftCardPaymentInstrument.getGiftCardAccountLockedState())) {
                UnlockGiftCardRequest unlockGiftCardRequest = getUnlockGiftCardRequest(giftCardPaymentInstrument, storeId, terminalId);
                String clientReqIdPrefix = unlockGiftCardRequest.getClientRequestId();
                try {
                    unlockGiftCardRequest.setClientRequestId(clientReqIdPrefix);
                    UnlockGiftCardResponse unlockGiftCardResponse = giftCardPaymentAdapter.unlock(unlockGiftCardRequest);
                    if (Objects.nonNull(unlockGiftCardResponse) && unlockGiftCardResponse.getResult().name().equals("SUCCESS")) {
                        log.info("Pangea unlock is done successfully for giftCardPaymentInstrument with paymentInstrumentId[{}].", giftCardPaymentInstrument.getPaymentInstrumentId());
                        giftCardPaymentInstrument.setGiftCardAccountLockedState(AccountLockedState.UNLOCKED);
                        updateGiftCardStatus(giftCardPaymentInstrument.getPaymentInstrumentId(), giftCardPaymentInstrument.getGiftCardAccountLockedState());
                    }
                } catch (Exception e) {
                    log.error("Failed to call pangaea unlock for giftCardPaymentInstrument with paymentInstrumentId[{}].", giftCardPaymentInstrument.getPaymentInstrumentId(), e);
                }

            }
        }
    }

     public void updateGiftCardStatus(String paymentInstrumentId, AccountLockedState giftCardAccountLockedState) {
        UpdatePaymentPreferenceRequest request = UpdatePaymentPreferenceRequest.builder()
                .paymentPreferenceId(UUID.fromString(paymentInstrumentId))
                .accountLockedState(giftCardAccountLockedState)
                .build();
        customerServiceClient.updatePaymentPreference(request);
    }

    private UnlockGiftCardRequest getUnlockGiftCardRequest(GiftCardPaymentInstrument giftCardPaymentInstrument, String storeId, String terminalId) {
        return UnlockGiftCardRequest.builder()
                .giftCardId(giftCardPaymentInstrument.getAdapterMetadata().getPiHash())
                .clientRequestId(UUID.randomUUID().toString())
                .storeId(storeId)
                .terminalId(terminalId)
                .build();
    }

}
