package com.walmart.international.wallet.payment.core.constants.enums;

public enum PaymentInstrumentSubType {
    ASSOCIATE_FOOD_VOUCHER,
    CASHI_WALLET,
    CORP_CARD,
    CREDIT_CARD,
    DEBIT_CARD,
    PREPAID
}
