package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class CustomerBillAccountsByType {

    List<CustomerBillAccount> overDueBills;
    List<CustomerBillAccount> dueBills;
    List<CustomerBillAccount> paidBills;
}
