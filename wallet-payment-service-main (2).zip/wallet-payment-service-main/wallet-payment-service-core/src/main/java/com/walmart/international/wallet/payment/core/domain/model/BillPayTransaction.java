package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.constants.enums.BillPayTxnStateReason;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;
import lombok.experimental.SuperBuilder;
import org.apache.commons.collections.CollectionUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillPayTransaction extends Transaction {
    private BillPayPaymentOptions billPayPaymentOptions;
    private UUID billerId;
    // TODO check and correct usage of this field in payment options API
    private String billAccountNumber;
    private String processorBillerId;
    @Singular("cardPaymentTransactionList")
    private List<CardPaymentTransaction> cardPaymentTransactionList;
    @Singular("giftCardPaymentTransactionList")
    private List<GiftCardTransaction> giftCardPaymentTransactionList;
    private CustomerBillAccount customerBillAccount;
    private BillDetail billDetail;
    private CoFTopUpTransaction internalCoFTopupTransaction;
    private LocalDateTime txnReqCompletedDate;
    private BillPayTxnStateReason stateReason;
    private String accountNumber;
    private BigDecimal hoursToFulfill;
    private String authText;
    private String pin;
    private String processorTransactionId;
    // TODO: can introduce a wrapper class for storing all txn data fields

    public void setBiller(Biller biller) {
        if (Objects.isNull(this.customerBillAccount)) {
            this.customerBillAccount = new CustomerBillAccount(biller);
        } else {
            this.customerBillAccount.setBiller(biller);
        }
    }

    public Optional<UUID> getCardSubTransactionId() {
        if (CollectionUtils.isNotEmpty(this.getCardPaymentTransactionList())
                && Objects.nonNull(this.getCardPaymentTransactionList().get(0).getCardSubTransaction())) {
            return Optional.of(this.getCardPaymentTransactionList().get(0).getCardSubTransaction().getId());
        }
        return Optional.empty();
    }

}
