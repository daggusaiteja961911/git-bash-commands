package com.walmart.international.wallet.payment.core.adapter.tas;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.services.digitalwallet.httpclient.util.HttpClientException;
import com.walmart.international.services.digitalwallet.httpclient.wallet.util.DownstreamWebClientErrorHandler;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.DownstreamHTTPClientConfigs;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.impl.WebClientV2Impl;
import com.walmart.international.wallet.payment.core.config.ccm.TASServiceConfig;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import static com.walmart.international.digiwallet.service.strati.telemetry.service.constants.TelemetryConstants.EMPTY_TAG;

@Slf4j
@Configuration
public class TASWebClientConfig {
    public static final String TAS = "TAS";
    ObjectMapper objectMapper = new ObjectMapper();
    @ManagedConfiguration
    TASServiceConfig tasServiceConfig;

    @Bean("tasWebClient")
    WebClientV2 getTASWebClient() {
        DownstreamWebClientErrorHandler errorHandler = DownstreamWebClientErrorHandler.builder()
                .clientResponse4xxErrorHandler(errorResponse -> errorResponse.bodyToMono(Object.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.statusCode()));
                }))
                .clientResponse5xxErrorHandler(errorResponse -> errorResponse.bodyToMono(Object.class).flatMap(errorBody -> {
                    return Mono.error(new HttpClientException(errorBody, errorResponse.statusCode()));
                }))
                .isError((httpCode, apiName) -> httpCode < 200 || httpCode >= 300)
                .errorCodeExtractor((responseBody, apiName) -> getErrorCode(responseBody, apiName))
                .build();
        DownstreamHTTPClientConfigs pangaeaHTTPClientConfigs = DownstreamHTTPClientConfigs.builder()
                .downstreamName(TAS)
                .downstreamErrorHandler(errorHandler)
                .connectionTimeoutMillis(tasServiceConfig.getWebClientConnectionTimeoutInMillis())
                .responseTimeoutMillis(tasServiceConfig.getWebClientResponseTimeoutInMillis())
                .isSaveLogsToDBEnabled(tasServiceConfig.isSaveLogsToDBEnabled())
                .build();
        return new WebClientV2Impl(pangaeaHTTPClientConfigs);
    }

    private String getErrorCode(String responseBody, String apiName) {
//        try {
//            ArcusCreateBillResponse response = objectMapper.readValue(responseBody, ArcusCreateBillResponse.class);
//            String errorCode = response.getErrorCode();
//            return errorCode != null ? errorCode : EMPTY_TAG;
//        } catch (Exception ex) {
//            log.error("getErrorCode::EWSWebClientConfig:: Error while parsing response to fetch error-code", ex);
//        }
        return EMPTY_TAG;
    }
}
