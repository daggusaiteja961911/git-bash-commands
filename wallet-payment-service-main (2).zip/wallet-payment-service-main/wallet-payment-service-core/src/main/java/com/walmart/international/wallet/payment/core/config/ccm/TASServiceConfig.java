package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "tas-service-config")
public interface TASServiceConfig extends WebClientCCMConfigs{

    @Property(propertyName = "tas.base.url")
    String getTasBaseUrl();
}
