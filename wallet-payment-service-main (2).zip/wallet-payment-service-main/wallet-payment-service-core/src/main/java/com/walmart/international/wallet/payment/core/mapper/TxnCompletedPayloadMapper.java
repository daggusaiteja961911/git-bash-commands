package com.walmart.international.wallet.payment.core.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.CurrencyUnit;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.GCTransactionType;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.PaymentInstrumentState;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.PaymentMode;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.PaymentModeType;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.Relationship;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.State;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionSource;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionType;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.BillPayTransactionDTO;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.BinDetails;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.PaymentInstrument;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.PaymentPreference;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TransactionEventDTO;
import com.walmart.international.services.payment.core.domain.Amount;
import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import com.walmart.international.services.payment.core.response.GetTxnDetailResponse;
import com.walmart.international.wallet.payment.core.constants.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.core.constants.enums.GiftCardTransactionType;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Transaction;
import com.walmart.international.wallet.payment.core.event.dto.constants.enums.LoadTransactionStatus;
import com.walmart.international.wallet.payment.core.event.dto.constants.enums.TransactionStatus;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Mapper(imports = {TransactionSource.class, TransactionType.class, PaymentMode.class})
public interface TxnCompletedPayloadMapper {

    TxnCompletedPayloadMapper INSTANCE = Mappers.getMapper(TxnCompletedPayloadMapper.class);

    @Mapping(target = "transactionId", source = "transactionId")
    @Mapping(target = "customerAccountId", source = "customer.customerAccountId")
    @Mapping(target = "amount", source = "amountRequested.value")
    @Mapping(target = "amountSettled", source = "amountFulfilled.value")
    @Mapping(target = "currencyUnit", source = "amountRequested.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.CASHI)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.LOAD)")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForCoFTopupTransaction")
    @Mapping(target = "clientRefId", source = "clientReqId")
    @Mapping(target = "parentTransactionId", source = ".", qualifiedByName = "mapParentTransactionIdForTransaction")
    @Mapping(target = "relationship", source = ".", qualifiedByName = "mapParentTransactionRelationshipForCoFTopupTransaction")
    @Mapping(target = "paymentInstruments", source = ".", qualifiedByName = "mapPaymentInstrumentsForCoFTopupTransaction")
    TransactionEventDTO mapCoFTopupTransactionToTransactionEvent(CoFTopUpTransaction coFTopUpTransaction);

    @Mapping(target = "transactionId", source = "coFTopupTransactionId")
    @Mapping(target = "amount", source = "amountRequested")
    @Mapping(target = "amountSettled", source = "amountProcessed")
    @Mapping(target = "currencyUnit", source = "currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.CASHI)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.LOAD)")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForCoFTopupTransaction")
    @Mapping(target = "clientRefId", source = "clientReqId")
    @Mapping(target = "parentTransactionId", source = ".", qualifiedByName = "mapParentTransactionIdForCoFTopupTransaction")
    @Mapping(target = "relationship", source = ".", qualifiedByName = "mapParentTransactionRelationshipForCoFTopupTransaction")
    TransactionEventDTO mapCoFTopupTransactionDOToTransactionEvent(CoFTopupTransactionDO coFTopupTransactionDO);

    @Mapping(target = "customerAccountId", source = "customer.customerAccountId")
    @Mapping(target = "amount", source = "amountRequested.value")
    @Mapping(target = "amountSettled", source = "amountFulfilled.value")
    @Mapping(target = "currencyUnit", source = "amountRequested.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForCoFTopupTransaction")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.CASHI)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.LOAD)")
    @Mapping(target = "paymentInstruments", source = "coFTopUpTransaction", qualifiedByName = "mapCoFTopupPaymentInstrumentsForSync")
    TransactionEventDTO mapCoFTopupTransactionToTransactionEventForSync(CoFTopUpTransaction coFTopUpTransaction); // add logo as well

    @Mapping(target = "customerAccountId", source = "customer.customerAccountId")
    @Mapping(target = "amount", source = "amountRequested.value")
    @Mapping(target = "amountSettled", source = "amountRequested.value")
    @Mapping(target = "currencyUnit", source = "amountRequested.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.BILLER)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.PAY)")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForBillPayTransaction")
    @Mapping(target = "clientRefId", source = "clientReqId")
    @Mapping(target = "parentTransactionId", source = ".", qualifiedByName = "mapParentTransactionIdForTransaction")
    @Mapping(target = "billPay", source = ".")
    @Mapping(target = "paymentInstruments", source = ".", qualifiedByName = "mapPaymentInstrumentsForBillPayTransaction")
    TransactionEventDTO mapBillPayTransactionToTransactionEvent(BillPayTransaction billPayTransaction);

    @Mapping(target = "transactionId", source = "billPayTransactionId")
    @Mapping(target = "amountSettled", source = "amount")
    @Mapping(target = "currencyUnit", source = "currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.BILLER)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.PAY)")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForBillPayTransaction")
    @Mapping(target = "clientRefId", source = "clientReqId")
    @Mapping(target = "billPay", source = ".")
    TransactionEventDTO mapBillPayTransactionDOToTransactionEvent(BillPayTransactionDO billPayTransactionDO);

    @Mapping(target = "customerAccountId", source = "customer.customerAccountId")
    @Mapping(target = "amount", source = "amountRequested.value")
    @Mapping(target = "amountSettled", source = "amountRequested.value")
    @Mapping(target = "currencyUnit", source = "amountRequested.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForBillPayTransaction")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.BILLER)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.PAY)")
    @Mapping(target = "paymentInstruments", source = "billPayTransaction", qualifiedByName = "mapBillPayPaymentInstrumentsForSync")
    TransactionEventDTO mapBillPayTransactionToTransactionEventForSync(BillPayTransaction billPayTransaction); // add logo as well

    @Mapping(target = "amountSettled", source = "amount")
    @Mapping(target = "currencyUnit", source = "currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "state", source = "state", qualifiedByName = "mapTransactionState")
    @Mapping(target = "stateReason", source = "stateReason", qualifiedByName = "mapTransactionStateReasonForBillPayTransaction")
    @Mapping(target = "createdDate", source = "createDate")
    @Mapping(target = "updatedDate", source = "updateDate")
    @Mapping(target = "transactionId", source = "billPayTransactionId")
    @Mapping(target = "transactionSource", expression = "java(TransactionSource.BILLER)")
    @Mapping(target = "transactionType", expression = "java(TransactionType.PAY)")
    TransactionEventDTO mapBillPayTransactionDOToTransactionEventForSync(BillPayTransactionDO billPayTransactionDO); // add logo as well

    @Named("mapCoFTopupPaymentInstrumentsForSync")
    default List<PaymentInstrument> mapCoFTopupPaymentInstrumentsForSync(CoFTopUpTransaction coFTopUpTransaction) {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<GiftCardTransaction> giftCardLoadTransactionList = coFTopUpTransaction.getGiftCardLoadTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = coFTopUpTransaction.getCardPaymentTransactionList();

        if (CollectionUtils.isNotEmpty(giftCardLoadTransactionList)) {
            giftCardLoadTransactionList.forEach(giftCardTransaction -> {
                if (Objects.nonNull(giftCardTransaction.getGiftCardSubTransaction())) {
                    paymentInstruments.add(mapPaymentInstrumentFromGiftCardTransactionForSync(giftCardTransaction));
                }
            });
        }
        if (CollectionUtils.isNotEmpty(cardPaymentTransactionList)) {
            cardPaymentTransactionList.forEach(cardPaymentTransaction -> {
                if (Objects.nonNull(cardPaymentTransaction.getCardSubTransaction())) {
                    paymentInstruments.add(mapPaymentInstrumentFromCardPaymentTransactionForSync(cardPaymentTransaction));
                }
            });
        }

        return paymentInstruments;
    }

    @Named("mapBillPayPaymentInstrumentsForSync")
    default List<PaymentInstrument> mapBillPayPaymentInstrumentsForSync(BillPayTransaction billPayTransaction) {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<GiftCardTransaction> giftCardPaymentTransactionList = billPayTransaction.getGiftCardPaymentTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = billPayTransaction.getCardPaymentTransactionList();

        if (CollectionUtils.isNotEmpty(giftCardPaymentTransactionList)) {
            giftCardPaymentTransactionList.forEach(giftCardTransaction -> {
                if (Objects.nonNull(giftCardTransaction.getGiftCardSubTransaction())) {
                    paymentInstruments.add(mapPaymentInstrumentFromGiftCardTransactionForSync(giftCardTransaction));
                }
            });
        }
        if (CollectionUtils.isNotEmpty(cardPaymentTransactionList)) {
            cardPaymentTransactionList.forEach(cardPaymentTransaction -> {
                if (Objects.nonNull(cardPaymentTransaction.getCardSubTransaction())) {
                    paymentInstruments.add(mapPaymentInstrumentFromCardPaymentTransactionForSync(cardPaymentTransaction));
                }
            });
        }

        return paymentInstruments;
    }

    default PaymentInstrument mapPaymentInstrumentFromGiftCardTransactionForSync(GiftCardTransaction giftCardTransaction) {
        PaymentInstrument paymentInstrument = new PaymentInstrument();
        paymentInstrument.setId(giftCardTransaction.getGiftCardSubTransaction().getId());
        paymentInstrument.setType(PaymentMode.GIFTCARD);
        paymentInstrument.setTransactionState(mapGiftCardPaymentInstrumentState(giftCardTransaction.getGiftCardSubTransaction().getStatus()));
        paymentInstrument.setTransactionType(mapGiftCardTransactionType(giftCardTransaction.getGiftCardTransactionType()));
        paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(giftCardTransaction.getGiftCardSubTransaction().getCreateDate()));
        paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(giftCardTransaction.getGiftCardSubTransaction().getUpdateDate()));
        paymentInstrument.setIsVale(mapIsVale(giftCardTransaction));
        paymentInstrument.setAmount(giftCardTransaction.getAmount().getValue());

        if (Objects.nonNull(giftCardTransaction.getGiftCardPaymentInstrument())) {
            paymentInstrument.setPaymentPreference(mapToPaymentPreferenceFromGiftCardPaymentInstrument(giftCardTransaction.getGiftCardPaymentInstrument()));
        }
        return paymentInstrument;
    }

    default PaymentInstrument mapPaymentInstrumentFromGiftCardSubTransactionDetailForSync(GetTxnDetailResponse.GiftCardSubTransactionDetail giftCardSubTransactionDetail) {
        PaymentInstrument paymentInstrument = new PaymentInstrument();
        paymentInstrument.setId(giftCardSubTransactionDetail.getId());
        paymentInstrument.setType(PaymentMode.GIFTCARD);
        paymentInstrument.setTransactionState(mapGiftCardPaymentInstrumentState(giftCardSubTransactionDetail.getStatus()));
        paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(giftCardSubTransactionDetail.getCreateDate()));
        paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(giftCardSubTransactionDetail.getUpdateDate()));
        return paymentInstrument;
    }

    default PaymentInstrument mapPaymentInstrumentFromCardPaymentTransactionForSync(CardPaymentTransaction cardPaymentTransaction) {
        PaymentInstrument paymentInstrument = new PaymentInstrument();
        paymentInstrument.setId(cardPaymentTransaction.getCardSubTransaction().getId());
        paymentInstrument.setType(PaymentMode.CARD);
        paymentInstrument.setTransactionState(mapCardPaymentInstrumentState(cardPaymentTransaction.getCardSubTransaction().getStatus()));
        // As on today, vale card is not allowed in the cards
        paymentInstrument.setIsVale(false);
        paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(cardPaymentTransaction.getCardSubTransaction().getCreateDate()));
        paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(cardPaymentTransaction.getCardSubTransaction().getUpdateDate()));
        paymentInstrument.setAmount(cardPaymentTransaction.getAmount().getValue());

        if (Objects.nonNull(cardPaymentTransaction.getCardPaymentInstrument())) {
            paymentInstrument.setPaymentPreference(mapToPaymentPreferenceFromCardPaymentInstrument(cardPaymentTransaction.getCardPaymentInstrument()));
        }
        return paymentInstrument;
    }

    default PaymentInstrument mapPaymentInstrumentFromCardSubTransactionDetailForSync(GetTxnDetailResponse.CardSubTransactionDetail cardSubTransactionDetail) {
        PaymentInstrument paymentInstrument = new PaymentInstrument();
        paymentInstrument.setId(cardSubTransactionDetail.getId());
        paymentInstrument.setType(PaymentMode.CARD);
        paymentInstrument.setTransactionState(mapCardPaymentInstrumentState(cardSubTransactionDetail.getStatus()));
        // As on today, vale card is not allowed in the cards
        paymentInstrument.setIsVale(false);
        paymentInstrument.setSrcTxnCreatedAt(toLocalDateTime(cardSubTransactionDetail.getCreateDate()));
        paymentInstrument.setSrcTxnUpdatedAt(toLocalDateTime(cardSubTransactionDetail.getUpdateDate()));
        return paymentInstrument;
    }


    private Boolean mapIsVale(GiftCardTransaction giftCardTransaction) {
        if (Objects.isNull(giftCardTransaction) || Objects.isNull(giftCardTransaction.getGiftCardPaymentInstrument()) ||
                Objects.isNull(giftCardTransaction.getGiftCardPaymentInstrument().getCompany())) {
            return false;
        } else {
            return giftCardTransaction.getGiftCardPaymentInstrument().getCompany().getIsVale();
        }
    }

    @Named("mapCurrencyUnit")
    default CurrencyUnit mapCurrencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit currencyUnit) {
        if (Objects.nonNull(currencyUnit)
                && (currencyUnit == com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.MXN)) {
            return CurrencyUnit.MXN;
        }
        return null;
    }

    @Named("mapCurrencyUnit")
    default CurrencyUnit mapCurrencyUnit(com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit currencyUnit) {
        if (Objects.nonNull(currencyUnit)
                && (currencyUnit == com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit.MXN)) {
            return CurrencyUnit.MXN;
        }
        return null;
    }

    @Named("mapCurrencyUnit")
    default CurrencyUnit mapCurrencyUnit(Amount.CurrencyUnit currencyUnit) {
        if (Objects.nonNull(currencyUnit) && (currencyUnit == Amount.CurrencyUnit.MXN)) {
            return CurrencyUnit.MXN;
        }
        return null;
    }

    @Named("mapTransactionState")
    default State mapTransactionState(TransactionStateEnum transactionState) {
        if (Objects.nonNull(transactionState)) {
            switch (transactionState) {
                case SUCCESS:
                    return State.SUCCESS;
                case FAILURE:
                case CANCELLED:
                    return State.FAILURE;
                case PENDING:
                    return State.PENDING;
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapTransactionState")
    default State mapTransactionState(com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum transactionState) {
        if (Objects.nonNull(transactionState)) {
            switch (transactionState) {
                case SUCCESS:
                    return State.SUCCESS;
                case FAILURE:
                case CANCELLED:
                    return State.FAILURE;
                case PENDING:
                    return State.PENDING;
                default:
                    return null;
            }
        }
        return null;
    }

    // TODO: this mapping has to be replaced in future to make use of stateReason from V2. Currently V2 stateReasons are mapped to V1 stateReasons
    @Named("mapTransactionStateReasonForCoFTopupTransaction")
    default String mapTransactionStateReasonForCoFTopupTransaction(CoFTopupTxnStateReason coFTopupTxnStateReason) {
        if (Objects.nonNull(coFTopupTxnStateReason)) {
            switch (coFTopupTxnStateReason) {
                case DEBIT_FAILED:
                    return LoadTransactionStatus.CHARGE_FAILED.name();
                case CREDIT_FAILED:
                case DEBIT_REVERSAL_INITIATED:
                case DEBIT_REVERSAL_PENDING:
                    return LoadTransactionStatus.REVERSE_INITIATED.name();
                case DEBIT_REVERSAL_FAILED:
                case DEBIT_REVERSAL_INIT_FAILED:
                    return LoadTransactionStatus.REVERSE_INITIATION_FAILED.name();
                case DEBIT_3DS_GENERATED:
                    return LoadTransactionStatus.CHARGE_INITIATED.name();
                case CREDIT_SUCCESS:
                    return LoadTransactionStatus.PANGEA_UNLOCK_SUCCESS.name();
                case CREDIT_SUCCESS_WITH_LOCK:
                    return LoadTransactionStatus.PANGEA_UNLOCK_FAIL.name();
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapTransactionStateReasonForCoFTopupTransaction")
    default String mapTransactionStateReasonForCoFTopupTransaction(com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason coFTopupTxnStateReason) {
        if (Objects.nonNull(coFTopupTxnStateReason)) {
            switch (coFTopupTxnStateReason) {
                case DEBIT_FAILED:
                    return LoadTransactionStatus.CHARGE_FAILED.name();
                case CREDIT_FAILED:
                case DEBIT_REVERSAL_INITIATED:
                case DEBIT_REVERSAL_PENDING:
                    return LoadTransactionStatus.REVERSE_INITIATED.name();
                case DEBIT_REVERSAL_FAILED:
                case DEBIT_REVERSAL_INIT_FAILED:
                    return LoadTransactionStatus.REVERSE_INITIATION_FAILED.name();
                case DEBIT_3DS_GENERATED:
                    return LoadTransactionStatus.CHARGE_INITIATED.name();
                case CREDIT_SUCCESS:
                    return LoadTransactionStatus.PANGEA_UNLOCK_SUCCESS.name();
                case CREDIT_SUCCESS_WITH_LOCK:
                    return LoadTransactionStatus.PANGEA_UNLOCK_FAIL.name();
                default:
                    return null;
            }
        }
        return null;
    }

    // TODO: this mapping has to be replaced in future to make use of stateReason from V2. Currently V2 stateReasons are mapped to V1 stateReasons
    @Named("mapTransactionStateReasonForBillPayTransaction")
    default String mapTransactionStateReasonForBillPayTransaction(BillPayTxnStateReason billPayTxnStateReason) {
        if (Objects.nonNull(billPayTxnStateReason)) {
            switch (billPayTxnStateReason) {
                case TOPUP_3DS_GENERATED:
                    return TransactionStatus.PENDING_3DS_GENERATED.name();
                case TOPUP_3DS_ACKNOWELDGED:
                    return TransactionStatus.PENDING_3DS_ACKNOWLEDGED.name();
                case TOPUP_3DS_CANCELLED:
                    return TransactionStatus.PENDING_3DS_CANCELLED.name();
                case BILL_PROCESSOR_PAYMENT_SUCCESS:
                    return TransactionStatus.REGALII_PAY_BILL_SUCCESS.name();
                case TOPUP_FAILED:
                case TOPUP_3DS_FAILED:
                case DEBIT_FAILED:
                    return TransactionStatus.AUTHORIZE_PAY_BILL_FAIL.name();
                case DEBIT_REVERSAL_SUCCESS:
                    return TransactionStatus.REVERSE_AUTHORIZE_SUCCESS.name();
                case DEBIT_REVERSAL_INITIATED:
                case DEBIT_REVERSAL_INIT_FAILED:
                    return TransactionStatus.REVERSE_AUTHORIZE_FAIL.name();
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapTransactionStateReasonForBillPayTransaction")
    default String mapTransactionStateReasonForBillPayTransaction(com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason billPayTxnStateReason) {
        if (Objects.nonNull(billPayTxnStateReason)) {
            switch (billPayTxnStateReason) {
                case TOPUP_3DS_GENERATED:
                    return TransactionStatus.PENDING_3DS_GENERATED.name();
                case TOPUP_3DS_ACKNOWELDGED:
                    return TransactionStatus.PENDING_3DS_ACKNOWLEDGED.name();
                case TOPUP_3DS_CANCELLED:
                    return TransactionStatus.PENDING_3DS_CANCELLED.name();
                case BILL_PROCESSOR_PAYMENT_SUCCESS:
                    return TransactionStatus.REGALII_PAY_BILL_SUCCESS.name();
                case TOPUP_FAILED:
                case TOPUP_3DS_FAILED:
                case DEBIT_FAILED:
                    return TransactionStatus.AUTHORIZE_PAY_BILL_FAIL.name();
                case DEBIT_REVERSAL_SUCCESS:
                    return TransactionStatus.REVERSE_AUTHORIZE_SUCCESS.name();
                case DEBIT_REVERSAL_INITIATED:
                case DEBIT_REVERSAL_INIT_FAILED:
                    return TransactionStatus.REVERSE_AUTHORIZE_FAIL.name();
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapParentTransactionIdForTransaction")
    default UUID mapParentTransactionIdForTransaction(Transaction transaction) {
        if (Objects.nonNull(transaction.getParentTransaction())) {
            return transaction.getParentTransaction().getTransactionId();
        }
        return null;
    }

    @Named("mapParentTransactionIdForCoFTopupTransaction")
    default UUID mapParentTransactionIdForCoFTopupTransaction(CoFTopupTransactionDO coFTopupTransactionDO) {
        if (Objects.nonNull(coFTopupTransactionDO.getTxnReferenceId())) {
            return UUID.fromString(coFTopupTransactionDO.getTxnReferenceId());
        }
        return null;
    }

    @Named("mapParentTransactionRelationshipForCoFTopupTransaction")
    default Relationship mapParentTransactionRelationshipForCoFTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        if (Objects.nonNull(coFTopUpTransaction.getParentTransaction())) {
            return Relationship.LOAD;
        }
        return null;
    }

    @Named("mapParentTransactionRelationshipForCoFTopupTransaction")
    default Relationship mapParentTransactionRelationshipForCoFTopupTransaction(CoFTopupTransactionDO coFTopupTransactionDO) {
        if (Objects.nonNull(coFTopupTransactionDO.getTxnReferenceId())) {
            return Relationship.LOAD;
        }
        return null;
    }

    @Mapping(target = "billerId", source = "customerBillAccount.biller.processorBillerId")
    @Mapping(target = "hoursToFulfil", source = "customerBillAccount.biller.hoursToFulfill", defaultValue = "0")
    @Mapping(target = "billPayTransactionId", source = "transactionId")
    @Mapping(target = "billerName", source = "customerBillAccount.biller.displayName")
    @Mapping(target = "billerLogo", source = "customerBillAccount.biller.imageURL")
    @Mapping(target = "termsAndConditions", source = "customerBillAccount.biller.termsAndConditions")
    @Mapping(target = "redeemUrl", source = "customerBillAccount.biller.redeemURL")
    @Mapping(target = "redeemInstructions", source = "customerBillAccount.biller.redeemInstructions")
    @Mapping(target = "itemName", source = "billDetail.name")
    @Mapping(target = "information", source = "customerBillAccount.biller.information")
    @Mapping(target = "arcusTransactionId", source = "processorTransactionId")
    BillPayTransactionDTO mapBillPayTransactionDTOFromBillPayTransaction(BillPayTransaction billPayTransaction);

    @Mapping(target = "billerId", source = "billerDO.processorBillerId")
    @Mapping(target = "hoursToFulfil", source = "hoursToFulfill", defaultValue = "0")
    @Mapping(target = "billerName", source = "billerDO.displayName")
    @Mapping(target = "billerLogo", source = "billerDO.imageURL")
    @Mapping(target = "termsAndConditions", source = "billerDO.termsAndConditions")
    @Mapping(target = "redeemUrl", source = "billerDO.redeemURL")
    @Mapping(target = "redeemInstructions", source = "billerDO.redeemInstructions")
    @Mapping(target = "itemName", source = "billDetailDO.name")
    @Mapping(target = "information", source = "billerDO.information")
    @Mapping(target = "arcusTransactionId", source = "processorTransactionId")
    BillPayTransactionDTO mapBillPayTransactionDTOFromBillPayTransactionDO(BillPayTransactionDO billPayTransactionDO);

    @Named("mapPaymentInstrumentsForCoFTopupTransaction")
    default List<PaymentInstrument> mapPaymentInstrumentsForCoFTopupTransaction(CoFTopUpTransaction coFTopUpTransaction) {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<GiftCardTransaction> giftCardLoadTransactionList = coFTopUpTransaction.getGiftCardLoadTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = coFTopUpTransaction.getCardPaymentTransactionList();

        if (CollectionUtils.isNotEmpty(giftCardLoadTransactionList)) {
            giftCardLoadTransactionList.forEach(giftCardLoadTransaction -> {
                if (Objects.nonNull(giftCardLoadTransaction.getGiftCardSubTransaction())) {
                    paymentInstruments.add(mapToPaymentInstrumentFromGiftCardTransaction(giftCardLoadTransaction));
                }
            });
        }
        if (CollectionUtils.isNotEmpty(cardPaymentTransactionList)) {
            cardPaymentTransactionList.forEach(cardPaymentTransaction -> {
                if (Objects.nonNull(cardPaymentTransaction.getCardSubTransaction())) {
                    paymentInstruments.add(mapToPaymentInstrumentFromCardPaymentTransaction(cardPaymentTransaction));
                }
            });
        }
        return paymentInstruments;
    }

    @Named("mapPaymentInstrumentsForBillPayTransaction")
    default List<PaymentInstrument> mapPaymentInstrumentsForBillPayTransaction(BillPayTransaction billPayTransaction) {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<GiftCardTransaction> giftCardPaymentTransactionList = billPayTransaction.getGiftCardPaymentTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = billPayTransaction.getCardPaymentTransactionList();

        if (CollectionUtils.isNotEmpty(giftCardPaymentTransactionList)) {
            giftCardPaymentTransactionList.forEach(giftCardPaymentTransaction -> {
                if (Objects.nonNull(giftCardPaymentTransaction.getGiftCardSubTransaction())) {
                    paymentInstruments.add(mapToPaymentInstrumentFromGiftCardTransaction(giftCardPaymentTransaction));
                }
            });
        }
        if (CollectionUtils.isNotEmpty(cardPaymentTransactionList)) {
            cardPaymentTransactionList.forEach(cardPaymentTransaction -> {
                if (Objects.nonNull(cardPaymentTransaction.getCardSubTransaction())) {
                    paymentInstruments.add(mapToPaymentInstrumentFromCardPaymentTransaction(cardPaymentTransaction));
                }
            });
        }
        return paymentInstruments;
    }

    @Mapping(target = "approvalCode", source = "giftCardSubTransaction.authCode")
    @Mapping(target = "transactionStateReason", source = "giftCardSubTransaction.status")
    @Mapping(target = "srcTxnCreatedAt", source = "giftCardSubTransaction.createDate")
    @Mapping(target = "srcTxnUpdatedAt", source = "giftCardSubTransaction.updateDate")
    @Mapping(target = "id", source = "giftCardSubTransaction.id")
    @Mapping(target = "parentPaymentPreferenceId", source = "giftCardPaymentInstrument.parentPaymentPreferenceId")
    @Mapping(target = "amount", source = "giftCardSubTransaction.amount.value")
    @Mapping(target = "paymentPreference", source = "giftCardPaymentInstrument")
    @Mapping(target = "failureReason", source = "giftCardSubTransaction.failureDescription")
    @Mapping(target = "currencyCode", source = "giftCardSubTransaction.amount.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionState", source = "giftCardSubTransaction.status", qualifiedByName = "mapGiftCardPaymentInstrumentState")
    @Mapping(target = "type", expression = "java(PaymentMode.GIFTCARD)")
    @Mapping(target = "transactionType", source = "giftCardTransactionType")
    PaymentInstrument mapToPaymentInstrumentFromGiftCardTransaction(GiftCardTransaction giftCardTransaction);

    @Mapping(target = "approvalCode", source = "authCode")
    @Mapping(target = "transactionStateReason", source = "status")
    @Mapping(target = "srcTxnCreatedAt", source = "createDate")
    @Mapping(target = "srcTxnUpdatedAt", source = "updateDate")
    @Mapping(target = "amount", source = "amount.amount")
    @Mapping(target = "failureReason", source = "failureDescription")
    @Mapping(target = "currencyCode", source = "amount.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionState", source = "status", qualifiedByName = "mapGiftCardPaymentInstrumentState")
    @Mapping(target = "type", expression = "java(PaymentMode.GIFTCARD)")
    PaymentInstrument mapToPaymentInstrumentFromGiftCardSubTransactionDetail(GetTxnDetailResponse.GiftCardSubTransactionDetail giftCardSubTransactionDetail);

    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "paymentType", source = "paymentInstrumentSubType")
    @Mapping(target = "paymentId", source = "paymentInstrumentId")
    PaymentPreference mapToPaymentPreferenceFromGiftCardPaymentInstrument(GiftCardPaymentInstrument giftCardPaymentInstrument);

    @Mapping(target = "pbAuthCode", source = "cardSubTransaction.authCode")
    @Mapping(target = "pbAffiliateId", source = "cardSubTransaction.paymentProviderAffiliateId")
    @Mapping(target = "msiInstallment", source = "cardSubTransaction.msiInstallmentCount")
    @Mapping(target = "srcTxnCreatedAt", source = "cardSubTransaction.createDate")
    @Mapping(target = "srcTxnUpdatedAt", source = "cardSubTransaction.updateDate")
    @Mapping(target = "id", source = "cardSubTransaction.id")
    @Mapping(target = "msiMonthlyAmount", source = "cardSubTransaction.msiAmount")
    @Mapping(target = "pbTxnId", source = "cardSubTransaction.paymentProviderTxnId")
    @Mapping(target = "pgTransactionDate", source = "cardSubTransaction.paymentGatewayTxnDate")
    @Mapping(target = "amount", source = "cardSubTransaction.amount.value")
    @Mapping(target = "threeDSUrl", source = "redirect3DSURL")
    @Mapping(target = "redirectUrl", source = "redirectCashiURL")
    @Mapping(target = "pbFraudStatus", source = "cardSubTransaction.paymentProviderFraudStatus")
    @Mapping(target = "paymentPreference", source = "cardPaymentInstrument")
    @Mapping(target = "msiSchemeId", source = "cardSubTransaction.msiSchemeId")
    @Mapping(target = "failureReason", source = "cardSubTransaction.failureDescription")
    @Mapping(target = "currencyCode", source = "cardSubTransaction.amount.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionState", source = "cardSubTransaction.status", qualifiedByName = "mapCardPaymentInstrumentState")
    @Mapping(target = "transactionStateReason", source = "cardSubTransaction.status")
    @Mapping(target = "type", expression = "java(PaymentMode.CARD)")
    PaymentInstrument mapToPaymentInstrumentFromCardPaymentTransaction(CardPaymentTransaction cardPaymentTransaction);

    @Mapping(target = "pbAuthCode", source = "authCode")
    @Mapping(target = "pbAffiliateId", source = "paymentProviderAffiliateId")
    @Mapping(target = "msiInstallment", source = "msiInstallmentCount")
    @Mapping(target = "srcTxnCreatedAt", source = "createDate")
    @Mapping(target = "srcTxnUpdatedAt", source = "updateDate")
    @Mapping(target = "pbTxnId", source = "paymentProviderTxnId")
    @Mapping(target = "pgTransactionDate", source = "paymentGatewayTxnDate")
    @Mapping(target = "amount", source = "amount.amount")
    @Mapping(target = "threeDSUrl", source = "redirect3DSURL")
    @Mapping(target = "pbFraudStatus", source = "paymentProviderFraudStatus")
    @Mapping(target = "failureReason", source = "failureDescription")
    @Mapping(target = "currencyCode", source = "amount.currencyUnit", qualifiedByName = "mapCurrencyUnit")
    @Mapping(target = "transactionState", source = "status", qualifiedByName = "mapCardPaymentInstrumentState")
    @Mapping(target = "transactionStateReason", source = "status")
    @Mapping(target = "type", expression = "java(PaymentMode.CARD)")
    PaymentInstrument mapToPaymentInstrumentFromCardSubTransactionDetail(GetTxnDetailResponse.CardSubTransactionDetail cardSubTransactionDetail);

    @Mapping(target = "binDetails", source = "binDetails", qualifiedByName = "mapToBinDetailsFromCardPaymentInstrument")
    @Mapping(target = "aliasName", source = "metadata.aliasName")
    @Mapping(target = "paymentType", source = "paymentInstrumentSubType")
    @Mapping(target = "maskedNumber", source = "metadata.cardNumber")
    @Mapping(target = "paymentId", source = "paymentInstrumentId")
    @Mapping(target = "cardholderName", source = "metadata.cardholderName")
    @Mapping(target = "billingAddress", source = "billingAddress")
    @Mapping(target = "brand", source = "metadata.brand")
    @Mapping(target = "last4Digits", source = "metadata.last4Digits")
    PaymentPreference mapToPaymentPreferenceFromCardPaymentInstrument(CardPaymentInstrument cardPaymentInstrument);

    @Named("mapToBinDetailsFromCardPaymentInstrument")
    default BinDetails mapToBinDetailsFromCardPaymentInstrument(CardPaymentInstrument.BinDetails binDetailsFromCardPaymentInstrument) {
        if (binDetailsFromCardPaymentInstrument == null) {
            return null;
        }
        BinDetails binDetails = new BinDetails();
        binDetails.setBankColor(binDetailsFromCardPaymentInstrument.getBankColor());
        binDetails.setBankName(binDetailsFromCardPaymentInstrument.getBankName());
        binDetails.setBrandName(binDetailsFromCardPaymentInstrument.getBrandName());
        binDetails.setBrandLogo(binDetailsFromCardPaymentInstrument.getBankLogo());
        binDetails.setBankLogo(binDetailsFromCardPaymentInstrument.getBankLogo());
        binDetails.setTextColor(binDetailsFromCardPaymentInstrument.getTextColor());
        binDetails.setBin(Integer.parseInt(binDetailsFromCardPaymentInstrument.getBin()));
        return binDetails;
    }

    default PaymentModeType mapPaymentType(PaymentInstrumentSubType paymentType) {
        if (paymentType == null) {
            return null;
        }
        PaymentModeType paymentModeType;
        switch (paymentType) {
            case CREDIT_CARD:
                paymentModeType = PaymentModeType.CREDIT;
                break;
            case DEBIT_CARD:
                paymentModeType = PaymentModeType.DEBIT;
                break;
            case CASHI_WALLET:
                paymentModeType = PaymentModeType.GIFTCARD;
                break;
            case CORP_CARD:
            case ASSOCIATE_FOOD_VOUCHER:
                paymentModeType = PaymentModeType.CORPGIFTCARD;
                break;
            default:
                throw new IllegalArgumentException("Unexpected enum constant: " + paymentType);
        }
        return paymentModeType;
    }

    default String mapBillingAddress(CardPaymentInstrument.BillingAddress billingAddress) {
        try {
            return new ObjectMapper().writeValueAsString(billingAddress);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    @Named("mapGiftCardPaymentInstrumentState")
    default PaymentInstrumentState mapGiftCardPaymentInstrumentState(SubTransactionStatusV2 subTransactionStatus) {
        if (Objects.nonNull(subTransactionStatus)) {
            switch (subTransactionStatus) {
                case LOAD_REQUESTED:
                case LOAD_PROCESSING:
                case PAYMENT_PENDING:
                case PAYMENT_ON_HOLD:
                    return PaymentInstrumentState.PENDING;
                case LOAD_SUCCEEDED:
                case PAYMENT_SUCCEEDED:
                    return PaymentInstrumentState.SUCCESS;
                case LOAD_FAILED:
                case PAYMENT_FAILED:
                case PAYMENT_CANCELLED:
                    return PaymentInstrumentState.FAILURE;
                case REVERSAL_INITIATED:
                    return PaymentInstrumentState.REVERSAL_INITIATED;
                case REVERSAL_FAILED:
                    return PaymentInstrumentState.REVERSAL_FAILED;
                case REVERSAL_PROCESSING:
                    return PaymentInstrumentState.REVERSAL_PENDING;
                case REVERSAL_SUCCEEDED:
                    return PaymentInstrumentState.REVERSED;
                default:
                    return null;
            }
        }
        return null;
    }

    @Named("mapCardPaymentInstrumentState")
    default PaymentInstrumentState mapCardPaymentInstrumentState(SubTransactionStatusV2 subTransactionStatus) {
        if (Objects.nonNull(subTransactionStatus)) {
            switch (subTransactionStatus) {
                case PAYMENT_SUCCEEDED:
                    return PaymentInstrumentState.SUCCESS;
                case PAYMENT_PROCESSING:
                case PAYMENT_PENDING:
                case PAYMENT_3DS_PENDING:
                    return PaymentInstrumentState.PENDING;
                case PAYMENT_FAILED:
                case PAYMENT_REJECTED:
                    return PaymentInstrumentState.FAILURE;
                case REVERSAL_INITIATED:
                    return PaymentInstrumentState.REVERSAL_INITIATED;
                case REVERSAL_FAILED:
                    return PaymentInstrumentState.REVERSAL_FAILED;
                case REVERSAL_PROCESSING:
                    return PaymentInstrumentState.REVERSAL_PENDING;
                case REVERSAL_SUCCEEDED:
                    return PaymentInstrumentState.REVERSED;
                case PAYMENT_CANCELLED:
                    return PaymentInstrumentState.CANCELLED;
                default:
                    return null;
            }
        }
        return null;
    }

    default GCTransactionType mapGiftCardTransactionType(GiftCardTransactionType giftCardTransactionType) {
        if (Objects.nonNull(giftCardTransactionType)) {
            switch (giftCardTransactionType) {
                case LOAD:
                    return GCTransactionType.ADD_BALANCE;
                case PAY:
                    return GCTransactionType.AUTHORIZE;
                default:
                    return null;
            }
        }
        return null;
    }

    default LocalDateTime toLocalDateTime(Date dateToConvert) {
        if (Objects.isNull(dateToConvert)) {
            return null;
        }
        return Instant.ofEpochMilli(dateToConvert.getTime())
                .atZone(ZoneId.of("UTC"))
                .toLocalDateTime();
    }

    default UUID mapStringToUUID(String string) {
        return UUID.fromString(string);
    }

    default String mapUUIDtoString(UUID uuid) {
        return String.valueOf(uuid);
    }
}
