package com.walmart.international.wallet.payment.core.adapter.tas;

import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.wallet.payment.core.adapter.tas.response.TxnEventRestConsumptionResponse;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;

public interface TxnAggregatorServiceAdapter {

    void syncBillPayTransaction(BillPayTransaction billPayTransaction);

    void syncBillPayTransaction(BillPayTransactionDO billPayTransactionDO);

    void syncCoFTopupTransaction(CoFTopUpTransaction coFTopupTransaction);

    TxnEventRestConsumptionResponse publishPayloadViaRESTCall(EventPayload eventPayload) throws Throwable;
}
