package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

import java.util.List;

@Configuration(configName = SingleScreenPaymentConfiguration.CCM_ENTRY_NAME)
public interface SingleScreenPaymentConfiguration {

    String CCM_ENTRY_NAME = "single-screen-payment-config";

    @Property(propertyName = "is.save.last.used.card.enabled")
    Boolean isSaveLastUsedCardEnabled();

    @Property(propertyName = "last.used.card.core.pool.size")
    Integer getLastUsedCardCorePoolSize();

    @Property(propertyName = "last.used.card.max.pool.size")
    Integer getLastUsedCardMaxPoolSize();

    @Property(propertyName = "last.used.card.keep-alive.time")
    Integer getLastUsedCardKeepAliveTime();

    @Property(propertyName = "payment.options.order")
    String getPaymentOptionsOrder();

    @Property(propertyName = "cuenta.cashi.digital.card.bins")
    List<String> getCuentaCashiDigitalCardBins();
}