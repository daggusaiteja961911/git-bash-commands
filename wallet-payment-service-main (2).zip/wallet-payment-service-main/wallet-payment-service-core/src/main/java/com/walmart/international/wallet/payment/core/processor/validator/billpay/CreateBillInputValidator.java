package com.walmart.international.wallet.payment.core.processor.validator.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.BillerMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillerRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class CreateBillInputValidator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    private CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    @Autowired
    private BillerRepository billerRepository;

    @Autowired
    private CustomerBillAccountRepository customerBillAccountRepository;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    private BillerMapper billerMapper = BillerMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {
        BillRequestDomainContext billRequestDomainContext = (BillRequestDomainContext) wpsRequestDomainContext;
        BillResponseDomainContext billResponseDomainContext = (BillResponseDomainContext) wpsResponseDomainContext;

        UUID customerAccountId = billRequestDomainContext.getCustomerBillAccount().getCustomerAccountId();
        if (Objects.isNull(customerAccountId)) {
            throw new DataValidationException(ErrorConstants.CreateBill.INVALID_CUSTOMER_ACCOUNT_ID, "CustomerAccountId cannot be null");
        }

        CustomerBillAccount customerBillAccount = billRequestDomainContext.getCustomerBillAccount();
        UUID billerId = customerBillAccount.getBillerId();
        String processorBillerId = customerBillAccount.getProcessorBillerId();

        if (billerId == null && processorBillerId == null) {
            throw new DataValidationException(ErrorConstants.CreateBill.BILLER_ID_AND_PROCESSOR_ID_MISSING, "Both billerId and processorBillerId cannot be null simultaneously");
        }

        BillerDO billerDO = getBillerDOIfExists(billerId, processorBillerId);
        // In standard API flow, processorBillerId or billerId will be null depending on what was provided originally in the request
        if (Objects.isNull(customerBillAccount.getProcessorBillerId())) {
            customerBillAccount.setProcessorBillerId(billerDO.getProcessorBillerId());
        }
        if (Objects.isNull(customerBillAccount.getBillerId())) {
            customerBillAccount.setBillerId(billerDO.getBillerId());
        }

        if (BillPayUtil.isBarcodeToAccountArcusProcessorBiller(billerDO.getProcessorBillerId())) {
            log.info("Request contains BarcodeTransformProcessorBillerId[{}]", processorBillerId);
            String accountNumber = BillPayUtil.getAccountNumberFromBarcodeNumber(customerBillAccount.getAccountNumber(), billerDO.getProcessorBillerId());
            customerBillAccount.setAccountNumber(accountNumber);
        }

        CustomerBillAccountDO customerBillAccountDO = getCustomerBillAccountDOIfPresent(customerAccountId, customerBillAccount, billerDO);
        if (Objects.nonNull(customerBillAccountDO)) {
            customerBillAccountMapper.updateCustomerBillAccountFromCustomerBillAccountDO(customerBillAccountDO, customerBillAccount);
            billResponseDomainContext.setCustomerBillAccountDO(customerBillAccountDO);
        }
        if (Objects.isNull(customerBillAccount.getBiller())) {
            customerBillAccount.setBiller(billerMapper.mapBillerDOToBillerWithoutSubBillersAndBillPlans(billerDO));
        }
        billResponseDomainContext.setCustomerBillAccount(customerBillAccount);
        billResponseDomainContext.setBillerDO(billerDO);
        return true;
    }

    private CustomerBillAccountDO getCustomerBillAccountDOIfPresent(UUID customerAccountId, CustomerBillAccount customerBillAccount, BillerDO billerDO) throws ProcessingException {
        Optional<CustomerBillAccountDO> customerBillAccountDOOptional;
        try {
            customerBillAccountDOOptional = fetchCustomerBillAccountDOFromDB(customerAccountId, customerBillAccount.getAccountNumber().trim(), billerDO);
        } catch (Exception ex) {
            String msg = String.format("Exception while fetching customerBillAccountDO from DB for customerAccountId[%s}, accountNumber[%s}, processorBillerId[%s]",
                    customerAccountId, customerBillAccount.getAccountNumber().trim(), billerDO.getProcessorBillerId());
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
        if (customerBillAccountDOOptional.isPresent() && customerBillAccountDOOptional.get().isDeleted()) {
            customerBillAccountDOOptional.get().setDeleted(false);
            return updateCustomerBillAccountDO(customerBillAccountDOOptional.get());
        }
        return customerBillAccountDOOptional.orElse(null);
    }

    private Optional<CustomerBillAccountDO> fetchCustomerBillAccountDOFromDB(UUID customerAccountId, String accountNumber, BillerDO billerDO) {
        if (billPaymentConfiguration.isUniqueConstraintPresentInCBATable()) {
            return customerBillAccountRepository.findByCustomerAccountIdAndAccountNumberAndBillerDO(customerAccountId, accountNumber, billerDO);
        } else {
            return customerBillAccountRepository.findFirstByCustomerAccountIdAndAccountNumberAndBillerDOOrderByUpdateDateDesc(customerAccountId, accountNumber, billerDO);
        }
    }

    private BillerDO getBillerDOIfExists(UUID billerId, String processorBillerId) throws BusinessValidationException {
        Optional<BillerDO> billerDOOptional;
        if (billerId == null) {
            billerDOOptional = billerRepository.getByProcessorBillerId(processorBillerId);
            if (billerDOOptional.isEmpty()) {
                throw new BusinessValidationException(ErrorConstants.CreateBill.INVALID_PROCESSOR_BILLER_ID, String.format("Biller record not found for processorBillerId [%s]", processorBillerId));
            }
        } else {
            billerDOOptional = billerRepository.getByBillerId(billerId);
            if (billerDOOptional.isEmpty()) {
                throw new BusinessValidationException(ErrorConstants.CreateBill.INVALID_BILLER_ID, String.format("Biller record not found for billerId [%s]", billerId));
            }
        }
        return billerDOOptional.get();
    }

    private CustomerBillAccountDO updateCustomerBillAccountDO(CustomerBillAccountDO customerBillAccountDO) throws ProcessingException {
        log.info("RefreshBill - Updating bill with billId[{}} for customerAccountId[{}]", customerBillAccountDO.getCustomerBillAccountId(), customerBillAccountDO.getCustomerAccountId());
        try {
            customerBillAccountRepository.save(customerBillAccountDO);
        } catch (Exception ex) {
            String msg = String.format("Error while updating customer bill account with id[%s] to DB", customerBillAccountDO.getCustomerBillAccountId());
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
        return customerBillAccountDO;
    }
}