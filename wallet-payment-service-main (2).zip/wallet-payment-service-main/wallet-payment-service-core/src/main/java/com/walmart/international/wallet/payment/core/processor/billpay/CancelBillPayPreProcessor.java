package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.ewallet.services.events.WalletEventService;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.notification.txnaggregator.TxnCompletedPayloadGenerator;
import com.walmart.international.wallet.payment.core.adapter.tas.TxnAggregatorServiceAdapter;
import com.walmart.international.wallet.payment.core.adapter.tas.response.TxnEventRestConsumptionResponse;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.event.payload.PayBillInitEventPayload;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillPayTransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class CancelBillPayPreProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private BillPayTransactionRepository billPayTransactionRepository;

    @Autowired
    private WalletEventService<PayBillInitEventPayload> payBillInitEventService;

    @Autowired
    private TxnAggregatorServiceAdapter txnAggregatorServiceAdapter;

    @Autowired
    private TxnCompletedPayloadGenerator txnCompletedPayloadGenerator;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {
        BillPayTxnRequestDomainContext requestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext responseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        BillPayTransactionDO billPayTransactionDO = responseDomainContext.getBillPayTransactionDO();
        updateTxnStateTo3DSCancelled(billPayTransactionDO, requestDomainContext.getHeaderValue(WPSConstants.Headers.CORRELATION_ID));
        PayBillInitEventPayload eventPayload = preparePayBillInitEventPayload(requestDomainContext, responseDomainContext);
        payBillInitEventService.raiseEvent(WPSConstants.Event.CANCEL_PAY_BILL_INIT, eventPayload);
        return true;
    }

    private void updateTxnStateTo3DSCancelled(BillPayTransactionDO billPayTransactionDO, String correlationId) {
        billPayTransactionDO.setStateReason(BillPayTxnStateReason.TOPUP_3DS_CANCELLED);
        billPayTransactionDO = billPayTransactionRepository.save(billPayTransactionDO);
        try {
            EventPayload eventPayload = txnCompletedPayloadGenerator.generatePayload(billPayTransactionDO, correlationId);
            TxnEventRestConsumptionResponse response = txnAggregatorServiceAdapter.publishPayloadViaRESTCall(eventPayload);
            if (Objects.isNull(response) || Objects.isNull(response.getId()) || !(response.getId().equals(billPayTransactionDO.getBillPayTransactionId().toString()))) {
                String msg = String.format("Error while publishing updated txn status to TxnAgg for txnId[%s], customerAccountId[%s]",
                        billPayTransactionDO.getBillPayTransactionId(), billPayTransactionDO.getCustomerAccountId());
                throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.FAILURE_IN_PUBLISHING_PAYLOAD_TO_TAS, msg);
            }
        } catch (Throwable e) {
            String msg = String.format("Error while publishing updated txn status to TxnAgg for txnId[%s], customerAccountId[%s]",
                    billPayTransactionDO.getBillPayTransactionId(), billPayTransactionDO.getCustomerAccountId());
            throw new BusinessValidationException(ErrorConstants.CancelPayBillInitTransaction.FAILURE_IN_PUBLISHING_PAYLOAD_TO_TAS, msg, e);
        }
    }

    private PayBillInitEventPayload preparePayBillInitEventPayload(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        return PayBillInitEventPayload.builder()
                .billPayTxnRequestDomainContext(billPayTxnRequestDomainContext)
                .billPayTxnResponseDomainContext(billPayTxnResponseDomainContext).build();
    }
}
