package com.walmart.international.wallet.payment.core.adapter.kafka.service;

import com.walmart.international.ewallet.payment.api.dto.TxnDetail;
import com.walmart.international.services.payment.core.dao.repository.CardTransactionRepository;
import com.walmart.international.services.payment.core.domain.CardWorkflowStatusV2;
import com.walmart.international.services.payment.core.dto.CardTransactionDTO;
import com.walmart.international.services.payment.core.kafka.dto.EventPayload;
import com.walmart.international.services.payment.core.kafka.response.AsyncChargeKafkaPayload;
import com.walmart.international.services.payment.core.kafka.response.AsyncRefundKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.InvalidKafkaPayloadException;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.ReconHandlingException;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.TransactionType;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.service.BillPaymentCoreService;
import com.walmart.international.wallet.payment.core.service.CofTopupCoreService;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ReconService {
    @Autowired
    private CardTransactionRepository cardTransactionRepository;

    @Autowired
    private BillPaymentCoreService billPaymentCoreService;

    @Autowired
    private CofTopupCoreService cofTopupCoreService;

    public void validateIfTransactionExistsInSystem(AsyncChargeKafkaPayload asyncChargeKafkaPayload) {
        Set<UUID> cardTransactionIds = getAllCardTransactionIdsFromPayload(asyncChargeKafkaPayload);

        if (cardTransactionIds.isEmpty()) {
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaChargeRecon.INVALID_PAYMENT_OPTIONS_IN_PAYLOAD);
        }
        if (!cardTransactionRepository.doesExistByIdsIn(cardTransactionIds)) {
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaChargeRecon.TRANSACTION_DOES_NOT_EXIST_IN_SYSTEM);
        }
    }

    public void validateIfTransactionExistsInSystem(AsyncRefundKafkaResponse asyncRefundKafkaPayload) {
        Set<UUID> cardTransactionIds = getAllCardTransactionIdsFromPayload(asyncRefundKafkaPayload);

        if (cardTransactionIds.isEmpty()) {
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaRefundRecon.INVALID_PAYMENT_OPTIONS_IN_PAYLOAD);
        }
        if (!cardTransactionRepository.doesExistByIdsIn(cardTransactionIds)) {
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaRefundRecon.TRANSACTION_DOES_NOT_EXIST_IN_SYSTEM);
        }
    }

    public void updateTransactionStatusForRefund(TransactionType transactionType, CardTransactionDTO cardTransactionDTO) {
        UUID transactionId = UUID.fromString(cardTransactionDTO.getCoreTransaction().getClientTransactionId().split("_")[0]);
        try {
            if (transactionType.equals(TransactionType.BILL)) {
                billPaymentCoreService.updateBillPayTransactionStateForReversal(transactionId, mapRefundStateToBillPayStateReason(cardTransactionDTO));
            } else if (transactionType.equals(TransactionType.COF)) {
                cofTopupCoreService.updateTransactionForReversalStatus(transactionId, mapRefundStateToCofStateReason(cardTransactionDTO));
            }
        } catch (Exception ex) {
            log.error("Error while updating refund recon state for transaction : {} : {}", transactionType, cardTransactionDTO.getSubTransactionId(), ex);
        }
    }

    private BillPayTxnStateReason mapRefundStateToBillPayStateReason(CardTransactionDTO cardTransactionDTO) {
        if (cardTransactionDTO.getWorkflowStatus().equals(CardWorkflowStatusV2.REVERSAL_SUCCEEDED)) {
            return BillPayTxnStateReason.DEBIT_REVERSAL_SUCCESS;
        } else if (cardTransactionDTO.getWorkflowStatus().equals(CardWorkflowStatusV2.REVERSAL_FAILED)) {
            return BillPayTxnStateReason.DEBIT_REVERSAL_PENDING;
        } else {
            throw new ReconHandlingException(ErrorConstants.KafkaRefundRecon.INVALID_REFUND_RECON_STATE);
        }
    }

    private CoFTopupTxnStateReason mapRefundStateToCofStateReason(CardTransactionDTO cardTransactionDTO) {
        if (cardTransactionDTO.getWorkflowStatus().equals(CardWorkflowStatusV2.REVERSAL_SUCCEEDED)) {
            return CoFTopupTxnStateReason.DEBIT_REVERSAL_SUCCESS;
        } else if (cardTransactionDTO.getWorkflowStatus().equals(CardWorkflowStatusV2.REVERSAL_FAILED)) {
            return CoFTopupTxnStateReason.DEBIT_REVERSAL_PENDING;
        } else {
            throw new ReconHandlingException(ErrorConstants.KafkaRefundRecon.INVALID_REFUND_RECON_STATE);
        }
    }


    private Set<UUID> getAllCardTransactionIdsFromPayload(AsyncChargeKafkaPayload asyncChargeKafkaPayload) {
        return Optional.ofNullable(asyncChargeKafkaPayload.getAsyncChargeResponse())
                .orElse(Collections.emptyList())
                .stream().map(AsyncChargeKafkaPayload.AsyncChargeKafkaResponse::getEventPayload)
                .filter(Objects::nonNull)
                .map(EventPayload::getTxns)
                .flatMap(txns ->
                        txns.stream()
                                .filter(Objects::nonNull)
                                .map(TxnDetail::getPaymentId))
                .collect(Collectors.toSet());
    }

    private Set<UUID> getAllCardTransactionIdsFromPayload(AsyncRefundKafkaResponse asyncRefundKafkaPayload) {
        if (asyncRefundKafkaPayload == null || asyncRefundKafkaPayload.getEventPayload() == null)
            return Collections.emptySet();

        return Optional.ofNullable(asyncRefundKafkaPayload.getEventPayload().getTxns())
                .orElse(Collections.emptyList())
                .stream()
                .filter(Objects::nonNull)
                .map(TxnDetail::getPaymentId)
                .collect(Collectors.toSet());
    }
}
