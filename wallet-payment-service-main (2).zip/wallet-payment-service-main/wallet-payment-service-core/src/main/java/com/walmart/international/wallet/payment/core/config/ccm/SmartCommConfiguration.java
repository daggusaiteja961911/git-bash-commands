package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "smartcomm-config")
public interface SmartCommConfiguration {

    @Property(propertyName = "event.success.bill.pay.name")
    String getEventSuccessfulBillPay();

    @Property(propertyName = "event.cof.topup.success")
    String getEventCoFTopupSuccessful();

    @Property(propertyName = "event.billpay.reminder.on.due.date")
    String getBillPayReminderOnDueDateEvent();

    @Property(propertyName = "event.billpay.reminder.on.due.date.with.alias")
    String getBillPayReminderOnDueDateWithAliasEvent();

    @Property(propertyName = "event.billpay.reminder.due.soon")
    String getBillPayReminderSoonEvent();

    @Property(propertyName = "event.billpay.reminder.due.soon.with.alias")
    String getBillPayReminderSoonWithAliasEvent();

    @Property(propertyName = "event.billpay.nudge")
    String getBillPayNudgeEvent();
}
