package com.walmart.international.wallet.payment.core.processor.coftopup;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.notification.constants.EventDownstream;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.utils.EventHelper;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class CancelCoFTopupPostProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private EventHelper eventHelper;

    private CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO();
        coFTopupMapper.updateCoFTopupTransactionFromCoFTopupTransactionDO(coFTopupTransactionDO, coFTopUpTransaction);
        // TODO - minimal sync call not made for cancel cof topup as of now
        eventHelper.publishAsync(coFTopUpTransaction.getTransactionId().toString(), coFTopUpTransaction,
                WalletEventType.TXN_COMPLETED, List.of(EventDownstream.TXN_AGGREGATER_SERVICE));
        return true;
    }
}