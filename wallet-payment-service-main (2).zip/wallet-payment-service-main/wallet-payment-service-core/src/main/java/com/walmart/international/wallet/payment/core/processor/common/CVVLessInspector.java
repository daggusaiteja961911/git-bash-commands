package com.walmart.international.wallet.payment.core.processor.common;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.services.payment.core.dao.repository.CardTransactionRepository;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import io.strati.libs.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class CVVLessInspector implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {
    @Autowired
    CardTransactionRepository cardTransactionRepository;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        List<CardPaymentInstrument> cardPaymentInstrumentList = null;
        if (wpsResponseDomainContext instanceof CoFTopupTxnResponseDomainContext) {
            CoFTopupTxnResponseDomainContext cofTopupTxnResponseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
            cardPaymentInstrumentList = cofTopupTxnResponseDomainContext.getTransaction().getCofTopupPaymentOptions().getCardPaymentInstruments().getCardPaymentInstrumentList();
        } else if (wpsResponseDomainContext instanceof BillPayTxnResponseDomainContext) {
            BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
            cardPaymentInstrumentList = billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getCardPaymentInstruments().getCardPaymentInstrumentList();
        }
        enableCvvRequiredFlagForCardsWithFailuresInLast24Hours(cardPaymentInstrumentList);
        return true;
    }

    private void enableCvvRequiredFlagForCardsWithFailuresInLast24Hours(List<CardPaymentInstrument> cardPaymentInstruments) {
        if (Objects.isNull(cardPaymentInstruments)) {
            return;
        }
        List<CardPaymentInstrument> cvvLessAllowedCardPaymentInstruments = cardPaymentInstruments.stream().filter(card -> !card.getMetadata().getCvvRequired()).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(cvvLessAllowedCardPaymentInstruments)) {
            List<String> cvvLessAllowedPaymentInstrumentIds = cvvLessAllowedCardPaymentInstruments.stream().map(CardPaymentInstrument::getPaymentInstrumentId).collect(Collectors.toList());
            Set<String> paymentInstrumentIdsWithFailureInLast24Hours = getPaymentInstrumentIdsWithFailureInLast24Hours(cvvLessAllowedPaymentInstrumentIds);
            if (CollectionUtils.isNotEmpty(paymentInstrumentIdsWithFailureInLast24Hours)) {
                cvvLessAllowedCardPaymentInstruments.forEach(cvvLessAllowedCardPaymentInstrument -> {
                    if (paymentInstrumentIdsWithFailureInLast24Hours.contains(cvvLessAllowedCardPaymentInstrument.getPaymentInstrumentId())) {
                        cvvLessAllowedCardPaymentInstrument.getMetadata().setCvvRequired(true);
                    }
                });
            }
        }
    }

    private Set<String> getPaymentInstrumentIdsWithFailureInLast24Hours(List<String> cvvLessAllowedPaymentInstrumentIds) {
        List<UUID> cvvLessAllowedPaymentInstrumentUUIDs = cvvLessAllowedPaymentInstrumentIds.stream().map(UUID::fromString).collect(Collectors.toList());
        Date currentDate = new Date();
        List<UUID> cardPaymentInstrumentIdsWithFailureInDuration = cardTransactionRepository.getCardPaymentInstrumentIdsWithFailureInDuration(cvvLessAllowedPaymentInstrumentUUIDs, new Date(currentDate.getTime() - 24 * 3600 * 1000), currentDate);
        return cardPaymentInstrumentIdsWithFailureInDuration.stream().map(uuid -> uuid.toString()).collect(Collectors.toSet());
    }
}
