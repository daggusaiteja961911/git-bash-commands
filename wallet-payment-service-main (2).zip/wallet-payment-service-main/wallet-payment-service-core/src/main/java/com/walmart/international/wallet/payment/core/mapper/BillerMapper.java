package com.walmart.international.wallet.payment.core.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.commons.utils.StringUtils;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillDetail;
import com.walmart.international.wallet.payment.core.domain.model.BillPlan;
import com.walmart.international.wallet.payment.core.domain.model.BillTypeValidation;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.domain.model.BillerMetadata;
import com.walmart.international.wallet.payment.data.dao.entity.BillDetailDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillPlanDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryBillerMappingDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryVersionMappingDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.constant.enums.InputType;
import io.strati.libs.commons.collections.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 *  Mapping from/to Domain Model
 */
@Mapper
@Component
public interface BillerMapper {

    BillerMapper INSTANCE = Mappers.getMapper(BillerMapper.class);

    List<BillerCategory> mapBillerCategoryVersionMappingsDOsToBillerCategoryList(List<BillerCategoryVersionMappingDO> billerCategoryVersionMappingDOList);

    @Mapping(target = "id", source = "billerCategory.categoryId")
    @Mapping(target = "categoryName", source = "billerCategory.categoryName")
    @Mapping(target = "billers", source = "billerCatgeoryMappings")
    @Mapping(target = "hasEnabledBillers", source = "billerCatgeoryMappings", qualifiedByName = "mapHasEnabledBillers")
    @Mapping(target = "hasNewBillers", source = "billerCatgeoryMappings", qualifiedByName = "mapHasNewBillers")
    BillerCategory mapBillerCategoryVersionMappingDOToBillerCategory(BillerCategoryVersionMappingDO billerCategoryVersionMappingDO);

    default List<Biller> mapBillerCategoryBillerMappingDOsToBiller(List<BillerCategoryBillerMappingDO> billerCategoryBillerMappingDOs) {
        if (Objects.isNull(billerCategoryBillerMappingDOs)) {
            return null;
        }
        List<Biller> billers = new ArrayList<>();
        billerCategoryBillerMappingDOs.sort(Comparator.comparing(BillerCategoryBillerMappingDO::getAppDisplaySequenceNumber));
        for ( BillerCategoryBillerMappingDO billerCategoryBillerMappingDO : billerCategoryBillerMappingDOs ) {
            if (billerCategoryBillerMappingDO.isEnabled() && Objects.nonNull(billerCategoryBillerMappingDO.getBiller()) &&
                    billerCategoryBillerMappingDO.getBiller().getEnabled()) {
                Biller biller = mapBillerDOToBillerWithoutSubBillersAndBillPlans(billerCategoryBillerMappingDO.getBiller());
                biller.setSubBillers(mapSubBillers(billerCategoryBillerMappingDO.getBiller()));
                billers.add(biller);
            }
        }
        return billers;
    }

    //used by getPopularBillers API
    default List<Biller> mapBillerDOsToBillerList(List<BillerDO> billerDOS) {
        if (Objects.isNull(billerDOS)) {
            return null;
        }
        List<Biller> billers = new ArrayList<>();
        for ( BillerDO billerDO : billerDOS ) {
            if (billerDO.getEnabled()) {
                Biller biller = mapBillerDOToBillerWithoutSubBillersAndBillPlans(billerDO);
                biller.setSubBillers(mapSubBillers(billerDO));
                billers.add(biller);
            }
        }
        return billers;
    }

    //used by getPopularBIllers and getBillerCategories API
    default List<Biller> mapSubBillers(BillerDO billerDO) {
        if (CollectionUtils.isNotEmpty(billerDO.getSubBillers()) && billerDO.getSubBillerShownAsProduct()) {
            List<BillerDO> subBillers = billerDO.getSubBillers();
            return subBillers.stream().filter(BillerDO::getEnabled)
                    .filter(subBiller -> StringUtils.isNotEmpty(subBiller.getProductDisplayName()))
                    .sorted(Comparator.comparing(BillerDO::getAppDisplaySequenceNumber))
                    .map(subBillerDO -> {
                        Biller subBiller = mapBillerDOToBillerWithoutSubBillersAndBillPlans(subBillerDO);
                        subBiller.setDisplayName(subBillerDO.getProductDisplayName());
                        return subBiller;})
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    @Mapping(target = "billTypeValidation", source = "metaData", qualifiedByName = "mapBillTypeValidationMetadata")
    @Mapping(target = "inputType", source = "inputType", qualifiedByName = "mapInputType")
    @Mapping(target = "tags", source = "tags", qualifiedByName = "mapTagsToArray")
    @Mapping(target = "subBillers", ignore = true)
    @Mapping(target = "billPlans", ignore = true)
    Biller mapBillerDOToBillerWithoutSubBillersAndBillPlans(BillerDO billerDO) throws ProcessingException;

    //used by getBillerById
    default List<Biller> mapSubBillerDOsToBillers(BillerDO billerDO) {
        List<BillerDO> subBillers = billerDO.getSubBillers();
        List<Biller> billers = null;
        if (CollectionUtils.isNotEmpty(subBillers)) {
            subBillers.sort(Comparator.comparing(BillerDO::getAppDisplaySequenceNumber));
            billers = new ArrayList<>();
            for (BillerDO subBillerDO : subBillers) {
                if (Boolean.TRUE.equals(subBillerDO.getEnabled())) {
                    Biller biller = mapBillerDOToBillerWithoutSubBillersAndBillPlans(subBillerDO);
                    biller.setBillPlans(mapBillPlans(subBillerDO));
                    billers.add(biller);
                }
            }
        }
        return billers;
    }

    @Named("mapBillTypeValidationMetadata")
    default BillTypeValidation mapBillTypeValidationMetadata(byte[] metadata) throws ProcessingException {
        try {
            if (metadata != null) {
                BillerMetadata billerMetadata = new ObjectMapper().readValue(new String(metadata), BillerMetadata.class);
                if (billerMetadata.getValidations().size() == 1) {
                    return billerMetadata.getValidations().get(0);
                }
            }
            return null;
        } catch (JsonProcessingException jpe) {
            String msg = "Error in reading biller metadata";
            throw new ProcessingException(ErrorConstants.BillerData.INVALID_BILL_TYPE_VALIDATION_METADATA, msg, jpe);
        }
    }

    @Named("mapInputType")
    default InputType mapInputType(InputType inputType) {
        if (inputType == null || (inputType.toString().equalsIgnoreCase("null"))) {
            return InputType.ALPHANUMERIC;
        }
        return inputType;
    }

    @Named("mapBillPlans")
    default List<BillPlan> mapBillPlans(BillerDO billerDO) {
        List<BillPlan> billPlans = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(billerDO.getBillPlans())) {
            List<BillPlanDO> billPlanDOList = new ArrayList<>(billerDO.getBillPlans());
            billPlanDOList.sort(Comparator.comparing(BillPlanDO::getAppDisplaySequenceNumber));
            for (BillPlanDO billPlanDO : billPlanDOList) {
                if (billPlanDO.isEnabled()) {
                    billPlans.add(mapBillPlan(billPlanDO));
                }
            }
        } else if (StringUtils.isNotEmpty(billerDO.getAvailableTopupAmount())) {
            BillPlan billPlan = new BillPlan();
            List<BillDetail> billDetails = new ArrayList<>();
            int counter = 1;
            for (String billAmount : billerDO.getAvailableTopupAmount().split("\\s*,\\s*")) {
                BillDetail billDetail = new BillDetail();
                billDetail.setName("Monto " + counter);
                billDetail.setAmount(new BigDecimal(billAmount));
                billDetails.add(billDetail);
                counter++;
            }
            billPlan.setBillDetails(billDetails);
            billPlans.add(billPlan);
        }
        return billPlans;
    }

    @Mapping(target = "plan", source = "planName")
    @Mapping(target = "billDetails", source = "billDetails")
    BillPlan mapBillPlan(BillPlanDO billPlanDO);

    default List<BillDetail> mapBillDetails(List<BillDetailDO> billDetailDOList) {
        if (billDetailDOList == null) {
            return null;
        }
        List<BillDetail> bills = new ArrayList<>();
        billDetailDOList.sort(Comparator.comparing(BillDetailDO::getAppDisplaySequenceNumber));
        for ( BillDetailDO billDetailDO : billDetailDOList ) {
            if (billDetailDO.isEnabled()) {
                bills.add(mapBillDetail(billDetailDO));
            }
        }
        return bills;
    }

    @Mapping(target = "amount", source = "billAmount")
    @Mapping(target = "socialMediaIcons", source = "socialMediaIcons", qualifiedByName = "mapSocialMediaIcons")
    @Mapping(target = "durationUnit", source = "durationUnit", qualifiedByName = "mapDurationUnit")
    BillDetail mapBillDetail(BillDetailDO billDetailDO);

    @Named("mapSocialMediaIcons")
    default String[] mapSocialMediaIcons(String socialMediaIcons) {
        return !org.apache.commons.lang3.StringUtils.isEmpty(socialMediaIcons) ? socialMediaIcons.split("\\s*,\\s*") : null;
    }

    @Named("mapDurationUnit")
    default BillDetail.DurationUnit mapDurationUnit(String durationUnit) {
        if (StringUtils.isNotEmpty(durationUnit)) {
            try {
                return BillDetail.DurationUnit.valueOf(durationUnit);
            } catch (Exception ex) {
                return null;
            }
        }
        return null;
    }

    @Named("mapTagsToArray")
    default String[] mapTagsToArray(String tags) {
        return !org.apache.commons.lang3.StringUtils.isEmpty(tags) ? tags.split("\\s*;\\s*") : new String[0];
    }

    @Named("mapHasEnabledBillers")
    default Boolean hasEnabledBillers(List<BillerCategoryBillerMappingDO> billerCatgeoryMappings) {
        if (Objects.isNull(billerCatgeoryMappings)) {
            return Boolean.FALSE;
        }
        for (BillerCategoryBillerMappingDO billerCategoryBillerMappingDO : billerCatgeoryMappings) {
            if (billerCategoryBillerMappingDO.isEnabled() && !Objects.isNull(billerCategoryBillerMappingDO.getBiller()) &&
                    billerCategoryBillerMappingDO.getBiller().getEnabled()) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    @Named("mapHasNewBillers")
    default Boolean hasNewBillers(List<BillerCategoryBillerMappingDO> billerCatgeoryMappings) {
        if (Objects.isNull(billerCatgeoryMappings)) {
            return Boolean.FALSE;
        }
        for (BillerCategoryBillerMappingDO billerCategoryBillerMappingDO : billerCatgeoryMappings) {
            if (!Objects.isNull(billerCategoryBillerMappingDO.getBiller()) &&
                    Boolean.TRUE.equals(billerCategoryBillerMappingDO.getBiller().getNewBiller())) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }
}
