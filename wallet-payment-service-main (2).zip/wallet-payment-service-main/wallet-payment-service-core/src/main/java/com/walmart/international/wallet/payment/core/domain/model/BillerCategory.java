package com.walmart.international.wallet.payment.core.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillerCategory implements Serializable {
    private static final long serialVersionUID = -759311152096064473L;
    private UUID id;
    private String categoryName;
    private String imageUrl;
    private int billerCategoryVersion;
    private Boolean hasEnabledBillers = false;
    private Boolean hasNewBillers = false;
    private List<Biller> billers;
}
