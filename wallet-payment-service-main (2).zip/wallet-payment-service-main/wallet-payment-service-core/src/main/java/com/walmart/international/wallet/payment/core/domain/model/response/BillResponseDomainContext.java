package com.walmart.international.wallet.payment.core.domain.model.response;

import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder
@ToString(callSuper = true)
public class BillResponseDomainContext extends WPSResponseDomainContext {
    CustomerBillAccount customerBillAccount;
    CustomerBillAccountDO customerBillAccountDO;
    BillerDO billerDO;
    String status;
    String message;
}
