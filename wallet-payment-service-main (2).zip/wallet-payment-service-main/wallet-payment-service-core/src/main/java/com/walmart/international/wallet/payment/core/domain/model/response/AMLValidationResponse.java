package com.walmart.international.wallet.payment.core.domain.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AMLValidationResponse {

    private Boolean amlValidationResult;
    private String requestId;
    private BigDecimal maxAmlLimit;
    private BigDecimal exhaustedLimit;
    private String statusCode;
    private String statusMessage;
}
