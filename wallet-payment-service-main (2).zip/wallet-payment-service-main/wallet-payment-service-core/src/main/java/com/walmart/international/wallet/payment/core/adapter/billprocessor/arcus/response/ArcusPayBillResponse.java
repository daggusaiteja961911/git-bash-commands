package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ArcusPayBillResponse {

    private String type;

    private Integer id;

    private BigDecimal amount;

    @JsonProperty("amount_currency")
    private String amountCurrency;

    @JsonProperty("fx_rate")
    private BigDecimal fxRate;

    @JsonProperty("amount_usd")
    private BigDecimal amountUsd;

    @JsonProperty("transaction_fee")
    private BigDecimal transactionFee;

    @JsonProperty("total_usd")
    private BigDecimal totalUsd;

    @JsonProperty("hours_to_fulfill")
    private BigDecimal hoursToFulfill;

    @JsonProperty("created_at")
    private String createdAt;

    private String status;

    @JsonProperty("external_id")
    private String externalId;

    @JsonProperty("ticket_text")
    private String ticketText;

    @JsonProperty("account_number")
    private String accountNumber;

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

    @JsonProperty("mode")
    private String mode;
}
