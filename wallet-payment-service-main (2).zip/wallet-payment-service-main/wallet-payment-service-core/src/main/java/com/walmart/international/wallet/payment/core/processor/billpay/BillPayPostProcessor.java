package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.campaign.dto.enums.TransactionType;
import com.walmart.international.campaign.dto.request.RewardRequest;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IPostProcessor;
import com.walmart.international.notification.NotificationAdapter;
import com.walmart.international.notification.constants.MessagingType;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.dto.NotificationDetails;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.notification.exceptions.ReminderServiceException;
import com.walmart.international.wallet.payment.core.config.ccm.PaymentNotificationTemplateConfiguration;
import com.walmart.international.wallet.payment.core.config.ccm.SmartCommConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.event.CampaignServiceNotifier;
import com.walmart.international.wallet.payment.core.event.payload.CampaignRewardEventPayload;
import com.walmart.international.wallet.payment.core.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.core.service.BillPayReminderService;
import com.walmart.international.wallet.payment.core.service.TxnAggregatorDataSyncService;
import com.walmart.international.wallet.payment.core.utils.BillPayUtil;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryBillerMappingDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillerCategoryBillerMappingRepository;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class BillPayPostProcessor implements IPostProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @ManagedConfiguration
    private SmartCommConfiguration smartCommConfiguration;

    @Autowired
    private CustomerBillAccountRepository customerBillAccountRepository;

    @Autowired
    private BillPayReminderService billPayReminderService;

    @Autowired
    private CampaignServiceNotifier campaignServiceNotifier;

    @ManagedConfiguration
    private PaymentNotificationTemplateConfiguration paymentNotificationTemplateConfiguration;

    @Autowired
    private BillerCategoryBillerMappingRepository billerCategoryBillerMappingRepository;

    @Autowired
    private NotificationAdapter<NotificationPayload> notificationPayloadNotificationAdapter;

    @Autowired
    private TxnAggregatorDataSyncService txnAggregatorDataSyncService;

    private CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    private BillPayMapper billPayMapper = BillPayMapper.INSTANCE;


    @Override
    public boolean postProcess(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) {
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();

        try {
            log.info("Raising bill pay reminder notification events for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
            billPayReminderService.raiseBillPayReminderNotificationsEvents(billPayTransaction);
        } catch (ReminderServiceException rse) {
            log.error("Error while calling raiseBillPayReminderNotificationsEvents for BillPayTransaction with txnId:[{}]. StackTrace: [{}]",
                    billPayTransaction.getTransactionId(), ExceptionUtils.getStackTrace(rse));
        }

        updateCustomerBillAccountDO(billPayTxnResponseDomainContext.getCustomerBillAccountDO(), billPayTransaction.getCustomerBillAccount());

        txnAggregatorDataSyncService.pushTransactionDataToTAAS(billPayTxnResponseDomainContext);

        notifyCampaignService(billPayTransaction, billPayTxnResponseDomainContext.getCustomerBillAccountDO().getBillerDO());

        sendPushNotificationForSuccessfulBillPayment(billPayTransaction);

        if (isEligibleForBillPaymentSuccessEmailNotification(billPayTransaction)) {
            sendEmailNotificationForSuccessfulBillPayment(billPayTransaction);
        }
        return true;
    }

    private void updateCustomerBillAccountDO(CustomerBillAccountDO customerBillAccountDO, CustomerBillAccount customerBillAccount) throws ProcessingException {
        log.info("Updating bill with billId[{}} for customerAccountId[{}]", customerBillAccountDO.getCustomerBillAccountId(), customerBillAccountDO.getCustomerAccountId());
        try {
            customerBillAccountMapper.updateCustomerBillAccountDOFromCustomerBillAccount(customerBillAccount, customerBillAccountDO);
            customerBillAccountRepository.save(customerBillAccountDO);
        } catch (Exception ex) {
            log.error("Error while updating customer bill account with id[{}] to DB", customerBillAccountDO.getCustomerBillAccountId());
        }
    }

    private void notifyCampaignService(BillPayTransaction billPayTransaction, BillerDO billerDO) {
        try {
            CampaignRewardEventPayload campaignRewardEventPayload = getCampaignRewardEventPayload(billPayTransaction, billerDO);
            campaignServiceNotifier.notifyCampaignService(campaignRewardEventPayload, billPayTransaction.getCustomer().getCustomerAccountId());
        } catch (Exception ex) {
            log.error("Error while notifying campaign service of successful BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
        }
    }

    private CampaignRewardEventPayload getCampaignRewardEventPayload(BillPayTransaction billPayTransaction, BillerDO billerDO) {
        log.info("Generating campaign reward event payload for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
        CustomerBillAccount customerBillAccount = billPayTransaction.getCustomerBillAccount();
        RewardRequest.RewardRequestBuilder rewardRequestBuilder = RewardRequest.builder()
                .transactionId(billPayTransaction.getTransactionId())
                .transactionType(TransactionType.BILL_PAY)
                .billerId(customerBillAccount.getProcessorBillerId())
                .billerCategories(getBillerCategoriesIdToNameMapForCampaignRequest(billerDO, billPayTransaction.getTransactionId()))
                .processingAmount(billPayTransaction.getAmountFulfilled().getValue())
                .requestDate(customerBillAccount.getLastPaidDate());

        populateCardTransactionDetails(billPayTransaction, rewardRequestBuilder);

        return CampaignRewardEventPayload.builder()
                .customerAccountId(billPayTransaction.getCustomer().getCustomerAccountId())
                .eventType(WPSConstants.Event.REWARD_BILL_PAY)
                .rewardRequest(rewardRequestBuilder.build())
                .build();
    }

    private void populateCardTransactionDetails(BillPayTransaction billPayTransaction, RewardRequest.RewardRequestBuilder rewardRequestBuilder) {
        try {
            if (CollectionUtils.isNotEmpty(billPayTransaction.getCardPaymentTransactionList())) {
                log.info("Populating card txn details for campaign reward event payload for BillPayTransaction with txnId:[{}]",
                        billPayTransaction.getTransactionId());
                CardPaymentTransaction cardPaymentTransaction = billPayTransaction.getCardPaymentTransactionList().get(0);
                CardPaymentInstrument cardPaymentInstrument = cardPaymentTransaction.getCardPaymentInstrument();
                CardPaymentInstrument.BinDetails binDetails = cardPaymentInstrument.getBinDetails();
                rewardRequestBuilder.bin(Integer.valueOf(binDetails.getBin()))
                        .amountPaidWithCard(cardPaymentTransaction.getAmount().getValue())
                        .cardBrand(binDetails.getBrandName())
                        .bankName(binDetails.getBankName())
                        .cardType(cardPaymentInstrument.getPaymentInstrumentSubType().name());
            }
        }
        catch (Exception ex) {
            logger.error("Error while populating card transaction details in reward request for billPayTransactionId : {}", billPayTransaction.getTransactionId());
        }
    }

    public Map<UUID, String> getBillerCategoriesIdToNameMapForCampaignRequest(BillerDO billerDO, UUID billPayTransactionId) {
        Map<UUID, String> billerCategoriesIdToNameMap = new HashMap<>();
        try {
            log.info("Fetching billerCategoriesIdToNameMap for campaign reward request for BillPayTransaction with txnId:[{}]", billPayTransactionId);
            // TODO: could refactor this to fetch from cache and avoid DB call
            while (Objects.nonNull(billerDO.getParentBiller())) {
                billerDO = billerDO.getParentBiller();
            }
            Optional<BillerCategoryBillerMappingDO> billerCategoryBillerMappingDOOptional = billerCategoryBillerMappingRepository.findByBiller(billerDO);
            if (billerCategoryBillerMappingDOOptional.isPresent()) {
                if (Objects.nonNull(billerCategoryBillerMappingDOOptional.get().getBillerCategoryVersionMapping())
                        && Objects.nonNull(billerCategoryBillerMappingDOOptional.get().getBillerCategoryVersionMapping().getBillerCategory())) {
                    BillerCategoryDO billerCategoryDO = billerCategoryBillerMappingDOOptional.get().getBillerCategoryVersionMapping().getBillerCategory();
                    billerCategoriesIdToNameMap.put(billerCategoryDO.getCategoryId(), billerCategoryDO.getCategoryName());
                }
            }
        } catch (Exception ex) {
            log.error("Error while fetching billerCategoriesIdToNameMap for biller with processorBillerId[{}] for billPayTransactionId[{}]. StackTrace: [{}]",
                    billerDO.getProcessorBillerId(), billPayTransactionId, ExceptionUtils.getStackTrace(ex));
        }
        return billerCategoriesIdToNameMap;
    }

    private boolean isEligibleForBillPaymentSuccessEmailNotification(BillPayTransaction billPayTransaction) {
        log.info("Evaluating if BillPayTransaction with txnId:[{}] is eligible for bill payment success email notification",
                billPayTransaction.getTransactionId());
        if (CollectionUtils.isNotEmpty(billPayTransaction.getCardPaymentTransactionList()) && billPayTransaction.getCardPaymentTransactionList().size() > 1) {
            return false;
        }
        if (CollectionUtils.isNotEmpty(billPayTransaction.getGiftCardPaymentTransactionList())) {
            int b2bCardCount = 0;
            for (GiftCardTransaction giftCardPaymentTransaction : billPayTransaction.getGiftCardPaymentTransactionList()) {
                if (giftCardPaymentTransaction.getGiftCardPaymentInstrument().getPaymentInstrumentSubType().equals(PaymentInstrumentSubType.CORP_CARD)) {
                    b2bCardCount++;
                    if (b2bCardCount > 1) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private void sendEmailNotificationForSuccessfulBillPayment(BillPayTransaction billPayTransaction) {
        Customer customer = billPayTransaction.getCustomer();
        try {
            log.info("Sending email notification for successful bill payment for BillPayTransaction with txnId:[{}] for customerAccountId:[{}]",
                    billPayTransaction.getTransactionId(), customer.getCustomerAccountId());
            NotificationPayload notificationPayload = BillPayUtil.getNotificationPayloadForPayBillSuccessEmailNotification(billPayTransaction, smartCommConfiguration.getEventSuccessfulBillPay());
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.EMAIL));
        } catch (Exception ex) {
            logger.error("Error while sending Email notification for successful bill payment with transactionId[{}] for customerAccountId[{}]", billPayTransaction.getTransactionId(), customer.getCustomerAccountId());
        }
    }

    private void sendPushNotificationForSuccessfulBillPayment(BillPayTransaction billPayTransaction) throws ProcessingException {
        Customer customer = billPayTransaction.getCustomer();
        UUID customerAccountId = customer.getCustomerAccountId();
        BigDecimal amountFulfilled = billPayTransaction.getAmountFulfilled().getValue();
        UUID billPayTransactionId = billPayTransaction.getTransactionId();
        String billerName = billPayTransaction.getCustomerBillAccount().getBiller().getDisplayName();
        try {
            log.info("Sending push notification for PAY_BILL_SUCCESS for customerAccountId[{}], billPayTransactionId[{}], amount[{}] and billerName[{}]",
                    customerAccountId, billPayTransactionId, amountFulfilled, billerName);
            NotificationPayload<NotificationDetails> notificationPayload =
                    BillPayUtil.getNotificationPayloadForPayBillSuccessPushNotification(billPayTransaction, paymentNotificationTemplateConfiguration.getBillPaySuccessInAppNotificationExpiryTime());
            notificationPayloadNotificationAdapter.sendNotification(notificationPayload, Collections.singletonList(MessagingType.PUSH));
        } catch (Exception ex) {
            log.error("Error sending push notification for PAY_BILL_SUCCESS for customerAccountId[{}], billPayTransactionId[{}], amount[{}] and billerName[{}]. StackTrace: [{}]",
                    customerAccountId, billPayTransactionId, amountFulfilled, billerName, ExceptionUtils.getStackTrace(ex));
        }
    }

}
