package com.walmart.international.wallet.payment.core.adapter.customer;

import com.walmart.international.services.digitalwallet.httpclient.wallet.constants.ApiName;

public enum CustomerAPIName implements ApiName{
    GET_PAYMENT_INSTRUMENTS, GET_CUSTOMER_BY_ID, GET_CUSTOMER_BASIC_DETAIL_BY_ID, UPDATE_LAST_USED_CARD_DATE, UPDATE_PAYMENT_PREFERENCE;

    @Override
    public String getApiName() {
        return this.name();
    }
}
