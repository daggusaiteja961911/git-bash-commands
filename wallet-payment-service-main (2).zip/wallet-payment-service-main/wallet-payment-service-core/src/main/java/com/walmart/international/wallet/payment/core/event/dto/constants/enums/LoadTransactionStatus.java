package com.walmart.international.wallet.payment.core.event.dto.constants.enums;

public enum LoadTransactionStatus {
    CHARGE_INITIATED,
    CHARGE_SUCCESS,
    CHARGE_FAILED,
    REVERSE_INITIATED,
    REVERSE_INITIATION_FAILED,
    PANGEA_ADD_BALANCE_SUCCESS,
    PANGEA_ADD_BALANCE_FAIL,
    PANGEA_UNLOCK_SUCCESS,
    PANGEA_UNLOCK_FAIL
}
