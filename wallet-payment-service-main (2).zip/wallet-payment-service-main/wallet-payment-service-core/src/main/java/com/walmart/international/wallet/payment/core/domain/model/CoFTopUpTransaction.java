package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.wallet.payment.core.constants.enums.CoFTopupTxnStateReason;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;
import lombok.experimental.SuperBuilder;
import org.apache.commons.collections.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CoFTopUpTransaction extends Transaction {

    private CoFTopupPaymentOptions cofTopupPaymentOptions;
    @Singular("cardPaymentTransactionList")
    private List<CardPaymentTransaction> cardPaymentTransactionList;
    @Singular("giftCardLoadTransactionList")
    private List<GiftCardTransaction> giftCardLoadTransactionList;
    private CoFTopupTxnStateReason stateReason;

    public Optional<UUID> getCardSubTransactionId() {
        if (CollectionUtils.isNotEmpty(this.getCardPaymentTransactionList())
                && Objects.nonNull(this.getCardPaymentTransactionList().get(0).getCardSubTransaction())) {
            return Optional.of(this.getCardPaymentTransactionList().get(0).getCardSubTransaction().getId());
        }
        return Optional.empty();
    }

}
