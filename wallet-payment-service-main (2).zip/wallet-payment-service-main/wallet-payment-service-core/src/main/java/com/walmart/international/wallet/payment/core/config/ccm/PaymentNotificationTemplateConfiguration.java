package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "payment-notification-template-config")
public interface PaymentNotificationTemplateConfiguration {

    @Property(propertyName = "payment.failed.reversal.notification.warning.logo")
    String getPaymentFailedReversalNotificationWarningLogo();

    @Property(propertyName = "payment.failed.reversal.push.expiry.time")
    Integer getPaymentFailedReversalPushExpiryTime();

    @Property(propertyName = "billpay.success.in.app.notification.expiry.time")
    Integer getBillPaySuccessInAppNotificationExpiryTime();
}
