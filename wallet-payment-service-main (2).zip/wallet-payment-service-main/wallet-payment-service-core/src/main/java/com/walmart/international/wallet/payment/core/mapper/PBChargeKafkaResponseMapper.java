package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.ewallet.payment.api.dto.GatewayDetails;
import com.walmart.international.ewallet.payment.api.dto.TxnDetail;
import com.walmart.international.ewallet.payment.common.constant.CurrencyUnit;
import com.walmart.international.ewallet.payment.common.constant.ResultStatus;
import com.walmart.international.ewallet.payment.common.dto.Amount;
import com.walmart.international.services.payment.core.kafka.response.AsyncChargeKafkaPayload;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.ChargeEventDetails;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.ErrorDetails;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PBChargeKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.PaymentStatus;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.util.UUID;

@Mapper(componentModel = "spring")
public interface PBChargeKafkaResponseMapper {

    @Mapping(target = "eventType", source = "kafkaResponse.eventType")
    @Mapping(target = "eventPayload", source = "kafkaResponse.eventPayload", qualifiedByName = "mapEventPayloadToPaymentCoreRequest")
    AsyncChargeKafkaPayload.AsyncChargeKafkaResponse mapPBKafkaResponseToPaymentCoreRequest(PBChargeKafkaResponse kafkaResponse);


    @Named("mapEventPayloadToPaymentCoreRequest")
    @Mapping(target = "paymentProviderParentTxnId", source = "chargeEventDetails.paymentBrokerParentId")
    @Mapping(target = "orderId", source = "chargeEventDetails.orderId")
    @Mapping(target = "txns", source = "chargeEventDetails.payments", qualifiedByName = "mapChargeEventToPaymentCoreRequest")
    AsyncChargeKafkaPayload.ChargeEventPayload mapEventPayloadToPaymentCoreRequest(ChargeEventDetails chargeEventDetails);

    @Named("mapChargeEventToPaymentCoreRequest")
    @Mapping(target = "paymentId", source = "paymentDetail.paymentId", qualifiedByName = "convertStringToUUID")
    @Mapping(target = "paymentProviderTxnId", source = "paymentDetail.paymentBrokerId")
    @Mapping(target = "paymentProviderCreationDate", source = "paymentDetail.creationDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    @Mapping(target = "status", source = "paymentDetail.status", qualifiedByName = "mapPaymentStatus")
    @Mapping(target = "amount", source = "paymentDetail.amount", qualifiedByName = "mapFromAmount")
    @Mapping(target = "fraudStatus", source = "paymentDetail.fraudStatus")
    @Mapping(target = "paymentProviderError", source = "paymentDetail.error", qualifiedByName = "mapErrorToPaymentCoreError")
    @Mapping(target = "gateway", source = "paymentDetail.gateway", qualifiedByName = "mapGatewayToPaymentCoreRequest")
    TxnDetail mapChargeEventToPaymentCoreRequest(ChargeEventDetails.PaymentDetails paymentDetail);

    @Named("mapGatewayToPaymentCoreRequest")
    @Mapping(target = "name", source = "gateway.name")
    @Mapping(target = "referenceId", source = "gateway.referenceId")
    @Mapping(target = "cardReference", source = "gateway.cardReference")
    @Mapping(target = "transactionDate", source = "gateway.transactionDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    @Mapping(target = "authorization", source = "gateway.authorization")
    @Mapping(target = "affiliationNumber", source = "gateway.affiliationNumber")
    GatewayDetails mapGatewayToPaymentCoreRequest(com.walmart.international.wallet.payment.core.adapter.kafka.request.pb.GatewayDetails gateway);

    @Named("mapErrorToPaymentCoreError")
    @Mapping(target = "paymentProviderErrorCode", source = "pbError.errorCode")
    @Mapping(target = "paymentProviderErrorMessage", source = "pbError.errorDescription")
    TxnDetail.PaymentProviderError mapErrorToPaymentCoreError(ErrorDetails pbError);

    @Named("convertStringToUUID")
    default UUID mapFromString(String s) {
        return UUID.fromString(s);
    }

    @Named("mapPaymentStatus")
    default ResultStatus mapPaymentStatus(PaymentStatus paymentStatus) {
        switch (paymentStatus) {
            case SUCCESS:
                return ResultStatus.SUCCESS;
            case FAILED:
                return ResultStatus.FAILURE;
            case PENDING:
                return ResultStatus.PENDING;
            case AUTHORISED:
                return ResultStatus.AUTHORISED;
            case THREE_DS_GENERATED:
                return ResultStatus.THREE_DS_GENERATED;
            default:
                return ResultStatus.UNKNOWN;
        }
    }

    @Named("mapFromAmount")
    default Amount mapFromAmount(BigDecimal amount) {
        return Amount.builder()
                .amount(amount)
                .currencyUnit(CurrencyUnit.MXN).
                build();
    }


}
