# wallet-payment-service

## Local Setup Guide
- Checkout to the main branch : `git checkout main`
- Run `mvn compile` and `mvn clean install` from terminal (Requires VPN Connection)
- Create a folder to hold configuration data in local, for eg : `/Users/<user>/secrets/wallet-payment-service`
- Create a folder to hold kafka-ssl.properties in local, for eg : `/Users/<user>/scm/sandbox/wallet-payment-service/<env>`

### Download CCM2 configurations
- https://admin.tunr.non-prod.walmart.com/services/wallet-payment-service/service-configs/qa-1.0.0
- Click on `Work offline` and download with envName=<env>
- Extract and unzip to above secrets folder
~~Secrets from Vault~~  
~~The secret configurations are stored in Vault and they should be downloaded to local as well.~~

#### Secrets from Akeyless
- Sign in using SAML in Akeyless : https://akeyless.gw.prod.glb.us.walmart.net:18888/
- Akeyless Path: `Prod/WCNP/homeoffice/IDCDigitalWalletProd/<env>/wallet-payment-service`
- Download following files to secrets folder: 1.secret_props, 2.arcus_props, 3.paymentbroker-config
- For local setup , update the trustore and keystore location to `/tmp/truststore.jks` and `/tmp/keystore.jks` respectively in the secret_props file. The ssl password in secret_props needs to be updated to match the password in local `kafka-ssl.properties`.
- Download keystore and truststore from `Prod/WCNP/homeoffice/IDCDigitalWalletProd/<env>/common` to local. They are base64 encoded. These should be decoded and placed in `/tmp` folder
```
base64 --decode -i keystore.txt > /tmp/keystore.jks 
base64 --decode -i truststore.txt > /tmp/truststore.jks
```
- Refer https://walmart.slack.com/archives/G01D5P4TZ9N/p1660050477613879 for setting up kafka-ssl.properties file in local **OR** Reach out to a teammate
- Also download the file 55858464-38cd-4bad-a9bd-dc3dc27a5130.txt from `Prod/WCNP/homeoffice/IDCDigitalWalletProd/<env>/common` to local and place it in `/tmp` folder as well

##### Java VM args
```
-Dcom.walmart.platform.config.runOnEnv=<env>
-Druntime.context.environmentType=<env>
-Druntime.context.environment=<env>
-Druntime.context.cashi.tenant=MX
-Dccm.configs.dir=/Users/<user>/secrets/wallet-payment-service/wallet-payment-service-qa-1_0.0
-Dexternal.configs.source.dir=/Users/<user>/secrets/wallet-payment-service
-DsecretPath=/Users/<user>/secrets/wallet-payment-service/secret_props.properties
-Druntime.context.system.property.override.enabled=true
-Druntime.context.appName=wallet-payment-service
-Djsse.enableSNIExtension=true
-Dscm.server.url=http://tunr.non-prod.walmart.com/scm-app/v2
-Dcom.walmart.platform.logging.profile=CONSOLE
-Dcom.walmart.platform.logging.file.format=OTelLog
-Dcom.walmart.platform.telemetry.otel.enabled=true
-Dcom.walmart.platform.metrics.impl.type=MICROMETER
-Dcom.walmart.platform.metrics.enabled=true
-Dcom.walmart.platform.metrics.histogram.impl.type=HistogramOnly
-Dcom.walmart.platform.metrics.whitelist=ALL
-Dcom.walmart.platform.txnmarking.otel.type=LOGGING
-DprivateKeyPath=/tmp/55858464-38cd-4bad-a9bd-dc3dc27a5130.txt
-Dspring.profiles.active=<env>
-Dio.strati.RuntimeContext=io.strati.impl.runtime.context.RuntimeContextEnv
-Dcom.walmart.platform.txnmarking.kafka.brokerList=null
-Dcom.walmart.platform.txnmarking.file.path=/dev/null
-Dcom.walmart.platform.metrics.file.path=/dev/null
-Dcom.walmart.platform.metrics.forwardToRawlog=false
-Dcom.walmart.platform.metrics.log=true
-Djavax.net.ssl.trustStore=/tmp/truststore.jks
-Dssl.truststore.location=/tmp/truststore.jks
-Dssl.keystore.location=/tmp/keystore.jks
-Dorg.jboss.logging.provider=slf4j
```
