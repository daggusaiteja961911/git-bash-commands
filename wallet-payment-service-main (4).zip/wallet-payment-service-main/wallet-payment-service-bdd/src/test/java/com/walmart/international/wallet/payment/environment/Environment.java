package com.walmart.international.wallet.payment.environment;

import com.github.dockerjava.api.command.CreateContainerCmd;
import com.github.dockerjava.api.model.ExposedPort;
import com.github.dockerjava.api.model.HealthCheck;
import com.github.dockerjava.api.model.PortBinding;
import com.github.dockerjava.api.model.Ports;

import lombok.SneakyThrows;
import org.junit.ClassRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.Network;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.images.builder.ImageFromDockerfile;
import org.testcontainers.utility.DockerImageName;
import org.testcontainers.utility.MountableFile;

import java.nio.file.Paths;
import java.time.Duration;
import java.util.Arrays;
import java.util.function.Consumer;

public class Environment {

    private static final Logger log = LoggerFactory.getLogger(Environment.class);
    private static Consumer<CreateContainerCmd> databasePort = e -> e.withPortBindings(new PortBinding(Ports.Binding.bindPort(1433), new ExposedPort(1433)));
    private static Consumer<CreateContainerCmd> appPort = e -> e.withPortBindings(new PortBinding(Ports.Binding.bindPort(8090), new ExposedPort(8090)));
    private static Consumer<CreateContainerCmd> ewalletPort = e -> e.withPortBindings(new PortBinding(Ports.Binding.bindPort(8080), new ExposedPort(8080)));
    private static Consumer<CreateContainerCmd> zookeeperPort = e -> e.withPortBindings(new PortBinding(Ports.Binding.bindPort(2181), new ExposedPort(2181)));
    private static Consumer<CreateContainerCmd> kafkaPort = e -> e.withPortBindings(new PortBinding(Ports.Binding.bindPort(9092), new ExposedPort(9092)));
    private static Consumer<CreateContainerCmd> memcachedPort = e -> e.withPortBindings(new PortBinding(Ports.Binding.bindPort(11211), new ExposedPort(11211)));
    public static String apiBaseUrl = "";
    public static String jdbcUrl = "";

    public static void createEnvironmentIfNotExists() {
        if (!app.isCreated()) {
            log.info("createEnvironmentIfNotExists: creating the environment");
            init();
        }
    }

    @SneakyThrows
    public static void init() {
        zookeeper.start();
        kafka.start();
        kafkaInitializer.start();
        database.start();
        Thread.sleep(10000);
        mssqlTools.start();
        jdbcUrl = "jdbc:sqlserver://" + database.getHost() + ":1433";
        log.info("apiBaseUrl: " + apiBaseUrl);
    }

    public static void stopContainers() {
        app.getDockerClient()
                .stopContainerCmd(app.getContainerId())
                .withTimeout(100)
                .exec();
        // TODO : check this
        app.copyFileFromContainer("/opt/jacoco-it.exec", "target/jacoco-it.exec");
    }

    public static String getApiBaseUrl() {
        return apiBaseUrl;
    }

    public static String getJdbcUrl(){
        return jdbcUrl;
    }

    @ClassRule
    public static Network network = Network.newNetwork();

    @ClassRule
    public static GenericContainer<?> database = new GenericContainer<>(
            DockerImageName.parse("azcr.docker.prod.walmart.com/azure-sql-edge:latest"))
            .withCreateContainerCmdModifier(databasePort)
            .withCreateContainerCmdModifier(it -> {
                it.withHealthcheck(new HealthCheck()
                        .withTest(Arrays.asList("/opt/mssql-tools/bin/sqlcmd -U sa -P Pass@word -Q \"SELECT \\\"READY\\\"\" | grep -c \"READY\""))
                        .withRetries(5));
            })
            .withNetwork(network)
            .withNetworkAliases("database")
            .withExposedPorts(1433)
            .withEnv("SA_PASSWORD", "Pass@word")
            .withEnv("ACCEPT_EULA", "Y")
            .withCopyFileToContainer(MountableFile.forClasspathResource("test-data/database", 0777), "/tmp/database/");

    @ClassRule
    public static GenericContainer<?> mssqlTools = new GenericContainer<>(
            DockerImageName.parse("azcr.docker.prod.walmart.com/mssql-tools:latest"))
            .withCreateContainerCmdModifier(it -> {
                if (System.getProperty("sys.arch") != null) {
                    it.withPlatform(System.getProperty("sys.arch"));
                }
                it.withStdinOpen(true);
            })
            .withNetwork(network)
            .withNetworkAliases("mssql-tools")
            .withEnv("ACCEPT_EULA", "Y")
            .withEnv("SA_PASSWORD", "Pass@word")
            .withEnv("MSSQL_DATABASE", "test")
            .withCopyFileToContainer(MountableFile.forClasspathResource("test-data/database", 0777), "/tmp/database/")
            .withCommand("/tmp/database/database-init.sh")
            .dependsOn(database);

    @ClassRule
    public static GenericContainer<?> zookeeper = new GenericContainer<>(
            DockerImageName.parse("confluentinc/cp-zookeeper:7.0.1"))
            .withCreateContainerCmdModifier(zookeeperPort)
            .withNetwork(network)
            .withNetworkAliases("zookeeper")
            .withExposedPorts(2181)
            .withEnv("ZOOKEEPER_CLIENT_PORT", "2181")
            .withEnv("ZOOKEEPER_TICK_TIME", "2000");

    @ClassRule
    public static GenericContainer<?> kafka = new GenericContainer<>(
            DockerImageName.parse("confluentinc/cp-kafka:7.0.1"))
            .withCreateContainerCmdModifier(kafkaPort)
            .withNetwork(network)
            .withNetworkAliases("kafka")
            .withExposedPorts(9092)
            .withEnv("KAFKA_BROKER_ID", "1")
            .withEnv("KAFKA_ZOOKEEPER_CONNECT", "zookeeper:2181")
            .withEnv("KAFKA_LISTENER_SECURITY_PROTOCOL_MAP", "PLAINTEXT:PLAINTEXT,PLAINTEXT_INTERNAL:PLAINTEXT")
            .withEnv("KAFKA_ADVERTISED_LISTENERS", "PLAINTEXT://localhost:9092,PLAINTEXT_INTERNAL://kafka:29092")
            .withEnv("KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR", "1")
            .withEnv("KAFKA_TRANSACTION_STATE_LOG_MIN_ISR", "1")
            .withEnv("KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR", "1")
            .waitingFor(Wait.forListeningPort())
            .dependsOn(zookeeper);

    @ClassRule
    public static GenericContainer<?> kafkaInitializer = new GenericContainer<>(
            DockerImageName.parse("confluentinc/cp-kafka:7.0.1"))
            .withNetwork(network)
            .dependsOn(kafka)
            .withCopyFileToContainer(MountableFile.forClasspathResource("test-data/kafka-init.sh", 0777), "/tmp/kafka-init.sh")
            .withCommand("/tmp/kafka-init.sh");

    @ClassRule
    public static GenericContainer<?> app = new GenericContainer<>(
            new ImageFromDockerfile()
                    .withFileFromClasspath("Dockerfile", "Dockerfile")
                    .withFileFromClasspath("test-data", "test-data")
                    .withFileFromPath("app.jar", Paths.get("src/test/resources/app.jar")))
            .withExposedPorts(8090)
            .withNetwork(network)
            .withCreateContainerCmdModifier(appPort)
            .withNetworkAliases("app")
            .withCopyFileToContainer(MountableFile.forClasspathResource("test-data/database", 0777), "/tmp/database/")
            .withCopyFileToContainer(MountableFile.forHostPath("./target/jacoco-agent/org.jacoco.agent-runtime.jar", 0777), "/opt/org.jacoco.agent-runtime.jar")
            .waitingFor(Wait.forHttp("/wallet-service/actuator/health").withStartupTimeout(Duration.ofSeconds(450)))
            .dependsOn(mssqlTools);
}
