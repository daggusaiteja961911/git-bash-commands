package com.walmart.international.wallet.payment.stepdefs;

import com.walmart.international.wallet.payment.bdd.TestApplicationBdd;
import com.walmart.international.wallet.payment.environment.SpringBootContextInitializer;
import com.walmart.international.wallet.payment.environment.TestJpaConfig;
import io.cucumber.java.Before;
import io.cucumber.spring.CucumberContextConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@Slf4j
@CucumberContextConfiguration
@SpringBootTest
@ContextConfiguration(
        initializers = { SpringBootContextInitializer.class },
        classes = {TestApplicationBdd.class, TestJpaConfig.class}
)
public class SpringIntegrationTest {

    @Before
    public void before(){
        log.info("++++++++++++ IN SPRING INTEGRATION TEST CLASS ++++++++++++++");
    }
}
