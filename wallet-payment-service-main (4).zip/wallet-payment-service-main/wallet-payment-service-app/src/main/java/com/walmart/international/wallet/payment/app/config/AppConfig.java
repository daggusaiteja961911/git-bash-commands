package com.walmart.international.wallet.payment.app.config;

import com.walmart.international.campaign.client.CampaignServiceClientImpl;
import com.walmart.international.digiwallet.customer.adapter.CustomerServiceAdapter;
import com.walmart.international.digiwallet.customer.adapter.impl.CustomerServiceAdapterImpl;
import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.FlowBuilder;
import com.walmart.international.services.digitalwallet.httpclient.service.DigitalWalletHttpClient;
import com.walmart.international.wallet.payment.core.constants.enums.flow.CAFlowType;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Autowired
    private DigitalWalletHttpClient httpClient;

    @Bean("campaignServiceClient")
    CampaignServiceClientImpl getCampaignServiceClient() {
        return new CampaignServiceClientImpl();
    }

    @Bean("flowBuilder")
    FlowBuilder wpsFlowTypeFlowBuilder() {
        if (Tenant.getTenant().equals(Tenant.MX)) {
            return new FlowBuilder<>().initiate(MXFlowType.values());
        } else if (Tenant.getTenant().equals(Tenant.CA)) {
            return new FlowBuilder<>().initiate(CAFlowType.values());
        }
        throw new BeanCreationException("Missing tenant context");
    }

    @Bean("customerServiceAdapter")
    CustomerServiceAdapter getCustomerServiceAdapter() {
        return new CustomerServiceAdapterImpl(httpClient);
    }
}
