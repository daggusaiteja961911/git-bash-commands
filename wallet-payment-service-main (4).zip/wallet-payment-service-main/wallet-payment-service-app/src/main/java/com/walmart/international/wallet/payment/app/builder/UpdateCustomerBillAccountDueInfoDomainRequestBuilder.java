package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.BillMapper;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountDueInfoRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class UpdateCustomerBillAccountDueInfoDomainRequestBuilder extends BaseDomainRequestBuilder<UpdateCustomerBillAccountDueInfoRequest, BillRequestDomainContext> {

    BillMapper billMapper = BillMapper.INSTANCE;

    @Override
    public BillRequestDomainContext buildDomainRequest(UpdateCustomerBillAccountDueInfoRequest updateCustomerBillAccountDueInfoRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        return BillRequestDomainContext.builder()
                .customerBillAccount(billMapper.updateCustomerBillAccountDueInfoRequestToCustomerBillAccount(updateCustomerBillAccountDueInfoRequest))
                .headers(headers)
                .build();
    }
}
