package com.walmart.international.wallet.payment.app.healthcheck;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;
import java.util.HashMap;

@Slf4j
@Component
public class DatabaseHealthIndicator extends AbstractHealthIndicator {
    @Autowired
    private DataSource dataSource;
    private static final String QUERY = "SELECT 1";

    public void getDBHealth(Health.Builder builder) {
        HashMap<String, String> details = new HashMap<>();
        try (Connection connection = dataSource.getConnection()) {
            details.put("query", QUERY);

            if (connection != null && connection.getMetaData() != null) {
                details.put("driverName", connection.getMetaData().getDriverName());
                Statement statement = connection.createStatement();
                statement.execute(QUERY);
            }
        } catch (Exception ex) {
            log.error("DB Health check failed with exception: ", ex);
            builder.down().withDetails(details).withException(ex).build();
            return;
        }

        builder.up().withDetails(details).build();
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        getDBHealth(builder);
    }
}