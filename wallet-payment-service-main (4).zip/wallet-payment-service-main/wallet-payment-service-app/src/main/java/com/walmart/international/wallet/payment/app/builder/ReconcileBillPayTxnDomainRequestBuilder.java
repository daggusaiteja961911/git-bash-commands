package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.billpay.ReconcilePendingBillPayTxnRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class ReconcileBillPayTxnDomainRequestBuilder extends BaseDomainRequestBuilder<ReconcilePendingBillPayTxnRequest, BillPayTxnRequestDomainContext> {

    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(ReconcilePendingBillPayTxnRequest request, MultiValueMap<String, String> headers, Tenant tenant) {
        return BillPayTxnRequestDomainContext.builder()
                .transaction(BillPayTransaction.builder().transactionId(request.getTxnId()).build())
                .headers(headers)
                .build();
    }
}

