package com.walmart.international.wallet.payment.app.service.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.dto.request.migration.BillerDataUpdatePollRequest;
import com.walmart.international.wallet.payment.dto.response.migration.BillProviderInfoDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerCategoriesDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerDataUpdatePollResponse;
import com.walmart.international.wallet.payment.dto.response.migration.BillersListResponseDTO;

public interface MigrationBillerService {

    BillerCategoriesDTO getBillerCategories(int billerCategoryVersion);

    BillersListResponseDTO getPopularBillers() throws BusinessValidationException;

    BillProviderInfoDTO getBillProviderInfo(String processorBillerId) throws ApplicationException;

    BillerDataUpdatePollResponse getBillerDataUpdateInfo(BillerDataUpdatePollRequest billerDataUpdatePollRequest);
}
