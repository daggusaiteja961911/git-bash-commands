package com.walmart.international.wallet.payment.app.service.impl.mapper;

import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerCategoryDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerInformation;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPlanDetailUpdateInfo;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillerCategoryBillerDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillerCategoryProductBillerDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.GetPopularBillersBillerDTO;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 *  Mapping from domain entity to DTO
 */
@Mapper
@Component
public interface BillerDTOMapper {
    BillerDTOMapper INSTANCE = Mappers.getMapper(BillerDTOMapper.class);

    BillerInformation mapBillerInformation(Biller biller);

    List<BillerByIdDTO> mapBillerEntitiesToDTO(List<Biller> billers);

    BillerByIdDTO mapBiller(Biller biller);

    default List<GetBillerCategoryBillerDTO> mapBillerEntitiesToGetBillerCategoryBillerDTO(List<Biller> billers) {
        List<GetBillerCategoryBillerDTO> getBillerCategoryBillerDTOS = null;
        if (CollectionUtils.isNotEmpty(billers)) {
            getBillerCategoryBillerDTOS = new ArrayList<>();
            for (Biller biller : billers) {
                getBillerCategoryBillerDTOS.add(mapBillerEntityToGetBillerCategoryBillerDTO(biller));
            }
        }
        return getBillerCategoryBillerDTOS;
    }

    @Mapping(target = "isNewBiller", source = "newBiller")
    @Mapping(target = "products", source = "subBillers")
    GetBillerCategoryBillerDTO mapBillerEntityToGetBillerCategoryBillerDTO(Biller biller);

    @Mapping(target = "isNewBiller", source = "newBiller")
    GetBillerCategoryProductBillerDTO mapBillerEntityToGetBillerCategoryProductBilletDTO(Biller biller);

    default List<BillerPlanDetailUpdateInfo> mapBillerDataLastUpdatedAtMap(Map<String, Object> billerDataLastUpdatedAtMap) {
        List<BillerPlanDetailUpdateInfo> billerPlanDetailUpdates = new ArrayList<>();
        if (Objects.nonNull(billerDataLastUpdatedAtMap)) {
            billerDataLastUpdatedAtMap.forEach((key, value) -> billerPlanDetailUpdates.add(BillerPlanDetailUpdateInfo.builder()
                    .billerId(UUID.fromString(key.substring(0, key.indexOf(WPSConstants.Biller.SUFFIX_BILLER_DATA_UPDATED_AT))))
                    .lastUpdatedAt((LocalDateTime) value)
                    .build()));
        }
        return billerPlanDetailUpdates;
    }

    List<BillerCategoryDTO> mapBillerCategoriesListToBillerCategoryDTOList(List<BillerCategory> billerCategoriesList);

    @Mapping(target = "isNewBiller", source = "newBiller")
    @Mapping(target = "products", source = "subBillers")
    GetPopularBillersBillerDTO mapBillerEntityToGetPopularBillersBillerDTO(Biller biller);

    default List<GetPopularBillersBillerDTO> mapBillerEntityListToGetPopularBillersBillerDTOList(List<Biller> billerList) {
        List<GetPopularBillersBillerDTO> popularBillersBillerDTOS = null;
        if (CollectionUtils.isNotEmpty(billerList)) {
            popularBillersBillerDTOS = new ArrayList<>();
            for (Biller biller : billerList) {
                popularBillersBillerDTOS.add(mapBillerEntityToGetPopularBillersBillerDTO(biller));
            }
        }
        return popularBillersBillerDTOS;
    }
}
