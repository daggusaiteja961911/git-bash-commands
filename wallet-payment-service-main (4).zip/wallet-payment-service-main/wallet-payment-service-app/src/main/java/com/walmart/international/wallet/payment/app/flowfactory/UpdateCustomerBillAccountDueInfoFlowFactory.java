package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import org.springframework.stereotype.Component;

@Component
public class UpdateCustomerBillAccountDueInfoFlowFactory extends FlowFactory<BillRequestDomainContext> {

    @Override
    public FlowType deriveFlow(BillRequestDomainContext billRequestDomainContext, Tenant tenant) throws ProcessingException {
        switch (tenant) {
            case MX:
                return MXFlowType.UPDATE_CUSTOMER_BILL_ACCOUNT_DUE_INFO;
            case CA:
            case UNKNOWN:
            default:
                String msg = String.format("Invalid tenantId [%s] for UpdateCustomerBillAccountDueInfo flow", tenant);
                throw new ProcessingException(ErrorConstants.UpdateCustomerBillAccountDueInfo.FLOW_FACTORY_INVALID_TENANT_ID, msg);
        }
    }
}
