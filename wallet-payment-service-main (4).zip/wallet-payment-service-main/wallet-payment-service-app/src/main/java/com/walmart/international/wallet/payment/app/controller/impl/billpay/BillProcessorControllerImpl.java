package com.walmart.international.wallet.payment.app.controller.impl.billpay;

import com.walmart.international.wallet.payment.app.controller.billpay.BillProcessorController;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillProcessorControllerImpl implements BillProcessorController {

//   TODO
//    Implement following APIs here
//     1. getAccount
//     2. getUtilities
//     3. getTopUps
//     4. getBillPayTxn - Arcus Search API
//     5. getGiftCards (new API)

}
