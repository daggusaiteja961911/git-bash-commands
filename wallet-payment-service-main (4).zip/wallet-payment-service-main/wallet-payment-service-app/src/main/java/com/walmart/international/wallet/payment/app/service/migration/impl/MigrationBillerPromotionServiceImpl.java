package com.walmart.international.wallet.payment.app.service.migration.impl;

import com.walmart.international.wallet.payment.app.service.migration.MigrationBillerPromotionService;
import com.walmart.international.wallet.payment.app.service.migration.impl.mapper.MigrationBillerPromotionDTOMappper;
import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import com.walmart.international.wallet.payment.core.service.BillerPromotionCoreService;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class MigrationBillerPromotionServiceImpl implements MigrationBillerPromotionService {

    @Autowired
    private BillerPromotionCoreService billerPromotionCoreService;

    private static final MigrationBillerPromotionDTOMappper billerPromotionDTOMappper = MigrationBillerPromotionDTOMappper.INSTANCE;

    @Override
    public BillerPromotionsResponse getPromotions(String billerCategoryIds, String billerIds, int billerCategoryVersion) {
        HashMap<String, List<BillerPromotionDTO>> billerPromotions = new HashMap<>();
        Map<String, List<BillerPromotion>> billerPromotionsForPromotionCategory = billerPromotionCoreService.getAllPromotionsForPromotionCategory(billerCategoryIds, billerIds, billerCategoryVersion);
        for (Map.Entry<String, List<BillerPromotion>> billerPromotionsByBillerId : billerPromotionsForPromotionCategory.entrySet()) {
            billerPromotions.put(billerPromotionsByBillerId.getKey(), billerPromotionDTOMappper.mapBillerPromotionsToBillerPromotionDTOs(billerPromotionsByBillerId.getValue()));
        }
        return BillerPromotionsResponse.builder()
                .promotionMap(billerPromotions)
                .build();
    }
}
