package com.walmart.international.wallet.payment.app.service.impl;


import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.EventType;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionSource;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.TransactionType;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TransactionEventDTO;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TxnCompletedEventPayload;
import com.walmart.international.notification.service.TxnEventAuditService;
import com.walmart.international.wallet.payment.core.config.ccm.TxnAggregatorResiliencyConfig;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionSyncType;
import com.walmart.international.wallet.payment.data.dao.entity.TxnEventAuditDO;
import com.walmart.international.wallet.payment.data.dao.repository.TxnEventAuditRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.OptimisticLockException;
import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;


@Component
@Slf4j
public class TxnEventAuditServiceImpl implements TxnEventAuditService {

    @Autowired
    private TxnEventAuditRepository txnEventAuditRepository;

    @ManagedConfiguration
    private TxnAggregatorResiliencyConfig txnAggregatorConfiguration;

    private final Set<TransactionSource> walletTransactionTypes = Set.of(TransactionSource.POS, TransactionSource.MERCHANT, TransactionSource.BILLER, TransactionSource.CASHI);

    @Override
    public <T> void updateLastSyncDetailsOfCurrentTxn(T payloadData) {
        if (txnAggregatorConfiguration.isTxnResiliencyFeatureEnabled()){
            try {
                if (payloadData == null || !EventType.TXN_COMPLETED.getType().equals(((EventPayload)payloadData).getType()))
                    return;

                TxnCompletedEventPayload txnCmpEvent = (TxnCompletedEventPayload) ((EventPayload) payloadData).getData();
                TransactionEventDTO txnEvent = txnCmpEvent.getTransactionEvent();

                log.info("Transaction source: :{} ", txnEvent.getRelatedTxnSource());

                if (walletTransactionTypes.contains(txnEvent.getTransactionSource())) {
                    log.info("Found payload of type TxnCompletedEventPayload :: going to update sync details for txn:{} and source: {}", txnEvent.getTransactionId(), txnEvent.getTransactionSource());
                    if (txnEvent.getLastEventDate() != null) {
                        if (txnEvent.getTransactionType().equals(TransactionType.PAY) || txnEvent.getTransactionType().equals(TransactionType.REFUND))
                            this.updateLastSyncDateOfTxnForEvent(txnEvent.getTransactionId(), txnEvent.getLastEventDate(), txnEvent.getStateReason(), TransactionSyncType.BILL_PAY);
                        else
                            this.updateLastSyncDateOfTxnForEvent(txnEvent.getTransactionId(), txnEvent.getLastEventDate(), txnEvent.getStateReason(), TransactionSyncType.LOAD_MONEY);
                    }
                    else
                        log.error("Last event date not set in the generated payload for transactionId : {}", txnEvent.getTransactionId());
                } else
                    log.error("Transaction : {} with source as : {} is ineligible for txn agg sync flow", txnEvent.getTransactionId(), txnEvent.getTransactionSource());
            } catch (Exception ex) {
                log.error("Error while updating last sync details of the current txn : {}", ex.getMessage());
            }
        }
    }

    private void updateLastSyncDateOfTxnForEvent(UUID transactionId, Date lastSyncDate, String lastEvent, TransactionSyncType transactionSyncType) {
        try {
            Optional<TxnEventAuditDO> existingTxnEntity = txnEventAuditRepository.findById(transactionId);
            TxnEventAuditDO updatedTxnDO = null;
            if (existingTxnEntity.isPresent()) {
                TxnEventAuditDO existingTxnDO = existingTxnEntity.get();
                if (existingTxnDO.getLastSyncedDate() == null || lastSyncDate.compareTo(existingTxnDO.getLastSyncedDate()) > 0) {
                    //current last sync is greater than existing one
                    existingTxnDO.setLastSyncedDate(lastSyncDate);
                    existingTxnDO.setLastSyncedEventDesc(lastEvent);
                    existingTxnDO.setTransactionSyncType(transactionSyncType);
                    updatedTxnDO = existingTxnDO;
                }
            } else {
                //insert
                log.info("No existing txn sync DO found , inserting a new one for txn : {}", transactionId);
                updatedTxnDO = new TxnEventAuditDO(transactionId, lastSyncDate, lastEvent, transactionSyncType);
            }
            //updating retry count in case of successful sync
            if ( updatedTxnDO != null) {
                updatedTxnDO.setRetryCount(0);
            }
            if (updatedTxnDO == null)
                throw new BusinessValidationException("Bad Argument, Error while saving TransactionAudit with transaction id : {}", transactionId.toString());
            txnEventAuditRepository.save(updatedTxnDO);
        } catch (OptimisticLockException ex) {
            log.error("Optimistic lock exception on TxnEventAudit Entity while performing an update for synced txn : {} : {} with error:{}", transactionId, ex.getEntity(), ex.getMessage());
            throw ex;
        } catch (Exception ex) {
            log.error("Exception in updateLastSyncDateOfTxnForEvent for transactionId : {} error::{} ", transactionId, ex.getMessage(), ex);
            throw ex;
        }
    }
}
