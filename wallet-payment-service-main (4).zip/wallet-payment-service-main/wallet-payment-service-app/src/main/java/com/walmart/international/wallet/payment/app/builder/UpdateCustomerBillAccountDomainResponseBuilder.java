package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.app.builder.mapper.BillMapper;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class UpdateCustomerBillAccountDomainResponseBuilder extends BaseDomainResponseBuilder<UpdateCustomerBillAccountResponse, BillRequestDomainContext, BillResponseDomainContext> {

    BillMapper billMapper = BillMapper.INSTANCE;

    @Override
    public BillResponseDomainContext buildDomainResponse(BillRequestDomainContext billRequestDomainContext) {
        return BillResponseDomainContext.builder().build();
    }

    @Override
    public UpdateCustomerBillAccountResponse buildDomainResponse(BillRequestDomainContext billRequestDomainContext, BillResponseDomainContext billResponseDomainContext) {
        return billMapper.customerBillAccountToUpdateCustomerBillAccountResponse(billResponseDomainContext.getCustomerBillAccount());
    }
}
