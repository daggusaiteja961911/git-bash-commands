package com.walmart.international.wallet.payment.app.service.migration.impl;

import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillPaymentService;
import com.walmart.international.wallet.payment.dto.request.migration.CancelPayBillInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchBillPayPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.PayInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeInitRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelPayBillInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchBillPayPaymentInstrumentsResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.ValidateChargeInitResponseEWS;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.UUID;

@Component
@Slf4j
public class MigrationBillPaymentServiceImpl implements MigrationBillPaymentService {

    @Autowired
    WalletServiceRouter walletServiceRouter;
    @Override
    public FetchBillPayPaymentInstrumentsResponseEWS fetchBillPayPaymentInstruments(UUID customerAccountId, FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        fetchBillPayPaymentInstrumentsRequest.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationFetchBillPayPaymentInstruments(fetchBillPayPaymentInstrumentsRequest, headers);
    }

    @Override
    public PayInitResponseEWS payBillInit(UUID customerAccountId, PayInitRequestEWS payInitRequestEWS, MultiValueMap<String, String> headers) {
        payInitRequestEWS.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationPayBillinit(payInitRequestEWS, headers);
    }

    @Override
    public CancelPayBillInitResponseEWS cancelPaymentInit(UUID customerAccountId, UUID transactionId, CancelPayBillInitRequestEWS cancelPayBillInitRequestEWS, MultiValueMap<String, String> headers) {
        cancelPayBillInitRequestEWS.setCustomerAccountId(customerAccountId);
        cancelPayBillInitRequestEWS.setTransactionId(transactionId);
        return walletServiceRouter.migrationCancelPayBillInit(cancelPayBillInitRequestEWS, headers);
    }

    @Override
    public ValidateChargeInitResponseEWS validateChargeInit(UUID customerAccountId, ValidateChargeInitRequestEWS validateChargeInitRequestEWS, MultiValueMap<String, String> headers) {
       validateChargeInitRequestEWS.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationValidatePayBillInit(validateChargeInitRequestEWS, headers);
    }

    @Override
    public FetchPaymentOptionsWithPreselectionResponse fetchBillPayPaymentInstrumentsWithPreselection(UUID customerAccountId, FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        fetchBillPayPaymentInstrumentsRequest.setCustomerAccountId(customerAccountId);
        return walletServiceRouter.migrationFetchBillPayPaymentInstrumentsWithPreselection(fetchBillPayPaymentInstrumentsRequest, headers);

    }
}
