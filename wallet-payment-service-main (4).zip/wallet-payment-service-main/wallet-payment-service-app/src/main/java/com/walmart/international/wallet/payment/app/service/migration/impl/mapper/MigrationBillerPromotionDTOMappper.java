package com.walmart.international.wallet.payment.app.service.migration.impl.mapper;

import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPromotionDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Mapper
@Component
public interface MigrationBillerPromotionDTOMappper {

    MigrationBillerPromotionDTOMappper INSTANCE = Mappers.getMapper(MigrationBillerPromotionDTOMappper.class);

    BillerPromotionDTO mapBillerPromotionToBillerPromotionDTO(BillerPromotion billerPromotion);

    default List<BillerPromotionDTO> mapBillerPromotionsToBillerPromotionDTOs(List<BillerPromotion> billerPromotionList) {
        List<BillerPromotionDTO> response = new ArrayList<>();
        if (billerPromotionList != null) {
            billerPromotionList.forEach(promotion -> {
                response.add(mapBillerPromotionToBillerPromotionDTO(promotion));
            });
        }
        return response;
    }

}
