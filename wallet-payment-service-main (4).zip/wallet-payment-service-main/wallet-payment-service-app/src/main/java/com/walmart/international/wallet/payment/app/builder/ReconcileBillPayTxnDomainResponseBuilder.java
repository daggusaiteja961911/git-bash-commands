package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.billpay.ReconcilePendingBillPayTxnResponse;
import org.springframework.stereotype.Component;

@Component
public class ReconcileBillPayTxnDomainResponseBuilder extends BaseDomainResponseBuilder<ReconcilePendingBillPayTxnResponse, BillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext> {

    @Override
    public BillPayTxnResponseDomainContext buildDomainResponse(BillPayTxnRequestDomainContext reconcileBillPayTxnRequestDomainContext) throws ApplicationException {
        return BillPayTxnResponseDomainContext.builder().build();
    }

    @Override
    public ReconcilePendingBillPayTxnResponse buildDomainResponse(BillPayTxnRequestDomainContext reconcileBillPayTxnRequestDomainContext, BillPayTxnResponseDomainContext reconcileBillPayTxnResponseDomainContext) throws ApplicationException {
        BillPayTransaction billPayTransaction = reconcileBillPayTxnResponseDomainContext.getTransaction();
        return ReconcilePendingBillPayTxnResponse.builder()
                .txnId(billPayTransaction.getTransactionId().toString())
                .state(billPayTransaction.getState().name())
                .stateReason(billPayTransaction.getStateReason().name())
                .build();
    }
}
