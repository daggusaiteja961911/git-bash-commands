package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.billpay.FetchBillPayPaymentInstrumentsRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class FetchBillPayPaymentInstrumentsDomainRequestBuilder extends BaseDomainRequestBuilder<FetchBillPayPaymentInstrumentsRequest, BillPayTxnRequestDomainContext> {

    @Override
    public BillPayTxnRequestDomainContext buildDomainRequest(FetchBillPayPaymentInstrumentsRequest fetchBillPayPaymentInstrumentsRequest, MultiValueMap<String, String> map, Tenant tenant) {
        Customer customer = Customer.builder()
                .customerAccountId(fetchBillPayPaymentInstrumentsRequest.getCustomerAccountId())
                .build();

        BillPayTransaction billPayTransaction = BillPayTransaction.builder()
                .amountRequested(Amount.builder()
                        .value(fetchBillPayPaymentInstrumentsRequest.getAmount())
                        .currencyUnit(CurrencyUnit.valueOf(fetchBillPayPaymentInstrumentsRequest.getCurrencyUnit()))
                        .build())
                .billerId(fetchBillPayPaymentInstrumentsRequest.getBillerId())
                .billAccountNumber(fetchBillPayPaymentInstrumentsRequest.getAccountNumber())
                .customer(customer)
                .build();

        return BillPayTxnRequestDomainContext.builder()
                .transaction(billPayTransaction)
                .headers(map)
                .build();
    }
}
