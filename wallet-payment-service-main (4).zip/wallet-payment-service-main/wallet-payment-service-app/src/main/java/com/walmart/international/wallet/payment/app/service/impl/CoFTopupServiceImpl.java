package com.walmart.international.wallet.payment.app.service.impl;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.app.router.WalletServiceRouter;
import com.walmart.international.wallet.payment.app.service.CoFTopupService;
import com.walmart.international.wallet.payment.dto.request.topup.CancelCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.FetchCoFTopupPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class CoFTopupServiceImpl implements CoFTopupService {

    @Autowired
    WalletServiceRouter walletServiceRouter;

    @Override
    public CoFTopupResponse coFTopup(CoFTopupRequest coFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.coFTopup(coFTopupRequest, headers);
    }

    @Override
    public CancelCoFTopUpResponse cancelCoFTopup(CancelCoFTopupRequest cancelCoFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.cancelCoFTopup(cancelCoFTopupRequest, headers);
    }

    @Override
    public FetchCoFTopupPaymentInstrumentsResponse fetchCoFTopupPaymentInstruments(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.fetchCoFTopupPaymentInstruments(fetchCoFTopupPaymentInstrumentsRequest, headers);
    }

    @Override
    public FetchCoFTopupPaymentInstrumentsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers) {
        return walletServiceRouter.fetchCoFTopupPaymentInstrumentsWithPreselection(fetchCoFTopupPaymentInstrumentsRequest, headers);
    }

    @Override
    public ValidateCoFTopupResponse validateCoFTopup(ValidateCoFTopupRequest validateCoFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return walletServiceRouter.validateCoFTopup(validateCoFTopupRequest, headers);
    }
}
