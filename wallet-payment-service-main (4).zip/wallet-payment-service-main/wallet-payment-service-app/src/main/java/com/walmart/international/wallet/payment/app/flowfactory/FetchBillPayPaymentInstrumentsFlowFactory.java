package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import org.springframework.stereotype.Component;

@Component
public class FetchBillPayPaymentInstrumentsFlowFactory extends FlowFactory<BillPayTxnRequestDomainContext> {

    @Override
    public FlowType deriveFlow(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, Tenant tenant) {
        switch (tenant) {
            case MX:
                return MXFlowType.FETCH_BILL_PAY_PAYMENT_INSTRUMENTS;
            case CA:
            case UNKNOWN:
            default:
                String msg = String.format("Invalid tenantId [%s] for FetchBillPayPaymentInstruments flow", tenant);
                throw new ProcessingException(ErrorConstants.FetchBillPayPaymentInstruments.FLOW_FACTORY_INVALID_TENANT_ID, msg);
        }
    }
}
