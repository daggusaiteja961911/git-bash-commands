package com.walmart.international.wallet.payment.app.builder.mapper;

import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.dto.response.billpay.PayBillInitResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.TransactionDTO;
import com.walmart.international.wallet.payment.dto.response.common.CardPaymentInstrumentDTO;
import com.walmart.international.wallet.payment.dto.response.common.GiftCardPaymentInstrumentDTO;
import org.codehaus.plexus.util.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 *  Mapping from ResponseContext to API response - to be used in Builder classes
 */
@Mapper
public interface BillPayMapper {

    BillPayMapper INSTANCE = Mappers.getMapper(BillPayMapper.class);

    @Mapping(target = "amount", source = "amountRequested.value")
    @Mapping(target = "amountCurrency", source = "amountRequested.currencyUnit")
    @Mapping(target = "accountNumber", source = "billAccountNumber")
    TransactionDTO mapBillPayTransactionToTransactionDTO(BillPayTransaction transaction);

    List<GiftCardPaymentInstrumentDTO> mapGiftCardPaymentInstrumentListToGiftCardPaymentInstrumentDTOList(List<GiftCardPaymentInstrument> giftCardPaymentInstrumentList);

    @Mapping(target = "piHash", source = "adapterMetadata.piHash")
    @Mapping(target = "accountNumber", source = "adapterMetadata.accountNumber")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    GiftCardPaymentInstrumentDTO mapGiftCardPaymentInstrumentToGiftCardPaymentInstrumentDTO(GiftCardPaymentInstrument giftCardPaymentInstrument);

    List<CardPaymentInstrumentDTO> mapCardPaymentInstrumentListToCardPaymentInstrumentDTO(List<CardPaymentInstrument> cardPaymentInstrumentList);

    @Mapping(target = "cardholderName", source = "metadata.cardholderName")
    @Mapping(target = "aliasName", source = "metadata.aliasName")
    @Mapping(target = "cardNumber", source = "metadata.cardNumber")
    @Mapping(target = "last4Digits", source = "metadata.last4Digits")
    @Mapping(target = "brand", source = "metadata.brand")
    @Mapping(target = "tokenId", source = "adapterMetadata.tokenId")
    @Mapping(target = "cvvVerified", source = "metadata.cvvVerified")
    @Mapping(target = "cvvRequired", source = "metadata.cvvRequired")
    @Mapping(target = "billingAddress.countryCode", source = "billingAddress.country")
    @Mapping(target = "binDetails", source = "binDetails", qualifiedByName = "mapBinDetails")
    @Mapping(target = "isPreSelected", source = "isPreSelected", defaultValue = "false")
    CardPaymentInstrumentDTO mapCardPaymentInstrumentToPaymentInstrumentDTO(CardPaymentInstrument cardPaymentInstrument);

    @Named("mapBinDetails")
    default CardPaymentInstrumentDTO.BinDetails binDetailsToBinDetails(CardPaymentInstrument.BinDetails binDetails) {
        if ( binDetails == null ) {
            return null;
        }

        CardPaymentInstrumentDTO.BinDetails binDetails1 = new CardPaymentInstrumentDTO.BinDetails();

        if (Objects.nonNull(binDetails.getBin())) {
            binDetails1.setBin(binDetails.getBin());
        }

        if (StringUtils.isNotEmpty(binDetails.getBankName())) {
            binDetails1.setBankName(binDetails.getBankName());
        }
        if (StringUtils.isNotEmpty(binDetails.getBankLogo())) {
            binDetails1.setBankLogo(binDetails.getBankLogo());
        }
        binDetails1.setBrandName( binDetails.getBrandName() );
        binDetails1.setBrandLogo( binDetails.getBrandLogo() );
        binDetails1.setBankColor( binDetails.getBankColor() );
        binDetails1.setTextColor( binDetails.getTextColor() );

        return binDetails1;
    }

    @Named("mapUUIDtoString")
    default String mapUUIDtoString(UUID uuid) {
        return String.valueOf(uuid);
    }

    @Mapping(target = "billPayTransactionId", source = "transaction.transactionId", qualifiedByName = "mapUUIDtoString")
    @Mapping(target = "pollingInterval", source = "transaction.pollingInterval")
    PayBillInitResponse mapToPayBillInitResponseFromContext(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext);
}
