package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.CancelCoFTopupRequestEWS;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class MigrationCancelCoFTopupTransactionDomainRequestBuilder extends BaseDomainRequestBuilder<CancelCoFTopupRequestEWS, CoFTopupTxnRequestDomainContext> {
    @Override
    public CoFTopupTxnRequestDomainContext buildDomainRequest(CancelCoFTopupRequestEWS cancelCoFTopupRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        Customer customer = Customer.builder()
                .customerAccountId(cancelCoFTopupRequestEWS.getCustomerAccountId())
                .build();

        CoFTopUpTransaction transaction = CoFTopUpTransaction.builder()
                .transactionId(cancelCoFTopupRequestEWS.getTransactionId())
                .transactionType(TransactionType.COF_TOPUP)
                .abortReason(cancelCoFTopupRequestEWS.getAbortReason())
                .customer(customer)
                .build();

        return CoFTopupTxnRequestDomainContext.builder()
                .transaction(transaction)
                .build();
    }
}
