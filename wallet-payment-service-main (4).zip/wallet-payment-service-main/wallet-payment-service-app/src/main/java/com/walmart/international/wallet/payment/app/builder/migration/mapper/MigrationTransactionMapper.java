package com.walmart.international.wallet.payment.app.builder.migration.mapper;

import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.dto.request.common.CardTokenInformation;
import com.walmart.international.wallet.payment.dto.request.common.FraudInfo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MigrationTransactionMapper {

    MigrationTransactionMapper INSTANCE = Mappers.getMapper(MigrationTransactionMapper.class);

    CardPaymentTransaction.CardTokenInformation mapCardTokenInformationFromDTOToContext(CardTokenInformation cardTokenInformation);

    CardPaymentTransaction.FraudInfo mapFraudInfoFromDTOToContext(FraudInfo fraudInfo);
}
