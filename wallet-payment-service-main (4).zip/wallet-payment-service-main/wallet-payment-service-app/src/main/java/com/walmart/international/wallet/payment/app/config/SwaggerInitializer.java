package com.walmart.international.wallet.payment.app.config;


import com.walmart.international.wallet.payment.dto.constants.HeaderConstants;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.Parameter;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerInitializer {

    public static final String WALLET_PAYMENT_SERVICE = "Wallet Payment Service";
    public static final String HEADER = "header";
    private static final String STRING = "string";

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()

                .info(
                        new Info()
                                .title(WALLET_PAYMENT_SERVICE)
                                .contact(
                                        new Contact()
                                                .name(WALLET_PAYMENT_SERVICE)
                                                .url(
                                                        "https://confluence.walmart.com/display/MXDIGIWAL/Wallet+Service")
                                )
                                .version("V1")
                                .description("REST API for Wallet Payment Service"));
    }


    @Bean
    public OperationCustomizer customize() {
        return (operation, handlerMethod) ->
                operation
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .schema(new Schema<String>().type(STRING))
                                        .required(true)
                                        .description("WM_SVC.NAME, ex wallet_service ")
                                        .name(HeaderConstants.WM_SVC_NAME))
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .name(HeaderConstants.WM_SVC_VERSION))
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .name(HeaderConstants.WM_SVC_ENV))

                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .description("ex: 55858464-38cd-4bad-a9bd-dc3dc27a5130")
                                        .name(HeaderConstants.WM_CONSUMER_ID))
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .name(HeaderConstants.device_app_version))
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .name(HeaderConstants.device_fingerprint))
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .name(HeaderConstants.WM_CONSUMER_USER_ID))
                        .addParametersItem(
                                new Parameter()
                                        .in(HEADER)
                                        .required(true)
                                        .schema(new Schema<String>().type(STRING))
                                        .name(HeaderConstants.WM_QOS_CORRELATION_ID));

    }
}


