package com.walmart.international.wallet.payment.app.controller.billpay.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.migration.CancelPayBillInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.FetchBillPayPaymentInstrumentsRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.PayInitRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeInitRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelPayBillInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchBillPayPaymentInstrumentsResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.PayInitResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.ValidateChargeInitResponseEWS;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.UUID;

@RequestMapping("/ews-internal")
@Tag(name = "MigrationBillPaymentController API", description = "Migration APIs to perform Bill Payment related activities.")
public interface MigrationBillPaymentController {

    @PostMapping(value = "/V2/payment/request/option/{customerAccountId}", consumes = "application/json", produces = "application/json")
    FetchBillPayPaymentInstrumentsResponseEWS migrationFetchBillPayPaymentInstruments(@PathVariable UUID customerAccountId,
                                                                                      @RequestBody FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest,
                                                                                      @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/V3/payment/request/option/{customerAccountId}", consumes = "application/json", produces = "application/json")
    FetchPaymentOptionsWithPreselectionResponse migrationFetchBillPayPaymentInstrumentsWithPreselection(@PathVariable UUID customerAccountId,
                                                                                                        @RequestBody FetchBillPayPaymentInstrumentsRequestEWS fetchBillPayPaymentInstrumentsRequest,
                                                                                                        @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/account/{customerAccountId}/pay/init", consumes = "application/json", produces = "application/json")
    PayInitResponseEWS migrationPayBillInit(@PathVariable UUID customerAccountId,
                                            @RequestBody PayInitRequestEWS payInitRequestEWS,
                                            @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/V1/payment/cancel/{customerAccountId}/{transactionId}/init", consumes = "application/json", produces = "application/json")
    CancelPayBillInitResponseEWS migrationCancelPaymentInit(@PathVariable UUID customerAccountId,
                                                            @PathVariable UUID transactionId,
                                                            @RequestBody CancelPayBillInitRequestEWS cancelPayBillInitRequestEWS,
                                                            @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;

    @PostMapping(value = "/account/{customerAccountId}/validate-charge/init", consumes = "application/json", produces = "application/json")
    ValidateChargeInitResponseEWS migrationValidateChargeInit(@PathVariable UUID customerAccountId,
                                                              @RequestBody ValidateChargeInitRequestEWS validateChargeInitRequestEWS,
                                                              @RequestHeader MultiValueMap<String, String> headers) throws ApplicationException;
}
