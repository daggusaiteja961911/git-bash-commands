package com.walmart.international.wallet.payment.app.controller.impl.billpay.migration;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.strati.telemetry.Metered;
import com.walmart.international.wallet.payment.app.controller.billpay.migration.MigrationBillController;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillService;
import com.walmart.international.wallet.payment.dto.request.migration.AlreadyPaidRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.CreateBillRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.DueAndSavedBillerRequest;
import com.walmart.international.wallet.payment.dto.request.migration.GetSavedBillerAccountsRequest;
import com.walmart.international.wallet.payment.dto.response.migration.AlreadyPaidResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CreateBillV2DTO;
import com.walmart.international.wallet.payment.dto.response.migration.DueAndSavedBillsDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SavedBillerAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UpdateSavedBillerAccountRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class MigrationBillControllerImpl implements MigrationBillController {

    @Autowired
    private MigrationBillService migrationBillService;

    @Override
    public CreateBillV2DTO migrationCreateBill(UUID customerAccountId, CreateBillRequestEWS createBillRequestEWS, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillService.createBill(customerAccountId, createBillRequestEWS, headers);
    }

    @Override
    public SavedBillerAccountResponseDTO migrationDeleteSavedBillerAccount(UUID customerAccountId, UUID savedBillerAccountId) throws ApplicationException {
        return migrationBillService.deleteSavedBillerAccount(customerAccountId, savedBillerAccountId);
    }

    @Override
    public SavedBillerAccountsResponse migrationGetAllSavedBillerAccountsForBiller(UUID customerAccountId, GetSavedBillerAccountsRequest getSavedBillerAccountsRequest) throws ApplicationException {
        return migrationBillService.getAllSavedBillerAccountsForBiller(customerAccountId, getSavedBillerAccountsRequest);
    }

    @Override
    public SavedBillerAccountResponseDTO migrationUpdateSavedBillerAccount(UUID customerAccountId, UUID savedBillerAccountId, UpdateSavedBillerAccountRequest updateSavedBillerAccountRequest, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillService.updateSavedBillerAccount(customerAccountId, savedBillerAccountId, updateSavedBillerAccountRequest, headers);
    }

    @Override
    public DueAndSavedBillsDTO migrationGetBills(DueAndSavedBillerRequest request, UUID customerAccountId, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillService.getBills(request, customerAccountId, headers);
    }

    @Override
    public AlreadyPaidResponseEWS migrationMarkAlreadyPaid(AlreadyPaidRequestEWS alreadyPaidRequest, UUID customerAccountId,
                                                           UUID customerBillAccountId, MultiValueMap<String, String> headers) throws ApplicationException {
        return migrationBillService.markAlreadyPaid(alreadyPaidRequest, customerAccountId, customerBillAccountId, headers);
    }
}
