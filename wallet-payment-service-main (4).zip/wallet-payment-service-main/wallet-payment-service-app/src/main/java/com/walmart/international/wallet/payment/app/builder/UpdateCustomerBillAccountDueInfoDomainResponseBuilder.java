package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainResponseBuilder;
import com.walmart.international.digiwallet.service.web.rest.i8n.local.SimpleMessageResolver;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountDueInfoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class UpdateCustomerBillAccountDueInfoDomainResponseBuilder extends BaseDomainResponseBuilder<UpdateCustomerBillAccountDueInfoResponse, BillRequestDomainContext, BillResponseDomainContext> {

    @Autowired
    SimpleMessageResolver msgResolver;

    @Override
    public BillResponseDomainContext buildDomainResponse(BillRequestDomainContext billRequestDomainContext) {

        return BillResponseDomainContext.builder().build();
    }

    @Override
    public UpdateCustomerBillAccountDueInfoResponse buildDomainResponse(BillRequestDomainContext billRequestDomainContext, BillResponseDomainContext billResponseDomainContext) {
        return UpdateCustomerBillAccountDueInfoResponse.builder()
                .status("SUCCESS")
                .message(WPSConstants.Bills.RECORDS_UPDATED_SUCCESSFULLY).build();
    }

    @Override
    public UpdateCustomerBillAccountDueInfoResponse buildDomainResponse(BillRequestDomainContext billRequestDomainContext, BillResponseDomainContext billResponseDomainContext, ApplicationException e) {
        if (e instanceof BusinessValidationException) {
            if (returnFailureResponseInCaseOfException(e.getErrorCode())) {
                return UpdateCustomerBillAccountDueInfoResponse.builder()
                        .status("Failed")
                        .message(msgResolver.getMsg(ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_NOT_FOUND))
                        .build();
            }
        }
        throw e;
    }

    private boolean returnFailureResponseInCaseOfException(String errorCode) {
        switch (errorCode) {
            case com.walmart.international.wallet.payment.core.constants.ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_NOT_FOUND:
            case com.walmart.international.wallet.payment.core.constants.ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_ACCOUNT_NUMBER_MISMATCH:
            case com.walmart.international.wallet.payment.core.constants.ErrorConstants.UpdateCustomerBillAccountDueInfo.CUSTOMER_BILL_ACCOUNT_PROCESSOR_BILLER_ID_MISMATCH:
                return true;
            default:
                return false;

        }
    }

}