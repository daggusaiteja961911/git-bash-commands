package com.walmart.international.wallet.payment.app.auth;

import com.walmart.international.digiwallet.service.basic.ng.exception.UserAuthorizationException;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import com.walmart.international.wallet.payment.dto.constants.HeaderConstants;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Slf4j
@Component
public class WPSAuthValidator {

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    public void validateHeaderUserId(String customerAccountId, MultiValueMap<String, String> headers) {
        if (walletPaymentServiceConfiguration.isHeaderUserIdValidationEnabled()) {
            String headerUserId = null;
            if (headers.containsKey(HeaderConstants.WM_CONSUMER_USER_ID)) {
                headerUserId = headers.getFirst(HeaderConstants.WM_CONSUMER_USER_ID);
            } else if (headers.containsKey(HeaderConstants.WM_CONSUMER_USER_ID.toLowerCase())) {
                headerUserId = headers.getFirst(HeaderConstants.WM_CONSUMER_USER_ID.toLowerCase());
            }
            if (StringUtils.isEmpty(headerUserId)) {
                String msg = "UserId from header is null or empty";
                throw new UserAuthorizationException(ErrorConstants.UserAuthorization.HEADER_USER_ID_MISSING, msg);
            }
            if (!headerUserId.equals(customerAccountId)) {
                String msg = String.format("Unauthorised. UserId from header:[%s] does not match with customerAccountId from request:[%s]", headerUserId, customerAccountId);
                throw new UserAuthorizationException(ErrorConstants.UserAuthorization.HEADER_USER_ID_MISMATCH_WITH_CUSTOMER_ACCOUNT_UD, msg);
            }
            log.info("HeaderUserId validation successful. HeaderUserId:[{}] and customerAccountId:[{}] have the same value", headerUserId, customerAccountId);
        } else {
            log.info("HeaderUserId validation skipped for customerAccountId:[{}]", customerAccountId);
        }
    }
}
