package com.walmart.international.wallet.payment.app.builder;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class ValidateCoFTopupTxnDomainRequestBuilder extends BaseDomainRequestBuilder<ValidateCoFTopupRequest, CoFTopupTxnRequestDomainContext> {

    @Override
    public CoFTopupTxnRequestDomainContext buildDomainRequest(ValidateCoFTopupRequest validateCoFTopupRequest, MultiValueMap<String, String> headers, Tenant tenant) {
        return CoFTopupTxnRequestDomainContext.builder()
                .transaction(CoFTopUpTransaction.builder()
                        .transactionId(validateCoFTopupRequest.getCoFTopupTxnId())
                        .transactionType(TransactionType.COF_TOPUP)
                        .customer(Customer.builder()
                                .customerAccountId(validateCoFTopupRequest.getCustomerAccountId())
                                .build())
                        .build())
                .build();
    }
}
