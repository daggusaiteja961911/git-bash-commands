package com.walmart.international.wallet.payment.app.builder.migration;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.flow.builder.BaseDomainRequestBuilder;
import com.walmart.international.wallet.payment.core.constants.enums.TransactionType;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeRequestEWS;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
@Slf4j
public class MigrationValidateCoFTopupTxnDomainRequestBuilder extends BaseDomainRequestBuilder<ValidateChargeRequestEWS, CoFTopupTxnRequestDomainContext> {

    @Override
    public CoFTopupTxnRequestDomainContext buildDomainRequest(ValidateChargeRequestEWS validateChargeRequestEWS, MultiValueMap<String, String> headers, Tenant tenant) {
        CardPaymentTransaction cardPaymentTransaction = CardPaymentTransaction.builder()
                .cardSubTransaction(CardPaymentTransaction.CardSubTransaction.builder()
                        .id(validateChargeRequestEWS.getCardTransactionId())
                        .build())
                .build();

        return CoFTopupTxnRequestDomainContext.builder()
                .transaction(CoFTopUpTransaction.builder()
                        .transactionType(TransactionType.COF_TOPUP)
                        .cardPaymentTransactionList(cardPaymentTransaction)
                        .customer(Customer.builder()
                                .customerAccountId(validateChargeRequestEWS.getCustomerAccountId())
                                .build())
                        .build())
                .build();
    }
}
