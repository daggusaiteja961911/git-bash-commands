package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.topup.CancelCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.CoFTopupRequest;
import com.walmart.international.wallet.payment.dto.request.topup.FetchCoFTopupPaymentInstrumentsRequest;
import com.walmart.international.wallet.payment.dto.request.topup.ValidateCoFTopupRequest;
import com.walmart.international.wallet.payment.dto.response.topup.CancelCoFTopUpResponse;
import com.walmart.international.wallet.payment.dto.response.topup.CoFTopupResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsResponse;
import com.walmart.international.wallet.payment.dto.response.topup.FetchCoFTopupPaymentInstrumentsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.topup.ValidateCoFTopupResponse;
import org.springframework.util.MultiValueMap;

public interface CoFTopupService {

    CoFTopupResponse coFTopup(CoFTopupRequest coFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    CancelCoFTopUpResponse cancelCoFTopup(CancelCoFTopupRequest cancelCoFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    FetchCoFTopupPaymentInstrumentsResponse fetchCoFTopupPaymentInstruments(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    FetchCoFTopupPaymentInstrumentsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(FetchCoFTopupPaymentInstrumentsRequest fetchCoFTopupPaymentInstrumentsRequest, MultiValueMap<String, String> headers);

    ValidateCoFTopupResponse validateCoFTopup(ValidateCoFTopupRequest validateCoFTopupRequest, MultiValueMap<String, String> headers) throws ApplicationException;
}
