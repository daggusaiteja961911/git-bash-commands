package com.walmart.international.wallet.payment.app.service.migration.impl;

import com.walmart.commons.collections.CollectionUtils;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.app.service.migration.impl.mapper.MigrationBillerDTOMapper;
import com.walmart.international.wallet.payment.dto.request.migration.BillerDataUpdatePollRequest;
import com.walmart.international.wallet.payment.dto.response.migration.BillProviderInfoDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerCategoriesDTO;
import com.walmart.international.wallet.payment.dto.response.migration.BillerDataUpdatePollResponse;
import com.walmart.international.wallet.payment.dto.response.migration.BillerInformation;
import com.walmart.international.wallet.payment.dto.response.migration.BillerPlanDetailsUpdateInfo;
import com.walmart.international.wallet.payment.dto.response.migration.BillersListResponseDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SimpleBillerDTO;
import com.walmart.international.wallet.payment.dto.response.migration.SimpleBillerProviderDTO;
import com.walmart.international.wallet.payment.app.service.migration.MigrationBillerService;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class MigrationBillerServiceImpl implements MigrationBillerService {

    @Autowired
    private BillerCoreService billerCoreService;

    private MigrationBillerDTOMapper migrationBillerDTOMapper = MigrationBillerDTOMapper.INSTANCE;

    @Override
    public BillerCategoriesDTO getBillerCategories(int billerCategoryVersion) {
            return getBillerCategoriesMapFromCache(billerCategoryVersion);
        }

    @Override
    public BillersListResponseDTO getPopularBillers() throws BusinessValidationException {
        List<Biller> popularBillersList = billerCoreService.getPopularBillers();
        List<SimpleBillerDTO> popularBillersDTOList = migrationBillerDTOMapper.mapBillerListToGetPopularBillersSimpleBillerDTOList(popularBillersList);
        return BillersListResponseDTO.builder().billers(popularBillersDTOList).build();
    }

    private BillerCategoriesDTO getBillerCategoriesMapFromCache( int billerCategoryVersion) {
        List<BillerCategory> billerCategoriesList;
        Date billerCategoryDataLastUpdatedAt;

        billerCategoriesList = billerCoreService.getBillerCategoriesList(billerCategoryVersion);
        billerCategoryDataLastUpdatedAt = billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp();

        if (CollectionUtils.isNotEmpty(billerCategoriesList)) {

            return BillerCategoriesDTO.builder()
                    .categories(migrationBillerDTOMapper.mapBillerCategoriesListToBillerCategoryDTOList(billerCategoriesList))
                    .billerCategoryDataLastUpdatedAt(billerCategoryDataLastUpdatedAt)
                    .build();
        }
        return BillerCategoriesDTO.builder()
                .categories(new ArrayList<>())
                .build();
    }

    @Override
    public BillProviderInfoDTO getBillProviderInfo(String processorBillerId) throws ApplicationException {
        Biller biller = billerCoreService.fetchAndCacheBillerData(processorBillerId);
        return prepareBillProviderResponse(biller);
    }

    private BillProviderInfoDTO prepareBillProviderResponse(Biller biller) {
        BillerInformation billerInformation = migrationBillerDTOMapper.mapBillerInformation(biller);
        List<SimpleBillerProviderDTO> billers;
        if (CollectionUtils.isNotEmpty(biller.getSubBillers())) {
            billers = migrationBillerDTOMapper.mapBillersToDTOs(biller.getSubBillers());
        } else {
            billers = migrationBillerDTOMapper.mapBillersToDTOs(Collections.singletonList(biller));
        }
        return BillProviderInfoDTO.builder()
                .billerInformation(billerInformation)
                .billers(billers)
                .lastUpdatedAt(Date.from(biller.getMaxUpdateTimestamp().toInstant(ZoneOffset.UTC)))
                .build();
    }

    @Override
    public BillerDataUpdatePollResponse getBillerDataUpdateInfo(BillerDataUpdatePollRequest billerDataUpdatePollRequest) {
        Set<String> processorBillerIds = Objects.nonNull(billerDataUpdatePollRequest.getBillerIds()) ? billerDataUpdatePollRequest.getBillerIds().stream().map(Object::toString).collect(Collectors.toSet()) : new HashSet<>();


        Date billerCategoryDataLastUpdatedAt = billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp();
        Map<String, Object> billerDataLastUpdatedAtMap = billerCoreService.fetchBillerDataLastUpdatedAtMap(new ArrayList<>(), new ArrayList<>(processorBillerIds));
        List<BillerPlanDetailsUpdateInfo> billerPlanDetailUpdates = migrationBillerDTOMapper.mapBillerDataLastUpdatedAtMap(billerDataLastUpdatedAtMap);

        return BillerDataUpdatePollResponse.builder()
                .billerPlanDetailsUpdateInfoList(billerPlanDetailUpdates)
                .billerCategoryDataLastUpdatedAt(billerCategoryDataLastUpdatedAt)
                .build();
    }
}