package com.walmart.international.wallet.payment.app.flowfactory;

import com.walmart.international.digiwallet.service.basic.constants.Tenant;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowFactory;
import com.walmart.international.wallet.payment.core.constants.enums.flow.MXFlowType;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.dto.constants.ErrorConstants;
import org.springframework.stereotype.Component;

@Component
public class CoFTopupFlowFactory extends FlowFactory<CoFTopupTxnRequestDomainContext> {

    @Override
    public FlowType deriveFlow(CoFTopupTxnRequestDomainContext cofTopupTxnRequestDomainContext, Tenant tenant) {
        switch (tenant) {
            case MX:
                return MXFlowType.COF_TOPUP;
            case CA:
            case UNKNOWN:
            default:
                String msg = String.format("Invalid tenantId [%s] for CoFTopup flow", tenant);
                throw new ProcessingException(ErrorConstants.CoFTopup.FLOW_FACTORY_INVALID_TENANT_ID, msg);
        }
    }
}
