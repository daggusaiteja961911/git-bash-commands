package com.walmart.international.wallet.payment.app.controller.billpay;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/services/bill-processor")
@Tag(name = "BillProcessorController API", description = "APIs to perform BillProcessor related activities.")
public interface BillProcessorController {
}
