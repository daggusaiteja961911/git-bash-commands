package com.walmart.international.wallet.payment.app.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.wallet.payment.dto.request.billpay.AlreadyPaidRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.CreateBillRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.DeleteCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetBillsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.GetSavedCustomerBillAccountsRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountDueInfoRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.UpdateCustomerBillAccountRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.AlreadyPaidResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.CreateBillResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.DeleteCustomerBillAccountResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetBillsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.GetSavedCustomerBillAccountsResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountDueInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.UpdateCustomerBillAccountResponse;
import org.springframework.util.MultiValueMap;

public interface BillService {

    GetBillsResponse getBills(GetBillsRequest request,
                              MultiValueMap<String, String> headers) throws ApplicationException;

    CreateBillResponse createBill(CreateBillRequest createBillRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    UpdateCustomerBillAccountResponse updateCustomerBillAccount(UpdateCustomerBillAccountRequest request,
                                                                MultiValueMap<String, String> headers) throws ApplicationException;

    UpdateCustomerBillAccountDueInfoResponse updateCustomerBillAccountDueInfo(UpdateCustomerBillAccountDueInfoRequest request, MultiValueMap<String, String> headers) throws ApplicationException;

    DeleteCustomerBillAccountResponse deleteCustomerBillAccount(DeleteCustomerBillAccountRequest deleteCustomerBillAccountRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    GetSavedCustomerBillAccountsResponse getSavedCustomerBillAccounts(GetSavedCustomerBillAccountsRequest getSavedCustomerBillAccountsRequest, MultiValueMap<String, String> headers) throws ApplicationException;

    AlreadyPaidResponse markAlreadyPaid(AlreadyPaidRequest alreadyPaidRequest, MultiValueMap<String, String> headers) throws ApplicationException;
}
