package com.walmart.international.wallet.payment.app.service.impl;

import com.querydsl.core.Tuple;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.app.service.impl.mapper.BillerDTOMapper;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerBehaviourCodeUpdateRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerIncorrectSearchKeywordsResponse;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheEvictRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataCacheReloadRequest;
import com.walmart.international.wallet.payment.dto.request.billpay.BillerDataUpdateInfoRequest;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerByIdResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerCategoriesResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataCacheAlterResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerDataUpdateInfoResponse;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerInformation;
import com.walmart.international.wallet.payment.dto.response.billpay.BillerPlanDetailUpdateInfo;
import com.walmart.international.wallet.payment.dto.response.billpay.GetPopularBillersBillerDTO;
import com.walmart.international.wallet.payment.dto.response.billpay.PopularBillersResponse;
import com.walmart.international.wallet.payment.app.service.BillerService;
import com.walmart.international.wallet.payment.core.config.ccm.WalletPaymentServiceConfiguration;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.service.BillerCoreService;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Component
@Slf4j
public class BillerServiceImpl implements BillerService {

    @ManagedConfiguration
    private WalletPaymentServiceConfiguration walletPaymentServiceConfiguration;

    @Autowired
    private BillerCoreService billerCoreService;

    private BillerDTOMapper billerDTOMapper = BillerDTOMapper.INSTANCE;

    @Override
    public BillerCategoriesResponse getBillerCategories(int billerCategoryVersion) {
        return getBillerCategoriesMapFromCache(billerCategoryVersion);
    }

    private BillerCategoriesResponse getBillerCategoriesMapFromCache(int billerCategoryVersion) {
        List<BillerCategory> billerCategoriesList;
        Date billerCategoryDataLastUpdatedAt;

        billerCategoriesList = billerCoreService.getBillerCategoriesList(billerCategoryVersion);
        billerCategoryDataLastUpdatedAt = billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp();

        if (CollectionUtils.isNotEmpty(billerCategoriesList)) {
            return BillerCategoriesResponse.builder()
                    .categories(billerDTOMapper.mapBillerCategoriesListToBillerCategoryDTOList(billerCategoriesList))
                    .billerCategoryDataLastUpdatedAt(billerCategoryDataLastUpdatedAt)
                    .build();
        }
        return BillerCategoriesResponse.builder()
                .categories(new ArrayList<>())
                .build();
    }

    @Override
    public PopularBillersResponse getPopularBillers() throws BusinessValidationException {
        List<Biller> popularBillersList = billerCoreService.getPopularBillers();
        List<GetPopularBillersBillerDTO> popularBillersDTOList = billerDTOMapper.mapBillerEntityListToGetPopularBillersBillerDTOList(popularBillersList);
        return PopularBillersResponse.builder().billers(popularBillersDTOList).build();
    }

    @Override
    public BillerByIdResponse getBillerById(UUID billerId, String processorBillerId) throws ApplicationException {
        Biller biller = billerCoreService.fetchAndCacheBillerData(billerId, processorBillerId);
        return prepareBillerDataResponse(biller);
    }

    private BillerByIdResponse prepareBillerDataResponse(Biller biller) {
        if (Objects.isNull(biller)) {
            return null;
        }
        BillerInformation billerInformation = billerDTOMapper.mapBillerInformation(biller);
        List<BillerByIdDTO> billerByIdDTOS;
        if (CollectionUtils.isNotEmpty(biller.getSubBillers())) {
            billerByIdDTOS = billerDTOMapper.mapBillerEntitiesToDTO(biller.getSubBillers());
        } else {
            billerByIdDTOS = billerDTOMapper.mapBillerEntitiesToDTO(Collections.singletonList(biller));
        }
        return BillerByIdResponse.builder()
                .billerInformation(billerInformation)
                .billers(billerByIdDTOS)
                .lastUpdatedAt(biller.getMaxUpdateTimestamp())
                .build();
    }

    @Override
    public BillerDataUpdateInfoResponse getBillerDataUpdateInfo(BillerDataUpdateInfoRequest billerDataUpdateInfoRequest) {
        Set<UUID> billerIds = billerDataUpdateInfoRequest.getBillerIds();

        Date billerCategoryDataLastUpdatedAt = billerCoreService.fetchBillerCategoryDataLastUpdatedAtTimestamp();
        Date billerIncorrectSearchKeywordsLastUpdatedAt = billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp();
        Map<String, Object> billerDataLastUpdatedAtMap = billerCoreService.fetchBillerDataLastUpdatedAtMap(CollectionUtils.isNotEmpty(billerIds) ? new ArrayList<>(billerIds) : new ArrayList<>(), new ArrayList<>());
        List<BillerPlanDetailUpdateInfo> billerPlanDetailUpdates = billerDTOMapper.mapBillerDataLastUpdatedAtMap(billerDataLastUpdatedAtMap);

        return BillerDataUpdateInfoResponse.builder()
                .billerCategoryDataLastUpdatedAt(billerCategoryDataLastUpdatedAt)
                .billerPlanDetailUpdateInfoList(billerPlanDetailUpdates)
                .billerIncorrectSearchKeywordsLastUpdatedAt(billerIncorrectSearchKeywordsLastUpdatedAt)
                .build();
    }

    @Override
    public BillerDataCacheAlterResponse reloadCacheForBillerData(BillerDataCacheReloadRequest billerDataCacheReloadRequest) {
        if (billerDataCacheReloadRequest.isBillerCategoryDataReloadRequired()) {
            log.info("Cache reloading for biller category data started at {}", new Date());
            billerCoreService.reloadCacheForBillerCategoryData(walletPaymentServiceConfiguration.getBillerCategoryVersions());
            log.info("Cache reloading for biller category data ended at {}", new Date());
        }

        if (billerDataCacheReloadRequest.isBillerIncorrectSearchKeywordsCacheUpdateRequired()) {
            log.info("Cache reloading for biller incorrect search data started at {}", new Date());
            billerCoreService.reloadIncorrectSearchDataInCache();
            log.info("Cache reloading for biller incorrect search data ended at {}", new Date());
        }

        Map<String, Set<String>> retryBillers = null;
        if (CollectionUtils.isNotEmpty(billerDataCacheReloadRequest.getBillerIds()) || CollectionUtils.isNotEmpty(billerDataCacheReloadRequest.getProcessorBillerIds())) {
            retryBillers = billerCoreService.reloadCacheForBillerData(billerDataCacheReloadRequest.getProcessorBillerIds(), billerDataCacheReloadRequest.getBillerIds());
        }

        return BillerDataCacheAlterResponse.builder()
                .processorBillerIdsToRetry(Objects.nonNull(retryBillers) ? retryBillers.get(WPSConstants.Biller.RETRY_PROCESSOR_BILLER_IDS) : new HashSet<>())
                .billerIdsToRetry((Objects.nonNull(retryBillers) ? retryBillers.get(WPSConstants.Biller.RETRY_BILLER_IDS) : new HashSet<>()))
                .build();
    }

    @Override
    public BillerDataCacheAlterResponse evictCacheForBillerData(BillerDataCacheEvictRequest billerDataCacheEvictRequest) {
        List<String> processorBillerIdsToEvict;
        List<UUID> billerIdsToEvict;

        if (billerDataCacheEvictRequest.isEvictCacheForAllBillers()) {
            processorBillerIdsToEvict = new ArrayList<>();
            billerIdsToEvict = new ArrayList<>();
            List<Tuple> billersToEvict = billerCoreService.getBillerIdsAndProcessorBillerIdsOfBillersWhoseDataIsCached();
            billersToEvict.forEach(biller -> {
                billerIdsToEvict.add(biller.get(0, UUID.class));
                processorBillerIdsToEvict.add(biller.get(1, String.class));
            });
        } else {
            billerIdsToEvict = CollectionUtils.isNotEmpty(billerDataCacheEvictRequest.getBillerIds()) ? new ArrayList<>(billerDataCacheEvictRequest.getBillerIds()) : new ArrayList<>();
            processorBillerIdsToEvict = CollectionUtils.isNotEmpty(billerDataCacheEvictRequest.getProcessorBillerIds()) ? new ArrayList<>(billerDataCacheEvictRequest.getProcessorBillerIds()) : new ArrayList<>();
        }
        Map<String, Set<String>> retryBillers = null;
        if (CollectionUtils.isNotEmpty(billerIdsToEvict) || CollectionUtils.isNotEmpty(processorBillerIdsToEvict)) {
            retryBillers = billerCoreService.evictCacheForBillerAndUpdateTimestampData(billerIdsToEvict, processorBillerIdsToEvict);
        }
        return BillerDataCacheAlterResponse.builder()
                .processorBillerIdsToRetry(Objects.nonNull(retryBillers) ? retryBillers.get(WPSConstants.Biller.RETRY_PROCESSOR_BILLER_IDS) : new HashSet<>())
                .billerIdsToRetry(Objects.nonNull(retryBillers) ? retryBillers.get(WPSConstants.Biller.RETRY_BILLER_IDS) : new HashSet<>())
                .build();
    }

    @Override
    public BillerIncorrectSearchKeywordsResponse getBillerIncorrectSearchKeywords() throws ApplicationException {
        Map<String, List<String>> billerIncorrectSearchKeywordsMap;
        Date billerIncorrectSearchKeywordsLastUpdatedAt;

        billerIncorrectSearchKeywordsMap = billerCoreService.fetchBillerIncorrectSearchKeywordMap();
        billerIncorrectSearchKeywordsLastUpdatedAt = billerCoreService.fetchBillerIncorrectSearchDataUpdateTimestamp();

        if (!billerIncorrectSearchKeywordsMap.isEmpty()) {
            return BillerIncorrectSearchKeywordsResponse.builder()
                    .billerIncorrectSearchKeywords(billerIncorrectSearchKeywordsMap)
                    .billerIncorrectSearchKeywordsLastUpdatedAt(billerIncorrectSearchKeywordsLastUpdatedAt)
                    .build();
        }
        return BillerIncorrectSearchKeywordsResponse.builder()
                .billerIncorrectSearchKeywords(new HashMap<>())
                .build();
    }

    @Override
    public Map<String, String> updateBillerBehaviourCode(BillerBehaviourCodeUpdateRequest billerBehaviourCodeUpdateRequest) {
        if (billerBehaviourCodeUpdateRequest.isUpdateBehaviourCodeForAllBillers()) {
            return billerCoreService.updateBehaviourCodeForAllBillersAndCreateBillerIdToBBCMap();
        } else if (CollectionUtils.isNotEmpty(billerBehaviourCodeUpdateRequest.getBillerIds())) {
            return billerCoreService.updateBehaviourCodeForGivenBillerIdsAndCreateBillerIdToBBCMap(billerBehaviourCodeUpdateRequest.getBillerIds());
        }
        return Collections.emptyMap();
    }

}
