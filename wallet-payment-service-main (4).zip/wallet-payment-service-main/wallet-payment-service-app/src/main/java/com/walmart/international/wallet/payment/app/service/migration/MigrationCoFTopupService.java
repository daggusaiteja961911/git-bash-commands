package com.walmart.international.wallet.payment.app.service.migration;

import com.walmart.international.wallet.payment.dto.request.migration.CancelCoFTopupRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.LoadMoneyRequestEWS;
import com.walmart.international.wallet.payment.dto.request.migration.ValidateChargeRequestEWS;
import com.walmart.international.wallet.payment.dto.response.migration.CancelCoFTopupResponseEWS;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsResponse;
import com.walmart.international.wallet.payment.dto.response.migration.FetchPaymentOptionsWithPreselectionResponse;
import com.walmart.international.wallet.payment.dto.response.migration.UnifiedPaymentResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.util.UUID;

@Component
public interface MigrationCoFTopupService {
    FetchPaymentOptionsResponse fetchCoFTopupPaymentInstruments(UUID customerAccountId, MultiValueMap<String, String> headers);

    UnifiedPaymentResponse loadMoney(UUID customerAccountId, LoadMoneyRequestEWS loadMoneyRequestEWS, MultiValueMap<String, String> headers);

    UnifiedPaymentResponse validateCharge(UUID customerAccountId, ValidateChargeRequestEWS validateChargeRequestEWS, MultiValueMap<String, String> headers);

    CancelCoFTopupResponseEWS cancelPayment(UUID customerAccountId, UUID transactionId, CancelCoFTopupRequestEWS cancelCoFTopupRequestEWS, MultiValueMap<String, String> headers);

    FetchPaymentOptionsWithPreselectionResponse fetchCoFTopupPaymentInstrumentsWithPreselection(UUID customerAccountId, MultiValueMap<String, String> headers);
}
