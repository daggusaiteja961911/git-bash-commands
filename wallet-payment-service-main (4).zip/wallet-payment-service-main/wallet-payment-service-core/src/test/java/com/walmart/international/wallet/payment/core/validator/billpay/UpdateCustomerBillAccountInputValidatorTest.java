//package com.walmart.international.wallet.payment.core.validator.billpay;
//
//import com.walmart.international.digiwallet.service.basic.exception.BaseException;
//import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
//import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
//import com.walmart.international.wallet.payment.MockUtils;
//import com.walmart.international.wallet.payment.core.config.ccm.ArcusConfiguration;
//import com.walmart.international.wallet.payment.core.processor.validator.billpay.UpdateCustomerBillAccountInputValidator;
//import com.walmart.international.wallet.payment.core.domain.model.request.BillPaymentRequestDomainContext;
//import com.walmart.international.wallet.payment.core.domain.model.response.BillPaymentResponseDomainContext;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//public class UpdateCustomerBillAccountInputValidatorTest {
//
//    @InjectMocks
//    UpdateCustomerBillAccountInputValidator updateCustomerBillAccountInputValidator;
//
//    @Mock
//    ArcusConfiguration arcusConfig;
//    @Test
//    public void shouldReturnTrueForRequestFromArcusToUpdateDueInfo() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("123");
//        //then
//        assertTrue(updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldReturnTrueForRequestFromAppToUpdateAlias() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("1234");
//        //then
//        assertTrue(updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldThrowDataValidationExceptionWhenProcessorBillAccountIdIsNull() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setProcessorBillAccountId(null);
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("123");
//        //then
//        assertThrows(DataValidationException.class, () -> updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldThrowDataValidationExceptionWhenProcessorBillerIdIsNull() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setProcessorBillerId(null);
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("123");
//        //then
//        assertThrows(DataValidationException.class, () -> updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldThrowDataValidationExceptionWhenAccountNumberIsNull() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setAccountNumber(null);
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("123");
//        //then
//        assertThrows(DataValidationException.class, () -> updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldThrowDataValidationExceptionWhenDueDateIsNull() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setDueDate(null);
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("123");
//        //then
//        assertThrows(DataValidationException.class, () -> updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldThrowDataValidationExceptionWhenCustomerBillAccountIdIsNull() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setCustomerBillAccountId(null);
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("1234");
//        //then
//        assertThrows(DataValidationException.class, () -> updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//
//    @Test
//    public void shouldThrowDataValidationExceptionWhenCustomerAccountIdIsNull() throws BaseException, ApplicationException {
//        //given
//        BillPaymentRequestDomainContext billPaymentRequestDomainContext = MockUtils.getBillPaymentRequestDomainContext();
//        billPaymentRequestDomainContext.getHeaders().set("wm_consumer.id", "123");
//        billPaymentRequestDomainContext.getCustomerBillAccountDetails().setCustomerAccountId(null);
//        //when
//        when(arcusConfig.getConsumerId()).thenReturn("1234");
//        //then
//        assertThrows(DataValidationException.class, () -> updateCustomerBillAccountInputValidator.process(billPaymentRequestDomainContext, new BillPaymentResponseDomainContext()));
//    }
//}
