package com.walmart.international.wallet.payment;

import com.walmart.commons.utils.DateUtils;
import com.walmart.international.digiwallet.customer.api.dto.response.CustomerResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.BillerCategory;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryBillerMappingDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerCategoryVersionMappingDO;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import org.joda.time.DateTime;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

public class MockUtils {

    public static final String customerAccountId = "4fdd45e1-8ee1-4cf5-bfc8-df05658818c8";

//    public static BillPaymentRequestDomainContext getCreateBillRequestDomainContextForCreateBill() {
//        CustomerDomainContext customer = CustomerDomainContext.builder()
//                .customerAccountId(UUID.fromString(customerAccountId))
//                .build();
//
//        BillerDetails billerDetails = BillerDetails.builder()
//                .billerId(null)
//                .accountNumber("9393939393")
//                .processorBillerId("35")
//                .build();
//
//        return BillPaymentRequestDomainContext.builder()
//                .customer(customer)
//                .billerDetails(billerDetails)
//                .build();
//    }

    public static CustomerResponse getCustomerResponseForCreateBill() {
        return CustomerResponse.builder()
                .customerAccountId(customerAccountId)
                .build();
    }

    public static BillerDO getBillerDOForCreateBill() {
        BillerDO billerDO = new BillerDO();
        billerDO.setProcessorBillerId("35");
        return billerDO;
    }

    public static MultiValueMap<String, String> getHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set("ContentType", MediaType.APPLICATION_JSON.toString());
        headers.set("Accept", MediaType.APPLICATION_JSON.toString());
        headers.set("wm_qos.correlation_id", UUID.randomUUID().toString());
        headers.set("wm_consumer.id", "123456");
        return headers;
    }

    public static BillerDO getBillerDO() {
        return BillerDO.builder()
                .billerId(UUID.randomUUID())
                .processorBillerId("35")
                .billerName("CFE")
                .productDisplayName("ABC")
                .parentBiller(
                        BillerDO.builder()
                                .billerId(UUID.randomUUID())
                                .processorBillerId("37")
                                .productDisplayName("XYZ")
                                .build()
                )
                .build();
    }

    public static Biller getBiller() {
        return Biller.builder()
                .billerId(UUID.randomUUID())
                .processorBillerId("35")
                .billerName("CFE")
                .productDisplayName("ABC")
                .parentBiller(
                        Biller.builder()
                                .billerId(UUID.randomUUID())
                                .processorBillerId("37")
                                .productDisplayName("XYZ")
                                .build()
                )
                .build();
    }

//    public static BillerDetails getBillerDetails() {
//        return BillerDetails.builder()
//                .billerId(UUID.randomUUID())
//                .processorBillerId("35")
//                .accountNumber("1234567890")
//                .billDetailId(UUID.randomUUID())
//                .billerName("CFE").build();
//    }

    public static CustomerBillAccountDO getCustomerBillAccountDO() {
        return CustomerBillAccountDO.builder()
                .customerBillAccountId(UUID.randomUUID())
                .accountNumber("1234567890")
                .alias("Alias")
                .status("linked")
                .billerDO(getBillerDO())
                .revisedAccountNumber("137673647674363")
                .customerAccountId(UUID.randomUUID())
                .dueDate(DateUtils.addDays(DateTime.now().toDate(), 5))
                .dueInfoUpdatedAt(DateTime.now().toDate())
                .dueAmount(BigDecimal.valueOf(100.0))
                .dueAmountCurrencyUnit(CurrencyUnit.MXN)
                .processorBillAccountId("HSFHRHZH1A4FV51V3PMXEKXMMQ")
                .isSaved(true)
                .lastPaidAmount(BigDecimal.valueOf(100.0))
                .lastPaidAmountCurrencyUnit(CurrencyUnit.MXN)
                .build();
    }

    public static CustomerBillAccount getCustomerBillAccount() {
        return CustomerBillAccount.builder()
                .customerBillAccountId(UUID.randomUUID())
                .accountNumber("1234567890")
                .alias("Alias")
                .status("linked")
                .biller(getBiller())
                .revisedAccountNumber("137673647674363")
                .customerAccountId(UUID.randomUUID())
                .dueDate(DateUtils.addDays(DateTime.now().toDate(), 5))
                .dueInfoUpdatedAt(DateTime.now().toDate())
                .dueAmount(BigDecimal.valueOf(100.0))
                .dueAmountCurrencyUnit(CurrencyUnit.MXN.name())
                .processorBillAccountId("HSFHRHZH1A4FV51V3PMXEKXMMQ")
                .isSaved(true)
                .build();
    }

//    public static CustomerBillAccountDetails getCustomerBillAccountDetails() {
//        return CustomerBillAccountDetails.builder()
//                .customerBillAccountId(UUID.randomUUID())
//                .accountNumber("1234567890")
//                .processorBillAccountId("HSFHRHZH1A4FV51V3PMXEKXMMQ")
//                .processorBillerId("35")
//                .dueAmount(BigDecimal.valueOf(100))
//                .dueAmountCurrencyUnit("MXN")
//                .alias("AliasName")
//                .customerAccountId(UUID.randomUUID())
//                .dueDate("2024-03-22T13:00:00Z").build();
//    }

//    public static BillPaymentRequestDomainContext getBillPaymentRequestDomainContext() {
//        return BillPaymentRequestDomainContext.builder()
//                .customerBillAccountDetails(getCustomerBillAccountDetails())
//                .billerDetails(getBillerDetails())
//                .headers(getHeaders()).build();
//    }

    public static BillerCategory getBillerCategory() {
        return BillerCategory.builder()
                .billers(getBillers())
                .categoryName("xyz")
                .billerCategoryVersion(1)
                .build();
    }

//    public static BillerCategoryDTO getBillerCategoryDTO() {
//        return BillerCategoryDTO.builder()
//                .billers(getBillerDTOs())
//                .categoryName("xyz")
//                .billerCategoryVersion(1)
//                .build();
//    }

    private static List<Biller> getBillers() {
        Biller biller  = Biller.builder()
                .processorBillerId("35")
                .billerAccountNumber("1234455")
                .billerId(UUID.randomUUID())
                .displayName("ABC")
                .build();
        List<Biller> billersList = new ArrayList<>();
        billersList.add(biller);
        return billersList;
    }

//    private static List<BillerByIdDTO> getBillerDTOs() {
//        BillerByIdDTO billerByIdDTO = BillerByIdDTO.builder()
//                .processorBillerId("35")
//                .billerAccountNumber("1234455")
//                .billerId(UUID.randomUUID())
//                .displayName("ABC")
//                .build();
//        List<BillerByIdDTO> billersList = new ArrayList<>();
//        billersList.add(billerByIdDTO);
//        return billersList;
//    }

//    public static BillerCategoriesResponse getBillerCategoriesResponse() {
//        return BillerCategoriesResponse.builder()
//                .categories(List.of(getBillerCategoryDTO()))
//                .status(TransactionStatusEnum.SUCCESS.name())
//                .build();
//    }

    public static Date getFormattedDate(String date) throws BusinessValidationException {
        SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        formatDate.setTimeZone(TimeZone.getTimeZone("America/Mexico_City"));
        try {
            return formatDate.parse(date);
        } catch (ParseException e) {
            String msg = String.format("Error while parsing date [%s]", date);
            throw new BusinessValidationException(ErrorConstants.Common.DATE_PARSE_ERROR, msg);
        }
    }

    public static BillerCategoryVersionMappingDO getBillerCategoryVersionMappingDO() {
        return BillerCategoryVersionMappingDO.builder()
                .categoryVersionId(UUID.randomUUID())
                .billerCategory(getBillerCategoryDO())
                .billerCatgeoryMappings(List.of(getBillerCategoryBillerMappingDO()))
                .isEnabled(true)
                .imageUrl("xyz")
                .billerCategoryVersion(1)
                .categoryOrder(1).build();
    }

    private static BillerCategoryDO getBillerCategoryDO() {
        return BillerCategoryDO.builder()
                .categoryId(UUID.randomUUID())
                .categoryName("ABC")
                .build();
    }

    public static BillerCategoryBillerMappingDO getBillerCategoryBillerMappingDO() {
        return BillerCategoryBillerMappingDO.builder()
                .billerCategoryMappingId(UUID.randomUUID())
                .biller(getBillerDO())
                .appDisplaySequenceNumber(1)
                .isEnabled(true).build();
    }

//    public static BillerByIdResponse getBillerByIdResponse() {
//        List<BillDetailDTO> billDetails = new ArrayList<>();
//        billDetails.add(getBillDetail());
//
//        BillPlanDTO billPlan = BillPlanDTO.builder()
//                .billDetails(billDetails)
//                .build();
//
//        BillerByIdDTO biller = BillerByIdDTO.builder()
//                .billerId(UUID.fromString("36e751ef-94af-11e9-9ec7-fa163ed8f124"))
//                .processorBillerId("13674")
//                .displayName("PlayStation")
//                .billType("gift_card")
//                .canCheckBalance(false)
//                .billPlans(Collections.singletonList(billPlan))
//                .build();
//
//        return BillerByIdResponse.builder()
//                .billerInformation(getBillerInformation())
//                .billers(Collections.singletonList(biller))
//                .lastUpdatedAt(LocalDateTime.now())
//                .build();
//    }

//    private static BillerInformation getBillerInformation() {
//        return BillerInformation.builder()
//                .billerId(UUID.fromString("36e751ef-94af-11e9-9ec7-fa163ed8f124"))
//                .processorBillerId("13674")
//                .displayName("PlayStation")
//                .imageURL("https://cashi.walmart.com/Providers-Icons/PNG_NEW/Playstation_080923.png")
//                .disclaimer("Juegos, complementos, suscripciones, y mucho más. Válido únicamente en PlayStation Store México.")
//                .termsAndConditions("https://www.playstation.com/es-mx/legal/website-terms-of-use/")
//                .information("Para más información visita https://www.playstation.com/es-mx/")
//                .build();
//    }

//    private static BillDetailDTO getBillDetail() {
//        return BillDetailDTO.builder()
//                .billDetailId(UUID.randomUUID())
//                .amount(new BigDecimal("205.00"))
//                .name("Monto 1")
//                .description("Acceso a PlayStation Store hasta agotarse el saldo adquirido.")
//                .validity("No tiene vencimiento. Válido hasta agotar el saldo.")
//                .socialMediaIcons(new String[] {"WHATSAPP",
//                        "FACEBOOK",
//                        "MESSENGER",
//                        "TWITTER",
//                        "INSTAGRAM",
//                        "SNAPCHAT"})
//                .build();
//    }
}
