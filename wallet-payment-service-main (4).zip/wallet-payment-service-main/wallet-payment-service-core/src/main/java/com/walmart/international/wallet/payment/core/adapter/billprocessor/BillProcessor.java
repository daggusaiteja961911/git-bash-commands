package com.walmart.international.wallet.payment.core.adapter.billprocessor;

import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.CreateBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.PayBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.CreateBillResponse;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;

import java.util.List;

public interface BillProcessor {

    PayBillResponse payBill(PayBillRequest request, int arcusAuthKeyVersion) throws BillProcessorException;

    CreateBillResponse createBill(CreateBillRequest request, int arcusAuthKeyVersion) throws BillProcessorException;

    CreateBillResponse refreshBill(String billId, int arcusAuthKeyVersion) throws BillProcessorException;

    List<PayBillResponse> getTxns(String cashiOrderId, int arcusAuthKeyVersion) throws BillProcessorException;
}
