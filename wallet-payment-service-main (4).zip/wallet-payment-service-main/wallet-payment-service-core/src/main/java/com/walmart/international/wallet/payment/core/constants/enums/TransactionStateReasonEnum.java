package com.walmart.international.wallet.payment.core.constants.enums;

public enum TransactionStateReasonEnum {

    //Pending state reasons
    DEBIT_INITIATED,
    DEBIT_SUCCESS,
    DEBIT_PENDING,

    CREDIT_INITIATED,
    CREDIT_SUCCESS,
    CREDIT_PENDING,
    CREDIT_FAILED,

    VALIDATION_SUCCESS,
    TOPUP_INITIATED,
    TOPUP_SUCCESS,
    TOPUP_PENDING,
    BILL_PAYMENT_PROCESSOR_INITIATED,

    //Success state reason
    BILL_PAY_SUCCESS,
    SUCCESS,
    FAILED,

    //Failed state reason
    BILL_PAYMENT_PROCESSOR_FAILED,
    VALIDATION_FAILED,
    TOPUP_FAILED,
    DEBIT_FAILED,
    BILL_PAY_ABORT;

}
