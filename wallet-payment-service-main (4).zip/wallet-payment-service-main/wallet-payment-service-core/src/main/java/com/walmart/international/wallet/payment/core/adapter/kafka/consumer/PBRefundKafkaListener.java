package com.walmart.international.wallet.payment.core.adapter.kafka.consumer;

import com.walmart.international.services.payment.core.kafka.response.AsyncRefundKafkaResponse;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.InvalidKafkaResponseException;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.KafkaResponseMappingException;
import com.walmart.international.wallet.payment.core.adapter.kafka.handler.RefundReconHandler;
import com.walmart.international.wallet.payment.core.adapter.kafka.request.refund.PBReverseKafkaResponse;
import com.walmart.international.wallet.payment.core.config.ccm.KafkaConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.mapper.PbRefundKafkaResponseMapper;
import com.walmart.kafka.consumer.BaseConsumer;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("pbRefundConsumerV2")
@Slf4j
public class PBRefundKafkaListener extends BaseConsumer<PBReverseKafkaResponse> {

    @Autowired
    private PbRefundKafkaResponseMapper pbRefundKafkaResponseMapper;

    @Autowired
    private RefundReconHandler refundReconHandler;

    @ManagedConfiguration
    private KafkaConfiguration kafkaConfiguration;

    @Override
    protected void process(PBReverseKafkaResponse message) {
        if (kafkaConfiguration.isPBKafkaRefundConsumerEnabled()) {
            log.info("PBRefundKafkaListener :: processing refund event received from PB : {}", message);
            try {
                //validate kafka message
                if (message == null || message.getEventPayload() == null) {
                    throw new InvalidKafkaResponseException(ErrorConstants.KafkaRefundRecon.INVALID_KAFKA_REFUND_PAYLOAD);
                }

                if (StringUtils.isEmpty(message.getEventType()) || !message.getEventType().startsWith("refund.")) {
                    throw new InvalidKafkaResponseException(ErrorConstants.KafkaRefundRecon.INVALID_KAFKA_EVENT_TYPE);
                }

                AsyncRefundKafkaResponse refundKafkaResponse = null;
                try {
                    refundKafkaResponse = pbRefundKafkaResponseMapper.mapPBKafkaResponseToPaymentCoreRequest(message);
                    refundKafkaResponse.getEventPayload().setCardTxnId(refundKafkaResponse.getEventPayload().getTxns().get(0).getPaymentId());
                } catch (Exception ex) {
                    throw new KafkaResponseMappingException(ErrorConstants.KafkaRefundRecon.MAPPING_ERROR_FROM_KAFKA_TO_PAYMENT_CORE,
                            "Error while mapping kafka refund response to payment core", ex);
                }

                try {
                    refundReconHandler.handle(refundKafkaResponse);
                } catch (Exception ex) {
                    log.error("Error while processing kafka refund response", ex);
                }
            } catch (Exception e) {
                log.error("V2-Error in PBReverseCardResponseKafka payload[{}], error[{}]", message, e.getMessage(), e);
            }
        } else {
            log.info("Ignoring incoming PB charge kafka message as config is disabled");
        }

    }

    public void listen(PBReverseKafkaResponse message) {
        process(message);
    }

    @Override
    protected Class<PBReverseKafkaResponse> getMessageClass() {
        return PBReverseKafkaResponse.class;
    }
}
