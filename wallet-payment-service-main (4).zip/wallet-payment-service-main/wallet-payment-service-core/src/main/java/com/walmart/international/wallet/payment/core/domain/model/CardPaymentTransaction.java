package com.walmart.international.wallet.payment.core.domain.model;

import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
@Builder
public class CardPaymentTransaction {

    private UUID paymentInstrumentId;
    private CardTokenInformation cardTokenInformation;
    private FraudInfo fraudInfo;
    private MSIInfo msiInfo;
    private Amount amount;
    private AffiliationType affiliationType;
    private String providerWalletId;
    private CardPaymentInstrument cardPaymentInstrument;
    private CardSubTransaction cardSubTransaction;
    private String redirect3DSURL;
    private String redirectCashiURL;
    private Integer timeoutMinsFor3ds;

    @Data
    public static class CardTokenInformation {
        private String panToken;
        private String cvvToken;
        private String keyId;
        private String integrityCheck;
        private String phase;
    }

    @Data
    public static class FraudInfo {
        private String inAuthId;
    }

    @Data
    public static class MSIInfo {
        private String schemeId;
        private BigDecimal amount;
        private Integer installment;
    }

    @Data
    @Builder
    public static class CardSubTransaction {
        private UUID id;
        // pb card token id which is passed on to payment core
        private String paymentProviderInstrumentId;
        private UUID paymentInstrumentId;
        private SubTransactionStatusV2 status;
        private String authCode;
        private Amount amount;
        private String failureCode;
        private String failureDescription;
        private Date createDate;
        private Date updateDate;
        private UUID parentSubTransactionId;
        private Boolean isMSI;
        private Integer msiInstallmentCount;
        private BigDecimal msiAmount;
        private String paymentProviderTxnId;
        private Date paymentGatewayTxnDate;
        private String paymentGatewayName;
        private String paymentProviderFraudStatus;
        private String paymentProviderAffiliateId;
        private UUID msiSchemeId;
    }
}
