package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.BillRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class UpdateCustomerBillAccountProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private CustomerBillAccountRepository customerBillAccountRepository;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws BusinessValidationException {
        BillRequestDomainContext billRequestDomainContext = (BillRequestDomainContext) wpsRequestDomainContext;
        BillResponseDomainContext billResponseDomainContext = (BillResponseDomainContext) wpsResponseDomainContext;
        CustomerBillAccount customerBillAccount = billRequestDomainContext.getCustomerBillAccount();
        CustomerBillAccountDO customerBillAccountDO = fetchCustomerBillAccountDO(customerBillAccount.getCustomerBillAccountId());
        customerBillAccountUpdateBusinessValidation(customerBillAccountDO, customerBillAccount);
        updateCustomerBillAccountDetails(customerBillAccountDO, customerBillAccount);
        customerBillAccountMapper.updateCustomerBillAccountFromCustomerBillAccountDO(customerBillAccountDO, customerBillAccount);
        billResponseDomainContext.setCustomerBillAccount(customerBillAccount);
        return true;
    }

    private CustomerBillAccountDO fetchCustomerBillAccountDO(UUID customerBillAccountId) {
        Optional<CustomerBillAccountDO> customerBillAccountDO = customerBillAccountRepository.findById(customerBillAccountId);
        if (customerBillAccountDO.isEmpty()) {
            String msg = String.format("Record not found for customerBillAccountId[%s]", customerBillAccountId);
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_NOT_FOUND, msg);
        }
        return customerBillAccountDO.get();
    }

    private void customerBillAccountUpdateBusinessValidation(CustomerBillAccountDO customerBillAccountDO, CustomerBillAccount customerBillAccount) throws BusinessValidationException {
        log.info("Business Validation Process started for Customer Bill Account with customerBillAccountId: [{}] processorBillAccountId: [{}] processorBillerId: [{}] accountNumber: [{}]",
                customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getProcessorBillerId(), customerBillAccount.getAccountNumber());
        if (Objects.nonNull(customerBillAccount.getCustomerAccountId()) && !customerBillAccountDO.getCustomerAccountId().equals(customerBillAccount.getCustomerAccountId())) {
            String msg = String.format(
                    "Customer Account Id associated with customerBillAccountId[%s] doesn't match the Customer Account Id in request.",
                    customerBillAccount.getCustomerBillAccountId());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.CUSTOMER_BILL_ACCOUNT_CUSTOMER_ACCOUNT_ID_MISMATCH, msg);
        }
        if (StringUtils.isNotEmpty(customerBillAccount.getAlias()) &&
                customerBillAccountRepository.getCountByCustomerAccountIdAndBillerDO_BillerIdAndAliasAndIsSavedTrueAndIsDeletedFalse(customerBillAccount.getCustomerAccountId(),
                        customerBillAccount.getAlias(), customerBillAccountDO.getBillerDO().getBillerId()) > 0) {
            String msg = String.format("Account alias uniqueness constraint violated :customerBillAccountId[%s], customerId[%s].",
                    customerBillAccount.getCustomerBillAccountId(), customerBillAccount.getCustomerAccountId());
            throw new BusinessValidationException(ErrorConstants.UpdateCustomerBillAccount.ACCOUNT_ALIAS_UNIQUENESS_CONSTRAINT_VIOLATED, msg);
        }
    }


    private void updateCustomerBillAccountDetails(CustomerBillAccountDO customerBillAccountDO, CustomerBillAccount customerBillAccount) {
        log.info("CustomerBillAccount record updation started for customerBillAccountId:[{}]", customerBillAccount.getCustomerBillAccountId());
        if (Objects.nonNull(customerBillAccount.getAlias())) {
            customerBillAccountDO.setAlias(customerBillAccount.getAlias());
        }
        customerBillAccountRepository.save(customerBillAccountDO);
        log.info("CustomerBillAccount record updation success for customerBillAccountId:[{}]", customerBillAccount.getCustomerBillAccountId());
    }

}

