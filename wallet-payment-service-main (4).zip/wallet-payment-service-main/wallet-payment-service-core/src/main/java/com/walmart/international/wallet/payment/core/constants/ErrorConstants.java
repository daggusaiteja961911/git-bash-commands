package com.walmart.international.wallet.payment.core.constants;

public class ErrorConstants {

    public static class Common {
        public static final String INTERNAL_SERVER_ERROR = "COM-1001";
        public static final String BILL_PROCESSOR_INVALID_TENANT_ID = "COM-1002";
        public static final String DATE_PARSE_ERROR = "COM-1004";
        public static final String BILLER_CATEGORY_DATA_UPDATED_AT_DB_FETCH_ERROR = "COM-1005";
        public static final String BILLER_CATEGORY_VERSION_MAPPING_DB_FETCH_ERROR = "COM-1006";
        public static final String AMOUNT_CURRENCY_MISMATCH = "COM-1007";
        public static final String INVALID_AMOUNT_VALUE = "COM-1008";
    }

    public static class TransactionAudit {
        public static final String TRANSACTION_SYNC_GENERIC_FAILURE = "TAS-1001";
        public static final String EMPTY_TRANSACTION_LIST = "TAS-1002";
        public static final String MAX_ALLOWED_TRANSACTIONS_EXCEEDED = "TAS-1003";
    }

    public static class GetSavedCustomerBillAccounts {
        public static final String PROCESSOR_BILLER_ID_IS_NULL = "GCBA-1004";
        public static final String BILLER_ID_IS_NULL = "GCBA-1005";
        public static final String NO_ENABLED_BILLERS_FOUND = "GCBA-1006";
    }

    public static class UpdateCustomerBillAccount {
        public static final String CUSTOMER_BILL_ACCOUNT_ID_NULL = "UCBA-1006";
        public static final String CUSTOMER_ACCOUNT_ID_NULL = "UCBA-1007";
        public static final String CUSTOMER_BILL_ACCOUNT_NOT_FOUND = "UCBA-1008";
        public static final String CUSTOMER_BILL_ACCOUNT_CUSTOMER_ACCOUNT_ID_MISMATCH = "UCBA-1009";
        public static final String ACCOUNT_ALIAS_UNIQUENESS_CONSTRAINT_VIOLATED = "UCBA-1010";
    }

    public static class UpdateCustomerBillAccountDueInfo {
        public static final String PROCESSOR_BILL_ACCOUNT_ID_NULL = "UCBADI-1001";
        public static final String PROCESSOR_BILLER_ID_NULL = "UCBADI-1002";
        public static final String ACCOUNT_NUMBER_NULL = "UCBADI-1004";
        public static final String DUE_DATE_NULL = "UCBADI-1006";
        public static final String WPS_INVALID_DUE_DATE_ERROR_DUPLICATE = "UCBADI-1008";
        public static final String WPS_INVALID_DUE_DATE_ERROR_PAST_DATE = "UCBADI-1009";
        public static final String CUSTOMER_BILL_ACCOUNT_NOT_FOUND = "UCBADI-1010";
        public static final String CUSTOMER_BILL_ACCOUNT_ACCOUNT_NUMBER_MISMATCH = "UCBADI-1011";
        public static final String CUSTOMER_BILL_ACCOUNT_PROCESSOR_BILLER_ID_MISMATCH = "UCBADI-1012";
        public static final String GENERIC_ERROR = "UCBADI-1015";
        public static final String SAVED_CUSTOMER_BILL_ACCOUNT_NOT_FOUND = "UCBADI-1016";
        public static final String ALL_CUSTOMER_BILL_ACCOUNTS_FAILED_BUSINESS_VALIDATION = "UCBADI-1017";
    }

    public static class DeleteCustomerBillAccount {
        public static final String CUSTOMER_BILL_ACCOUNT_NOT_FOUND = "DCBA-1003";
        public static final String CUSTOMER_BILL_ACCOUNT_CUSTOMER_ACCOUNT_ID_MISMATCH = "DCBA-1004";
        public static final String CUSTOMER_BILL_ACCOUNT_ALREADY_DELETED = "DCBA-1005";
    }

    public static class ArcusClient {
        public static final String VALIDATION_FAILED = "ARC-1001";
        public static final String AUTHORIZATION_FAILED = "ARC-1002";
        public static final String RESOURCE_NOT_FOUND = "ARC-1003";
        public static final String REQUEST_RATE_EXCEEDED = "ARC-1004";
        public static final String REQUEST_PROCESSING_FAILED = "ARC-1005";
        public static final String NULL_OR_EMPTY_RESPONSE_BODY = "ARC-1006";
        public static final String CREATE_REFERSH_BILL_INVALID_ACCOUNT_NUMBER = "ARC-1007";
        public static final String CREATE_REFRESH_BILL_OVERDUE = "ARC-1008";
        public static final String CREATE_REFRESH_BILL_PAYMENT_UNAVAILABLE = "ARC-1009";
        public static final String CREATE_REFRESH_BILL_PAYMENT_ALREADY_MADE = "ARC-1010";
        public static final String CREATE_REFRESH_BILL_GENERIC_FAILURE = "ARC-1011";
        public static final String PAY_BILL_OUTDATED_RECEIPT = "ARC-1012";
        public static final String PAY_BILL_WRONG_AMOUNT = "ARC-1013";
        public static final String PAY_BILL_WRONG_NUMBER = "ARC-1014";
        public static final String PAY_BILL_PHONE_NUMBER_INACTIVE = "ARC-1015";
        public static final String PAY_BILL_PAYMENT_ALREADY_MADE = "ARC-1016";
        public static final String PAY_BILL_GENERIC_FAILURE = "ARC-1017";
    }

    public static class EWSClient {
        public static final String EWS_CLIENT_FAILURE_RESPONSE = "EWS-1001";
        public static final String EWS_CLIENT_GENERIC_FAILURE = "EWS-1002";
    }

    public static class CreateBill {
        public static final String INVALID_CUSTOMER_ACCOUNT_ID = "CB-1006";
        public static final String BILLER_ID_AND_PROCESSOR_ID_MISSING = "CB-1007";
        public static final String INVALID_PROCESSOR_BILLER_ID = "CB-1008";
        public static final String INVALID_BILLER_ID = "CB-1009";
    }

    public static class CoFTopupChargeReversal {
        public static final String CHARGE_CARD_PAYMENT_CORE_REVERSAL_FAILED = "CTCR-1001";
        public static final String INVALID_TRANSACTION_ID = "CTCR-1002";
        public static final String INVALID_TRANSACTION_STATE = "CTCR-1003";
    }

    public static class CoFTopup {
        public static final String CARD_PAYMENT_TXN_EMPTY = "CT-1006";
        public static final String PAYMENT_INSTRUMENTS_NOT_FOUND_FOR_CUSTOMER = "CT-1007";
        public static final String GIFT_CARD_PAYMENT_INSTRUMENT_NOT_FOUND = "CT-1008";
        public static final String PRIMARY_GIFT_CARD_PAYMENT_INSTRUMENT_NOT_FOUND = "CT-1009";
        public static final String CARD_PAYMENT_INSTRUMENT_NOT_FOUND = "CT-1010";
        public static final String COF_TOPUP_TO_WALLET_DISABLED = "CT-1011";
        public static final String MISSING_CLIENT_REQ_ID = "CT-1012";
        public static final String DUPILCATE_CLIENT_REQ_ID = "CT-1013";
        public static final String MIN_AMOUNT_LIMIT_ERROR = "CT-1014";
        public static final String CUSTOMER_ACCOUNT_ID_NULL = "CT-1015";
        public static final String CHARGE_CARD_PAYMENT_CORE_PAY_FAILED = "CT-1016";
        public static final String CUSTOMER_ACCOUNT_NOT_FOUND = "CT-1017";
        public static final String LOAD_TO_WALLET_PAYMENT_CORE_LOAD_FAILED = "CT-1018";
        public static final String CHARGE_CARD_PAYMENT_CORE_REVERSAL_FAILED = "CT-1019";
        public static final String MAX_WALLET_BALANCE_ALLOWED_EXCEEDED = "CT-1020";
        public static final String CARD_TOKEN_INFORMATION_MISSING = "CT-1021";
        public static final String CARD_TOKEN_INFORMATION_NOT_REQUIRED = "CT-1022";
        public static final String CARD_PAYMENT_FAILURE_REFER_TO_CARD_ISSUER = "CT-1023";  // has EWS and APP dependency
        public static final String CARD_PAYMENT_FAILURE_DO_NOT_HONOR = "CT-1024";  // has EWS and APP dependency
        public static final String CARD_PAYMENT_FAILURE_INSUFFICIENT_FUNDS = "CT-1025";  // has EWS and APP dependency
        public static final String CARD_PAYMENT_FAILURE_RESTRICTED_CARD = "CT-1026";  // has EWS and APP dependency
        public static final String CVV_LESS_TRANSACTION_NOT_ALLOWED = "CT-1027";  // has EWS and APP dependency
        public static final String CARD_PAYMENT_FAILURE_CARD_FORMAT_ERROR = "CT-1028";  // has EWS and APP dependency
        public static final String CARD_PAYMENT_FAILURE_EXPIRED_CARD = "CT-1029";  // has EWS and APP dependency
        public static final String CARD_PAYMENT_FAILURE_INCORRECT_CVV = "CT-1030";  // has EWS and APP dependency
    }

    public static class ValidateCoFTopup {
        public static final String INVALID_CARD_TXN_ID = "VCT-1001";
        public static final String INVALID_COF_TOPUP_TXN_ID = "VCT-1002";
        public static final String INVALID_CUSTOMER_TRANSACTION = "VCT-1003";
        public static final String VALIDATE_CHARGE_PAYMENT_CORE_CONTINUE_PAY_FAILED = "VCT-1004";
        public static final String CANNOT_PROCESS_IMPLICIT_TOPUP = "VCT-1005";
        public static final String CARD_PAYMENT_FAILURE_REFER_TO_CARD_ISSUER = "VCT-1009";
        public static final String CARD_PAYMENT_FAILURE_DO_NOT_HONOR = "VCT-1010";
        public static final String CARD_PAYMENT_FAILURE_INSUFFICIENT_FUNDS = "VCT-1011";
        public static final String CARD_PAYMENT_FAILURE_RESTRICTED_CARD = "VCT-1012";
        public static final String CARD_PAYMENT_FAILURE_CARD_FORMAT_ERROR = "VCT-1013";
        public static final String CARD_PAYMENT_FAILURE_EXPIRED_CARD = "VCT-1014";
        public static final String CARD_PAYMENT_FAILURE_INCORRECT_CVV = "VCT-1015";
    }

    public static class PayBillInit {
        public static final String PAYMENT_OPTIONS_INFO_MISSING = "PBI-1001";
        public static final String MULTIPLE_CARD_PAYMENT_INSTRUMENT_NOT_ALLOWED = "PBI-1002";
        public static final String MISMATCH_IN_PAYMENT_AMOUNT = "PBI-1003";
        public static final String CUSTOMER_ACCOUNT_ID_NULL = "PBI-1004";
        public static final String MISSING_CLIENT_REQ_ID = "PBI-1005";
        public static final String DUPILCATE_CLIENT_REQ_ID = "PBI-1006";
        public static final String BILL_PAY_COF_DISABLED = "PBI-1007";
        public static final String CUSTOMER_ACCOUNT_NOT_FOUND = "PBI-1008";
        public static final String PAYMENT_INSTRUMENTS_NOT_FOUND_FOR_CUSTOMER = "PBI-1009";
        public static final String CARD_PAYMENT_INSTRUMENT_NOT_FOUND = "PBI-1010";
        public static final String GIFT_CARD_PAYMENT_INSTRUMENT_NOT_FOUND = "PBI-1011";
        public static final String PAYMENT_OPTIONS_COMBINATION_NOT_ALLOWED = "PBI-1012";
        public static final String BILL_DETAIL_DATA_STALED = "PBI-1013";
        public static final String BILLER_NOT_FOUND_OR_NOT_ENABLED = "PBI-1014";
        public static final String BILLER_ID_AND_PROCESSOR_BILLER_ID_IS_NULL = "PBI-1015";
        public static final String BILLER_MIN_AMOUNT_VALIDATION_ERROR = "PBI-1016";
        public static final String BILLER_MAX_AMOUNT_VALIDATION_ERROR = "PBI-1017";
        public static final String BILLER_PARTIAL_PAYMENT_MIN_AMOUNT_VALIDATION_ERROR = "PBI-1018";
        public static final String BILLER_PARTIAL_ACCEPT_ONLY_PESOS_VALIDATION_ERROR = "PBI-1019";
        public static final String CUSTOMER_BILL_ACCOUNT_NOT_FOUND = "PBI-1020";
        public static final String BILLER_PARTIAL_PAYMENT_NOT_SUPPORTED = "PBI-1021";
        public static final String PAYMENT_CORE_GIFT_CARD_PAYMENT_FAILED = "PBI-1022";
        public static final String PAYMENT_CORE_GIFT_CARD_REVERSAL_FAILED = "PBI-1023";
        public static final String BILL_PROCESSOR_PAYMENT_FAILED = "PBI-1024";
        public static final String SUCCESSFUL_BILL_PAYMENT_DB_UPDATE_FAILURE = "PBI-1025";
        public static final String BILL_PAY_REMINDER_CATEGORY_NULL = "PBI-1026";
        public static final String BILL_PAY_REMINDER_SUBCATEGORY_INVALID = "PBI-1027";
        public static final String BILL_PAY_REMINDER_GENERIC_EXCEPTION = "PBI-1028";
        public static final String BILL_PAY_REMINDER_SMARTCOMM_EVENT_NOT_EXISTS = "PBI-1029";
        public static final String BILL_PAY_REMINDER_BILLER_METADATA_ERROR = "PBI-1030";
        public static final String BILL_PAY_REMINDER_SET_CONTENT_DETAILS_FAILED = "PBI-1031";
        public static final String INTERNAL_COF_TOPUP_FAILED = "PBI-1032";
        public static final String PAYMENT_CORE_REGISTER_PAY_REQUEST_FAILED = "PBI-1033";
        public static final String FAILURE_IN_PUBLISHING_PAYLOAD_TO_TAS = "PBI-1034";
        public static final String INVALID_CARD_TXN_ID = "PBI-1035";
        public static final String INVALID_COF_TOPUP_TXN_ID = "PBI-1036";
        public static final String INVALID_CUSTOMER_TRANSACTION = "PBI-1037";
        public static final String INVALID_BILL_PAY_TXN_ID = "PBI-1038";
        public static final String INTERNAL_VALIDATE_COF_TOPUP_FAILED = "PBI-1039";
        public static final String COF_TOPUP_TRANSACTION_NOT_FOUND = "PBI-1040";
        public static final String INVALID_BILL_PAY_TXN_STATE = "PBI-1041";
        public static final String INVALID_COF_TOPUP_TXN_STATE = "PBI-1042";
    }

    public static class ReconcileBillPayTxn {
        public static final String INVALID_BILL_PAY_TXN_ID = "RBPT-1002";
        public static final String BILL_PAY_TXN_ID_NOT_FOUND = "RBPT-1003";
        public static final String INVALID_BILL_PAY_TXN_STATE_OR_STATE_REASON = "RBPT-1004";
        public static final String BILL_PAY_TXN_STATE_NOT_PENDING = "RBPT-1005";
        public static final String CUSTOMER_ACCOUNT_NOT_FOUND = "RBPT-1006";
        public static final String BILL_DETAIL_DATA_NOT_FOUND = "RBPT-1007";
        public static final String CUSTOMER_BILL_ACCOUNT_NOT_FOUND = "RBPT-1008";
        public static final String RECON_PAY_BILL_DB_UPDATE_FAILURE = "RBPT-1010";
        public static final String BILLER_NOT_FOUND_OR_NOT_ENABLED = "RBPT-1011";
    }

    public static class GetPopularBillers {
        public static final String NO_POPULAR_BILLERS_FOUND = "GPB-1001";
        public static final String POPULAR_BILLERS_DB_FETCH_ERROR = "GPB-1002";
    }

    public static class BillerData {
        public static final String BILLER_NOT_FOUND_OR_NOT_ENABLED = "GBID-1001";
        public static final String INVALID_BILL_TYPE_VALIDATION_METADATA = "GBID-1002";
        public static final String BILLER_DB_FETCH_ERROR = "GBID-1003";
    }

    public static class BillerDateUpdateInfo {
        public static final String BILLER_DB_FETCH_ERROR = "GBDU-1001";
    }

    public static class ReloadCacheForBillerData {
        public static final String BILLER_DB_FETCH_ERROR = "RCBD-1001";
    }

    public static class EvictCacheForBillerData {
        public static final String BILLER_DB_FETCH_ERROR = "ECBD-1001";
    }

    public static class AML {
        public static final String ERROR_PROCESSING_AML_CALL = "AML-007";
        public static final String ERROR_PROCESSING_AML_INGEST = "AML-008";
    }

    public static class FetchBillPayPaymentInstruments {
        public static final String INVALID_BILLER_ID = "FBPI-1009";
    }

    public static class FetchPaymentInstruments {
        public static final String CUSTOMER_ACCOUNT_ID_NULL = "FPI-1001";
    }

    public static class Promotions {
        public static final String BILLER_ID_NULL = "GP-1001";
        public static final String INVALID_BILLER_CATEGORY_ID = "GP-1002";
    }

    public static class CustomerClientForEWS {
        public static final String EXPIRY_DETAILS_PARSE_EXCEPTION = "CCE-1001";
    }

    public static class IncorrectSearchBillerData {
        public static final String BILLER_SEARCH_DB_FETCH_ERROR = "ISBD-1001";
    }

    public static class CancelCoFTopup {
        public static final String TRANSACTION_ID_MANDATORY = "CCT-1002";
        public static final String CUSTOMER_ACCOUNT_ID_MANDATORY = "CCT-1003";
        public static final String TRANSACTION_NOT_FOUND = "CCTT-1004";  // marked as CCTT due to EWS dependency, has to be corrected to CCT in future
        public static final String TRANSACTION_ALREADY_MARKED_SUCCESS = "CCTT-1005";  // marked as CCTT due to EWS dependency, has to be corrected to CCT in future
        public static final String TRANSACTION_ALREADY_MARKED_FAILED = "CCTT-1006";  // marked as CCTT due to EWS dependency, has to be corrected to CCT in future
        public static final String CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE = "CCT-1007";
        public static final String PAYMENT_CORE_CANCEL_PAYMENT_FAILED = "CCT-1008";
    }

    public static class AlreadyPaid {
        public static final String INVALID_LAST_PAID_DATE = "AP-1001";
        public static final String SAVED_BILLER_ACCOUNT_NOT_FOUND = "AP-1002";
    }

    public static class CancelPayBillInitTransaction {
        public static final String TRANSACTION_ID_MANDATORY = "CPBI-1002";
        public static final String CUSTOMER_ACCOUNT_ID_MANDATORY = "CPBI-1003";
        public static final String BILL_TXN_NOT_FOUND = "CPBI-1004";
        public static final String COF_TOPUP_TRANSACTION_NOT_FOUND = "CPBI-1005";
        public static final String TRANSACTION_ALREADY_MARKED_SUCCESS = "CPBI-1006";
        public static final String TRANSACTION_ALREADY_MARKED_FAILED = "CPBI-1007";
        public static final String CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE = "CPBI-1008";
        public static final String PAYMENT_CORE_CANCEL_PAYMENT_FAILED = "CPBI-1009";
        public static final String FAILURE_IN_PUBLISHING_PAYLOAD_TO_TAS = "CPBI-1010";
    }

    public static class KafkaChargeRecon {
        public static final String INVALID_KAFKA_CHARGE_PAYLOAD = "KCR-1001";
        public static final String MAPPING_ERROR_FROM_KAFKA_TO_PAYMENT_CORE = "KCR-1002";
        public static final String INVALID_PAYMENT_OPTIONS_IN_PAYLOAD = "KCR-1003";
        public static final String TRANSACTION_DOES_NOT_EXIST_IN_SYSTEM = "KCR-1004";
        public static final String ERROR_PROCESSING_CHARGE_RECON = "KCR-1005";
        public static final String INVALID_TRANSACTION_TYPE_FOR_WPS = "KCR-1006";
        public static final String INVALID_KAFKA_PAYLOAD_EVENT_TYPE = "KCR-1007";
        public static final String INVALID_PAYMENT_INSTRUMENTS_FOR_CARD = "KCR-1008";
    }

    public static class KafkaRefundRecon {
        public static final String INVALID_KAFKA_REFUND_PAYLOAD = "KRR-1001";
        public static final String INVALID_KAFKA_EVENT_TYPE = "KRR-1002";
        public static final String MAPPING_ERROR_FROM_KAFKA_TO_PAYMENT_CORE = "KRR-1003";
        public static final String INVALID_PAYMENT_OPTIONS_IN_PAYLOAD = "KRR-1004";
        public static final String TRANSACTION_DOES_NOT_EXIST_IN_SYSTEM = "KRR-1005";
        public static final String ERROR_PROCESSING_REFUND_RECON = "KRR-1006";
        public static final String INVALID_REFUND_RECON_STATE = "KRR-1007";
    }
}
