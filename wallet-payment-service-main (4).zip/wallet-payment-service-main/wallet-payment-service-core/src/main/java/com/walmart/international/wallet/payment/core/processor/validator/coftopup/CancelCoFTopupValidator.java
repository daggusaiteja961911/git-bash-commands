package com.walmart.international.wallet.payment.core.processor.validator.coftopup;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.DataValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.services.payment.core.dao.repository.CoreTransactionRepository;
import com.walmart.international.services.payment.core.domain.SubTransactionStatusV2;
import com.walmart.international.services.payment.core.model.CoreTransactionDO;
import com.walmart.international.services.payment.core.model.SubTransactionDO;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.request.CoFTopupTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class CancelCoFTopupValidator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    private CoreTransactionRepository coreTransactionRepository;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws BusinessValidationException {
        CoFTopupTxnRequestDomainContext requestDomainContext = (CoFTopupTxnRequestDomainContext) wpsRequestDomainContext;
        CoFTopupTxnResponseDomainContext responseDomainContext = (CoFTopupTxnResponseDomainContext) wpsResponseDomainContext;
        CoFTopUpTransaction coFTopUpTransaction = requestDomainContext.getTransaction();
        Customer customer = coFTopUpTransaction.getCustomer();
        if (coFTopUpTransaction.getTransactionId() == null) {
            throw new DataValidationException(ErrorConstants.CancelCoFTopup.TRANSACTION_ID_MANDATORY);
        }

        if (customer.getCustomerAccountId() == null) {
            throw new DataValidationException(ErrorConstants.CancelCoFTopup.CUSTOMER_ACCOUNT_ID_MANDATORY);
        }

        //Validate topup transaction
        Optional<CoFTopupTransactionDO> oTopupTransaction = coFTopupTransactionRepository.findById(coFTopUpTransaction.getTransactionId());
        if (oTopupTransaction.isEmpty()) {
            String msg = String.format("CoFTopuptransaction not found for txnID[%s]", requestDomainContext.getTransaction().getTransactionId());
            throw new BusinessValidationException(ErrorConstants.CancelCoFTopup.TRANSACTION_NOT_FOUND, msg);
        }

        boolean validationFlag = validateCardSubTransaction(requestDomainContext.getTransaction().getTransactionId());
        responseDomainContext.setCoFTopupTransactionDO(oTopupTransaction.get());
        responseDomainContext.setTransaction(coFTopUpTransaction);
        updateCoFTopupTxnStateFor3DSCancelInitiated(responseDomainContext);
        return validationFlag;
    }

    private boolean validateCardSubTransaction(UUID transactionID) throws BusinessValidationException {
        String clientTransactionId = String.join("_", String.valueOf(transactionID), "1");
        CoreTransactionDO coreTransactionDO = coreTransactionRepository.findTopByClientTransactionIdOrderByCreateDateDesc(clientTransactionId);
        if (Objects.nonNull(coreTransactionDO)) {
            Optional<SubTransactionDO> ocardTransactionDO = coreTransactionDO.getCardSubTransaction();
            if (ocardTransactionDO.isPresent()) {
                SubTransactionDO cardTransactionDO = ocardTransactionDO.get();

                if (SubTransactionStatusV2.PAYMENT_FAILED.equals(cardTransactionDO.getStatus())) {
                    String msg = String.format("card subTransaction[%s] for transactionId :[%s] is already marked as FAILED", cardTransactionDO.getSubTransactionId(), transactionID);
                    throw new BusinessValidationException(ErrorConstants.CancelCoFTopup.TRANSACTION_ALREADY_MARKED_FAILED, msg);
                } else if (SubTransactionStatusV2.PAYMENT_SUCCEEDED.equals(cardTransactionDO.getStatus())) {
                    String msg = String.format("card subTransaction[%s] for transactionId :[%s] is already marked as SUCCESS", cardTransactionDO.getSubTransactionId(), transactionID);
                    throw new BusinessValidationException(ErrorConstants.CancelCoFTopup.TRANSACTION_ALREADY_MARKED_SUCCESS, msg);
                } else if (SubTransactionStatusV2.PAYMENT_CANCELLED.equals(cardTransactionDO.getStatus())) {
                    log.info("card subTransaction[{}] for transactionId :[{}] is already marked as CANCELLED", cardTransactionDO.getSubTransactionId(), transactionID);
                    return false;
                } else if (!SubTransactionStatusV2.PAYMENT_3DS_PENDING.equals(cardTransactionDO.getStatus())) {
                    String msg = String.format("card subTransaction[%s] for transactionId :[%s] is  marked as [%s]", cardTransactionDO.getSubTransactionId(), transactionID, cardTransactionDO.getStatus());
                    throw new BusinessValidationException(ErrorConstants.CancelCoFTopup.CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE, msg);
                }
                return true;
            }
            String msg = String.format("card subTransaction not found for transactionId :[%s]", transactionID);
            throw new BusinessValidationException(ErrorConstants.CancelCoFTopup.CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE, msg);
        }
        String msg = String.format("core Transaction not found present for transactionId :[%s]", transactionID);
        throw new BusinessValidationException(ErrorConstants.CancelCoFTopup.CANCEL_TRANSACTION_UNSUPPORTED_TRANSACTION_ERROR_CODE, msg);
    }

    private void updateCoFTopupTxnStateFor3DSCancelInitiated(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO();
        log.info("Updating transaction state for cancelled CoFTopupTransaction with transactionId : {}", coFTopupTransactionDO.getCoFTopupTransactionId());
        coFTopupTransactionDO.setState(TransactionStateEnum.FAILURE);
        coFTopupTransactionDO.setStateReason(CoFTopupTxnStateReason.DEBIT_3DS_CANCEL_INITIATED);
        coFTopupTransactionDO.updateLastEventDate();
        coFTopupTransactionDO = coFTopupTransactionRepository.save(coFTopupTransactionDO);
        coFTopupTxnResponseDomainContext.setCoFTopupTransactionDO(coFTopupTransactionDO);
    }
}
