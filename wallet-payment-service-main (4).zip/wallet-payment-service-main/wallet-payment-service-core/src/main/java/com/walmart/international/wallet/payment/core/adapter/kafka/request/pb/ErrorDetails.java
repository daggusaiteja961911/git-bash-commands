package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import lombok.Data;

@Data
public class ErrorDetails {
    private String category;
    private String errorCode;
    private String errorDescription;
    private Object metadata;
    private Boolean isMSI;
}
