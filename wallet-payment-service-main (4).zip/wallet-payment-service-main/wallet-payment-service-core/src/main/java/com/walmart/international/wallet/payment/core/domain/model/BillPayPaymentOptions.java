package com.walmart.international.wallet.payment.core.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillPayPaymentOptions {

    CardPaymentInstruments cardPaymentInstruments;
    GiftCardPaymentInstruments giftCardPaymentInstruments;
    PaymentInstruments paymentInstruments;

    Boolean isMSIAllowedForSplitPayment;
    Boolean allowB2BForSplitPayment;
    Boolean allowCoFForBillPayment;
    Boolean allowMultipleB2BForSplitPayment;
}
