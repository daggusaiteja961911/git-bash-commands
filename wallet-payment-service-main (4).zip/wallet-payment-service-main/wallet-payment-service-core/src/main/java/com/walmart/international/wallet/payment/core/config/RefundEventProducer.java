package com.walmart.international.wallet.payment.core.config;

import com.walmart.kafka.producer.annotation.CreateDRKafkaProducer;
import com.walmart.kafka.producer.annotation.KafkaDRRequestProducer;
import org.springframework.stereotype.Component;

@Component
@CreateDRKafkaProducer(producerConfigs = {@KafkaDRRequestProducer(beanName = "pbRefundRequestProducer", propertyName = "pbRefundRequestProducer")
})
public class RefundEventProducer {
}
