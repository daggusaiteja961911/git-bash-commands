package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Property;

public interface CommonServiceConfiguration {

    @Property(propertyName = "service.connection.timeout", defaultValue = "5000")
    Integer getConnectionTimeout();

    @Property(propertyName = "service.socket.timeout",  defaultValue = "10000")
    Integer getSocketTimeout();
}
