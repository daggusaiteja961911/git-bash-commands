package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = "aml-config")
public interface AMLConfig {

    @Property(propertyName = "aml.eval.processing.enabled")
    Boolean amlEvaluationEnabled();

    @Property(propertyName = "aml.ingest.processing.enabled", defaultValue = "true")
    Boolean amlIngestEnabled();

    @Property(propertyName = "skip.cof.topup.txn.sync")
    Boolean getSkipCoFTopupTxnSync();

    @Property(propertyName = "skip.bill.pay.txn.sync")
    Boolean getSkipBillPayTxnSync();
}
