package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.strati.telemetry.service.CashiTelemetryMetrics;
import com.walmart.international.digiwallet.service.strati.telemetry.service.constants.CashiTelemetry;
import com.walmart.international.digiwallet.service.strati.telemetry.service.constants.CashiTelemetryMetricName;
import com.walmart.international.digiwallet.service.web.rest.i8n.local.SimpleMessageResolver;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.request.AMLValidationRequest;
import com.walmart.international.wallet.payment.core.adapter.pls.PaymentLookupServiceAdapter;
import com.walmart.international.wallet.payment.core.domain.model.response.AMLValidationResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class AMLValidationService {

    @Autowired
    PaymentLookupServiceAdapter paymentLookupServiceAdapter;

    @Autowired
    CashiTelemetryMetrics cshTelMetrics;

    @Autowired
    SimpleMessageResolver messageResolver;

    public void validateAMLChecks(AMLValidationRequest amlValidationRequest) throws BusinessValidationException, ProcessingException {
        Optional<AMLValidationResponse> amlValidationResponse = paymentLookupServiceAdapter.validateTransactionForAmlCheck(amlValidationRequest);
        if (amlValidationResponse.isPresent()) {
            log.info("AML validation response {}", amlValidationResponse);
            cshTelMetrics.inc(WPSConstants.AML.TRANSACTION, WPSConstants.AML.AML_EVALUATION,
                    CashiTelemetry.Level3.ALL.name(), CashiTelemetryMetricName.CASHI_TRANSACTION.name());
            if (!amlValidationResponse.get().getAmlValidationResult()) {
                throw new BusinessValidationException(amlValidationResponse.get().getStatusCode(), "", new Object[]{amlValidationResponse.get().getStatusMessage()});
            }
        }
    }
}
