package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.domain.CoreTransactionStatusV2;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.request.ReversalRequest;
import com.walmart.international.services.payment.core.response.ReversalResponse;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.utils.WalletPaymentServiceUtil;
import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import com.walmart.international.wallet.payment.data.dao.repository.CoFTopupTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class CoFTopupCoreServiceImpl implements CoFTopupCoreService {

    @Autowired
    private CoFTopupTransactionRepository coFTopupTransactionRepository;

    @Autowired
    private PaymentCoreService paymentCoreService;

    @Autowired
    private WalletPaymentServiceUtil walletPaymentServiceUtil;

    @Override
    public void updateTransactionForReversalStatus(UUID transactionId, CoFTopupTxnStateReason stateReason) {
        try {
            Optional<CoFTopupTransactionDO> coFTopupTransactionDOOptional = coFTopupTransactionRepository.findById(transactionId);

            if (coFTopupTransactionDOOptional.isPresent()) {
                CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTransactionDOOptional.get();
                coFTopupTransactionDO.setStateReason(stateReason);
                coFTopupTransactionRepository.save(coFTopupTransactionDO);
            } else {
                log.error("CoF transaction does not exist for transactionID :{}, can not update refund state", transactionId);
            }
        } catch (Exception ex) {
            log.error("Error occurred while updating cof top up transaction : {} for refund status", transactionId, ex);
        }
    }

    @Override
    public void reverseCoFTopUpTransactionCharge(UUID transactionId) {
        Optional<CoFTopupTransactionDO> coFTopupTransactionDOOptional = coFTopupTransactionRepository.findById(transactionId);
        if (coFTopupTransactionDOOptional.isEmpty()) {
            throw new ProcessingException(ErrorConstants.CoFTopupChargeReversal.INVALID_TRANSACTION_ID);
        }
        CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTransactionDOOptional.get();
        if (coFTopupTransactionDO.getState() == TransactionStateEnum.SUCCESS) {
            throw new ProcessingException(ErrorConstants.CoFTopupChargeReversal.INVALID_TRANSACTION_STATE);
        }
        log.info("Initiating reversalRequest for transactionId:{}", transactionId);
        try {
            ReversalRequest reversalRequest = ReversalRequest.builder()
                    .clientTransactionId(String.join("_", String.valueOf(transactionId), "1"))
                    .clientTransactionUUID(transactionId)
                    .build();
            coFTopupTransactionDO = updateCoFTransactionStatus(coFTopupTransactionDO, TransactionStateEnum.FAILURE, CoFTopupTxnStateReason.DEBIT_REVERSAL_INITIATED);
            ReversalResponse reversalResponse = paymentCoreService.reverse(reversalRequest);
            if (reversalResponse.getStatus().equals(CoreTransactionStatusV2.FAILED)) {
                log.error("ReversalRequest failed for transactionId:{} with reversalResponse:{}", transactionId, reversalResponse);
                coFTopupTransactionDO = updateCoFTransactionStatus(coFTopupTransactionDO, TransactionStateEnum.FAILURE, CoFTopupTxnStateReason.DEBIT_REVERSAL_INIT_FAILED);
                throw new ProcessingException(ErrorConstants.CoFTopupChargeReversal.CHARGE_CARD_PAYMENT_CORE_REVERSAL_FAILED, reversalResponse.getFailureDescription());
            }
            log.info("ReversalRequest succeeded for transactionId:{}", transactionId);
            coFTopupTransactionDO = updateCoFTransactionStatus(coFTopupTransactionDO, TransactionStateEnum.FAILURE, CoFTopupTxnStateReason.DEBIT_REVERSAL_PENDING);
        } catch (PaymentCoreServiceException ex) {
            log.error("ReversalRequest failed for transactionId:{} with exception", transactionId, ex);
            updateCoFTransactionStatus(coFTopupTransactionDO, TransactionStateEnum.FAILURE, CoFTopupTxnStateReason.DEBIT_REVERSAL_INIT_FAILED);
            throw new ProcessingException(ErrorConstants.CoFTopupChargeReversal.CHARGE_CARD_PAYMENT_CORE_REVERSAL_FAILED, ex.getMessage());
        }
    }

    private CoFTopupTransactionDO updateCoFTransactionStatus(CoFTopupTransactionDO coFTopupTransactionDO, TransactionStateEnum failure, CoFTopupTxnStateReason debitReversalInitiated) {
        coFTopupTransactionDO.setState(failure);
        coFTopupTransactionDO.setStateReason(debitReversalInitiated);
        coFTopupTransactionDO = walletPaymentServiceUtil.updateLastEventDateCheck(coFTopupTransactionDO, failure,
                debitReversalInitiated);
        return coFTopupTransactionRepository.save(coFTopupTransactionDO);
    }
}
