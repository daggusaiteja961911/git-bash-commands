package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.wallet.payment.data.constant.enums.CoFTopupTxnStateReason;

import java.util.UUID;

public interface CoFTopupCoreService {

    void updateTransactionForReversalStatus(UUID transactionId, CoFTopupTxnStateReason stateReason);

    void reverseCoFTopUpTransactionCharge(UUID transactionId);
}
