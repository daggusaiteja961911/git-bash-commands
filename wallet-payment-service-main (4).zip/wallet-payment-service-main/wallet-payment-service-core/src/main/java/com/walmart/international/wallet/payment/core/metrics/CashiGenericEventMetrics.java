package com.walmart.international.wallet.payment.core.metrics;

import com.walmart.international.digiwallet.service.strati.telemetry.service.CashiTelemetryMetrics;
import com.walmart.international.digiwallet.service.strati.telemetry.util.CashiServiceGenericEventDimensions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CashiGenericEventMetrics {

    @Autowired
    private CashiTelemetryMetrics cashiTelemetryMetrics;

    private static final String CASHI_SERVICE_GENERIC_EVENTS = "cashi_service_generic_events";

    public void incCounter(String eventType, String eventName, String result) {
        cashiTelemetryMetrics.inc(eventName, eventType, result, CASHI_SERVICE_GENERIC_EVENTS, "count", CashiServiceGenericEventDimensions.values());
    }
}