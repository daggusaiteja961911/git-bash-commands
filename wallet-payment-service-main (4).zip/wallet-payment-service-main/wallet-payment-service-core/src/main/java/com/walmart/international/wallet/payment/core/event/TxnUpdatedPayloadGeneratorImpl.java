package com.walmart.international.wallet.payment.core.event;

import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.notification.txnaggregator.TxnUpdatedPayloadGenerator;
import org.springframework.stereotype.Component;

@Component
public class TxnUpdatedPayloadGeneratorImpl extends TxnUpdatedPayloadGenerator {
    @Override
    public EventPayload generatePayload(Object payload, String correlationId){
        return null;
    }
}
