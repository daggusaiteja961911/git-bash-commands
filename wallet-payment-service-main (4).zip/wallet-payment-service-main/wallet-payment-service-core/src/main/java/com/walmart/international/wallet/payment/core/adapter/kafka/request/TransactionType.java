package com.walmart.international.wallet.payment.core.adapter.kafka.request;

public enum TransactionType {
    BILL, COF
}
