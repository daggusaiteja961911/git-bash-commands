package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.utils.EventHelper;
import com.walmart.international.wallet.payment.core.adapter.tas.TxnAggregatorServiceAdapter;
import com.walmart.international.wallet.payment.core.config.ccm.AMLConfig;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.BillPayMapper;
import com.walmart.international.wallet.payment.core.mapper.CoFTopupMapper;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
@Slf4j
public class TxnAggregatorDataSyncService {

    @Autowired
    private EventHelper eventHelper;

    @ManagedConfiguration
    private AMLConfig amlConfig;

    @Autowired
    private TxnAggregatorServiceAdapter txnAggregatorServiceAdapter;

    private BillPayMapper billPayMapper = BillPayMapper.INSTANCE;

    private CoFTopupMapper coFTopupMapper = CoFTopupMapper.INSTANCE;

    public void pushTransactionDataToTAAS(BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnResponseDomainContext.getTransaction();
        BillPayTransactionDO billPayTransactionDO = billPayTxnResponseDomainContext.getBillPayTransactionDO();
        try {
            billPayMapper.updateBillPayTransactionFromBillPayTransactionDO(billPayTransactionDO, billPayTransaction);

            if (amlConfig.amlIngestEnabled() && !amlConfig.getSkipBillPayTxnSync()) {
                log.info("Ingesting data to sync in-sync for BillPayTransaction with txnId:[{}]", billPayTransaction.getTransactionId());
                txnAggregatorServiceAdapter.syncBillPayTransaction(billPayTransaction);
            }

            log.info("Publishing BillPayTransaction data with txnId:[{}] to TAAS", billPayTransaction.getTransactionId());
            String transactionId = billPayTransaction.getTransactionId().toString();
            eventHelper.publishAsync(transactionId, billPayTransaction, WalletEventType.TXN_COMPLETED,
                    Collections.singletonList(com.walmart.international.notification.constants.EventDownstream.TXN_AGGREGATER_SERVICE));
        } catch (Exception ex) {
            log.info("Exception in pushTransactionDataToTAAS for BillPayTransaction with txnId:[{}]. StackTrace:[{}]",
                    billPayTransaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
        }
    }

    public void pushTransactionDataToTAAS(CoFTopupTxnResponseDomainContext coFTopupTxnResponseDomainContext) {
        CoFTopUpTransaction coFTopUpTransaction = coFTopupTxnResponseDomainContext.getTransaction();
        CoFTopupTransactionDO coFTopupTransactionDO = coFTopupTxnResponseDomainContext.getCoFTopupTransactionDO();
        try {
            coFTopupMapper.updateCoFTopupTransactionFromCoFTopupTransactionDO(coFTopupTransactionDO, coFTopUpTransaction);

            if (amlConfig.amlIngestEnabled() && !amlConfig.getSkipCoFTopupTxnSync()) {
                log.info("Ingesting data to sync in-sync for CoFTopupTransaction with txnId:[{}]", coFTopUpTransaction.getTransactionId());
                txnAggregatorServiceAdapter.syncCoFTopupTransaction(coFTopUpTransaction);
            }

            log.info("Publishing CoFTopupTransaction data with txnId:[{}] to TAAS", coFTopUpTransaction.getTransactionId());
            String transactionId = coFTopUpTransaction.getTransactionId().toString();
            eventHelper.publishAsync(transactionId, coFTopUpTransaction, WalletEventType.TXN_COMPLETED,
                    Collections.singletonList(com.walmart.international.notification.constants.EventDownstream.TXN_AGGREGATER_SERVICE));
        } catch (Exception ex) {
            log.info("Exception in pushTransactionDataToTAAS for CoFTopupTransaction with txnId:[{}]. StackTrace:[{}]",
                    coFTopUpTransaction.getTransactionId(), ExceptionUtils.getStackTrace(ex));
        }
    }

}
