package com.walmart.international.wallet.payment.core.event.listener;

import com.walmart.international.campaign.client.CampaignServiceClient;
import com.walmart.international.ewallet.services.events.config.Listener;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.event.payload.CampaignRewardEventPayload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RewardInitiatedListener {

    @Autowired
    private CampaignServiceClient campaignServiceClient;

    @Listener(types = {WPSConstants.Event.REWARD_BILL_PAY, WPSConstants.Event.REWARD_LOAD_MONEY})
    public void handleEvent(CampaignRewardEventPayload campaignRewardEventPayload) {
        campaignServiceClient.rewardTransaction(campaignRewardEventPayload.getCustomerAccountId(), campaignRewardEventPayload.getRewardRequest());
    }
}
