package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.digiwallet.service.flow.FlowType;
import com.walmart.international.digiwallet.service.flow.builder.FlowBuilder;
import com.walmart.international.digiwallet.service.flow.chain.Chain;
import com.walmart.international.digiwallet.service.flow.domain.model.IRequestDomainContext;
import com.walmart.international.digiwallet.service.flow.domain.model.IResponseDomainContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class FlowExecutor {

    @Autowired
    private FlowBuilder flowBuilder;

    public void executeFlowType(FlowType flowType, IRequestDomainContext requestDomainContext, IResponseDomainContext responseDomainContext) {
        Optional<Chain<IRequestDomainContext, IResponseDomainContext>> chain = flowBuilder.getChainFor(flowType.getFlowName());
        if (chain.isPresent()) {
            chain.get().handle(requestDomainContext, responseDomainContext);
            log.info("Processed request with clientRequestId : {} with response : {} in flowType : {}",
                    requestDomainContext.getClientRequestId(), responseDomainContext, flowType);
        }
    }
}
