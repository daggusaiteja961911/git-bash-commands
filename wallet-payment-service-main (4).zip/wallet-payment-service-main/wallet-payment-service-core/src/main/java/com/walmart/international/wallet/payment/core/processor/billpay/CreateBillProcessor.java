package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessor;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.BillProcessorFactory;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.exception.BillProcessorValidationException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.request.CreateBillRequest;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.CreateBillResponse;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.mapper.CustomerBillAccountMapper;
import com.walmart.international.wallet.payment.data.dao.entity.CustomerBillAccountDO;
import com.walmart.international.wallet.payment.data.dao.repository.CustomerBillAccountRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

@Component
@Slf4j
public class CreateBillProcessor implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    CustomerBillAccountMapper customerBillAccountMapper = CustomerBillAccountMapper.INSTANCE;

    @Autowired
    CustomerBillAccountRepository customerBillAccountRepository;

    @Autowired
    BillProcessorFactory billProcessorFactory;


    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        BillResponseDomainContext billResponseDomainContext = (BillResponseDomainContext) wpsResponseDomainContext;

        CustomerBillAccount customerBillAccount = billResponseDomainContext.getCustomerBillAccount();
        Biller biller = customerBillAccount.getBiller();
        CustomerBillAccountDO customerBillAccountDO;

        UUID customerAccountId = customerBillAccount.getCustomerAccountId();
        String accountNumber = customerBillAccount.getAccountNumber();

        String processorBillerId = biller.getProcessorBillerId();
        CreateBillResponse createBillResponse;

        BillProcessor billProcessor = billProcessorFactory.getBillProcessor();

        if (Objects.nonNull(customerBillAccount.getCustomerBillAccountId())) {
            log.info("RefreshBill - Customer Bill Account exists for customerId[{}}, processorBillerId[{}}, " +
                    "accountNumber[{}]", customerAccountId, processorBillerId, accountNumber);
            customerBillAccountDO = billResponseDomainContext.getCustomerBillAccountDO();
            if (BooleanUtils.isTrue(biller.getCanCheckBalance())) {
                log.info("RefreshBill - CanCheckBalance is true for processorBillerId[{}]", processorBillerId);
                createBillResponse = callBillProcessorRefreshBill(billProcessor, customerBillAccount);
                customerBillAccount.setRevisedAccountNumber(createBillResponse.getAccountNumber());
                customerBillAccountMapper.mapCreateBillResponseToCustomerBillAccount(createBillResponse, billResponseDomainContext.getBillerDO(), customerBillAccount);
                //To handle mock
                if (Objects.isNull(customerBillAccount.getProcessorBillerId())) {
                    customerBillAccount.setProcessorBillerId(processorBillerId);
                }
                customerBillAccountMapper.updateCustomerBillAccountDOFromCustomerBillAccount(customerBillAccount, customerBillAccountDO);
            }
            updateCustomerBillAccountDO(customerBillAccountDO);
        } else {
            log.info("CreateBill - Customer Bill Account does not exist for customerAccountId[{}], processorBillerId[{}}, " +
                    "accountNumber[{}}", customerAccountId, processorBillerId, accountNumber);
            if (BooleanUtils.isTrue(biller.getCanCheckBalance())) {
                log.info("CreateBill - CanCheckBalance is true for processorBillerId[{}}", processorBillerId);
                createBillResponse = callBillProcessorCreateBill(billProcessor, customerBillAccount);
                customerBillAccount.setRevisedAccountNumber(createBillResponse.getAccountNumber());
                customerBillAccountMapper.mapCreateBillResponseToCustomerBillAccount(createBillResponse, billResponseDomainContext.getBillerDO(), customerBillAccount);
            }
            customerBillAccountDO = customerBillAccountMapper.mapCustomerBillAccountToCustomerBillAccountDOForCreateBill(customerBillAccount);
            customerBillAccountDO.setBillerDO(billResponseDomainContext.getBillerDO());
            customerBillAccountDO = saveCustomerBillAccountDO(customerBillAccountDO);
            customerBillAccount.setCustomerBillAccountId(customerBillAccountDO.getCustomerBillAccountId());
        }
        billResponseDomainContext.setCustomerBillAccount(customerBillAccount);
        return true;
    }

    //TODO Processoring binding to be correction
    private CreateBillResponse callBillProcessorRefreshBill(BillProcessor billProcessor, CustomerBillAccount customerBillAccount)
            throws BusinessValidationException, ProcessingException {
        CreateBillResponse createBillResponse;
        try {
            createBillResponse = billProcessor.refreshBill(customerBillAccount.getProcessorBillAccountId(), customerBillAccount.getBiller().getArcusAuthKeyVersion());
        } catch (BillProcessorValidationException ex) {
            String msg = String.format("Validation error in Refresh Bill for customerAccountId[%s] and processorBillAccountId[%s]", customerBillAccount.getCustomerAccountId(), customerBillAccount.getProcessorBillAccountId());
            throw new BusinessValidationException(ex.getErrorCode(), msg, ex);
        } catch (BillProcessorException ex) {
            String msg = String.format("Processing error in Refresh Bill for customerAccountId[%s] and processorBillAccountId[%s]", customerBillAccount.getCustomerAccountId(), customerBillAccount.getProcessorBillAccountId());
            throw new ProcessingException(ex.getErrorCode(), msg, ex);
        }
        return createBillResponse;
    }

    private CustomerBillAccountDO updateCustomerBillAccountDO(CustomerBillAccountDO customerBillAccountDO) throws ProcessingException {
        log.info("RefreshBill - Updating bill with billId[{}} for customerAccountId[{}]", customerBillAccountDO.getCustomerBillAccountId(), customerBillAccountDO.getCustomerAccountId());
        try {
            customerBillAccountRepository.save(customerBillAccountDO);
        } catch (Exception ex) {
            String msg = String.format("Error while updating customer bill account with id[%s] to DB", customerBillAccountDO.getCustomerBillAccountId());
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
        return customerBillAccountDO;
    }

    private CreateBillResponse callBillProcessorCreateBill(BillProcessor billProcessor, CustomerBillAccount customerBillAccount)
            throws BusinessValidationException, ProcessingException {
        CreateBillResponse createBillResponse;
        try {
            CreateBillRequest createBillRequest = CreateBillRequest.builder()
                    .processorBillerId(customerBillAccount.getBiller().getProcessorBillerId())
                    .accountNumber(customerBillAccount.getAccountNumber())
                    .build();
            createBillResponse = billProcessor.createBill(createBillRequest, customerBillAccount.getBiller().getArcusAuthKeyVersion());
        } catch (BillProcessorValidationException ex) {
            String msg = String.format("Validation error in CreateBill for customerAccountId[%s], processorBillerId[%s] and accountNumber[%s]",
                    customerBillAccount.getCustomerAccountId(), customerBillAccount.getBiller().getProcessorBillerId(), customerBillAccount.getAccountNumber());
            throw new BusinessValidationException(ex.getErrorCode(), msg, ex);
        } catch (BillProcessorException ex) {
            String msg = String.format("Processing error in CreateBill for customerAccountId[%s], processorBillerId[%s] and accountNumber[%s]",
                    customerBillAccount.getCustomerAccountId(), customerBillAccount.getBiller().getProcessorBillerId(), customerBillAccount.getAccountNumber());
            throw new ProcessingException(ex.getErrorCode(), msg, ex);
        }
        return createBillResponse;
    }

    private CustomerBillAccountDO saveCustomerBillAccountDO(CustomerBillAccountDO customerBillAccountDO) throws ProcessingException {
        log.info("CreateBill - Saving new bill entry");
        try {
            return customerBillAccountRepository.save(customerBillAccountDO);
        } catch (Exception ex) {
            String msg = String.format("Error while updating customer bill account with id[%s] to DB", customerBillAccountDO.getCustomerBillAccountId());
            throw new ProcessingException(ErrorConstants.Common.INTERNAL_SERVER_ERROR, msg, ex);
        }
    }

}
