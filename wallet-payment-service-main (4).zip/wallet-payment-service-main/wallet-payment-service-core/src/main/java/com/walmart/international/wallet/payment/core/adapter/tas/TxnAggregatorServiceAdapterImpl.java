package com.walmart.international.wallet.payment.core.adapter.tas;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.digiwallet.service.strati.telemetry.service.CashiTelemetryMetrics;
import com.walmart.international.digiwallet.service.strati.telemetry.service.constants.CashiTelemetry;
import com.walmart.international.digiwallet.service.strati.telemetry.service.constants.CashiTelemetryMetricName;
import com.walmart.international.ewallet.transaction.aggregator.payload.EventPayload;
import com.walmart.international.ewallet.transaction.aggregator.payload.consts.GCTransactionType;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.PaymentInstrument;
import com.walmart.international.ewallet.transaction.aggregator.payload.dto.TransactionEventDTO;
import com.walmart.international.services.digitalwallet.httpclient.wallet.constants.ApiName;
import com.walmart.international.services.digitalwallet.httpclient.wallet.webclient.WebClientV2;
import com.walmart.international.services.payment.core.api.PaymentCoreService;
import com.walmart.international.services.payment.core.exception.PaymentCoreServiceException;
import com.walmart.international.services.payment.core.response.GetTxnDetailResponse;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.tas.request.TransactionSyncRequest;
import com.walmart.international.wallet.payment.core.adapter.tas.response.TxnEventRestConsumptionResponse;
import com.walmart.international.wallet.payment.core.adapter.tas.response.TxnSyncResponse;
import com.walmart.international.wallet.payment.core.config.ccm.TASServiceConfig;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.mapper.CustomerMapper;
import com.walmart.international.wallet.payment.core.mapper.TxnCompletedPayloadMapper;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class TxnAggregatorServiceAdapterImpl implements TxnAggregatorServiceAdapter {

    private static final String TXN_SYNC_URL = "/txn-agg/v1/transactions";
    private static final Object PUBLISH_TXN_PAYLOAD_URL = "/txn-agg/v1/event/txn-completed/consume";
    private Map<String, String> metadata;

    @PostConstruct
    public void init() {
        metadata = new HashMap<>();
        metadata.put(WPSConstants.AML.SRC_APP, WPSConstants.AML.SRC_APP_NAME);
    }

    @ManagedConfiguration
    private TASServiceConfig tasServiceConfig;

    @Autowired
    @Qualifier("tasWebClient")
    private WebClientV2 webClientV2;

    @Autowired
    private CashiTelemetryMetrics cshTelMetrics;

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    @Autowired
    private PaymentCoreService paymentCoreService;

    private TxnCompletedPayloadMapper txnCompletedPayloadMapper = TxnCompletedPayloadMapper.INSTANCE;

    private CustomerMapper customerMapper = CustomerMapper.INSTANCE;


    @Override
    public void syncBillPayTransaction(BillPayTransaction billPayTransaction) {
        if (Objects.isNull(billPayTransaction)) {
            return;
        }
        log.info("Initiating syncing of bill pay transaction for id {}", billPayTransaction.getTransactionId());
        Optional<TransactionSyncRequest> transactionSyncRequest = createRequestPayloadForTxnSync(billPayTransaction);
        if (transactionSyncRequest.isPresent()) {
            String txnSyncApiUrl = String.format("%s%s", tasServiceConfig.getTasBaseUrl(), TXN_SYNC_URL);
            HttpHeaders headers = getHeaders();
            log.info("Calling TAS for minimal data sync TXN id [{}] , request payload [{}]", billPayTransaction.getTransactionId(),
                    transactionSyncRequest);
            processHttpCall(transactionSyncRequest.get(), txnSyncApiUrl, headers, TASAPIName.BILL_PAY_TXN_SYNC);
        }
    }

    @Override
    public void syncBillPayTransaction(BillPayTransactionDO billPayTransactionDO) {
        if (Objects.isNull(billPayTransactionDO)) {
            return;
        }
        log.info("Initiating syncing of bill pay transaction for id {}", billPayTransactionDO.getBillPayTransactionId());
        Optional<TransactionSyncRequest> transactionSyncRequest = createRequestPayloadForTxnSync(billPayTransactionDO);
        if (transactionSyncRequest.isPresent()) {
            String txnSyncApiUrl = String.format("%s%s", tasServiceConfig.getTasBaseUrl(), TXN_SYNC_URL);
            HttpHeaders headers = getHeaders();
            log.info("Calling TAS for minimal data sync TXN id [{}] , request payload [{}]", billPayTransactionDO.getBillPayTransactionId(),
                    transactionSyncRequest);
            processHttpCall(transactionSyncRequest.get(), txnSyncApiUrl, headers, TASAPIName.BILL_PAY_TXN_SYNC);
        }
    }

    @Override
    public void syncCoFTopupTransaction(CoFTopUpTransaction coFTopupTransaction) {
        if (Objects.isNull(coFTopupTransaction)) {
            return;
        }
        log.info("Initiating syncing of load money transaction for id {}", coFTopupTransaction.getTransactionId());
        Optional<TransactionSyncRequest> transactionSyncRequest = createRequestPayloadForTxnSync(coFTopupTransaction);
        if (transactionSyncRequest.isPresent()) {
            String txnSyncApiUrl = String.format("%s%s", tasServiceConfig.getTasBaseUrl(), TXN_SYNC_URL);
            HttpHeaders headers = getHeaders();
            log.info("Calling TAS for minimal data sync TXN id [{}] , request payload [{}]", coFTopupTransaction.getTransactionId(),
                    transactionSyncRequest);
            processHttpCall(transactionSyncRequest.get(), txnSyncApiUrl, headers, TASAPIName.COF_TXN_SYNC);
        }
    }

    @Override
    public TxnEventRestConsumptionResponse publishPayloadViaRESTCall(EventPayload eventPayload) throws Throwable {
        String txnPublishApiUrl = String.format("%s%s", tasServiceConfig.getTasBaseUrl(), PUBLISH_TXN_PAYLOAD_URL);
        HttpHeaders headers = getHeaders();
        log.info("Publishing TXN_AGG payload[{}] via REST API", eventPayload);
        ResponseEntity<TxnEventRestConsumptionResponse> response = webClientV2.post(txnPublishApiUrl, null, headers, eventPayload, TxnEventRestConsumptionResponse.class, TASAPIName.PUBLISH_TXN_PAYLOAD);
        log.info("Received response[{}] from TXN_AGG", response);
        return response.getBody();
    }

    private void processHttpCall(TransactionSyncRequest httpRequest, String txnSyncApiUrl, HttpHeaders headers, ApiName apiName) {
        try {
            ResponseEntity<TxnSyncResponse[]> txnSyncResponseEntity = webClientV2.post(txnSyncApiUrl,
                    null, headers, httpRequest, TxnSyncResponse[].class, apiName);

            if (Objects.isNull(txnSyncResponseEntity)) {
                throw new ProcessingException(ErrorConstants.AML.ERROR_PROCESSING_AML_INGEST);
            }
            log.info("Response [{}] on calling aml ingest ", txnSyncResponseEntity.getBody());
            HttpStatus status = txnSyncResponseEntity.getStatusCode();
            processResponseForTxnSync(txnSyncResponseEntity.getBody(), status, null);
        } catch (Throwable e) {
            log.error("Error while calling transaction sync {}", e.getMessage());
            publishFailedSyncEvent("HTTP_" + ErrorConstants.AML.ERROR_PROCESSING_AML_INGEST, (Exception) e);
        }
    }

    private HttpHeaders getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        return headers;
    }

    private Optional<TransactionSyncRequest> createRequestPayloadForTxnSync(CoFTopUpTransaction coFTopUpTransaction) {
        Optional<TransactionSyncRequest> transactionSyncRequest = Optional.empty();
        try {
            transactionSyncRequest = Optional.of(TransactionSyncRequest.builder()
                    .transactions(Collections.singletonList(txnCompletedPayloadMapper.mapCoFTopupTransactionToTransactionEventForSync(coFTopUpTransaction)))
                    .metadata(metadata).build());
        } catch (Exception exception) {
            log.error("Failed to create payload for minimal data sync {}", exception);
        }
        return transactionSyncRequest;
    }

    private Optional<TransactionSyncRequest> createRequestPayloadForTxnSync(BillPayTransaction billPayTransaction) {
        Optional<TransactionSyncRequest> transactionSyncRequest = Optional.empty();
        try {
            transactionSyncRequest = Optional.of(TransactionSyncRequest.builder()
                    .transactions(List.of(txnCompletedPayloadMapper.mapBillPayTransactionToTransactionEventForSync(billPayTransaction)))
                    .metadata(metadata).build());
        } catch (Exception exception) {
            log.error("Failed to create payload for minimal data sync {}", billPayTransaction.getTransactionId());
        }
        return transactionSyncRequest;
    }

    private Optional<TransactionSyncRequest> createRequestPayloadForTxnSync(BillPayTransactionDO billPayTransactionDO) {
        Optional<TransactionSyncRequest> transactionSyncRequest = Optional.empty();
        try {
            TransactionEventDTO transactionEventDTO = txnCompletedPayloadMapper.mapBillPayTransactionDOToTransactionEventForSync(billPayTransactionDO);
            transactionEventDTO.setPaymentInstruments(mapPaymentInstrumentsForBillPayTransaction(billPayTransactionDO));
            transactionSyncRequest = Optional.of(TransactionSyncRequest.builder()
                    .transactions(List.of(transactionEventDTO))
                    .metadata(metadata).build());
        } catch (Exception exception) {
            log.error("Failed to create payload for minimal data sync {}", billPayTransactionDO.getBillPayTransactionId());
        }
        return transactionSyncRequest;
    }

    private List<PaymentInstrument> mapPaymentInstrumentsForBillPayTransaction(BillPayTransactionDO billPayTransactionDO) throws PaymentCoreServiceException {
        List<PaymentInstrument> paymentInstruments = new ArrayList<>();
        List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList = customerServiceClient.getPaymentInstruments(billPayTransactionDO.getCustomerAccountId(), true, false, false).getPaymentInstruments();

        String clientTransactionId = billPayTransactionDO.getBillPayTransactionId().toString();
        GetTxnDetailResponse coreTransactionDetail = paymentCoreService.getTransactionDetail(clientTransactionId);
        if (Objects.isNull(coreTransactionDetail)) {
            return Collections.emptyList();
        }

        Optional<GetTxnDetailResponse.CoreTransaction> oCoreTransaction = Optional.ofNullable(coreTransactionDetail.getCoreTransactions().get(0));
        if (oCoreTransaction.isEmpty()) {
            return Collections.emptyList();
        }

        if (CollectionUtils.isNotEmpty(oCoreTransaction.get().getCardSubTransactions())) {
            for (GetTxnDetailResponse.CardSubTransactionDetail cardSubTransactionDetail : oCoreTransaction.get().getCardSubTransactions()) {
                PaymentInstrument paymentInstrument = txnCompletedPayloadMapper.mapPaymentInstrumentFromCardSubTransactionDetailForSync(cardSubTransactionDetail);
                paymentInstruments.add(paymentInstrument);
            }
        }

        if (CollectionUtils.isNotEmpty(oCoreTransaction.get().getGiftCardSubTransactions())) {
            for (GetTxnDetailResponse.GiftCardSubTransactionDetail giftCardSubTransactionDetail : oCoreTransaction.get().getGiftCardSubTransactions()) {
                PaymentInstrument paymentInstrument = txnCompletedPayloadMapper.mapPaymentInstrumentFromGiftCardSubTransactionDetailForSync(giftCardSubTransactionDetail);
                paymentInstrument.setTransactionType(GCTransactionType.AUTHORIZE);
                GiftCardPaymentInstrument giftCardPaymentInstrument = getGiftCardPaymentInstrumentUsedInGiftCardSubTransaction(customerPaymentInstrumentList,
                        giftCardSubTransactionDetail.getPaymentProviderInstrumentId());
                if (Objects.nonNull(giftCardPaymentInstrument)) {
                    paymentInstrument.setIsVale(giftCardPaymentInstrument.getCompany().getIsVale());
                }
                paymentInstruments.add(paymentInstrument);
            }
        }

        return paymentInstruments;
    }

    private GiftCardPaymentInstrument getGiftCardPaymentInstrumentUsedInGiftCardSubTransaction(List<WalletResponse.PaymentInstrument> customerPaymentInstrumentList, String paymentProviderInstrumentId) {
        for (WalletResponse.PaymentInstrument paymentInstrument : customerPaymentInstrumentList) {
            if (paymentInstrument.getAdapterMetadata().getPiHash().equals(paymentProviderInstrumentId)) {
                return customerMapper.mapPaymentInstrumentToGiftCardPaymentInstrument(paymentInstrument);
            }
        }
        return null;
    }


    private void processResponseForTxnSync(TxnSyncResponse[] response, HttpStatus status, Exception ex) {
        if (Objects.isNull(status)) {
            log.error("Empty response from TAS for TXN sync: [{}]", response);
            return;
        }

        if (status == HttpStatus.OK) {
            for (TxnSyncResponse txnSyncResponse : response) {
                if (txnSyncResponse.getSyncStatus().equals("SUCCESS")) {
                    log.info("Successfully synced txn id :", txnSyncResponse.getTransactionId());
                    cshTelMetrics.inc(WPSConstants.AML.TRANSACTION, WPSConstants.AML.MINIMAL_DATA_SYNC,
                            CashiTelemetry.Level3.ALL.name(), CashiTelemetryMetricName.CASHI_TRANSACTION.name());
                } else {
                    log.info("Failed synced txn , details are [{}]", txnSyncResponse);
                    publishFailedSyncEvent(txnSyncResponse.getErrorCode(), null);
                }
            }
        } else if (status.is4xxClientError() || status.is5xxServerError()) {
            log.error("Failed to sync txn with error code [{}], response [{}]", status, response);
            publishFailedSyncEvent("HTTP_" + status.toString(), ex);
        } else {
            log.error("Unexpected response to sync txn with http code [{}], response [{}]", status, response);
            publishFailedSyncEvent("HTTP_" + status.toString(), ex);
        }
    }


    private void publishFailedSyncEvent(String errorCode, Exception exception) {
        cshTelMetrics.error(WPSConstants.AML.TRANSACTION, WPSConstants.AML.MINIMAL_DATA_SYNC,
                errorCode, CashiTelemetryMetricName.CASHI_TRANSACTION.name(), exception);
    }

}
