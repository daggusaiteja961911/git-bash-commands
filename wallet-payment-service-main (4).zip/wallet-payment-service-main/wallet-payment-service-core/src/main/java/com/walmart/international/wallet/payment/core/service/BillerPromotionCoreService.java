package com.walmart.international.wallet.payment.core.service;

import com.walmart.international.wallet.payment.core.domain.model.BillerPromotion;

import java.util.List;
import java.util.Map;

public interface BillerPromotionCoreService {

    Map<String, List<BillerPromotion>> getAllPromotionsForPromotionCategory(String billerCategoryIds, String processorBillerIds, int billerCategoryVersion);
}
