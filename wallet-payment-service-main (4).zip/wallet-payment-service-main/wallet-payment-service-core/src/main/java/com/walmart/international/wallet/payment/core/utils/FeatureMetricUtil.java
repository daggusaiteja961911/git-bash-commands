package com.walmart.international.wallet.payment.core.utils;

import com.walmart.international.wallet.payment.core.constants.enums.AffiliationType;
import com.walmart.international.wallet.payment.core.metrics.CashiGenericEventMetrics;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FeatureMetricUtil {

    @Autowired
    private CashiGenericEventMetrics cashiGenericEventMetrics;

    public void addCvvTotalCountMetric(AffiliationType affiliationType) {
        if (AffiliationType.CVV_LESS.equals(affiliationType)) {
            cashiGenericEventMetrics.incCounter("FEATURE", affiliationType.name(), "");
        } else if (AffiliationType.CVV.equals(affiliationType)) {
            cashiGenericEventMetrics.incCounter("FEATURE", affiliationType.name(), "");
        }
    }

    public void addResultCvvMetrics(AffiliationType affiliationType, String result) {
        if (AffiliationType.CVV_LESS.equals(affiliationType)) {
            cashiGenericEventMetrics.incCounter("FEATURE", affiliationType.name(), result);
        } else if (AffiliationType.CVV.equals(affiliationType)) {
            cashiGenericEventMetrics.incCounter("FEATURE", affiliationType.name(), result);
        }
    }
}