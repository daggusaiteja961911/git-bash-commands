package com.walmart.international.wallet.payment.core.adapter.customer.ews.constants.enums;

public enum AccountLockedState {
    UNLOCKED,
    LOCKED,
    POTENTIAL_FRAUD
}
