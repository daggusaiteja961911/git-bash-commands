package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.notification.utils.EncryptionUtils;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.response.PayBillResponse;
import com.walmart.international.wallet.payment.core.domain.model.Amount;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import org.apache.commons.lang.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;

@Mapper(uses = { BillerMapper.class })
public interface BillPayMapper {

    BillPayMapper INSTANCE = Mappers.getMapper(BillPayMapper.class);

    @Mapping(target = "pin", source = "pin", qualifiedByName = "encryptAndMapPin")
    @Mapping(target = "amount", ignore = true)
    void mapPayBillResponseToBillPayTransactionDO(PayBillResponse payBillResponse, @MappingTarget BillPayTransactionDO billPayTransactionDO);

    @Mapping(target = "transactionId", source = "billPayTransactionId")
    @Mapping(target = "billDetail", ignore = true)
    void updateBillPayTransactionFromBillPayTransactionDO(BillPayTransactionDO billPayTransactionDO, @MappingTarget BillPayTransaction billPayTransaction);

    /**
     Maps BillPayTransactionDO to BillPayTransaction <br/>
     <font color="red">Please note: cardPaymentTransactionList, giftCardPaymentTransactionList, and internalCoFTopupTransaction fields are not populated.</font>
     @param billPayTransactionDO
     @return BillPayTransaction
     */
    @Named("mapBillPayTransactionDOtoBillPayTransaction")
    @Mapping(target = "billerId", source = "billPayTransactionDO.billerDO.billerId")
    @Mapping(target = "billAccountNumber", source = "billPayTransactionDO.accountNumber")
    @Mapping(target = "processorBillerId", source = "billPayTransactionDO.billerDO.processorBillerId")
    @Mapping(target = "billDetail", source = "billPayTransactionDO.billDetailDO", qualifiedByName = "mapBillDetailDOToBillDetail")
    @Mapping(target = "pin", source = "billPayTransactionDO.pin")
    @Mapping(target = "processorTransactionId", source = "billPayTransactionDO.processorTransactionId")
    @Mapping(target = "amountFulfilled", expression = "java(mapToAmount(billPayTransactionDO.getAmount(), billPayTransactionDO.getCurrencyUnit()))")
    BillPayTransaction mapBillPayTransactionDOtoBillPayTransaction(BillPayTransactionDO billPayTransactionDO);

    @Named("encryptAndMapPin")
    default String encryptAndMapPin(String pin) {
        if (StringUtils.isNotEmpty(pin)) {
            return EncryptionUtils.encrypt(pin);
        } else {
            return null;
        }
    }

    @Named("mapToAmount")
    default Amount mapToAmount(BigDecimal value, CurrencyUnit currencyUnit) {
        return Amount.builder()
                .value(value)
                .currencyUnit(com.walmart.international.wallet.payment.core.constants.enums.CurrencyUnit.valueOf(currencyUnit.name()))
                .build();
    }
}
