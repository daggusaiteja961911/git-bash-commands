package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.webclient;

import com.walmart.international.services.digitalwallet.httpclient.wallet.constants.ApiName;

public enum ArcusAPIName implements ApiName {
    CREATE_BILL, REFRESH_BILL, PAY_BILL, GET_TXNS;

    @Override
    public String getApiName() {
        return this.name();
    }
}
