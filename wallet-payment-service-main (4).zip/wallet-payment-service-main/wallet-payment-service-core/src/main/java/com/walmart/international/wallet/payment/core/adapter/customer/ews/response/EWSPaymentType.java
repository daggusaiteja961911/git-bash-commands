package com.walmart.international.wallet.payment.core.adapter.customer.ews.response;

public enum EWSPaymentType {

    CREDIT("credit", null),
    DEBIT("debit", null),
    UNKNOWN("unknown", null),
    GIFTCARD("giftcard", "pangeaBalanceService"),
    CORPGIFTCARD("corpgiftcard", "pangeaBalanceService"),
    CARD("credit/debit", null),
    PREPAID("prepaid", "null");

    private String type;
    private String balanceAPIBeanName;

    EWSPaymentType(String type, String balanceAPIBeanName) {
        this.type = type;
        this.balanceAPIBeanName = balanceAPIBeanName;
    }
}
