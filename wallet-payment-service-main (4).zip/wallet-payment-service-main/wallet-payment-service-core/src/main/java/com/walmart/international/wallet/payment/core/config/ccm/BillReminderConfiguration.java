package com.walmart.international.wallet.payment.core.config.ccm;

import io.strati.ccm.utils.client.annotation.Configuration;
import io.strati.ccm.utils.client.annotation.Property;

@Configuration(configName = BillReminderConfiguration.CCM_ENTRY_NAME)
public interface BillReminderConfiguration {

    String CCM_ENTRY_NAME = "bill-reminder-config";

    @Property(propertyName = "fast.approaching.bills.alert.days.count")
    Integer getFastApproachingBillAlertDaysCount();

    @Property(propertyName = "overdue.bills.alert.days.count")
    Integer getDaysForOverdueBillAlertDaysCount();

    @Property(propertyName = "days.to.consider.bills.as.due.bills")
    Integer getDaysToConsiderBillsAsDueBills();

    @Property(propertyName = "billpay.maximum.days.for.nudge")
    Integer getMaxDaysForNudge();

    @Property(propertyName = "billpay.minimum.days.for.nudge")
    Integer getMinDaysForNudge();

    @Property(propertyName = "reminder.days.count.for.billpay.nudge")
    Integer getReminderDaysCountForBillpayNudge();

    @Property(propertyName = "billpay.reminder.first.notification.days.count")
    Integer getDaysForFirstBillPayReminder();

    @Property(propertyName = "billpay.reminder.second.notification.days.count")
    Integer getDaysForSecondBillPayReminder();

    @Property(propertyName = "enable.bill.pay.email.reminder")
    Boolean isBillPayEmailReminderEnabled();

    @Property(propertyName = "enable.bill.pay.email.nudge")
    Boolean isBillPayEmailNudgeEnabled();

    @Property(propertyName = "enable.bill.pay.email.first.reminder")
    Boolean isBillPayEmailFirstReminderEnabled();

    @Property(propertyName = "enable.bill.pay.email.second.reminder")
    Boolean isBillPayEmailSecondReminderEnabled();

    @Property(propertyName = "enable.bill.pay.email.reminder.on.due.date")
    Boolean isBillPayEmailReminderOnDueDateEnabled();

    @Property(propertyName = "billpay.email.reminder.onelink.base.url")
    String getEmailReminderOnelinkBaseUrl();

    @Property(propertyName = "billpay.nudge.days.of.month")
    String getDaysOfMonthForBillPaymentNudge();
}
