package com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ArcusCreateBillResponse {

    private String type;

    private String id;

    @JsonProperty("biller_id")
    private String billerId;

    @JsonProperty("account_number")
    private String accountNumber;

    @JsonProperty("name_on_account")
    private String nameOnAccount;

    @JsonProperty("due_date")
    private String dueDate;

    @JsonProperty("balance")
    private BigDecimal balance;

    @JsonProperty("balance_currency")
    private String balanceCurrency;

    @JsonProperty("balance_updated_at")
    private String balanceUpdatedAt;

    @JsonProperty("error_code")
    private String errorCode;

    @JsonProperty("error_message")
    private String errorMessage;

    @JsonProperty("status")
    private String status;

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

}
