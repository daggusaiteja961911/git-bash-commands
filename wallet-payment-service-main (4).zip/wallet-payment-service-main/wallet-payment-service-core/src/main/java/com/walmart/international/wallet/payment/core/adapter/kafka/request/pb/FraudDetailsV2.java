package com.walmart.international.wallet.payment.core.adapter.kafka.request.pb;

import lombok.Data;

@Data
public class FraudDetailsV2 {
    private String fraudEngine;
    private String fraudResponse;
    private Integer fraudScore;
    private String fraudReferenceId;
}
