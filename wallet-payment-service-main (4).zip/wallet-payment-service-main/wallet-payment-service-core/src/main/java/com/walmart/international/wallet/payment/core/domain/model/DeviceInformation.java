package com.walmart.international.wallet.payment.core.domain.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DeviceInformation {
    private String fingerPrint;
    private String platform;
    private String ip;
}
