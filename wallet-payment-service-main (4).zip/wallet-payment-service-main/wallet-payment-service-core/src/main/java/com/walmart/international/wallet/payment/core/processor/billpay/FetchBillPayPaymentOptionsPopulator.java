package com.walmart.international.wallet.payment.core.processor.billpay;

import com.walmart.international.digiwallet.service.basic.ng.exception.BusinessValidationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.digiwallet.service.web.rest.i8n.local.SimpleMessageResolver;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.config.ccm.BillPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.domain.model.DeviceAppVersion;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import com.walmart.international.wallet.payment.data.dao.repository.BillerRepository;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import io.strati.libs.commons.lang.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;

@Component
@Slf4j
public class FetchBillPayPaymentOptionsPopulator implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @Autowired
    private BillerRepository billerRepository;

    @ManagedConfiguration
    private BillPaymentConfiguration billPaymentConfiguration;

    @Autowired
    private SimpleMessageResolver simpleMessageResolver;

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws BusinessValidationException {

        BillPayTxnRequestDomainContext billPayTxnRequestDomainContext = (BillPayTxnRequestDomainContext) wpsRequestDomainContext;
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = (BillPayTxnResponseDomainContext) wpsResponseDomainContext;

        billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setIsMSIAllowedForSplitPayment(billPaymentConfiguration.getAllowMSIForSplitPayment());
        billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setAllowB2BForSplitPayment(billPaymentConfiguration.getAllowB2BForSplitPayment());
        billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setAllowMultipleB2BForSplitPayment(billPaymentConfiguration.getAllowMultipleB2BForSplitPayment());

        Boolean allowCoFForBillPayment = billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getAllowCoFForBillPayment();
        if (Objects.isNull(allowCoFForBillPayment)) {
            boolean isCoFBillPaymentPossibleInDevice = canDeviceDoCoFBillPayment(billPaymentConfiguration.getAllowCoF(), billPaymentConfiguration.getAndroidMinVersionForCoFBillPayment(), billPaymentConfiguration.getIOSMinVersionForCoFBillPayment(), billPayTxnRequestDomainContext);
            if (isCoFBillPaymentPossibleInDevice) {
                billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setAllowCoFForBillPayment(true);
            } else {
                billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().setAllowCoFForBillPayment(false);
                billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getCardPaymentInstruments().setCardPaymentInstrumentList(null);
            }
        }

        mapToTransaction(billPayTxnRequestDomainContext, billPayTxnResponseDomainContext);
        return true;
    }

    public void mapToTransaction(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext, BillPayTxnResponseDomainContext billPayTxnResponseDomainContext) throws BusinessValidationException {

        billPayTxnResponseDomainContext.getTransaction().setAmountRequested(billPayTxnRequestDomainContext.getTransaction().getAmountRequested());
        billPayTxnResponseDomainContext.getTransaction().setBillAccountNumber(billPayTxnRequestDomainContext.getTransaction().getBillAccountNumber());

        BigDecimal orderAmount = billPayTxnRequestDomainContext.getTransaction().getAmountRequested().getValue();
        Optional<BillerDO> billerDOOptional;
        if (Objects.nonNull(billPayTxnRequestDomainContext.getTransaction().getBillerId())) {
            logger.info("fetching biller with billerId[{}]", billPayTxnRequestDomainContext.getTransaction().getBillerId());
            billerDOOptional = billerRepository.getByBillerId(billPayTxnRequestDomainContext.getTransaction().getBillerId());
        } else {
            logger.info("fetching biller with processorbBllerId[{}]", billPayTxnRequestDomainContext.getTransaction().getProcessorBillerId());
            billerDOOptional = billerRepository.getByProcessorBillerId(billPayTxnRequestDomainContext.getTransaction().getProcessorBillerId());
        }
        if (billerDOOptional.isEmpty()) {
            String msg = String.format("Biller record not found for billerId [%s], processorBillerId [%s]", billPayTxnRequestDomainContext.getTransaction().getBillerId(), billPayTxnRequestDomainContext.getTransaction().getProcessorBillerId());
            throw new BusinessValidationException(ErrorConstants.FetchBillPayPaymentInstruments.INVALID_BILLER_ID, msg);
        }
        BillerDO biller = billerDOOptional.get();
        billPayTxnResponseDomainContext.getTransaction().setProcessorBillerId(biller.getProcessorBillerId());
        billPayTxnResponseDomainContext.getTransaction().setBillerId(biller.getBillerId());
        BigDecimal commission = StringUtils.isEmpty(biller.getCommission()) ? BigDecimal.ZERO : new BigDecimal(biller.getCommission());
        billPayTxnResponseDomainContext.getTransaction().getAmountRequested().setValue(orderAmount.add(commission));

        List<BillPayTransaction.AmountBreakup> amountBreakups = new ArrayList<>();
        amountBreakups.add(breakup(WPSConstants.FetchBillPayPaymentOptions.BILL_AMOUNT,
                createDisplayLabel(orderAmount, WPSConstants.FetchBillPayPaymentOptions.BILL_AMOUNT)));
        amountBreakups.add(breakup(WPSConstants.FetchBillPayPaymentOptions.COMMISSION,
                createDisplayLabel(commission, WPSConstants.FetchBillPayPaymentOptions.COMMISSION)));
        billPayTxnResponseDomainContext.getTransaction().setAmountBreakup(amountBreakups);
    }

    public BillPayTransaction.AmountBreakup breakup(String name, String amount) {
        return BillPayTransaction.AmountBreakup.builder()
                    .name(name)
                    .label(simpleMessageResolver.getMsg(name, Locale.forLanguageTag(WPSConstants.FetchBillPayPaymentOptions.ES)))
                    .value(amount)
                    .build();
    }

    public String createDisplayLabel(BigDecimal amount, String type) {
        if (WPSConstants.FetchBillPayPaymentOptions.ORDER_TOTAL_AMOUNT.equalsIgnoreCase(type)) {
            return WPSConstants.FetchBillPayPaymentOptions.DOLLAR + amount;
        }
        else if (WPSConstants.FetchBillPayPaymentOptions.BILL_AMOUNT.equalsIgnoreCase(type)) {
            return WPSConstants.FetchBillPayPaymentOptions.DOLLAR + amount;
        }
        else if (WPSConstants.FetchBillPayPaymentOptions.ORDER_DISCOUNT.equalsIgnoreCase(type)) {
            return WPSConstants.FetchBillPayPaymentOptions.MINUS + WPSConstants.FetchBillPayPaymentOptions.DOLLAR + amount;
        }
        else if (WPSConstants.FetchBillPayPaymentOptions.COMMISSION.equalsIgnoreCase(type)) {
            return (amount.equals(BigDecimal.ZERO) ? simpleMessageResolver.getMsg(WPSConstants.FetchBillPayPaymentOptions.FREE, Locale.forLanguageTag(WPSConstants.FetchBillPayPaymentOptions.ES)) : WPSConstants.FetchBillPayPaymentOptions.DOLLAR + amount);
        }
        else if (WPSConstants.FetchBillPayPaymentOptions.SHIPMENT_AMOUNT.equalsIgnoreCase(type)) {
            return WPSConstants.FetchBillPayPaymentOptions.DOLLAR + amount;
        }
        return String.valueOf(amount);
    }

    public static Boolean canDeviceDoCoFBillPayment(Boolean isCoFAllowedCCM, String androidMinVersionString, String iOSMinVersionString, BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        if (isCoFAllowedCCM != null && isCoFAllowedCCM) {
            DeviceAppVersion requiredVersion;
            DeviceAppVersion deviceVersion = new DeviceAppVersion(billPayTxnRequestDomainContext.getHeaders().get("device_app_version").get(0));

            if (billPayTxnRequestDomainContext.getHeaders().get("device_platform").get(0).equalsIgnoreCase("android")) {
                requiredVersion = new DeviceAppVersion(androidMinVersionString);
            }
            else if (billPayTxnRequestDomainContext.getHeaders().get("device_platform").get(0).equalsIgnoreCase("ios")) {
                requiredVersion = new DeviceAppVersion(iOSMinVersionString);
            }
            else {
                return false;
            }
            return deviceVersion.compareTo(requiredVersion) >= 0;
        }
        return false;
    }

}
