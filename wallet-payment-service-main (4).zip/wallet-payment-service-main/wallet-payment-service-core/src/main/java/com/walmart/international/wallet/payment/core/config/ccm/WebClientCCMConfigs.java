package com.walmart.international.wallet.payment.core.config.ccm;


import io.strati.ccm.utils.client.annotation.Property;

public interface WebClientCCMConfigs {
    @Property(propertyName = "webclient.is.saveLogsToDB.enabled", defaultValue = "false")
    Boolean isSaveLogsToDBEnabled();

    @Property(propertyName = "webclient.connection.timeout.millis", defaultValue = "5000")
    Integer getWebClientConnectionTimeoutInMillis();

    @Property(propertyName = "webclient.response.timeout.millis", defaultValue = "10000")
    Integer getWebClientResponseTimeoutInMillis();
}
