package com.walmart.international.wallet.payment.core.domain.model.request;

import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class CoFTopupTxnRequestDomainContext extends TransactionRequestDomainContext {
    public CoFTopUpTransaction getTransaction() {
        return (CoFTopUpTransaction) super.transaction;
    }

}


