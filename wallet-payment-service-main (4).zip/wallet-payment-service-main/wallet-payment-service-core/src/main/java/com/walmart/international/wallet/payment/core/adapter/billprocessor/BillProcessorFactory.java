package com.walmart.international.wallet.payment.core.adapter.billprocessor;

import com.walmart.international.digiwallet.service.basic.constants.EnvConstants;
import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;
import com.walmart.international.wallet.payment.core.adapter.billprocessor.arcus.ArcusBillProcessor;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BillProcessorFactory {

    @Autowired
    private ArcusBillProcessor arcusBillProcessor;

    public BillProcessor getBillProcessor() throws ProcessingException {
        if (System.getProperty(EnvConstants.SYS_PROP_TENANTID).equals(EnvConstants.MEXICO_TENANTID)) {
            return arcusBillProcessor;
        } else  {
            String msg = "Invalid tenantId for fetching bill processor";
            throw new ProcessingException(ErrorConstants.Common.BILL_PROCESSOR_INVALID_TENANT_ID, msg);
        }
    }
}
