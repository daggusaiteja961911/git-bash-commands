package com.walmart.international.wallet.payment.core.adapter.billprocessor.exception;

public class BillProcessorProcessingException extends BillProcessorException {
    public BillProcessorProcessingException(String errorCode, String message) {
        super(errorCode, message);
    }

    public BillProcessorProcessingException(String errorCode, String message, Object[] args) {
        super(errorCode, message, args);
    }

    public BillProcessorProcessingException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }

    public BillProcessorProcessingException(String errorCode, String message, Object[] args, Throwable cause) {
        super(errorCode, message, args, cause);
    }

    @Override
    public String toString() {
        return super.toString(this);
    }
}
