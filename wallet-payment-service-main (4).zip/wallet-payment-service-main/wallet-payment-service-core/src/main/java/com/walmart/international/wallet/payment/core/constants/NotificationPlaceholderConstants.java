package com.walmart.international.wallet.payment.core.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class NotificationPlaceholderConstants {

    public static final String AMOUNT = "{amount}";

    public static final String BILLER = "{biller}";

    public static final String ALIAS = "{alias}";

    public static final String EXPIRY_DATE = "{expiryDate}";

    public static final String PRODUCT = "{product}";

    public static final String LAST_PAID_AMOUNT = "{lastPaidAmt}";

    public static final String LAST_PAID_DATE = "{lastPaidDate}";

    public static final String VALIDITY = "{validity}";

    public static final String ITEM_DESCRIPTION = "{item_description}";


}
