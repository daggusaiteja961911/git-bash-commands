package com.walmart.international.wallet.payment.core.config;

import com.walmart.international.ewallet.services.events.executor.ScalingThreadPoolExecutor;
import com.walmart.international.wallet.payment.core.config.ccm.SingleScreenPaymentConfiguration;
import com.walmart.international.wallet.payment.core.executor.LastUsedCardThreadPoolExecutor;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class ThreadPoolExecutorConfig {

    @ManagedConfiguration
    private SingleScreenPaymentConfiguration singleScreenPaymentConfiguration;

    @Bean(name = "lastUsedCardThreadPoolExecutor")
    public LastUsedCardThreadPoolExecutor getThreadPoolExecutorForLastUsedCard() {
        return new LastUsedCardThreadPoolExecutor(singleScreenPaymentConfiguration.getLastUsedCardCorePoolSize(), singleScreenPaymentConfiguration.getLastUsedCardMaxPoolSize(),
                singleScreenPaymentConfiguration.getLastUsedCardKeepAliveTime(), TimeUnit.SECONDS, new ScalingThreadPoolExecutor.ScalingThreadPoolExecutorQueue());
    }
}