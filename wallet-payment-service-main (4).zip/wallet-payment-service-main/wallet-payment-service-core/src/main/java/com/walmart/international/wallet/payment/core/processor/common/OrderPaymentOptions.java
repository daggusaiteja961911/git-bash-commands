package com.walmart.international.wallet.payment.core.processor.common;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.international.digiwallet.service.basic.ng.exception.ApplicationException;
import com.walmart.international.digiwallet.service.flow.processor.IProcessor;
import com.walmart.international.wallet.payment.core.config.ccm.SingleScreenPaymentConfiguration;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayPaymentOptions;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopupPaymentOptions;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.PaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.PaymentInstruments;
import com.walmart.international.wallet.payment.core.domain.model.request.WPSRequestDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.BillPayTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.CoFTopupTxnResponseDomainContext;
import com.walmart.international.wallet.payment.core.domain.model.response.WPSResponseDomainContext;
import com.walmart.international.wallet.payment.core.dto.PaymentOrderDTO;
import io.strati.ccm.utils.client.annotation.ManagedConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@Slf4j
public class OrderPaymentOptions implements IProcessor<WPSRequestDomainContext, WPSResponseDomainContext> {

    @ManagedConfiguration
    SingleScreenPaymentConfiguration singleScreenPaymentConfiguration;

    @Autowired
    ObjectMapper objectMapper;

    List<PaymentOrderDTO> paymentOrderDTOList;

    @PostConstruct
    private void init() {
        try {
            paymentOrderDTOList = objectMapper.readValue(singleScreenPaymentConfiguration.getPaymentOptionsOrder(), new TypeReference<List<PaymentOrderDTO>>() {
            });
        } catch (Exception ex) {
            log.error("Exception while ordering payment options {}", ex);
        }
    }

    @Override
    public boolean process(WPSRequestDomainContext wpsRequestDomainContext, WPSResponseDomainContext wpsResponseDomainContext) throws ApplicationException {
        if (wpsResponseDomainContext instanceof CoFTopupTxnResponseDomainContext) {
            processCofPaymentOptions((CoFTopupTxnResponseDomainContext) wpsResponseDomainContext);
        } else if (wpsResponseDomainContext instanceof BillPayTxnResponseDomainContext) {
            processBillPaymentOptions((BillPayTxnResponseDomainContext) wpsResponseDomainContext);
        }
        return true;
    }

    private void processBillPaymentOptions(BillPayTxnResponseDomainContext wpsResponseDomainContext) {
        BillPayTxnResponseDomainContext billPayTxnResponseDomainContext = wpsResponseDomainContext;
        List<CardPaymentInstrument> cardPaymentInstrumentList = billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getCardPaymentInstruments().getCardPaymentInstrumentList();
        List<GiftCardPaymentInstrument> giftCardPaymentInstruments = billPayTxnResponseDomainContext.getTransaction().getBillPayPaymentOptions().getGiftCardPaymentInstruments().getGiftCardPaymentInstrumentList();
        List<PaymentInstrument> paymentInstruments = arrangePaymentOptions(cardPaymentInstrumentList, Optional.ofNullable(giftCardPaymentInstruments.get(0)));
        BillPayPaymentOptions billPayPaymentOptions = wpsResponseDomainContext.getTransaction().getBillPayPaymentOptions();
        billPayPaymentOptions.setPaymentInstruments(PaymentInstruments.builder()
                .paymentInstrumentList(paymentInstruments)
                .build());
        wpsResponseDomainContext.getTransaction().setBillPayPaymentOptions(billPayPaymentOptions);
    }

    private void processCofPaymentOptions(CoFTopupTxnResponseDomainContext wpsResponseDomainContext) {
        CoFTopupTxnResponseDomainContext cofTopupTxnResponseDomainContext = wpsResponseDomainContext;
        List<CardPaymentInstrument> cardPaymentInstrumentList = cofTopupTxnResponseDomainContext.getTransaction().getCofTopupPaymentOptions().getCardPaymentInstruments().getCardPaymentInstrumentList();
        List<PaymentInstrument> paymentInstruments = arrangePaymentOptions(cardPaymentInstrumentList, Optional.empty());
        CoFTopupPaymentOptions cofTopupPaymentOptions = cofTopupTxnResponseDomainContext.getTransaction().getCofTopupPaymentOptions();
        cofTopupPaymentOptions.setPaymentInstruments(PaymentInstruments.builder()
                .paymentInstrumentList(paymentInstruments)
                .build());
        cofTopupTxnResponseDomainContext.getTransaction().setCofTopupPaymentOptions(cofTopupPaymentOptions);
    }

    public List<PaymentInstrument> arrangePaymentOptions(List<CardPaymentInstrument> cardPaymentInstruments, Optional<GiftCardPaymentInstrument> optionalGiftCardPaymentInstrument) {
        List<PaymentInstrument> paymentOptions = new ArrayList<>();
        for (PaymentOrderDTO paymentOrderDTO : paymentOrderDTOList) {
            String tag = paymentOrderDTO.getTag();
            if (null != tag && !tag.isEmpty()) {
                if (PaymentInstrumentType.CARD.name().equals(tag) && CollectionUtils.isNotEmpty(cardPaymentInstruments)) {
                    List<CardPaymentInstrument> paymentPreferenceDTOS = cardPaymentInstruments.stream()
                            .filter(paymentPreferenceDTO -> paymentOrderDTO.getSubTag().isEmpty() ||
                                    paymentOrderDTO.getSubTag().equals(String.valueOf(paymentPreferenceDTO.getBinDetails().getBin())))
                            .filter(paymentPreferenceDTO -> paymentOrderDTO.getExcludedTags() == null || !paymentOrderDTO.getExcludedTags().contains(String.valueOf(paymentPreferenceDTO.getBinDetails().getBin())))
                            .collect(Collectors.toList());
                    paymentOptions.addAll(paymentPreferenceDTOS);
                    cardPaymentInstruments.removeAll(paymentPreferenceDTOS);
                } else if (PaymentInstrumentType.GIFTCARD.name().equals(tag) && optionalGiftCardPaymentInstrument.isPresent()) {
                    paymentOptions.add(optionalGiftCardPaymentInstrument.get());
                } else {
                    log.error("Unknown paymentOrderDto tag: [{}] and paymentOrderDto: [{}]", tag, paymentOrderDTO);
                }
            } else {
                log.error("Tag is null or empty for paymentOrderDto: [{}] ", paymentOrderDTO);
            }
        }
        return paymentOptions;
    }
}