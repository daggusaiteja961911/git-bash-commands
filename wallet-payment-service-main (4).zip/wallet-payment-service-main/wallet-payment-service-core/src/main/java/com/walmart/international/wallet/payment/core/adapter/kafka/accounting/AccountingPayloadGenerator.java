package com.walmart.international.wallet.payment.core.adapter.kafka.accounting;

import com.walmart.international.digiwallet.customer.api.dto.response.WalletResponse;
import com.walmart.international.digiwallet.customer.api.dto.response.enums.PaymentInstrumentType;
import com.walmart.international.notification.dto.accounting.AccountingEventType;
import com.walmart.international.notification.dto.accounting.AccountingPayload;
import com.walmart.international.notification.dto.accounting.OrderCustomAttributes;
import com.walmart.international.notification.dto.accounting.OrderLine;
import com.walmart.international.notification.dto.accounting.PaymentMethod;
import com.walmart.international.notification.dto.accounting.ReceiptDetails;
import com.walmart.international.services.payment.core.dao.repository.CoreTransactionRepository;
import com.walmart.international.services.payment.core.dto.CardTransactionDTO;
import com.walmart.international.wallet.payment.core.adapter.customer.ICustomerServiceClient;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.InvalidKafkaPayloadException;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.ReconHandlingException;
import com.walmart.international.wallet.payment.core.adapter.kafka.exception.TransactionNotFoundException;
import com.walmart.international.wallet.payment.core.constants.AccountingConstants;
import com.walmart.international.wallet.payment.core.constants.ErrorConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
public abstract class AccountingPayloadGenerator {

    @Autowired
    private ICustomerServiceClient customerServiceClient;

    @Autowired
    private CoreTransactionRepository coreTransactionRepository;

    protected static final String PM_ID = "NOPMID";

    public abstract AccountingPayload generatePayload(AccountingEventType eventType, String orderId,
                                                      CardTransactionDTO cardTransactionDetails) throws TransactionNotFoundException;

    protected abstract void setSetSellerInOrderLine(OrderLine orderLine);

    protected AccountingPayload initialiseAndGetPayload(AccountingEventType eventType, String orderId,
                                                        CardTransactionDTO cardTransactionDetails, BigDecimal originalAmount) {
        String statusCode = "";
        String statusDesc = "";
        String status;
        if (AccountingEventType.CHARGE_SUCCESS.equals(eventType)) {
            statusCode = AccountingConstants.Accounting.CHARGE_SUCCESS_STATUS_CODE;
            statusDesc = AccountingConstants.Accounting.CHARGE_SUCCESS_STATUS_DESC;
            status = AccountingConstants.Accounting.CHARGE_SUCCESS_STATUS;
        } else if (AccountingEventType.REFUND_SUCCESS.equals(eventType)) {
            statusCode = AccountingConstants.Accounting.REFUND_SUCCESS_STATUS_CODE;
            statusDesc = AccountingConstants.Accounting.REFUND_SUCCESS_STATUS_DESC;
            status = AccountingConstants.Accounting.REFUND_SUCCESS_STATUS;
        } else {
            throw new InvalidKafkaPayloadException(ErrorConstants.KafkaChargeRecon.INVALID_KAFKA_PAYLOAD_EVENT_TYPE);
        }

        AccountingPayload payload = new AccountingPayload();
        payload.setVerticalId(AccountingConstants.Accounting.VERTICAL_ID);
        payload.setOrderSource(AccountingConstants.Accounting.ORDER_SOURCE);
        payload.setOrderNo(orderId);
        OrderCustomAttributes customAttributes = OrderCustomAttributes.builder()
                .overallOrderStatusDesc(statusDesc)
                .sellerOrganizationCode(AccountingConstants.Accounting.VERTICAL_ID)
                .maxOrderStatusDesc(statusDesc)
                .originalTotalAmount(originalAmount)
                .maxOrderStatus(statusCode)
                .build();
        AccountingPayload.Amount amount = AccountingPayload.Amount.builder()
                .currencyAmount(originalAmount)
                .currencyUnit(AccountingConstants.CURRENCY_UNIT)
                .build();
        payload.setOrderCustomAttributes(customAttributes);
        payload.setOrderLines(getOrderLines(cardTransactionDetails, statusCode, statusDesc, status));
        payload.setOrderTotals(new AccountingPayload.OrderTotals(amount));
        if (AccountingEventType.REFUND_SUCCESS.equals(eventType)) {
            payload.setReturnDetails(getReturnDetails(orderId, amount, List.of(cardTransactionDetails)));
        }
        return payload;
    }

    public List<OrderLine> getOrderLines(CardTransactionDTO cardTransactionDetails, String statusCode, String statusDesc, String status) {
        List<OrderLine> orderLines = new ArrayList<>();
        OrderLine orderLine = new OrderLine();
        setSetSellerInOrderLine(orderLine);
        AccountingPayload.Amount amount = AccountingPayload.Amount.builder()
                .currencyAmount(cardTransactionDetails.getAmount())
                .currencyUnit(AccountingConstants.CURRENCY_UNIT)
                .build();
        orderLine.setUnitPrice(amount);

        OrderLine.Quantity quantity = new OrderLine.Quantity(1, "EA");
        OrderLine.OrderLineQuantityInfo quantityInfo = OrderLine.OrderLineQuantityInfo.builder()
                .statusChangeDate(cardTransactionDetails.getCreateDate())
                .statusDescription(statusDesc)
                .status(status)
                .statusCode(statusCode)
                .statusQuantity(quantity)
                .build();
        orderLine.setOrderLineQuantityInfo(Arrays.asList(quantityInfo));

        orderLine.setPrimeLineNo(1000001);
        orderLine.setOrderedQty(quantity);
        orderLine.setPaymentReferenceId(cardTransactionDetails.getPaymentGatewayRefId());
        orderLine.setFulfillmentType("S2H");

        OrderLine.OrderLineCustomAttributes customAttributes = OrderLine.OrderLineCustomAttributes.builder()
                .maxLineStatusDesc(statusDesc)
                .maxLineStatus(statusCode)
                .build();
        orderLine.setOrderLineCustomAttributes(customAttributes);

        OrderLine.OrderProduct orderProduct = OrderLine.OrderProduct.builder()
                .offerId(new OrderLine.OrderProduct.OfferId(AccountingConstants.Accounting.PRODUCT_OFFER_ID, AccountingConstants.Accounting.PRODUCT_OFFER_UPC))
                .productName(AccountingConstants.Accounting.CASHI_ITEM)
                .description(AccountingConstants.Accounting.CASHI_ITEM)
                .build();
        orderLine.setOrderProduct(orderProduct);
        orderLines.add(orderLine);
        log.info("OrderLines- [{}]", orderLines);
        return orderLines;
    }


    public List<PaymentMethod> getPaymentMethods(CardTransactionDTO cardTransactionDetails, String pmId) {
        List<PaymentMethod> paymentMethods = new ArrayList<>();
        AccountingPayload.Amount amount = AccountingPayload.Amount.builder()
                .currencyAmount(cardTransactionDetails.getAmount())
                .currencyUnit(AccountingConstants.CURRENCY_UNIT)
                .build();
        PaymentMethod paymentMethod = PaymentMethod.builder()
                .amountCollected(amount)
                .pmId(pmId)
                .transactionDate(cardTransactionDetails.getPaymentProviderCreationDate())
                .paymentType(PaymentInstrumentType.CARD.toString())
                .transactions(List.of(new PaymentMethod.Transaction(cardTransactionDetails.getPaymentGatewayRefId(), null)))
                .build();
        paymentMethods.add(paymentMethod);
        log.info("PaymentMethods- for card transaction Id - {} are : [{}]", cardTransactionDetails.getSubTransactionId(), paymentMethods);
        return paymentMethods;

    }

    public AccountingPayload.ReturnDetails getReturnDetails(String orderId, AccountingPayload.Amount amount, List<CardTransactionDTO> cardTransactionDetailsDTOS) {
        AccountingPayload.ReturnDetails returnDetails = new AccountingPayload.ReturnDetails();
        List<OrderLine> orderLines = new ArrayList<>();
        for (CardTransactionDTO cardTransactionDetails : cardTransactionDetailsDTOS) {
            orderLines.add(getOrderLineForReturn(cardTransactionDetails));
        }
        AccountingPayload.ReturnOrdersInfo returnOrdersInfo = AccountingPayload.ReturnOrdersInfo.builder()
                .orderTotals(new AccountingPayload.OrderTotals(amount))
                .orderNo("R" + orderId)
                .orderLines(orderLines)
                .returnOrderCustomAttributes(OrderCustomAttributes.builder()
                        .maxOrderStatusDesc(AccountingConstants.Accounting.RETURN_STATUS_DESC)
                        .originalTotalAmount(amount.getCurrencyAmount())
                        .maxOrderStatus(AccountingConstants.Accounting.RETURN_STATUS_CODE)
                        .build())
                .referenceOrderNo(orderId)
                .orderDate(cardTransactionDetailsDTOS.get(0).getCreateDate())
                .status(AccountingConstants.Accounting.RETURN_STATUS_DESC)
                .build();

        returnDetails.setReturnOrdersInfo(Arrays.asList(returnOrdersInfo));

        return returnDetails;
    }

    public OrderLine getOrderLineForReturn(CardTransactionDTO cardTransactionDTO) {
        OrderLine orderLine = new OrderLine();

        OrderLine.Quantity quantity = new OrderLine.Quantity(1, "EA");
        OrderLine.OrderLineQuantityInfo quantityInfo = OrderLine.OrderLineQuantityInfo.builder()
                //what should be
                .statusChangeDate(cardTransactionDTO.getPaymentGatewayTxnDate())
                .statusDescription(AccountingConstants.Accounting.REFUND_SUCCESS_STATUS_DESC)
                .status(AccountingConstants.Accounting.RETURN_STATUS)
                .statusCode(AccountingConstants.Accounting.RETURN_STATUS_CODE)
                .statusQuantity(quantity)
                .build();
        orderLine.setOrderLineQuantityInfo(List.of(quantityInfo));

        setSetSellerInOrderLine(orderLine);

        AccountingPayload.Amount amount = AccountingPayload.Amount.builder()
                .currencyAmount(cardTransactionDTO.getAmount())
                .currencyUnit(AccountingConstants.CURRENCY_UNIT)
                .build();
        orderLine.setUnitPrice(amount);

        orderLine.setPrimeLineNo(AccountingConstants.Accounting.PRIME_LINE_NO);
        orderLine.setReferenceLineId(AccountingConstants.Accounting.PRIME_LINE_NO.toString());
        orderLine.setReturnReason(AccountingConstants.Accounting.RETURN_REASON);

        ReceiptDetails.ReceiptInfo receiptInfo = new ReceiptDetails.ReceiptInfo();
        receiptInfo.setReceiptInfoDetail(ReceiptDetails.ReceiptInfoDetail.builder()
                .statusDate(cardTransactionDTO.getPaymentGatewayTxnDate())
                .receiptNo("")
                .receiptDate(cardTransactionDTO.getPaymentGatewayTxnDate()) //date
                .build());
        receiptInfo.setReceivedQuantity(new BigDecimal(1));
        receiptInfo.setDispositionCode("NA");
        orderLine.setReceiptDetails(new ReceiptDetails(List.of(receiptInfo)));

        OrderLine.OrderProduct orderProduct = OrderLine.OrderProduct.builder()
                .offerId(new OrderLine.OrderProduct.OfferId(AccountingConstants.Accounting.PRODUCT_OFFER_ID, AccountingConstants.Accounting.PRODUCT_OFFER_UPC))
                .productName(AccountingConstants.Accounting.CASHI_ITEM)
                .description(AccountingConstants.Accounting.CASHI_ITEM)
                .build();
        orderLine.setOrderProduct(orderProduct);

        orderLine.setReasonCode(AccountingConstants.Accounting.RETURN_REASON_CODE);
        return orderLine;
    }


}
