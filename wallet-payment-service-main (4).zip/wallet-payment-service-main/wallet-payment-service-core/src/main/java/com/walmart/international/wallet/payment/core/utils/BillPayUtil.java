package com.walmart.international.wallet.payment.core.utils;

import com.walmart.commons.collections.CollectionUtils;
import com.walmart.commons.utils.StringUtils;
import com.walmart.international.digiwallet.service.basic.util.DateUtils;
import com.walmart.international.notification.constants.MessagingEvent;
import com.walmart.international.notification.constants.TypeMessage;
import com.walmart.international.notification.constants.WalletEventType;
import com.walmart.international.notification.dto.NotificationDetails;
import com.walmart.international.notification.dto.NotificationPayload;
import com.walmart.international.notification.dto.PushNotificationEventDTO;
import com.walmart.international.notification.smartcomm.dto.SmartCommV2PaymentConfirmDTO;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataActionStatus;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataCategory;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataDetails;
import com.walmart.international.services.notificationservice.naas.NOCMetaDataStatus;
import com.walmart.international.wallet.payment.core.constants.WPSConstants;
import com.walmart.international.wallet.payment.core.constants.enums.BillerBehaviourCategory;
import com.walmart.international.wallet.payment.core.constants.enums.CacheAction;
import com.walmart.international.wallet.payment.core.constants.enums.PaymentInstrumentSubType;
import com.walmart.international.wallet.payment.core.domain.model.BillPayTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Biller;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CustomerBillAccount;
import com.walmart.international.wallet.payment.core.domain.model.DeviceInformation;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.GiftCardTransaction;
import com.walmart.international.wallet.payment.core.domain.model.request.BillPayTxnRequestDomainContext;
import com.walmart.international.wallet.payment.data.constant.enums.BillPayTxnStateReason;
import com.walmart.international.wallet.payment.data.constant.enums.TransactionStateEnum;
import com.walmart.international.wallet.payment.data.dao.entity.BillDetailDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillPayTransactionDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillPlanDO;
import com.walmart.international.wallet.payment.data.dao.entity.BillerDO;
import lombok.extern.slf4j.Slf4j;
import net.spy.memcached.internal.OperationFuture;
import net.spy.memcached.ops.StatusCode;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Slf4j
@Component
public class BillPayUtil {

    //TODO these all should move to domain objects.
    private static final int[] barcodeToAccountArcusProcessorBillerIds = {
            WPSConstants.Biller.CEA_ARCUS_PROCESSOR_BILLER_ID,
            WPSConstants.Biller.CFE_ARCUS_PROCESSOR_BILLER_ID,
            WPSConstants.Biller.MEGACABLE_ARCUS_PROCESSOR_BILLER_ID,
            WPSConstants.Biller.TELMEX_ARCUS_PROCESSOR_BILLER_ID,
            WPSConstants.Biller.TELNOR_ARCUS_PROCESSOR_BILLER_ID
    };

    public static boolean isBarcodeToAccountArcusProcessorBiller(String reqProcessorBillerId) {
        int reqProcessorBillerIdInt = Integer.parseInt(reqProcessorBillerId);
        for (int processorBillerId : barcodeToAccountArcusProcessorBillerIds) {
            if (reqProcessorBillerIdInt == processorBillerId) {
                return true;
            }
        }
        return false;
    }

    public static String getAccountNumberFromBarcodeNumber(String accountNumber, String processorBillerId) {
        if (processorBillerId.equals(String.valueOf(WPSConstants.Biller.CEA_ARCUS_PROCESSOR_BILLER_ID)) && accountNumber.length() == 23) {
            accountNumber = accountNumber.substring(0, 2).concat(accountNumber.substring(3, 10));
        } else if (processorBillerId.equals(String.valueOf(WPSConstants.Biller.CFE_ARCUS_PROCESSOR_BILLER_ID)) && accountNumber.length() == 30) {
            accountNumber = accountNumber.substring(2, 14);
        } else if (processorBillerId.equals(String.valueOf(WPSConstants.Biller.MEGACABLE_ARCUS_PROCESSOR_BILLER_ID)) && accountNumber.length() == 26) {
            accountNumber = accountNumber.substring(2, 12);
        } else if (processorBillerId.equals(String.valueOf(WPSConstants.Biller.TELMEX_ARCUS_PROCESSOR_BILLER_ID)) && accountNumber.length() == 20) {
            accountNumber = accountNumber.substring(0, 10);
        } else if (processorBillerId.equals(String.valueOf(WPSConstants.Biller.TELNOR_ARCUS_PROCESSOR_BILLER_ID)) && accountNumber.length() == 20) {
            accountNumber = accountNumber.substring(0, 10);
        }
        return accountNumber;
    }

    public static String getBillerBehaviourCode(BillerDO biller) {
        List<BillerDO> subBillers = CollectionUtils.isNotEmpty(biller.getSubBillers()) ? biller.getSubBillers() : Collections.singletonList(biller);
        if (isParentBiller(subBillers)) {
            if (isBillTypeContainsBarcode(biller)) {
                return BillerBehaviourCategory.BBC_8.name();
            } else if (isBillTypeGiftCard(biller)){
                return BillerBehaviourCategory.BBC_6.name();
            } else {
                return BillerBehaviourCategory.BBC_9.name();
            }
        } else if (isBillTypeGiftCard(biller)) {
            if (hasMultipleBillPlans(subBillers)) {
                return BillerBehaviourCategory.BBC_5.name();
            } else if (biller.getCustomAmountEnabled()) {
                return BillerBehaviourCategory.BBC_4.name();
            } else {
                return BillerBehaviourCategory.BBC_3.name();
            }
        } else if (hasBillPlan(subBillers)) {
            return BillerBehaviourCategory.BBC_1.name();
        } else if (biller.getCustomAmountEnabled()) {
            return BillerBehaviourCategory.BBC_2.name();
        } else {
            return BillerBehaviourCategory.BBC_7.name();
        }
    }

    private static boolean isParentBiller(List<BillerDO> billers) {
        return billers.size() > 1;
    }

    private static boolean isBillTypeContainsBarcode(BillerDO biller) {
        return biller.getBillType().contains(WPSConstants.Biller.BILL_TYPE_BARCODE);
    }

    private static boolean isBillTypeGiftCard(BillerDO biller) {
        return biller.getBillType().equals(WPSConstants.Biller.BILL_TYPE_GIFT_CARD);
    }

    private static boolean hasMultipleBillPlans(List<BillerDO> billers) {
        if (CollectionUtils.isNotEmpty(billers)) {
            for (BillerDO biller : billers) {
                if (CollectionUtils.isNotEmpty(biller.getBillPlans()) && biller.getBillPlans().size() > 1) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean hasBillPlan(List<BillerDO> billers) {
        if (CollectionUtils.isNotEmpty(billers)) {
            for (BillerDO biller : billers) {
                if (CollectionUtils.isNotEmpty(biller.getBillPlans())
                        || StringUtils.isNotEmpty(biller.getAvailableTopupAmount())) {
                    return true;
                }
            }
        }
        return false;
    }

    public static LocalDateTime computeMaxUpdatedTimestampForBillerData(BillerDO billerDO) {
        LocalDateTime maxUpdateTimestamp = billerDO.getUpdateDate() != null ? billerDO.getUpdateDate() :
                DateUtils.localDateTimeNowInUTC();

        //If biller has sub-billers, then timestamps across all sub-billers need to be considered
        List<BillerDO> billers = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(billerDO.getSubBillers())) {
            billers = billerDO.getSubBillers();
        } else {
            billers.add(billerDO);
        }

        for (BillerDO biller: billers) {
            if (biller.getUpdateDate() != null && biller.getUpdateDate().isAfter(maxUpdateTimestamp)) {
                maxUpdateTimestamp = biller.getUpdateDate();
            }
            if (CollectionUtils.isNotEmpty(biller.getBillPlans())) {
                maxUpdateTimestamp = computeMaxUpdateTimestampAcrossBillPlans(biller.getBillPlans(), maxUpdateTimestamp);
            }
        }
        return maxUpdateTimestamp;
    }

    private static LocalDateTime computeMaxUpdateTimestampAcrossBillPlans(List<BillPlanDO> billPlanDOS, LocalDateTime maxUpdateTimestamp) {
        for (BillPlanDO billPlanDO : billPlanDOS) {
            if (billPlanDO.getUpdateDate() != null && billPlanDO.getUpdateDate().isAfter(maxUpdateTimestamp)) {
                maxUpdateTimestamp = billPlanDO.getUpdateDate();
            }
            if (CollectionUtils.isNotEmpty(billPlanDO.getBillDetails())) {
                maxUpdateTimestamp = computeMaxUpdateTimestampAcrossBillDetails(billPlanDO.getBillDetails(), maxUpdateTimestamp);
            }
        }
        return maxUpdateTimestamp;
    }

    private static LocalDateTime computeMaxUpdateTimestampAcrossBillDetails(List<BillDetailDO> billDetails, LocalDateTime maxUpdateTimestamp) {
        LocalDateTime billDetailMaxTimestamp = billDetails.stream().filter(Objects::nonNull).map(BillDetailDO::getUpdateDate).filter(Objects::nonNull)
                .max(LocalDateTime::compareTo).orElse(maxUpdateTimestamp);
        return billDetailMaxTimestamp.isAfter(maxUpdateTimestamp) ? billDetailMaxTimestamp : maxUpdateTimestamp;
    }

    public static boolean isBillerHavingProducts(BillerDO billerDO) {
        return (CollectionUtils.isNotEmpty(billerDO.getSubBillers()) && billerDO.getSubBillerShownAsProduct());
    }

    public static boolean isBillerAProduct(BillerDO billerDO) {
        return (Objects.nonNull(billerDO.getParentBiller()) && billerDO.getParentBiller().getSubBillerShownAsProduct());
    }

    public static List<String> filterBillersFailedToCache(List<OperationFuture> billerDataFutureList,
                                                   CacheAction cacheAction, String cacheKeySuffix) {
        List<String> retryBillers = new ArrayList<>();
        log.info("Biller data cache {} wait started: {}", cacheAction.name(), new Date());
        billerDataFutureList.forEach(billerDataFuture -> {
            if (!billerDataFuture.getStatus().isSuccess()) {
                if (cacheAction == CacheAction.EVICT && billerDataFuture.getStatus().getStatusCode() == StatusCode.ERR_NOT_FOUND) {
                    log.warn("Cache evict ignored for biller details as key - {} was not present", billerDataFuture.getKey());
                } else {
                    log.error("Cache {} failed for biller details: key - {} with message - {}",
                            cacheAction.name(), billerDataFuture.getKey(), billerDataFuture.getStatus().getMessage());
                    String cacheKey = billerDataFuture.getKey();
                    retryBillers.add(cacheKey.substring(0, cacheKey.indexOf(cacheKeySuffix)));
                }
            } else {
                log.info("Cache {} succeeded for biller details:: key - {}", cacheAction.name(), billerDataFuture.getKey());
            }
        });
        log.info("Biller data cache {} wait ended: {}", cacheAction.name(), new Date());
        return retryBillers;
    }

    public static NotificationPayload<NotificationDetails> getNotificationPayloadForPayBillFailurePushNotification(BillPayTransaction billPayTransaction, String categoryImageUrl, Integer expiryTime) {
        Biller biller = billPayTransaction.getCustomerBillAccount().getBiller();

        String title = WPSConstants.Notification.BILL_PAY_FAILURE_TITLE;
        String message = WPSConstants.Notification.BILL_PAY_FAILURE_TEXT_START
                + billPayTransaction.getAmountRequested().getValue().setScale(2, BigDecimal.ROUND_HALF_UP)
                + WPSConstants.Notification.FOR
                + biller.getDisplayName()
                + WPSConstants.Notification.BILL_PAY_FAILURE_TEXT_END;

        NotificationDetails notificationDetails = new NotificationDetails();
        notificationDetails.setDeeplinkUrl(NotificationUtil.getDeepLink(WPSConstants.Notification.SHOW_TRANSACTION, billPayTransaction.getTransactionId().toString()));

        NOCMetaDataDetails nocMetaDataDetails = NOCMetaDataDetails.builder()
                .category(NOCMetaDataCategory.GENERIC_FAILURE)
                .status(NOCMetaDataStatus.WARNING)
                .actionStatus(NOCMetaDataActionStatus.PENDING)
                .categoryImageUrl(categoryImageUrl)
                .isActionable(true)
                .expiryBy(billPayTransaction.getCreateDate()
                        .plusHours(expiryTime)
                        .atZone(ZoneId.systemDefault()).toEpochSecond() * 1000)
                .build();

        PushNotificationEventDTO<NotificationDetails> eventDTO = PushNotificationEventDTO.builder()
                .event(MessagingEvent.PAY_BILL_FAILURE)
                .typeMessage(TypeMessage.TEXT)
                .customerId(billPayTransaction.getCustomer().getCustomerAccountId().toString())
                .title(title)
                .message(message)
                .deeplinkUrl(notificationDetails.getDeeplinkUrl())
                .nocMetadata(nocMetaDataDetails)
                .customData(notificationDetails)
                .action(WPSConstants.Notification.SHOW_TRANSACTION)
                .build();

        return NotificationPayload.builder()
                .pushEventType(WalletEventType.PAY_BILL_FAIL)
                .pushNotiEventDTO(eventDTO)
                .build();
    }

    public static NotificationPayload<NotificationDetails> getNotificationPayloadForPayBillSuccessPushNotification(BillPayTransaction billPayTransaction, Integer expiryTime) {
        Biller biller = billPayTransaction.getCustomerBillAccount().getBiller();
        Customer customer = billPayTransaction.getCustomer();
        BigDecimal amountFulfilled = billPayTransaction.getAmountFulfilled().getValue();

        String title = WPSConstants.Notification.CASHI_BALANCE_MESSAGE_START_V2 + biller.getDisplayName() + WPSConstants.Notification.CASHI_BALANCE_MESSAGE_END_V2;
        String message = WPSConstants.Notification.AMOUNT_PAID_SUCCESSFULLY
                + amountFulfilled.setScale(2, RoundingMode.HALF_UP) + WPSConstants.Notification.AMOUNT_PAID_SUCCESSFULLY_END;

        NotificationDetails notificationDetails = new NotificationDetails();
        notificationDetails.setDeeplinkUrl(NotificationUtil.getDeepLink(WPSConstants.Notification.SHOW_TRANSACTION, billPayTransaction.getTransactionId().toString()));
        NOCMetaDataDetails nocMetaDataDetails = NOCMetaDataDetails.builder()
                .category(NOCMetaDataCategory.GENERIC_SUCCESS)
                .status(NOCMetaDataStatus.SUCCESS)
                .expiryBy((LocalDateTime.now()
                        .plusHours(expiryTime)
                        .atZone(ZoneId.systemDefault()).toEpochSecond()) * 1000)
                .actionStatus(NOCMetaDataActionStatus.PENDING)
                .isActionable(Boolean.TRUE)
                .build();

        PushNotificationEventDTO<NotificationDetails> eventDTO = PushNotificationEventDTO.builder()
                .event(MessagingEvent.PAY_BILL_SUCCESS)
                .typeMessage(TypeMessage.TEXT)
                .customerId(customer.getCustomerAccountId().toString())
                .title(title)
                .message(message)
                .deeplinkUrl(notificationDetails.getDeeplinkUrl())
                .customData(notificationDetails)
                .nocMetadata(nocMetaDataDetails)
                .action(WPSConstants.Notification.SHOW_TRANSACTION)
                .build();

        return NotificationPayload.builder()
                .pushEventType(WalletEventType.PAY_BILL)
                .pushNotiEventDTO(eventDTO)
                .build();
    }

    public static NotificationPayload getNotificationPayloadForGiftCardAccountLockedPushNotification(String customerAccountId) {
        NOCMetaDataDetails nocMetaDataDetails = NotificationUtil.getNOCMetaData(MessagingEvent.ACCOUNT_LOCKED,
                WPSConstants.Notification.ACTION_CALL_HELP, null, null);
        PushNotificationEventDTO eventDTO = PushNotificationEventDTO.builder()
                .event(MessagingEvent.ACCOUNT_LOCKED)
                .customerId(customerAccountId)
                .typeMessage(TypeMessage.TEXT)
                .action(WPSConstants.Notification.ACTION_CALL_HELP)
                .nocMetadata(nocMetaDataDetails)
                .message(WPSConstants.Notification.ACCOUNT_LOCKED_MESSAGE)
                .title(WPSConstants.Notification.ACCOUNT_LOCKED_TITLE)
                .build();
        return NotificationPayload.builder()
                .pushEventType(WalletEventType.ACCOUNT_LOCKED)
                .pushNotiEventDTO(eventDTO)
                .build();
    }

    public static NotificationPayload getNotificationPayloadForPayBillSuccessEmailNotification(BillPayTransaction billPayTransaction, String payBillSuccessEvent) {
        Customer customer = billPayTransaction.getCustomer();
        CustomerBillAccount customerBillAccount = billPayTransaction.getCustomerBillAccount();
        Biller biller = billPayTransaction.getCustomerBillAccount().getBiller();
        SmartCommV2PaymentConfirmDTO paymentConfirmDTO = new SmartCommV2PaymentConfirmDTO(customer.getFirstName(), payBillSuccessEvent, customer.getEmailId());
        BigDecimal primaryGiftCardAmount = null;

        List<GiftCardTransaction> giftCardPaymentTransactions = billPayTransaction.getGiftCardPaymentTransactionList();
        List<CardPaymentTransaction> cardPaymentTransactionList = null;
        if (Objects.nonNull(billPayTransaction.getInternalCoFTopupTransaction())) {
            cardPaymentTransactionList = billPayTransaction.getInternalCoFTopupTransaction().getCardPaymentTransactionList();
        }

        if (org.apache.commons.collections.CollectionUtils.isNotEmpty(giftCardPaymentTransactions)) {
            for (GiftCardTransaction giftCardPaymentTransaction : giftCardPaymentTransactions) {
                if (PaymentInstrumentSubType.CORP_CARD.equals(giftCardPaymentTransaction.getGiftCardPaymentInstrument().getPaymentInstrumentSubType())) {
                    paymentConfirmDTO.setIsCorpGiftCardTxn(true);
                    paymentConfirmDTO.setPaymentMethod2("B2B");
                    GiftCardPaymentInstrument.Company companyDO = giftCardPaymentTransaction.getGiftCardPaymentInstrument().getCompany();
                    if (companyDO != null) {
                        paymentConfirmDTO.setB2bCompanyImageLink(companyDO.getCompanyLogo());
                        paymentConfirmDTO.setB2bCompanyName(companyDO.getCompanyName());
                    }
                    else {
                        paymentConfirmDTO.setB2bCompanyImageLink("");
                        paymentConfirmDTO.setB2bCompanyName("");
                    }
                    paymentConfirmDTO.setPaymentMethod2Amount(giftCardPaymentTransaction.getAmount().getValue().toString());
                } else {
                    paymentConfirmDTO.setPaymentMethod1("CASHI");
                    primaryGiftCardAmount = giftCardPaymentTransaction.getAmount().getValue();
                    paymentConfirmDTO.setPaymentMethod1Amount(primaryGiftCardAmount.toString());
                }
            }
        }

        if (org.apache.commons.collections.CollectionUtils.isNotEmpty(cardPaymentTransactionList)) {
            List<PaymentInstrumentSubType> cardPaymentInstrumentSubTypes = Arrays.asList(PaymentInstrumentSubType.CREDIT_CARD, PaymentInstrumentSubType.DEBIT_CARD, PaymentInstrumentSubType.PREPAID);
            for (CardPaymentTransaction cardPaymentTransaction : cardPaymentTransactionList) {
                if (cardPaymentInstrumentSubTypes.contains(cardPaymentTransaction.getCardPaymentInstrument().getPaymentInstrumentSubType())) {
                    paymentConfirmDTO.setPaymentMethod3("CARD");
                    paymentConfirmDTO.setIsCardTxn(true);
                    paymentConfirmDTO.setPaymentMethod3Amount(cardPaymentTransaction.getAmount().getValue().toString());
                    if (Objects.nonNull(primaryGiftCardAmount)) {
                        BigDecimal updatedPrimaryGiftCardAmount = primaryGiftCardAmount.subtract(cardPaymentTransaction.getAmount().getValue());
                        paymentConfirmDTO.setPaymentMethod1Amount(updatedPrimaryGiftCardAmount.toString());
                    }

                    //get card image details
                    CardPaymentInstrument cardPaymentInstrument = cardPaymentTransaction.getCardPaymentInstrument();
                    if (Objects.nonNull(cardPaymentInstrument)) {
                        CardPaymentInstrument.BinDetails binDetails = cardPaymentInstrument.getBinDetails();
                        if (Objects.nonNull(binDetails)) {
                            paymentConfirmDTO.setCardImageLink(binDetails.getBrandLogo());
                            paymentConfirmDTO.setBankName(binDetails.getBankName());
                        } else {
                            paymentConfirmDTO.setCardImageLink("");
                            paymentConfirmDTO.setBankName("");
                        }
                    }
                    break;
                }
            }
        }

        paymentConfirmDTO.setAmount(billPayTransaction.getAmountFulfilled().getValue());
        paymentConfirmDTO.setBillerName(biller.getDisplayName());
        paymentConfirmDTO.setPaidDate(customerBillAccount.getLastPaidDateValue());
        if (Objects.nonNull(biller.getCommission())) {
            paymentConfirmDTO.setCommissionValue(new BigDecimal(biller.getCommission()));
        } else {
            paymentConfirmDTO.setCommissionValue(BigDecimal.ZERO);
        }

        if (Objects.nonNull(customerBillAccount.getAlias())) {
            paymentConfirmDTO.setBillerAliasId(customerBillAccount.getAlias());
        } else {
            paymentConfirmDTO.setBillerAliasId("");
        }
        if (Objects.nonNull(customerBillAccount.getAccountNumber())) {
            paymentConfirmDTO.setContractNo(customerBillAccount.getAccountNumber());
        } else {
            paymentConfirmDTO.setContractNo("");
        }

        if (Objects.nonNull(billPayTransaction.getCashiOrderId())) {
            paymentConfirmDTO.setTransactionId(billPayTransaction.getCashiOrderId());
        } else {
            paymentConfirmDTO.setTransactionId("");
        }
        return NotificationPayload.builder()
                .emailEventType(WalletEventType.PAYMENT_CONFIRM)
                .smartCommV2EventDTO(paymentConfirmDTO)
                .build();
    }

    public static BillPayTransactionDO createBillPayTransactionDOInValidationFailureState(BillPayTxnRequestDomainContext billPayTxnRequestDomainContext) {
        BillPayTransaction billPayTransaction = billPayTxnRequestDomainContext.getTransaction();
        DeviceInformation deviceInformation = billPayTxnRequestDomainContext.getDeviceInfo();

        log.info("Creating BillPayTransaction in DB with processorBillerId:[{}], accountNumber:[{}] and customerAccountId[{}]",
                billPayTransaction.getCustomerBillAccount().getProcessorBillerId(),
                billPayTransaction.getCustomerBillAccount().getAccountNumber(),
                billPayTransaction.getCustomer().getCustomerAccountId());
        BillPayTransactionDO billPayTransactionDO = new BillPayTransactionDO();
        billPayTransactionDO.setBillerDO(billPayTxnRequestDomainContext.getBillerDO());
        billPayTransactionDO.setAccountNumber(billPayTransaction.getCustomerBillAccount().getAccountNumber());
        billPayTransactionDO.setAmount(billPayTransaction.getAmountRequested().getValue());
        billPayTransactionDO.setCurrencyUnit(com.walmart.international.wallet.payment.data.constant.enums.CurrencyUnit.valueOf(billPayTransaction.getAmountRequested().getCurrencyUnit().name()));
        billPayTransactionDO.setClientReqId(billPayTxnRequestDomainContext.getClientRequestId());
        billPayTransactionDO.setCustomerAccountId(billPayTransaction.getCustomer().getCustomerAccountId());
        billPayTransactionDO.setState(TransactionStateEnum.FAILURE);
        billPayTransactionDO.setStateReason(BillPayTxnStateReason.VALIDATION_FAILED);
        billPayTransactionDO.setDeviceIpAddress(deviceInformation.getIp());
        billPayTransactionDO.setDeviceId(deviceInformation.getFingerPrint());
        billPayTransactionDO.setBillDetailDO(billPayTxnRequestDomainContext.getBillDetailDO());
        return billPayTransactionDO;
    }

    public static UUID getBillerIdLinkedToCategoryForBiller(Biller biller) {
        if (Objects.isNull(biller)) {
            return null;
        }
        UUID categoryBillerID = getBillerIdLinkedToCategoryForBiller(biller.getParentBiller());
        if (categoryBillerID == null) {
            return biller.getBillerId();
        }
        return categoryBillerID;
    }

}
