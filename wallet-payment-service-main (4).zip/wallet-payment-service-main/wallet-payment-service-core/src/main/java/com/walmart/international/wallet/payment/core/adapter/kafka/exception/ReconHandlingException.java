package com.walmart.international.wallet.payment.core.adapter.kafka.exception;

import com.walmart.international.digiwallet.service.basic.ng.exception.ProcessingException;

public class ReconHandlingException extends ProcessingException {
    public ReconHandlingException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }

    public ReconHandlingException(String errorCode) {
        super(errorCode);
    }
}
