package com.walmart.international.wallet.payment.core.service;

import lombok.extern.slf4j.Slf4j;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.SessionHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
@Slf4j
public class JPASessionManagementService {

    @Autowired
    private SessionFactory sessionFactory;

    private final ConcurrentMap<String, Session> sessions = new ConcurrentHashMap<>();

    public void openSession(String id) {
        if (noSessionBoundToThread()) {
            Session session = getOrCreateSession(id);
            sessions.putIfAbsent(id, session);
            bindToThread(session);
        }
    }

    Session getOrCreateSession(String id) {
        Session session = sessions.get(id);
        if (session == null) {
            session = sessionFactory.openSession();
            session.setHibernateFlushMode(FlushMode.MANUAL);
        }
        return session;
    }

    void bindToThread(Session session) {
        TransactionSynchronizationManager.bindResource(sessionFactory, new SessionHolder(session));
    }

    boolean noSessionBoundToThread() {
        return !TransactionSynchronizationManager.hasResource(sessionFactory);
    }

    public void unbindSession() {
        TransactionSynchronizationManager.unbindResource(sessionFactory);
    }

    public void closeSession(String id) {
        Session session = sessions.remove(id);
        try {
            unbindSession();
        } catch (Exception ex) {
            log.error("FATAL. EXCEPTION OCCURRED IN UNBINDING SESSION WITH ID: [{}}", id, ex);
        } finally {
            session.close();
        }
    }
}
