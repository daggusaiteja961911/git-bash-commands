package com.walmart.international.wallet.payment.core.mapper;

import com.walmart.international.services.payment.core.domain.Address;
import com.walmart.international.services.payment.core.domain.BillingAddress;
import com.walmart.international.services.payment.core.domain.CardPayment;
import com.walmart.international.services.payment.core.domain.Customer;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentInstrument;
import com.walmart.international.wallet.payment.core.domain.model.CardPaymentTransaction;
import com.walmart.international.wallet.payment.core.domain.model.CoFTopUpTransaction;
import com.walmart.international.wallet.payment.data.dao.entity.CoFTopupTransactionDO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

@Mapper(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface CoFTopupMapper {

    CoFTopupMapper INSTANCE = Mappers.getMapper(CoFTopupMapper.class);

    @Mapping(target = "address", source = "billingAddress")
    @Mapping(target = "phone", source = "customer.phoneNumber")
    BillingAddress mapBillingAddressFromContextToPayRequest(CardPaymentInstrument.BillingAddress billingAddress, Customer customer);

    @Mapping(target = "exteriorNum", source = "streetExtNum")
    @Mapping(target = "interiorNum", source = "streetIntNum")
    @Mapping(target = "street1", source = "street")
    @Mapping(target = "postcode", source = "postalCode")
    Address mapAddressFromContext(CardPaymentInstrument.BillingAddress billingAddress);

    @Mapping(target = "pan", source = "panToken")
    @Mapping(target = "cvv", source = "cvvToken")
    CardPayment.CardTokenInformation mapCardTokenInfoFromContextToPayRequest(CardPaymentTransaction.CardTokenInformation cardTokenInformation);

    @Mapping(target = "transactionId", source = "coFTopupTransactionId")
    @Mapping(target = "transactionReferenceId", source = "txnReferenceId")
    @Mapping(target = "amountRequested", ignore = true)
    void updateCoFTopupTransactionFromCoFTopupTransactionDO(CoFTopupTransactionDO coFTopupTransactionDO, @MappingTarget CoFTopUpTransaction coFTopUpTransaction);

}
