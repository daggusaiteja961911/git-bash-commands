package com.walmart.international.wallet.payment.core.executor;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.walmart.international.ewallet.services.events.executor.ScalingThreadPoolExecutor;

import java.util.concurrent.TimeUnit;

public class LastUsedCardThreadPoolExecutor extends ScalingThreadPoolExecutor {

    public LastUsedCardThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, ScalingThreadPoolExecutorQueue workQueue) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, new ThreadFactoryBuilder().setNameFormat("last-used-card-thread-pool").build());
    }
}